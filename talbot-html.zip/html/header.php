<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="assets/images/favicon.png" type="image/x-icon">
    <title>Talbot Automatic Doors & Gates</title> <?php wp_head(); ?>
  </head>
  <body>
    <!-- Header -->
    <header>
      <a class="togglebtn">
        <span></span>
      </a>
      <div class="overlay"></div>
					
					<div class="preheader-top">
							<div class="container">
									<ul class="hd-call">
                <li>
                  <div class="hd-callwr">
                    <div class="hcall-icon">
                      <img src="assets/images/icon/phone-b.svg" alt="phone icon" title="" width="14" height="14">
                    </div>
                    <div class="hcall-info">VIC: <a href="tel:0422936188">0422 936 188</a>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="hd-callwr">
                    <div class="hcall-icon">
                      <img src="assets/images/icon/phone-b.svg" alt="phone icon" title="" width="14" height="14">
                    </div>
                    <div class="hcall-info">NSW: <a href="tel:1300560608">1300 560 608</a>
                    </div>
                  </div>
                </li>
                
              </ul>
						 </div>
					</div>
					
      <div class="header-top">
        <div class="container">
          <div class="header-top-wr">
            <div class="logo">
              <a href="home.php">
                <img src="assets/images/talbot-logo-image.svg" alt="talbot-logo-image" title="" width="198" height="52" class="talbot-logo">
                <img src="assets/images/	talbot-black-logo-image.svg" alt="talbot-logo-image" title="" width="198" height="52" class="talbot-logo-black">
              </a>
            </div>
            <!-- Navigation -->
            <div class="menu-link">
              <nav>
                <ul>
                  <li>
                    <a href="home.php">Home</a>
                  </li>
                  <li class="has-sub productmenu megamenu">
                    <a href="product.php"> Products</a>
                    <div class="sub-menu dropmenu">
                      <div class="megamenu-wrap">
                        <ul class="sublink">
                          <li class="sub-dropmenu  menu-item-hover arealv2 level">
                            <a href="product.php">Automatic Doors</a>
                            <ul class="sub-menu menu-level menu-level2">
                              <li class="sub-dropmenu menu-item-hover arealv3 level">
                                <a href="product.php">Sliding Doors</a>
                                <ul class="sub-menu menu-level menu-level3">
																																
                                  <li><a href="#">Sliding ASW200 1</a></li>
																																	 <li><a href="#">Sliding ASW200 2</a></li>
																																	 <li><a href="#">Sliding ASW200 3</a></li>
                                  <li><a href="#">ASW100</a></li><li><a href="#">ASW93</a></li>

                                </ul>
                              </li>
                              <li class="sub-dropmenu arealv3 level">
                                <a href="#">Swing Doors</a>
                                <ul class="sub-menu menu-level menu-level3">
																																	<li><a href="product-detail.php">Swing ASL200 1</a></li>
																																	 <li><a href="product-detail.php">Swing ASL200 2</a></li>
																																	 <li><a href="product-detail.php">Swing ASL200 3</a></li>
                                  <li><a href="#">ASL250</a></li><li><a href="#">ASL100 Telescopic</a></li><li><a href="#">ASL1600</a></li><li><a href="#">Mag-Lev</a></li>
																																</ul>
                              </li>
                              <li class="sub-dropmenu arealv3 level">
                                <a href="#">Revolving Door</a>
                                <ul class="sub-menu menu-level menu-level3">
                                  <li><a href="#">ASL1600</a></li><li><a href="#">Mag-Lev</a></li>
																																</ul>
                              </li>
                              <li class="sub-dropmenu arealv3 level">
                                <a href="#">Accessible Door Solutions</a>
                                <ul class="sub-menu menu-level menu-level3">
																																	 <li><a href="product-detail.php">Accessible ASL200</a></li>
																																	 <li><a href="product-detail.php">Accessible ASL200 1</a></li>
																																	 <li><a href="product-detail.php">Accessible ASL200 2</a></li>
                                  <li><a href="#">ASL250</a></li><li><a href="#">ASL100 Telescopic</a></li><li><a href="#">ASL1600</a></li><li><a href="#">Mag-Lev</a></li>
																																</ul>
                              </li>
                            </ul>
                          </li>
                          <li class="sub-dropmenu arealv2 level">
                            <a href="product.php">Automatic Gates</a>
                            <ul class="sub-menu menu-level menu-level2">
                              <li class="sub-dropmenu arealv3 level">
                                <a href="product.php">Bi-fold Gated</a>
                                <ul class="sub-menu menu-level menu-level3">
																																	 <li><a href="product-detail.php">Bi-fold Gated 1</a></li>
																																	<li><a href="product-detail.php">Bi-fold Gated 2</a></li>
																																	<li><a href="product-detail.php">Bi-fold Gated 3</a></li>
																																	 
																																	 
<!--
                                  <li>
                                    <a href="product-detail.php">ASL200 </a>
                                  </li>
                                  <li>
                                    <a href="#">ASL250 </a>
                                  </li>
                                  <li>
                                    <a href="#">ASL100 </a>
                                  </li>
                                  <li>
                                    <a href="#">ASL1600 </a>
                                  </li>
                                  <li>
                                    <a href="#">Mag-Lev </a>
                                  </li>
-->
                                </ul>
                              </li>
                              <li class="sub-dropmenu">
                                <a href="#">Telescopic Gates</a>
                              </li>
                              <li class="sub-dropmenu">
                                <a href="#">Boom Gates</a>
                              </li>
                              <li class="sub-dropmenu">
                                <a href="#">Curved Gates</a>
                              </li>
                              <li class="sub-dropmenu">
                                <a href="#">Sliding Garage Dooors</a>
                              </li>
                            </ul>
                          </li>
                          <li class="sub-dropmenu level custom">
                            <a href="#"> Custom Solutions </a>
                            <ul class="sub-menu menu-level menu-level2">
                              <li class="sub-dropmenu"> Custom-sized to precisely fit into doorways and portals industrial and commercial doors come in both automatic and swing varieties, allowing you to find the right type to suit your needs and requirements. </li>
                            </ul>
                          </li>
                          <li class="callaction-li">
                            <div class="callact-left"> Repair and service for Residential and Commercial </div>
                            <div class="callact-right">
                              <div class="btn-row">
                                <a href="tel:1300560608" class="button button-grey-border">
                                  <img src="assets/images/icon/phone-b.svg" alt="phone icon" title="" width="11" height="11">1300 560 608 </a>
                                <a href="#" class="button button-theme">Get a Free Quote</a>
                              </div>
                            </div>
                          </li>
                        </ul>
                        <div class="menu-img">
                          <img src="assets/images/menu-image.jpg" alt="menu-image" title="" width="450" height="400">
                        </div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <a href="services.php">Services</a>
                    <div class="sub-menu">
                      <ul class="sublink">
                        <li>
                          <a href="#">Our Team</a>
                        </li>
                        <li>
                          <a href="#">Why Choose Us</a>
                        </li>
                      </ul>
                    </div>
                  </li>
                  <li>
                    <a href="franchise-opportunity.php">Franchise Opportunities</a>
                  </li>
                  <li>
                    <a href="contact-us.php">Contact</a>
                  </li>
                  <li class="has-sub areamenu megamenu">
                    <a href="area-we-serve.php">Areas</a>
                    <div class="sub-menu dropmenu">
                      <ul class="sublink">
                        <li class="sub-dropmenu menu-item-hover level">
                          <a href="suburb.php">New South Wales</a>
<!--																										<div class="menu-text">Our great range of automatic gates gives New South Wales customers true choice. </div>-->
                          <ul class="sub-menu menu-level2">
                            <li class="menutagline">New South Wales</li>
                            <li>
                              <a href="">Balmain</a>
                            </li>
                            <li>
                              <a href="">Bankstown</a>
                            </li>
                            <li>
                              <a href="">Blacktown</a>
                            </li>
                            <li>
                              <a href="">Bondi</a>
                            </li>
                            <li>
                              <a href="">Campbelltown</a>
                            </li>
                            <li>
                              <a href="">Eastern Creek</a>
                            </li>
                            <li>
                              <a href="">Glebe</a>
                            </li>
                            <li>
                              <a href="">Lugarno</a>
                            </li>
                            <li>
                              <a href="">Liverpool</a>
                            </li>
                            <li>
                              <a href="">Mascot</a>
                            </li>
                            <li>
                              <a href="">Erskine Park</a>
                            </li>
                            <li>
                              <a href="">Mosman</a>
                            </li>
                            <li>
                              <a href="">Newtown</a>
                            </li>
                            <li>
                              <a href="">North Sydney</a>
                            </li>
                            <li>
                              <a href="">Penrith</a>
                            </li>
                            <li>
                              <a href="">Randwick</a>
                            </li>
                            <li>
                              <a href="">Rose Bay</a>
                            </li>
                            <li>
                              <a href="">Ryde</a>
                            </li>
                            <li>
                              <a href="">South Hurstville</a>
                            </li>
                            <li>
                              <a href="">Sutherland</a>
                            </li>
                            <li>
                              <a href="">Western Sydney</a>
                            </li>
                            <li>
                              <a href="">Wetherill Park</a>
                            </li>
                            <li>
                              <a href="">Alexandria</a>
                            </li>
                            <li>
                              <a href="">Belmore</a>
                            </li>
                            <li>
                              <a href="">Cammeray</a>
                            </li>
                            <li>
                              <a href="">Camperdown</a>
                            </li>
                            <li>
                              <a href="">Canterbury</a>
                            </li>
                            <li>
                              <a href="">Chippendale</a>
                            </li>
                            <li>
                              <a href="">Coogee</a>
                            </li>
                            <li>
                              <a href="">Crows Nest</a>
                            </li>
                            <li>
                              <a href="">Earlwood</a>
                            </li>
                            <li>
                              <a href="">Greenacre</a>
                            </li>
                            <li>
                              <a href="">Haymarket</a>
                            </li>
                            <li>
                              <a href="">Kingsford</a>
                            </li>
                            <li>
                              <a href="">Lakemba</a>
                            </li>
                            <li>
                              <a href="">Maroubra</a>
                            </li>
                            <li>
                              <a href="">Marsfield</a>
                            </li>
                            <li>
                              <a href="">Punchbowl</a>
                            </li>
                            <li>
                              <a href="">Regents Park</a>
                            </li>
                            <li>
                              <a href="">Rosebery</a>
                            </li>
                            <li>
                              <a href="">Roselands</a>
                            </li>
                            <li>
                              <a href="">Sefton</a>
                            </li>
                            <li>
                              <a href="">Surry Hills</a>
                            </li>
                            <li>
                              <a href="">Ultimo</a>
                            </li>
                            <li>
                              <a href="">Waterloo</a>
                            </li>
                            <li>
                              <a href="">Zetland</a>
                            </li>
                            <li>
                              <a href="">Baulkham Hills</a>
                            </li>
                            <li>
                              <a href="">Castle Hill</a>
                            </li>
                            <li>
                              <a href="">Chatswood</a>
                            </li>
                            <li>
                              <a href="">Kellyville</a>
                            </li>
                            <li>
                              <a href="">Macquarie Park</a>
                            </li>
                            <li>
                              <a href="">Norwest</a>
                            </li>
                            <li>
                              <a href="h">Pennant Hills</a>
                            </li>
                            <li>
                              <a href="">Avoca Beach</a>
                            </li>
                            <li>
                              <a href="">Bateau Bay</a>
                            </li>
                            <li>
                              <a href="">Belmont</a>
                            </li>
                            <li>
                              <a href="">Cardiff</a>
                            </li>
                            <li>
                              <a href="">Central Coast</a>
                            </li>
                            <li>
                              <a href="">Cessnock</a>
                            </li>
                            <li>
                              <a href="">Erina</a>
                            </li>
                            <li>
                              <a href="">Gosford</a>
                            </li>
                            <li>
                              <a href="">Kincumber</a>
                            </li>
                            <li>
                              <a href="">Lake Macquarie</a>
                            </li>
                            <li>
                              <a href="">Lower Hunter</a>
                            </li>
                            <li>
                              <a href="">Maitland</a>
                            </li>
                            <li>
                              <a href="h">Morisset</a>
                            </li>
                            <li>
                              <a href="">Nelson Bay</a>
                            </li>
                            <li>
                              <a href="">Newcastle</a>
                            </li>
                            <li>
                              <a href="">Summerland Point</a>
                            </li>
                            <li>
                              <a href="">Terrigal</a>
                            </li>
                            <li>
                              <a href="">The Entrance</a>
                            </li>
                            <li>
                              <a href="">Toronto</a>
                            </li>
                            <li>
                              <a href="">Umina Beach</a>
                            </li>
                            <li>
                              <a href="">Warners Bay</a>
                            </li>
                            <li>
                              <a href="">Woy Woy</a>
                            </li>
                            <li>
                              <a href="">Annandale</a>
                            </li>
                            <li>
                              <a href="">Ashfield</a>
                            </li>
                            <li>
                              <a href="">Belrose</a>
                            </li>
                            <li>
                              <a href="">Birchgrove</a>
                            </li>
                            <li>
                              <a href="">Brookvale</a>
                            </li>
                            <li>
                              <a href="">Cleveland</a>
                            </li>
                            <li>
                              <a href="">Cromer</a>
                            </li>
                            <li>
                              <a href="">Dee Why</a>
                            </li>
                            <li>
                              <a href="">Dobroyd Point</a>
                            </li>
                            <li>
                              <a href="">Dulwich Hill</a>
                            </li>
                            <li>
                              <a href="">Enmore</a>
                            </li>
                            <li>
                              <a href="">Forestville</a>
                            </li>
                            <li>
                              <a href="">Frenchs Forest</a>
                            </li>
                            <li>
                              <a href="">Haberfield</a>
                            </li>
                            <li>
                              <a href="">Leichhardt</a>
                            </li>
                            <li>
                              <a href="">Lewisham</a>
                            </li>
                            <li>
                              <a href="">Lilyfield</a>
                            </li>
                            <li>
                              <a href="">Manly</a>
                            </li>
                            <li>
                              <a href="">Marrickville</a>
                            </li>
                            <li>
                              <a href="">Mona Vale</a>
                            </li>
                            <li>
                              <a href="">Newport</a>
                            </li>
                            <li>
                              <a href="#">Northern Beaches</a>
                            </li>
                            <li>
                              <a href="#">Rozelle</a>
                            </li>
                            <li>
                              <a href="#">Stanmore</a>
                            </li>
                            <li>
                              <a href="#">Summerhill</a>
                            </li>
                            <li>
                              <a href="#">Warriewood</a>
                            </li>
                            <li>
                              <a href="#">Wollongong</a>
                            </li>
                          </ul>
                        </li>
                        <li class="sub-dropmenu level">
                          <a href="#">Queensland</a>
<!--																									 <div class="menu-text">Our great range of automatic gates gives Queensland customers true choice. </div>-->
                          <ul class="sub-menu menu-level2">
                            <li class="menutagline">Queensland</li>
                            <li>
                              <a href="">Balmain</a>
                            </li>
                            <li>
                              <a href="">Bankstown</a>
                            </li>
                            <li>
                              <a href="">Blacktown</a>
                            </li>
                            <li>
                              <a href="">Bondi</a>
                            </li>
                            <li>
                              <a href="">Campbelltown</a>
                            </li>
                            <li>
                              <a href="">Eastern Creek</a>
                            </li>
                            <li>
                              <a href="">Glebe</a>
                            </li>
                            <li>
                              <a href="">Lugarno</a>
                            </li>
                            <li>
                              <a href="">Liverpool</a>
                            </li>
                            <li>
                              <a href="">Mascot</a>
                            </li>
                            <li>
                              <a href="">Erskine Park</a>
                            </li>
                            <li>
                              <a href="">Mosman</a>
                            </li>
                            <li>
                              <a href="">Newtown</a>
                            </li>
                            <li>
                              <a href="">North Sydney</a>
                            </li>
                            <li>
                              <a href="">Penrith</a>
                            </li>
                            <li>
                              <a href="">Randwick</a>
                            </li>
                            <li>
                              <a href="">Rose Bay</a>
                            </li>
                            <li>
                              <a href="">Ryde</a>
                            </li>
                            <li>
                              <a href="">South Hurstville</a>
                            </li>
                            <li>
                              <a href="">Sutherland</a>
                            </li>
                            <li>
                              <a href="">Western Sydney</a>
                            </li>
                            <li>
                              <a href="">Wetherill Park</a>
                            </li>
                            <li>
                              <a href="">Alexandria</a>
                            </li>
                            <li>
                              <a href="">Belmore</a>
                            </li>
                            <li>
                              <a href="">Cammeray</a>
                            </li>
                            <li>
                              <a href="">Camperdown</a>
                            </li>
                            <li>
                              <a href="">Canterbury</a>
                            </li>
                            <li>
                              <a href="">Chippendale</a>
                            </li>
                            <li>
                              <a href="">Coogee</a>
                            </li>
                            <li>
                              <a href="">Crows Nest</a>
                            </li>
                            <li>
                              <a href="">Earlwood</a>
                            </li>
                            <li>
                              <a href="">Greenacre</a>
                            </li>
                            <li>
                              <a href="">Haymarket</a>
                            </li>
                            <li>
                              <a href="">Kingsford</a>
                            </li>
                            <li>
                              <a href="">Lakemba</a>
                            </li>
                            <li>
                              <a href="">Maroubra</a>
                            </li>
                            <li>
                              <a href="">Marsfield</a>
                            </li>
                            <li>
                              <a href="">Punchbowl</a>
                            </li>
                            <li>
                              <a href="">Regents Park</a>
                            </li>
                            <li>
                              <a href="">Rosebery</a>
                            </li>
                            <li>
                              <a href="">Roselands</a>
                            </li>
                            <li>
                              <a href="">Sefton</a>
                            </li>
                            <li>
                              <a href="">Surry Hills</a>
                            </li>
                            <li>
                              <a href="">Ultimo</a>
                            </li>
                            <li>
                              <a href="">Waterloo</a>
                            </li>
                            <li>
                              <a href="">Zetland</a>
                            </li>
                            <li>
                              <a href="">Baulkham Hills</a>
                            </li>
                            <li>
                              <a href="">Castle Hill</a>
                            </li>
                            <li>
                              <a href="">Chatswood</a>
                            </li>
                            <li>
                              <a href="">Kellyville</a>
                            </li>
                            <li>
                              <a href="">Macquarie Park</a>
                            </li>
                            <li>
                              <a href="">Norwest</a>
                            </li>
                            <li>
                              <a href="h">Pennant Hills</a>
                            </li>
                            <li>
                              <a href="">Avoca Beach</a>
                            </li>
                            <li>
                              <a href="">Bateau Bay</a>
                            </li>
                            <li>
                              <a href="">Belmont</a>
                            </li>
                            <li>
                              <a href="">Cardiff</a>
                            </li>
                            <li>
                              <a href="">Central Coast</a>
                            </li>
                            <li>
                              <a href="">Cessnock</a>
                            </li>
                            <li>
                              <a href="">Erina</a>
                            </li>
                            <li>
                              <a href="">Gosford</a>
                            </li>
                            <li>
                              <a href="">Kincumber</a>
                            </li>
                            <li>
                              <a href="">Lake Macquarie</a>
                            </li>
                            <li>
                              <a href="">Lower Hunter</a>
                            </li>
                            <li>
                              <a href="">Maitland</a>
                            </li>
                            <li>
                              <a href="h">Morisset</a>
                            </li>
                            <li>
                              <a href="">Nelson Bay</a>
                            </li>
                            <li>
                              <a href="">Newcastle</a>
                            </li>
                            <li>
                              <a href="">Summerland Point</a>
                            </li>
                            <li>
                              <a href="">Terrigal</a>
                            </li>
                            <li>
                              <a href="">The Entrance</a>
                            </li>
                            <li>
                              <a href="">Toronto</a>
                            </li>
                            <li>
                              <a href="">Umina Beach</a>
                            </li>
                            <li>
                              <a href="">Warners Bay</a>
                            </li>
                            <li>
                              <a href="">Woy Woy</a>
                            </li>
                            <li>
                              <a href="">Annandale</a>
                            </li>
                            <li>
                              <a href="">Ashfield</a>
                            </li>
                            <li>
                              <a href="">Belrose</a>
                            </li>
                            <li>
                              <a href="">Birchgrove</a>
                            </li>
                            <li>
                              <a href="">Brookvale</a>
                            </li>
                            <li>
                              <a href="">Cleveland</a>
                            </li>
                            <li>
                              <a href="">Cromer</a>
                            </li>
                            <li>
                              <a href="">Dee Why</a>
                            </li>
                            <li>
                              <a href="">Dobroyd Point</a>
                            </li>
                            <li>
                              <a href="">Dulwich Hill</a>
                            </li>
                            <li>
                              <a href="">Enmore</a>
                            </li>
                            <li>
                              <a href="">Forestville</a>
                            </li>
                            <li>
                              <a href="">Frenchs Forest</a>
                            </li>
                            <li>
                              <a href="">Haberfield</a>
                            </li>
                            <li>
                              <a href="">Leichhardt</a>
                            </li>
                            <li>
                              <a href="">Lewisham</a>
                            </li>
                            <li>
                              <a href="">Lilyfield</a>
                            </li>
                            <li>
                              <a href="">Manly</a>
                            </li>
                            <li>
                              <a href="">Marrickville</a>
                            </li>
                            <li>
                              <a href="">Mona Vale</a>
                            </li>
                            <li>
                              <a href="">Newport</a>
                            </li>
                            <li>
                              <a href="#">Northern Beaches</a>
                            </li>
                            <li>
                              <a href="#">Rozelle</a>
                            </li>
                            <li>
                              <a href="#">Stanmore</a>
                            </li>
                            <li>
                              <a href="#">Summerhill</a>
                            </li>
                            <li>
                              <a href="#">Warriewood</a>
                            </li>
                            <li>
                              <a href="#">Wollongong</a>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </nav>
            </div>
            <div class="header-right">
              <ul class="hd-call">
                <li>
                  <div class="hd-callwr">
                    <div class="hcall-icon">
                      <img src="assets/images/icon/phone-b.svg" alt="phone icon" title="" width="14" height="14">
                    </div>
                    <div class="hcall-info">VIC: <a href="tel:0422936188">0422 936 188</a>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="hd-callwr">
                    <div class="hcall-icon">
                      <img src="assets/images/icon/phone-b.svg" alt="phone icon" title="" width="14" height="14">
                    </div>
                    <div class="hcall-info">NSW: <a href="tel:1300560608">1300 560 608</a>
                    </div>
                  </div>
                </li>
                
              </ul>
													 <ul class="hd-quote">
																<li>
                  <a class="button button-theme" href="#">Get a Free Quote</a>
                </li>
													 </ul>
            </div>
            <div class="search-icon">
              <div class="searchtop_icon">
                <img src="assets/images/icon/search.svg" alt="search-icon" title="search" width="25" height="25" class="searchicon">
															 <img src="assets/images/close-black.png" alt="search-icon" title="search" width="25" height="25" class="closeicon">
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- search -->
      <div class="search-container" id="searchdiv">
        <div class="search__content">
          <div class="aws-container" role="search">
            <form>
              <div class="aws-wrapper">
                <label class="aws-search-label" for="6560217297512">Search Products</label>
                <input type="search" name="s" id="6560217297512" value="" class="aws-search-field" placeholder="Search for items..." autocomplete="off">
                <div class="aws-search-clear">
                  <span>×</span>
                </div>
                <div class="aws-loader"></div>
              </div>
              <div class="aws-search-btn aws-form-btn">
                <span class="aws-search-btn_icon">
                  <svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24px">
                    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
                  </svg>
                </span>
              </div>
            </form>
          </div>
          <div class="btnsearch search-toggle closed">
            <div class="aws-search-btn aws-form-btn">
              <span class="aws-search-btn_icon button">
                <img src="assets/images/icon/close-icon.png" alt="close-search" class="close-search-icon" width="10" height="10">
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- Header -->