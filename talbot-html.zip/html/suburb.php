<?php require_once __DIR__ . '/includes/includes.php'; ?>

<?php get_header(); ?>

<main class="suburb-page woocommerce">
	
 <!-- Inner banner  -->
 <section class="inner-banner area-banner">
  <img src="assets/images/suburb-banner.jpg" alt="suburb banner image" title="" width="1920" height="650" class="bgimg">
  <div class="container">
   <div class="inbanner-content">
   
				 <div class="area-topbanner">
						
     	<div class="heading-40 text-center">Automatic Door Installation Western Sydney</div>
						<div class="btn-row">
								<a href="tel:1300560608" class="button button-white"><img src="assets/images/icon/phone-b.svg" alt="" title="" width="14" height="14">1300 560 608</a>
								<a href="#" class="button button-theme">Get a Free Quote</a>
					 </div>
						
						<ul class="whychs-ul-suburb">
							<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/integrity-icon.svg" alt="integrity-icon" title="" width="90" height="86">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">Integrity</div>
																					
																			 </div>
																 </div>
													 </li>
							<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/whs-icon.svg" alt="whs-icon" title="" width="90" height="86">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">WH&amp;S</div>
																					
																			 </div>
																 </div>
													 </li>
							<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/technical-competence-icon.svg" alt="technical-competence-icon" title="" width="90" height="86">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">Technical Competence</div>
																					
																			 </div>
																 </div>
													 </li>
							<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/systemization.svg" alt="systemization-icon" title="" width="90" height="86">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">Systemization</div>
																					
																			 </div>
																 </div>
													 </li>
							<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/emergency.svg" alt="emergency icon" title="" width="90" height="86">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">24/7 emergency</div>
																					
																			 </div>
																 </div>
													 </li>
						</ul>
						
				 </div>
				
					<ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
									<a href="#">Areas We Serve</a>
         <span class="breadcrumb_last" aria-current="page">Automatic Door Installation Western Sydney</span>
        </span>
       </span>
      </li>
     </ul>
				
  </div>
  </div>
 </section>
	
	<section class="top-space-curve">
		
	<section class="content-wrapper areaform mb-100">
    <div class="container">
      <div class="flex-container wrap  justify-content-between ctent-block-wr">
        <div class="ctent-block">
									 <p>For sliding gates / automatic door installation, Western Sydney’s leading local choice is Talbot Auto Doors. Providing installation & repairs services for residential and commercial properties, we’re committed to providing a quality, efficient and affordable service.</p>
										<p>With everything from swing pedestrian doors to automatic sliding, sectional shutters to bifold gates, we’re the comprehensive name in automatic door installation. Western Sydney residents, business owners or strata managers can call us on 1300 560 608 to organize an appointment with a member of our great team.</p>
									<p>Beyond our automatic door installation for Western Sydney, we operate across a wide service area including the suburbs of:</p>
									<p>With over 30 years in the business, we’re the experts in sliding door repairs & automatic door installation Western Sydney can trust – so call us today to book your appointment.</p>
									<div class="btn-row">
										<a href="#" class="button button-theme">Get a Free Quote</a>
										<a href="tel:1300560608" class="button button-grey-border"><img src="assets/images/icon/phone-b.svg" alt="" title="" width="14" height="14">1300 560 608</a>
									</div>
									
        </div>
        <div class="ctent-img enquire-wrap">
         <div class="enquiry-form">
														<div class="heading-30 text-white">Enquire Now</div>
													 <form>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Name">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="email" class="form-control" placeholder="Email Address">
															   </div>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Phone">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Postcode">
															   </div>
																	<div class="form-group">
																				<div class="inputFileHolder">
                <div class="fileinputs">
                  <span class="wpcf7-form-control-wrap" data-name="attch_file">
																			<input size="40" class="wpcf7-form-control wpcf7-text file txt_box_upload inputfile form-control" id="attachment" aria-invalid="false" value="" type="text" name="attch_file">
																	</span>
                  <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc,.jpg,.jpeg,.png,.gif" aria-invalid="false" type="file" name="attachment1">
                    <div class="fakefile">
                      <div class="fakebtn">
                        <img src="assets/images/icon/file-attachment.svg" alt="" title="" width="20" height="23">
                      </div>
                    </div>
                    <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input size="40" class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc" aria-invalid="false" type="file" name="resume">
                    </span>
                    <div class="fakefile">
                      <div class="fakebtn"><img src="assets/images/icon/file-attachment.svg" alt="" title="" width="21" height="24"></div>
                    </div>
                  </span>
                  <span class="filename">Upload Image</span>
                </div>
              </div>
																		  
																		  <label>File types Allowed: gif, png, jpg, jpeg | Max size: 5MB</label>
																		 
            					</div>
																		<div class="form-group">
															   		<textarea class="form-control" placeholder="Message"></textarea>
															   </div>
															   <div class="sub-btnblk">
																				<input type="submit" value="Submit">
															   </div>
													 </form>
											 </div>
        </div>
      </div>
    </div>
  </section>
	
 <!--- content -->
  <section class="content-wrapper tophome-bg">
    <div class="container">
      <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
        <div class="ctent-block">
									 <div class="label-title">Established in 1985</div>
          <div class="heading-50">Talbot Automatic Doors and Gates</div>
          <p>We even offer 24-hour emergency door repair service to commercial clients. Sydney residents, we know there’s never a convenient time to have automatic gate or door issues, and that’s why we’re available round-the-clock to provide advise and repairs on your automatic sliding doors and gates</p>	
									<a href="#" class="button button-border">Learn more<img src="assets/images/icon/arrow-right.svg" alt="arrow-right" title="" width="14" height="14"></a>
        </div>
        <div class="ctent-img">
          <img src="assets/images/talbot-auomatic-doors.jpg" alt="talbot-auomatic-doors" title="" width="670" height="424">
        </div>
      </div>
    </div>
  </section>
		 
	<!-- section since 1985 -->
  <div class="year-list-box mb-100">
    <ul class="js-year marquee">
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title crav-stroke">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title crav-stroke">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
    </ul>
  </div>
	
	<!-- section Our products -->
	<section class="sec-hm-product mb-100"> 
	 <div class="container">
				<div class="hmproduct-wrap">
						<div class="hmproduct-left">
								<div class="label-title">Our Products</div>
							 <div class="heading-50">Experts in Automatic Doors and Gates an Australian</div>
							<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text.</p>
							
							<div class="pr-link-ul">
								<div class="pr-link-li">
										<div class="pr-linkbox">
											<div class="pr-link-icon">
													<img src="assets/images/icon/door-icon.svg" alt="door-icon" title="" width="54" height="60">
											</div>
											<div class="pr-link-title">Automatic Doors</div>
											<img src="assets/images/icon/angle-right.svg" alt="angle-right" title="" width="24" height="24" class="angle-arrow">
										</div>
								</div>
								<div class="pr-link-li">
									<div class="pr-linkbox">
									 <div class="pr-link-icon"><img src="assets/images/icon/gate-icon.svg" alt="gate-icon" title="" width="54" height="60"></div>
									 <div class="pr-link-title">Automatic Gates </div>
									<img src="assets/images/icon/angle-right.svg" alt="angle-right" title="" width="24" height="24" class="angle-arrow">
									</div>
								</div>
								<div class="pr-link-li">
									<div class="pr-linkbox">
									 <div class="pr-link-icon"><img src="assets/images/icon/custom-icon.svg" alt=""custom-icon title="" width="54" height="60"></div>
									 <div class="pr-link-title">Custom Solutions</div>
									 <img src="assets/images/icon/angle-right.svg" alt="angle-right" title="" width="24" height="24" class="angle-arrow">
									</div>
								</div>
							</div>
							
					 </div>
					 <div class="hmproduct-right">
							 <div class="pr-link-content">
									<div class="pr-link-tab active">
										 <div class="pr-link-wrap">
												  <div class="prlink-img-wr">
																<img src="assets/images/automatic-door-product.jpg" alt="automatic door product" title="" width="670" height="700" class="pr-img">
															 <div class="prlink-box">
																		<div class="pr-toplink">
																			 <ul class="pr-link-ul">
																				  <li><a href="#">Sliding Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Swing Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Revolving Door<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Accessible Door Solutions<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																			 </ul>
																	 </div>
																	 <div class="pr-btmlink">
																				<a href="#">View all Products<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a>
																	 </div>
															 </div>
												  </div>
										 </div>		
									</div>
							  <div class="pr-link-tab">
										 <div class="pr-link-wrap">
												  <div class="prlink-img-wr">
																<img src="assets/images/automatic-door-product.jpg" alt="automatic door product" title="" width="670" height="700" class="pr-img">
															 <div class="prlink-box">
																		<div class="pr-toplink">
																			 <ul class="pr-link-ul">
																				  <li><a href="#">Bi-fold Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Telescopic Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Boom Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Curved Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					<li><a href="#">Sliding Garage Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																			 </ul>
																	 </div>
																	 <div class="pr-btmlink">
																				<a href="#">View all Products<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a>
																	 </div>
															 </div>
												  </div>
										 </div>
									</div>
									<div class="pr-link-tab">
										<div class="pr-link-wrap">
												  <div class="prlink-img-wr">
																<img src="assets/images/automatic-door-product.jpg" alt="automatic door product" title="" width="670" height="700" class="pr-img">
															 <div class="prlink-box">
																		<div class="pr-toplink">
																				<p>Custom-sized to precisely fit into doorways and portals industrial and commercial doors come in both automatic and swing varieties, allowing you to find the right type to suit your needs and requirements. </p>
																	 </div>
																	 <div class="pr-btmlink">
																				<a href="#">View More<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a>
																	 </div>
															 </div>
												  </div>
									</div>
							 </div>
					 </div>
			 </div>
		</div>
		</div>
	</section>
	
	<!-- why choose Talbot -->
<?php block('whychoose-block'); ?>
	
	<!-- Explore Our Services -->
<?php block('our-service'); ?>
	
	
	<!-- simple steps -->
	<section class="step-wrap">
		 <div class="container">
					<div class="step-wrap-block">
							<div class="step-left">
									<div class="label-title">The 5 Simple Steps of</div>
								 <div class="heading-50">How to book with us?</div>
										
								<div class="step-accordion">
           <div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/enquiry-icon.svg" alt="enquiry-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 01</div>
																			<div class="faq-title">Make an Enquiry</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>Call <a href="tel:1300560608">1300 560 608</a> or fill in our ‘Enquire Now’ form below.</p>
																	 </div>    
																	<div class="facc-number">
																		01
																	</div>
                </div>
            </div>
									  <div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/quotation-icon.svg" alt="quotation-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 02</div>
																			<div class="faq-title">Free Quotation</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We’ll offer a free quote for auto door or gate installation</p>
																	 </div>    
																	<div class="facc-number">
																		02
																	</div>
                </div>
            </div>
											<div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/prompt-installation-icon.svg" alt="prompt-installation-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 03</div>
																			<div class="faq-title">Prompt Installation</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We complete your installation efficiently & precisely.</p>
																	 </div>    
																	<div class="facc-number">
																		03
																	</div>
                </div>
            </div>
											<div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/quality-icon.svg" alt="quality-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 04</div>
																			<div class="faq-title">Quality Check</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We test your installation to make sure its runs perfectly.</p>
																	 </div>    
																	<div class="facc-number">
																		04
																	</div>
                </div>
            </div>
											<div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/sales-icon.svg" alt="sales-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 05</div>
																			<div class="faq-title">Complete After Sales Service</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We’re available on standby for maintenance, repairs & more.</p>
																	 </div>    
																	<div class="facc-number">
																		05
																	</div>
                </div>
            </div>
								</div>  
								
						 </div>
						 <div class="step-right">
									<img src="assets/images/oatley-hotel.jpg" alt="oatley-hotel" title="" width="670" height="660">
						 </div>
				 </div>
				
				 <div class="step-logo-wrap">
						<div class="step-logo-left">
								<p>Our market leading web based job tracking system ensures that all work requests are recorded in our system as soon as they are either phoned in or received by email request; detailing the works required and urgency.</p>
							 <p>The job is then allocated to the next available technician who using his hand held device will record the time on site and the work completed. This is all done in real time, with technicians using their tablet to login when arriving on site and logout when complete. They enter the job notes at the same time, which can then be emailed to the building manager.</p>
						</div>
						<div class="step-logo-right">
								<div class="stp-logo-ul">
											<div class="stp-logo-li">
														<div class="st-logo-circle circle-border">
																<img src="assets/images/icon/since-year-logo.svg" alt="since-year-logo" title="" width="152" height="137">
												  </div>
									  </div>
									  <div class="stp-logo-li">
														<div class="st-logo-circle">
															 <img src="assets/images/icon/explogo-icon.svg" alt="explogo-icon" title="" width="56" height="56" class="exp-icon">
																<img src="assets/images/icon/experience-logo.svg" alt="experience-logo" title="" width="158" height="158" class="exp-logo">
												  </div>
									  </div>
							 </div>
						</div>
				</div>
				
		 </div>
	</section>
	
	<!-- talbot door franchising call action -->
	<?php block('franchising-callaction'); ?>
	
	<!-- talbot door franchising -->
	<section class="pt-pb100 hm-franchise-wr">
	  <div class="container">
			   <div class="hm-franchise">
								<div class="hm-franchise-left">
											<div class="heading-50">Talbot Door Franchising</div>
										 <div class="client-numbers" id="counterdiv">
        					<ul class="cust-list">
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="3"> 0 </span>
																						</div>
																			  <label>Head offices in Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="11"> 0 </span>
																										
																						</div>
																			<label>Regional offices across the Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="150"> 0 </span><span class="plus_no">+</span>
																										
																						</div>
																			<label>Experts working across the country</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																				  <div class="cust-detail">
																										<span class="cust-no counter-value" data-count="1200"> 0 </span> <span class="plus_no">+</span>
																									
																						</div>
																				<label>Completed projects across Australia</label>
																		</div>
														</li>
										</ul>        
										 </div>
										 
									  <div class="selectbox">
													 <select>
															<option>Contact Details</option>
															<option>Contact Details</option>
												  </select>
									  </div>
									
							 </div>
							 <div class="hm-franchise-right">
										<div class="franchise-map">
												<img src="assets/images/map.svg" alt="map" title="" width="606" height="525">
											 <div class="dot dot1"></div>
											 <div class="dot dot2"></div>
											 <div class="dot dot3"></div>
									 </div>
							 </div>
				  </div>
		 </div>
	</section>
	
	<!-- content -->
 <section class="sec-area pt-pb100">
			 <div class="container">
						 <div class="area-cnt-wr">
									<div class="ar-cnt-left">
									   <div class="heading-40">Areas We Serve</div>
								 </div>
								 <div class="ar-cnt-right">
											<p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
								 </div>
					  </div>
						
					  	<div class="heading-24">New South Wales</div>
								<ul class="suburb-list">
  <li>
    <a href="">Balmain</a>
  </li>
  <li>
    <a href="">Bankstown</a>
  </li>
  <li>
    <a href="">Blacktown</a>
  </li>
  <li>
    <a href="">Bondi</a>
  </li>
  <li>
    <a href="">Campbelltown</a>
  </li>
  <li>
    <a href="">Eastern Creek</a>
  </li>
  <li>
    <a href="">Glebe</a>
  </li>
  <li>
    <a href="">Lugarno</a>
  </li>
  <li>
    <a href="">Liverpool</a>
  </li>
  <li>
    <a href="">Mascot</a>
  </li>
  <li>
    <a href="">Erskine Park</a>
  </li>
  <li>
    <a href="">Mosman</a>
  </li>
  <li>
    <a href="">Newtown</a>
  </li>
  <li>
    <a href="">North Sydney</a>
  </li>
  <li>
    <a href="">Penrith</a>
  </li>
  <li>
    <a href="">Randwick</a>
  </li>
  <li>
    <a href="">Rose Bay</a>
  </li>
  <li>
    <a href="">Ryde</a>
  </li>
  <li>
    <a href="">South Hurstville</a>
  </li>
  <li>
    <a href="">Sutherland</a>
  </li>
  <li>
    <a href="">Western Sydney</a>
  </li>
  <li>
    <a href="">Wetherill Park</a>
  </li>
  <li>
    <a href="">Alexandria</a>
  </li>
  <li>
    <a href="">Belmore</a>
  </li>
  <li>
    <a href="">Cammeray</a>
  </li>
  <li>
    <a href="">Camperdown</a>
  </li>
  <li>
    <a href="">Canterbury</a>
  </li>
  <li>
    <a href="">Chippendale</a>
  </li>
  <li>
    <a href="">Coogee</a>
  </li>
  <li>
    <a href="">Crows Nest</a>
  </li>
  <li>
    <a href="">Earlwood</a>
  </li>
  <li>
    <a href="">Greenacre</a>
  </li>
  <li>
    <a href="">Haymarket</a>
  </li>
  <li>
    <a href="">Kingsford</a>
  </li>
  <li>
    <a href="">Lakemba</a>
  </li>
  <li>
    <a href="">Maroubra</a>
  </li>
  <li>
    <a href="">Marsfield</a>
  </li>
  <li>
    <a href="">Punchbowl</a>
  </li>
  <li>
    <a href="">Regents Park</a>
  </li>
  <li>
    <a href="">Rosebery</a>
  </li>
  <li>
    <a href="">Roselands</a>
  </li>
  <li>
    <a href="">Sefton</a>
  </li>
  <li>
    <a href="">Surry Hills</a>
  </li>
  <li>
    <a href="">Ultimo</a>
  </li>
  <li>
    <a href="">Waterloo</a>
  </li>
  <li>
    <a href="">Zetland</a>
  </li>
  <li>
    <a href="">Baulkham Hills</a>
  </li>
  <li>
    <a href="">Castle Hill</a>
  </li>
  <li>
    <a href="">Chatswood</a>
  </li>
  <li>
    <a href="">Kellyville</a>
  </li>
  <li>
    <a href="">Macquarie Park</a>
  </li>
  <li>
    <a href="">Norwest</a>
  </li>
  <li>
    <a href="h">Pennant Hills</a>
  </li>
  <li>
    <a href="">Avoca Beach</a>
  </li>
  <li>
    <a href="">Bateau Bay</a>
  </li>
  <li>
    <a href="">Belmont</a>
  </li>
  <li>
    <a href="">Cardiff</a>
  </li>
  <li>
    <a href="">Central Coast</a>
  </li>
  <li>
    <a href="">Cessnock</a>
  </li>
  <li>
    <a href="">Erina</a>
  </li>
  <li>
    <a href="">Gosford</a>
  </li>
  <li>
    <a href="">Kincumber</a>
  </li>
  <li>
    <a href="">Lake Macquarie</a>
  </li>
  <li>
    <a href="">Lower Hunter</a>
  </li>
  <li>
    <a href="">Maitland</a>
  </li>
  <li>
    <a href="h">Morisset</a>
  </li>
  <li>
    <a href="">Nelson Bay</a>
  </li>
  <li>
    <a href="">Newcastle</a>
  </li>
  <li>
    <a href="">Summerland Point</a>
  </li>
  <li>
    <a href="">Terrigal</a>
  </li>
  <li>
    <a href="">The Entrance</a>
  </li>
  <li>
    <a href="">Toronto</a>
  </li>
  <li>
    <a href="">Umina Beach</a>
  </li>
  <li>
    <a href="">Warners Bay</a>
  </li>
  <li>
    <a href="">Woy Woy</a>
  </li>
  <li>
    <a href="">Annandale</a>
  </li>
  <li>
    <a href="">Ashfield</a>
  </li>
  <li>
    <a href="">Belrose</a>
  </li>
  <li>
    <a href="">Birchgrove</a>
  </li>
  <li>
    <a href="">Brookvale</a>
  </li>
  <li>
    <a href="">Cleveland</a>
  </li>
  <li>
    <a href="">Cromer</a>
  </li>
  <li>
    <a href="">Dee Why</a>
  </li>
  <li>
    <a href="">Dobroyd Point</a>
  </li>
  <li>
    <a href="">Dulwich Hill</a>
  </li>
  <li>
    <a href="">Enmore</a>
  </li>
  <li>
    <a href="">Forestville</a>
  </li>
  <li>
    <a href="">Frenchs Forest</a>
  </li>
  <li>
    <a href="">Haberfield</a>
  </li>
  <li>
    <a href="">Leichhardt</a>
  </li>
  <li>
    <a href="">Lewisham</a>
  </li>
  <li>
    <a href="">Lilyfield</a>
  </li>
  <li>
    <a href="">Manly</a>
  </li>
  <li>
    <a href="">Marrickville</a>
  </li>
  <li>
    <a href="">Mona Vale</a>
  </li>
  <li>
    <a href="">Newport</a>
  </li>
  <li>
    <a href="#">Northern Beaches</a>
  </li>
  <li>
    <a href="#">Rozelle</a>
  </li>
  <li>
    <a href="#">Stanmore</a>
  </li>
  <li>
    <a href="#">Summerhill</a>
  </li>
  <li>
    <a href="#">Warriewood</a>
  </li>
  <li>
    <a href="#">Wollongong</a>
  </li>
</ul>
						  
						
					 <div class="map-area">
							<iframe src="https://www.google.com/maps/d/embed?mid=1ii8-nbOG-WdUdeGhPeqkMlqcjQC5N0FT&ehbc=2E312F" width="100%" height="640"></iframe>
					 </div>
					
			 </div>
	 </section>
	</section>
</main>
<?php get_footer();