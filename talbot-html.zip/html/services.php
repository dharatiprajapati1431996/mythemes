<?php require_once __DIR__ . '/includes/includes.php'; ?> 
 <?php get_header(); ?> 
<main class="service-page">
 <!-- Inner banner  -->
 <section class="inner-banner">
  <img src="assets/images/services-bg.jpg" alt="services banner image" title="" width="1920" height="650" class="bgimg">
  <div class="container">
   <div class="inbanner-content">
    <div class="inbanner-cnt-left">
     <div class="heading-50">Services</div>
    </div>
    <div class="inbanner-cnt-right">
     <ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
         <span class="breadcrumb_last" aria-current="page">Services</span>
        </span>
       </span>
      </li>
     </ul>
    </div>
   </div>
  </div>
 </section>
	
 <section class="top-space-curve">
		
		<section class="service-wrap mb-100">
			 <div class="container">
							<div class="service-ul">
								 <div class="service-li">
										<a href="#">
										 <div class="service-li-wr">
											  <div class="service-img">
														 <img src="assets/images/routine-maintenance-image.jpg" alt="routine-maintenance-image" width="700" height="400">
												 </div>
												 <div class="service-bottom">
															<div class="s-title">Routine Preventative Maintenance</div>
														 <div class="s-btn">
																<div class="button button-white">More Details</div>
														 </div>
												 </div>
										 </div>
										</a>	
								 </div>
								 <div class="service-li">
										<a href="#">
										 <div class="service-li-wr">
											  <div class="service-img">
														 <img src="assets/images/emergency-repairs-image.jpg" alt="emergency-repairs-image" width="700" height="400">
												 </div>
												 <div class="service-bottom">
															<div class="s-title">Emergency<br> Repairs</div>
														 <div class="s-btn">
																<div class="button button-white">More Details</div>
														 </div>
												 </div>
										 </div>
										</a>	
								 </div>
								<div class="service-li">
										<a href="#">
										 <div class="service-li-wr">
											  <div class="service-img">
														 <img src="assets/images/new-installations-image.jpg" alt="new-installation" width="700" height="400">
												 </div>
												 <div class="service-bottom">
															<div class="s-title">New<br> Installations</div>
														 <div class="s-btn">
																<div class="button button-white">More Details</div>
														 </div>
												 </div>
										 </div>
										</a>	
								 </div>
								<div class="service-li">
										<a href="#">
										 <div class="service-li-wr">
											  <div class="service-img">
														 <img src="assets/images/retrofit-upgrades-image.jpg" alt="Retrofit-Upgrades-image" width="700" height="400">
												 </div>
												 <div class="service-bottom">
															<div class="s-title">Retrofit<br> Upgrades</div>
														 <div class="s-btn">
																<div class="button button-white">More Details</div>
														 </div>
												 </div>
										 </div>
										</a>	
								 </div>
					  </div>
			 </div>
		</section>
		
		<!-- talbot door franchising call action -->
	 <?php block('franchising-callaction'); ?>
		
		 <section class="content-wrapper mb-100">
    <div class="container">
      <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
        <div class="ctent-block">
									 
          <div class="heading-30">This is dummy text, we use it at supple</div>
          <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
									<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
									<p>We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
        </div>
        <div class="ctent-img">
									<div class="ctent-logo-wr">
          		<img src="assets/images/service-content-image.jpg" alt="service-content-image" title="" width="670" height="500">
									 		<div class="ctent-logo">
												<img src="assets/images/year-logo.svg" alt="year logo" title="" width="146" height="76">
									 </div>
									</div>
        </div>
      </div>
				</div>
  </section>
		
		 <div class="container">
			 <div class="divider"></div>
		</div>
		
		 <!-- some of our clients -->
		 <?php block('client-logo'); ?>
		
 </section>
	
</main> 

<?php get_footer();