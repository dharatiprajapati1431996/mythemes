<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="product-page">
	
<!-- Inner banner  -->
<section class="inner-banner">
	  <img src="assets/images/product-banner-bg.jpg" alt="product banner image" title="" width="1920" height="650" class="bgimg">
   <div class="container">
     <div class="inbanner-content">
						  <div class="inbanner-cnt-left">
        		<div class="heading-50">Products</div>
								</div>
						  <div class="inbanner-cnt-right">
        		<ul class="woo_breadcums">
           <li>
                        <span>
                            <span>
                                <a href="#">Home</a>
                                <span class="breadcrumb_last" aria-current="page">Products</span>
                            </span>
                        </span>
                    </li>
        </ul>
								</div>	
				 </div>
   </div>
	</section>

	<section class="top-space-curve">
		
 	<!-- top content -->
		<section class="product-wrap-sec mb-100">
			<div class="container">
				 <div class="product-wrap flex-container wrap justify-content-between">
						 <div class="product-left">
								<img src="assets/images/icon/door-icon.svg" alt="door-icon" title="" width="54" height="60">
								<div class="heading-50">Automatic Doors</div>
								<p>We operate in compliance with all relevant environmental legislation and we strive to use pollution prevention and environmental best practices in all we do.</p>
								
								<div class="btn-row">
									 <a href="#" class="button button-grey-border">More Details</a>
									 <a href="#" class="button button-theme">Enquire Now</a>
								</div>
								
						 </div>
						 <div class="product-right">
									<div class="pr-link-wrap">
  									<div class="prlink-img-wr">
												<img src="assets/images/automatic-door-image.jpg" alt="automatic door product" title="" width="736" height="450" class="pr-img">
												<div class="prlink-box">
														<div class="pr-toplink">
																<ul class="pr-link-ul">
																		<li><a href="#">Sliding Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																		<li><a href="#">Swing Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																		<li><a href="#">Revolving Door<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																		<li><a href="#">Accessible Door Solutions<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																</ul>
														</div>

												</div>
  </div>
									</div>
						 </div>
				 </div>
				
				 <div class="divider"></div>
				
				 <div class="product-wrap flex-container wrap flex-row-reverse justify-content-between">
						 <div class="product-left">
								<img src="assets/images/icon/gate-icon.svg" alt="gate-icon" title="" width="54" height="60">
								<div class="heading-50">Automatic Gates </div>
								<p>Talbot auto doors offer a range of affordable automatic door and gate designs to suit your home.View some of our completed projects here</p>
								
								<div class="btn-row">
									 <a href="#" class="button button-grey-border">More Details</a>
									 <a href="#" class="button button-theme">Enquire Now</a>
								</div>
								
						 </div>
						 <div class="product-right">
									<div class="pr-link-wrap">
  									<div class="prlink-img-wr">
												<img src="assets/images/automatic-gates-image.jpg" alt="automatic gate product" title="" width="736" height="450" class="pr-img">
												<div class="prlink-box">
														<div class="pr-toplink">
																<ul class="pr-link-ul">
																				  <li><a href="#">Bi-fold Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Telescopic Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Boom Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Curved Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					<li><a href="#">Sliding Garage Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																			 </ul>
														</div>

												</div>
  </div>
									</div>
						 </div>
				 </div>
		 </div>	
	</section>
		
		<!-- call action -->
		<?php block('custom-solution-block');?>
		
		<section class="content-wrapper mb-100">
    <div class="container">
      <div class="flex-container wrap justify-content-between ctent-block-wr">
        <div class="ctent-block">
									 
          <div class="heading-40">Commercial Sliding and Swing Doors</div>
          <p>We include a full range of door accessories including sensors and touch-less switches.</p>
									 <p>The Talbot team fabricates its own aluminum framed and frame-less glass sliding door leaves, side lights and shop front lazing if required. Our ASW 200 swing door system is fire rated and suitable for use on all fire doors, including Fire Core, E-Core an Pyropanel fire doors. Talbot provide a service of suppling the door components only t complete project management for a multi door installation.</p>
									<p>We also service, maintain and install roller shutters, section shutters, boom gates and swing and sliding gates For further information see our Youtube video.</p>
        </div>
        <div class="ctent-img">
          <img src="assets/images/commercial-door.jpg" alt="liverpool-central" title="" width="670" height="600">
        </div>
      </div>
    </div>
  </section>
		
		<!-- talbot auto door -->
			<section class="content-wrapper pt-pb100 bg-grey-yellow top-curve">
    <div class="container">
      <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr mb-100">
        <div class="ctent-block">
									 
          <div class="heading-30">Talbot Auto Doors – the Leaders in Automatic Sliding Doors & Gates</div>
          <p>Talbot Auto Doors is your trusted local service for high-quality automatic doors. Sydney-based, our team has 30+ years of industry experience going into everything we do. With our reliable automatic gate installation, Sydney customers can feel confident in the quality of our workmanship and the fairness of our prices.</p>
									<p>Our range includes both residential and commercial gates. Sydney home and business-owners alike can trust in our product range to add safety (and value) to their property with our quality automatic gate installation. Sydney locals</p>
									<p>need only call us on <a href="tel:1300560608">1300 560 608</a> to book their installation appointment.</p>
									<p>But with our automatic door service, Sydney customers get much more than just installations. We also offer fast and affordable automatic door repairs to Sydney’s many suburbs, whether it’s a roller door in Bondi or a sliding gate in Peakhurst.</p>
									<p>We even offer 24-hour emergency automatic door repair. Sydney residents, Sydney home-owners and commercial clients alike can count on this 24-hour emergency service.</p>
									<p>With our commercial gates, Sydney strata managers & business owners can get competitive prices on larger-scale installation projects – secure in the knowledge that our 30+ years’ experience in the industry means we’ll get the job done on-time.</p>
									<p>So whether it’s installing automatic swing doors for Sydney home-owners or commercial gates for Sydney business-owners, our team can handle it.</p>
									<p>Talbot Auto Doors – call us on <a href="tel:1300560608">1300 560 608</a> for the hydraulic door repair and automatic door installation Sydney can’t stop talking about.</p>
        </div>
        <div class="ctent-img">
          <img src="assets/images/talbot-autodoor.jpg" alt="talbot-autodoor" title="" width="670" height="600">
        </div>
      </div>
					 
					 <div class="divider"></div>
					
					 <div class="heading-30 text-center">Commercial Shutters</div>
					  <div class="width-wr mb-40">
										<p>Talbot Auto Doors don’t only specialise in making and selling automatic doors. In conjunction with our partners we also make and sell roller shutters and roller doors.</p>
					  </div>
					
							<div class="commercial-boxbg">
							<div id="commercialTab">
  							<ul class="resp-tabs-list">
    						<li>Choose And Install  Your Roller Shutters <img src="assets/images/icon/double-arrow.svg" alt="double-arrow" title="" width="22" height="27" class="t-icon"></li>
    						<li>Commercial Roller Shutters Sydney<img src="assets/images/icon/double-arrow.svg" alt="double-arrow" title="" width="22" height="27" class="t-icon"></li>
    						<li>Roller Shutter Doors Sydney<img src="assets/images/icon/double-arrow.svg" alt="double-arrow" title="" width="22" height="27" class="t-icon"></li>
										<li>Commercial Automatic Doors<img src="assets/images/icon/double-arrow.svg" alt="double-arrow" title="" width="22" height="27" class="t-icon"></li>
    						<li>Commercial Automatic Doors<img src="assets/images/icon/double-arrow.svg" alt="double-arrow" title="" width="22" height="27" class="t-icon"></li>
  							</ul>
  							<div class="resp-tabs-container">
											<div class="comm-tab">
													 <div class="comm-tabwr">
																 <div class="comm-tab-left">
																						<div class="heading-30">Choose And Install  Your Roller Shutters</div>
																				 <p>We can assist with door installation, including roller door installation and security roller shutters installation. You can choose from commercial steel shutters or simple single Colorbond garage doors, whatever suits your house or business. Roller shutters, security roller shutters and roller doors can be added to your garage for extra security, or they can be installed at the time of building. </p>
																				<p>Even though there are many types of roller shutters to choose from, you shouldn’t be worried about having too much choice. Talbot Auto Doors & Gates will always help you select roller shutters that suit you best.</p>
																		 </div>
																	<div class="comm-tab-right">
																						<img src="assets/images/roller-shutter-image.jpg" alt="roller-shutter-image" title="" width="491" height="438">
																		 </div>
														</div>
											</div>
											<div class="comm-tab">
													 <div class="comm-tabwr">
																 <div class="comm-tab-left">
																						<div class="heading-30">Commercial Roller Shutters Sydney</div>
																				 <p>We can assist with door installation, including roller door installation and security roller shutters installation. You can choose from commercial steel shutters or simple single Colorbond garage doors, whatever suits your house or business. Roller shutters, security roller shutters and roller doors can be added to your garage for extra security, or they can be installed at the time of building. </p>
																				
																		 </div>
																	<div class="comm-tab-right">
																						<img src="assets/images/roller-shutter-image.jpg" alt="roller-shutter-image" title="" width="491" height="438">
																		 </div>
														</div>
											</div>
											<div class="comm-tab">
												<div class="comm-tabwr">
																 <div class="comm-tab-left">
																						<div class="heading-30">Roller Shutter Doors Sydney</div>
																				 <p>We can assist with door installation, including roller door installation and security roller shutters installation. You can choose from commercial steel shutters or simple single Colorbond garage doors, whatever suits your house or business. Roller shutters, security roller shutters and roller doors can be added to your garage for extra security, or they can be installed at the time of building. </p>
																				<p>Even though there are many types of roller shutters to choose from, you shouldn’t be worried about having too much choice. Talbot Auto Doors & Gates will always help you select roller shutters that suit you best.</p>
																		 </div>
																	<div class="comm-tab-right">
																						<img src="assets/images/roller-shutter-image.jpg" alt="roller-shutter-image" title="" width="491" height="438">
																		 </div>
														</div>
											</div>
										 <div class="comm-tab">
												<div class="comm-tabwr">
																 <div class="comm-tab-left">
																						<div class="heading-30">Commercial Automatic Doors</div>
																				 <p>We can assist with door installation, including roller door installation and security roller shutters installation. You can choose from commercial steel shutters or simple single Colorbond garage doors, whatever suits your house or business. Roller shutters, security roller shutters and roller doors can be added to your garage for extra security, or they can be installed at the time of building. </p>
																				<p>Even though there are many types of roller shutters to choose from, you shouldn’t be worried about having too much choice. Talbot Auto Doors & Gates will always help you select roller shutters that suit you best.</p>
																		 </div>
																	<div class="comm-tab-right">
																						<img src="assets/images/roller-shutter-image.jpg" alt="roller-shutter-image" title="" width="491" height="438">
																		 </div>
														</div>
											</div>
										 <div class="comm-tab">
													<div class="comm-tabwr">
																 <div class="comm-tab-left">
																						<div class="heading-30">Commercial Roller Shutters Sydney</div>
																				 <p>We can assist with door installation, including roller door installation and security roller shutters installation. You can choose from commercial steel shutters or simple single Colorbond garage doors, whatever suits your house or business. Roller shutters, security roller shutters and roller doors can be added to your garage for extra security, or they can be installed at the time of building. </p>
																			
																		 </div>
																	<div class="comm-tab-right">
																						<img src="assets/images/roller-shutter-image.jpg" alt="roller-shutter-image" title="" width="491" height="438">
																		 </div>
														</div>
											</div>
  						</div>
							</div>
					</div>
					
    </div>
  </section>
</section>
	
</main>
<?php get_footer();
