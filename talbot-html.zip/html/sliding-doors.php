<?php require_once __DIR__ . '/includes/includes.php'; ?> <?php get_header(); ?> <main class="productlist-page woocommerce">
 <!-- Inner banner  -->
 <section class="inner-banner">
  <img src="assets/images/sliding-door-banner-bg.jpg" alt="product banner image" title="" width="1920" height="650" class="bgimg">
  <div class="container">
   <div class="inbanner-content">
    <div class="inbanner-cnt-left">
     <div class="heading-50">Sliding Doors</div>
    </div>
    <div class="inbanner-cnt-right">
     <ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
         <a href="#">Products</a>
         <a href="#">Automatic Doors</a>
         <span class="breadcrumb_last" aria-current="page">Sliding Doors</span>
        </span>
       </span>
      </li>
     </ul>
    </div>
   </div>
  </div>
 </section>
 <section class="top-space-curve">
		
  <!-- listing -->
  <section class="prlist-wrap mb-100">
   <div class="container">
    <ul class="products columns-4">
     <li class="product type-product">
      <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
							<div class="prlist-li">
									<div class="product-img">
											<img src="assets/images/heavy-duty-image.jpg" width="340" height="340" src="#" alt="heavy-duty-image" decoding="async">
								 </div>
								 <div class="prod-text">
										<div class="ptitle-wr"><h2 class="woocommerce-loop-product__title">ASL 250 - Heavy Duty</h2></div>
								 </div>
							</div>
						</a>
							<div class="prbtn-list">
									<a href="#" class="button button-grey-border">More Details</a>
      			<a href="#" class="button button-theme">Enquire Now</a>
							</div>
     </li>
					<li class="product type-product">
      <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
							<div class="prlist-li">
									<div class="product-img">
											<img src="assets/images/medium-duty-image.jpg" width="340" height="340" src="#" alt="heavy-duty-image" decoding="async">
								 </div>
								 <div class="prod-text">
										<div class="ptitle-wr"><h2 class="woocommerce-loop-product__title">ASL 200 - Medium Duty</h2></div>
								 </div>
							</div>
						</a>
							<div class="prbtn-list">
									<a href="#" class="button button-grey-border">More Details</a>
      			<a href="#" class="button button-theme">Enquire Now</a>
							</div>
     </li>
					<li class="product type-product">
      <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
							<div class="prlist-li">
									<div class="product-img">
											<img src="assets/images/telescopic-image.jpg" width="340" height="340" src="#" alt="heavy-duty-image" decoding="async">
								 </div>
								 <div class="prod-text">
										<div class="ptitle-wr"><h2 class="woocommerce-loop-product__title">ASTL 250 - Telescopic</h2></div>
								 </div>
							</div>
						</a>
							<div class="prbtn-list">
									<a href="#" class="button button-grey-border">More Details</a>
      			<a href="#" class="button button-theme">Enquire Now</a>
							</div>
     </li>
					<li class="product type-product">
      <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
							<div class="prlist-li">
									<div class="product-img">
											<img src="assets/images/maglev-doors-image.jpg" width="340" height="340" src="#" alt="heavy-duty-image" decoding="async">
								 </div>
								 <div class="prod-text">
										<div class="ptitle-wr"><h2 class="woocommerce-loop-product__title">Maglev Doors</h2></div>
								 </div>
							</div>
						</a>
							<div class="prbtn-list">
									<a href="#" class="button button-grey-border">More Details</a>
      			<a href="#" class="button button-theme">Enquire Now</a>
							</div>
     </li>
    </ul>
   </div>
			
			<div class="container">
					
			</div>
  </section>
		
  <!-- call action --> 
	<section class="custom-callaction-sec mb-100">
			 <div class="container">
							<div class="custom-callact-sec">
								 <img src="assets/images/custom-callaction-bgimage.jpg" alt="custom-callaction-bgimage" title="" width="1472" height="200" class="bgimg">
								 <div class="custom-callwr">
								 		<div class="cust-logo">
											<img src="assets/images/custom-solution-logo.svg" alt="custom-solution-logo" title="" width="370" height="66">
								 </div>
								 		<div class="cust-right">
											 <div class="cust-content">
																<p>Talbot Auto Doors provide a number of products and services suitable for residential customers, specialising in automatic doors and gates.</p>
												</div>
											 <div class="cust-btn">
												<a href="tel:1300560608" class="button button-white"><img src="assets/images/icon/phone-icon.svg" alt="phone-icon" title="" width="27" height="27">NSW: 1300 560 608</a>
												<a href="#" class="button button-theme">Request a Quote</a>
										 </div>
								 </div>
									</div>	
					  </div>
			 </div>
		</section>	
		
  <!-- content block section  -->
  <section class="content-wrapper">
   <div class="container">
    <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr mb-100">
     <div class="ctent-block">
      <div class="heading-30">Our Process and Recommendations</div>
      <p>Automatic sliding doors are a great feature to add to your business. We assist with the design and installation of automatic doors and sliding doors in Sydney. Our team use tested door operators that are affordable and easy to install. We use the best products and materials to make your automatic doors and can modify any design to suit your needs.</p>
      <div class="heading-22">We find the best product for you</div>
      <p>There are many options for you to choose from and we will always find doors that suit your house or business completely. We’ve taken on a number of sliding gates and new installation projects for a range of clients, all of whom are ready to recommend our products and services. We have recently started to sell our auto door systems to local builders and shop fitters around the country who can install our simple systems.</p>
      <div class="heading-22">Glass Sliding Doors Sydney</div>
      <p>Keep the weather at bay while controlling the temperature inside your store thanks to the sliding automatic doors from Talbot Automatic Doors & Gates. Drawing on over 30 years of industry experience and knowledge our skilled experts can supply, install, and maintain a wide variety of glass sliding doors for Sydney businesses.</p>
      <p>Responding to approaching persons through a motion sensor, our glass sliding doors come in either framed or frameless styles and are constructed from resilient types of glass to prevent the door becoming a hazard should breakage occur. Available at competitive prices our comprehensive sliding door solutions will improve your business for less.</p>
      <div class="heading-22">Repairs and Servicing</div>
      <p>Talbot Automatic Doors and Gates are committed to providing you with the best service. We offer a 24 hour repair service, so if there is a problem with your doors you won’t have to wait long to get them fixed. We also recommend taking advantage of our ongoing maintenance service. It’s important to maintain your doors after installation, so any problems that may arise can be noticed before they cause any major damage or problems for you.</p>
     </div>
     <div class="ctent-img">
      <img src="assets/images/glass-door-image.jpg" alt="glass-door-image" title="" width="670" height="500">
     </div>
    </div>
    <div class="divider"></div>
   </div>
  </section>
		
  <!-- some of our clients -->
  <?php block('client-logo'); ?>
		
 </section>
	
</main> 

<?php get_footer();