<?php

$GLOBALS['assets'] = [
    'common' => [
        'styles' => [
            'variables',
            'font-awesome.min',
            'slick.min',
            'slick-theme.min',
            'reset',
            'normalize',
            'utiliti',
            'woocommerce',
            'woocommerce-layout',
            ['src' => 'woocommerce-smallscreen', 'media' => 'only screen and (max-width: 768px)'],
            'woo-custom',
            'style',
            'header'
        ],
        'scripts' => ['jquery-3.6.1.min', 'slick.min',  'menu','script'],
    ],

    'home' => [
        'styles' => ['easy-responsive-tabs','smk-accordion','home'],
        'scripts' => ['easy-responsive-tabs','smk-accordion','rotating-count','faq','home'],
    ],
   'product' => [
        'styles' => ['easy-responsive-tabs','product'],
        'scripts' => ['easy-responsive-tabs','product'],
    ],
			'product-detail' => [
        'styles' => ['product-detail'],
        'scripts' => ['product-detail'],
    ],
			 'sliding-doors' => [
        'styles' => ['easy-responsive-tabs','product'],
        'scripts' => ['easy-responsive-tabs'],
    ],
	  'services' => [
        'styles' => ['service'],
        'scripts' => [],
    ],
			'door-servicing' => [
        'styles' => ['easy-responsive-tabs','jquery.fancybox.min','service-detail','testimonial'],
        'scripts' => ['easy-responsive-tabs','jquery.fancybox.min','map-tab','testimonial'],
    ],
			'franchise-opportunity' => [
        'styles' => ['smk-accordion','jquery.fancybox.min','franchise'],
        'scripts' => ['smk-accordion','faq','jquery.fancybox.min','rotating-count','franchise'],
    ],
	  'contact-us' => [
        'styles' => ['easy-responsive-tabs','contact'],
        'scripts' => ['easy-responsive-tabs','rotating-count','map-tab'],
    ],
	   'area-we-serve' => [
        'styles' => ['easy-responsive-tabs','smk-accordion','home','area'],
        'scripts' => ['easy-responsive-tabs','smk-accordion','rotating-count','faq','home'],
    ],
		 'suburb' => [
        'styles' => ['easy-responsive-tabs','smk-accordion','home','area'],
        'scripts' => ['easy-responsive-tabs','smk-accordion','rotating-count','faq','home'],
    ],
];