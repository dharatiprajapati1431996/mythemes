<?php

function wp_head()
{
    foreach ($GLOBALS['assets'] as $page => $asset) {
        if ($page === 'common' || str_ends_with($_SERVER['PHP_SELF'], "/$page.php")) {
            if (isset($asset['styles']) && is_array($asset['styles'])) {
                foreach ($asset['styles'] as $style) {
                    $src = $style;
                    $media = 'all';
                    if (is_array($style)) extract($style);
                    echo "<link rel='stylesheet' href='assets/css/$src.css' media='$media'/>" . PHP_EOL;
                }
            }
        }
    }
}

function wp_footer()
{
    foreach ($GLOBALS['assets'] as $page => $asset) {
        if ($page === 'common' || str_ends_with($_SERVER['PHP_SELF'], "/$page.php")) {
            if (isset($asset['scripts']) && is_array($asset['scripts'])) {
                foreach ($asset['scripts'] as $script) {
                    echo "<script src='assets/js/$script.js'></script>" . PHP_EOL;
                }
            }
        }
    }
}

function get_header()
{
    include __DIR__ . '/../header.php';
}

function get_footer()
{
    include __DIR__ . '/../footer.php';
}

function block($path)
{
    if (file_exists($path = __DIR__ . '/../blocks/' . $path . '.php')) {
        include $path;
    }
    else {
        echo "<div style='color:red;'><strong>Path Not Found:</strong> $path</div>";
    }
}

function normalize_path($path, $separator = '\\/')
{
    $normalized = preg_replace('#\p{C}+|^\./#u', '', $path);
    $normalized = preg_replace('#/\.(?=/)|^\./|\./$#', '', $normalized);
    $regex = '#/*[^/.]+/\.\.#Uu';

    while (preg_match($regex, $normalized)) {
        $normalized = preg_replace($regex, '', $normalized);
    }

    if (preg_match('#/\.{2}|\.{2}/#', $normalized)) {
        throw new LogicException('Path is outside of the defined root, path: [' . $path . '], resolved: [' . $normalized . ']');
    }

    return trim($normalized, $separator);
}

if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool
    {
        $needle_len = strlen($needle);
        return ($needle_len === 0 || 0 === substr_compare($haystack, $needle, -$needle_len));
    }
}
