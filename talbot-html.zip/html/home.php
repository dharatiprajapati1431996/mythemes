<?php require_once __DIR__ . '/includes/includes.php'; ?>

<?php get_header(); ?>

<main class="home-page woocommerce">
	
  <?php block('home/banner');?>
	
 <!--- content -->
  <section class="content-wrapper tophome-bg">
    <div class="container">
      <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
        <div class="ctent-block">
									 <div class="label-title">Established in 1985</div>
          <div class="heading-50">Talbot Automatic Doors and Gates</div>
          <p>We even offer 24-hour emergency door repair service to commercial clients. Sydney residents, we know there’s never a convenient time to have automatic gate or door issues, and that’s why we’re available round-the-clock to provide advise and repairs on your automatic sliding doors and gates</p>	
									<a href="#" class="button button-border">Learn more<img src="assets/images/icon/arrow-right.svg" alt="arrow-right" title="" width="14" height="14"></a>
        </div>
        <div class="ctent-img">
          <img src="assets/images/talbot-auomatic-doors.jpg" alt="talbot-auomatic-doors" title="" width="670" height="424">
        </div>
      </div>
    </div>
  </section>
		 
	<!-- section since 1985 -->
  <div class="year-list-box mb-100">
    <ul class="js-year marquee">
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title crav-stroke">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title crav-stroke">SINCE 1985</div>
      </li>
      <li>
        <div class="crav-title">SINCE 1985</div>
      </li>
    </ul>
  </div>
	
	<!-- section Our products -->
	<section class="sec-hm-product mb-100"> 
	 <div class="container">
				<div class="hmproduct-wrap">
						<div class="hmproduct-left">
								<div class="label-title">Our Products</div>
							 <div class="heading-50">Experts in Automatic Doors and Gates an Australian</div>
							<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text.</p>
							
							<div class="pr-link-ul">
								<div class="pr-link-li">
										<div class="pr-linkbox">
											<div class="pr-link-icon">
													<img src="assets/images/icon/door-icon.svg" alt="door-icon" title="" width="54" height="60">
											</div>
											<div class="pr-link-title">Automatic Doors</div>
											<img src="assets/images/icon/angle-right.svg" alt="angle-right" title="" width="24" height="24" class="angle-arrow">
										</div>
								</div>
								<div class="pr-link-li">
									<div class="pr-linkbox">
									 <div class="pr-link-icon"><img src="assets/images/icon/gate-icon.svg" alt="gate-icon" title="" width="54" height="60"></div>
									 <div class="pr-link-title">Automatic Gates </div>
									<img src="assets/images/icon/angle-right.svg" alt="angle-right" title="" width="24" height="24" class="angle-arrow">
									</div>
								</div>
								<div class="pr-link-li">
									<div class="pr-linkbox">
									 <div class="pr-link-icon"><img src="assets/images/icon/custom-icon.svg" alt=""custom-icon title="" width="54" height="60"></div>
									 <div class="pr-link-title">Custom Solutions</div>
									 <img src="assets/images/icon/angle-right.svg" alt="angle-right" title="" width="24" height="24" class="angle-arrow">
									</div>
								</div>
							</div>
							
					 </div>
					 <div class="hmproduct-right">
							 <div class="pr-link-content">
									<div class="pr-link-tab active">
										 <div class="pr-link-wrap">
												  <div class="prlink-img-wr">
																<img src="assets/images/automatic-door-product.jpg" alt="automatic door product" title="" width="670" height="700" class="pr-img">
															 <div class="prlink-box">
																		<div class="pr-toplink">
																			 <ul class="pr-link-ul">
																				  <li><a href="#">Sliding Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Swing Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Revolving Door<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Accessible Door Solutions<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																			 </ul>
																	 </div>
																	 <div class="pr-btmlink">
																				<a href="#">View all Products<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a>
																	 </div>
															 </div>
												  </div>
										 </div>		
									</div>
							  <div class="pr-link-tab">
										 <div class="pr-link-wrap">
												  <div class="prlink-img-wr">
																<img src="assets/images/automatic-door-product.jpg" alt="automatic door product" title="" width="670" height="700" class="pr-img">
															 <div class="prlink-box">
																		<div class="pr-toplink">
																			 <ul class="pr-link-ul">
																				  <li><a href="#">Bi-fold Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Telescopic Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Boom Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					 <li><a href="#">Curved Gates<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																					<li><a href="#">Sliding Garage Doors<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a></li>
																			 </ul>
																	 </div>
																	 <div class="pr-btmlink">
																				<a href="#">View all Products<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a>
																	 </div>
															 </div>
												  </div>
										 </div>
									</div>
									<div class="pr-link-tab">
										<div class="pr-link-wrap">
												  <div class="prlink-img-wr">
																<img src="assets/images/automatic-door-product.jpg" alt="automatic door product" title="" width="670" height="700" class="pr-img">
															 <div class="prlink-box">
																		<div class="pr-toplink">
																				<p>Custom-sized to precisely fit into doorways and portals industrial and commercial doors come in both automatic and swing varieties, allowing you to find the right type to suit your needs and requirements. </p>
																	 </div>
																	 <div class="pr-btmlink">
																				<a href="#">View More<img src="assets/images/icon/arrow-right.svg" alt="arrow" width="14" height="14"></a>
																	 </div>
															 </div>
												  </div>
									</div>
							 </div>
					 </div>
			 </div>
		</div>
		</div>
	</section>
	
	<!-- why choose Talbot -->
<?php block('whychoose-block'); ?>
	
	<!-- Explore Our Services -->
<?php block('our-service'); ?>
	
	
	<!-- simple steps -->
	<section class="step-wrap">
		 <div class="container">
					<div class="step-wrap-block">
							<div class="step-left">
									<div class="label-title">The 5 Simple Steps of</div>
								 <div class="heading-50">How to book with us?</div>
										
								<div class="step-accordion">
           <div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/enquiry-icon.svg" alt="enquiry-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 01</div>
																			<div class="faq-title">Make an Enquiry</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>Call <a href="tel:1300560608">1300 560 608</a> or fill in our ‘Enquire Now’ form below.</p>
																	 </div>    
																	<div class="facc-number">
																		01
																	</div>
                </div>
            </div>
									  <div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/quotation-icon.svg" alt="quotation-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 02</div>
																			<div class="faq-title">Free Quotation</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We’ll offer a free quote for auto door or gate installation</p>
																	 </div>    
																	<div class="facc-number">
																		02
																	</div>
                </div>
            </div>
											<div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/prompt-installation-icon.svg" alt="prompt-installation-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 03</div>
																			<div class="faq-title">Prompt Installation</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We complete your installation efficiently & precisely.</p>
																	 </div>    
																	<div class="facc-number">
																		03
																	</div>
                </div>
            </div>
											<div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/quality-icon.svg" alt="quality-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 04</div>
																			<div class="faq-title">Quality Check</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We test your installation to make sure its runs perfectly.</p>
																	 </div>    
																	<div class="facc-number">
																		04
																	</div>
                </div>
            </div>
											<div class="accordion_in">
                <div class="faq-head">
																			<div class="faq-icon">
																			<img src="assets/images/icon/sales-icon.svg" alt="sales-icon" title="" width="56" height="54">
																	</div>
																			<div class="faq-hright">
																			<div class="faq-label">Step 05</div>
																			<div class="faq-title">Complete After Sales Service</div>
																	</div>	
													   </div>
                <div class="acc_content">
                		<div class="facc-dtl">
																				<p>We’re available on standby for maintenance, repairs & more.</p>
																	 </div>    
																	<div class="facc-number">
																		05
																	</div>
                </div>
            </div>
								</div>  
								
						 </div>
						 <div class="step-right">
									<img src="assets/images/oatley-hotel.jpg" alt="oatley-hotel" title="" width="670" height="660">
						 </div>
				 </div>
				
				 <div class="step-logo-wrap">
						<div class="step-logo-left">
								<p>Our market leading web based job tracking system ensures that all work requests are recorded in our system as soon as they are either phoned in or received by email request; detailing the works required and urgency.</p>
							 <p>The job is then allocated to the next available technician who using his hand held device will record the time on site and the work completed. This is all done in real time, with technicians using their tablet to login when arriving on site and logout when complete. They enter the job notes at the same time, which can then be emailed to the building manager.</p>
						</div>
						<div class="step-logo-right">
								<div class="stp-logo-ul">
											<div class="stp-logo-li">
														<div class="st-logo-circle circle-border">
																<img src="assets/images/icon/since-year-logo.svg" alt="since-year-logo" title="" width="152" height="137">
												  </div>
									  </div>
									  <div class="stp-logo-li">
														<div class="st-logo-circle">
															 <img src="assets/images/icon/explogo-icon.svg" alt="explogo-icon" title="" width="56" height="56" class="exp-icon">
																<img src="assets/images/icon/experience-logo.svg" alt="experience-logo" title="" width="158" height="158" class="exp-logo">
												  </div>
									  </div>
							 </div>
						</div>
				</div>
				
		 </div>
	</section>
	
	<!-- talbot door franchising call action -->
	<?php block('franchising-callaction'); ?>
	
	<!-- talbot door franchising -->
	<section class="pt-pb100 hm-franchise-wr mb-100">
	  <div class="container">
			   <div class="hm-franchise">
								<div class="hm-franchise-left">
											<div class="heading-50">Talbot Door Franchising</div>
										 <div class="client-numbers" id="counterdiv">
        					<ul class="cust-list">
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="3"> 0 </span>
																						</div>
																			  <label>Head offices in Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="11"> 0 </span>
																										
																						</div>
																			<label>Regional offices across the Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="150"> 0 </span><span class="plus_no">+</span>
																										
																						</div>
																			<label>Experts working across the country</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																				  <div class="cust-detail">
																										<span class="cust-no counter-value" data-count="1200"> 0 </span> <span class="plus_no">+</span>
																									
																						</div>
																				<label>Completed projects across Australia</label>
																		</div>
														</li>
										</ul>        
										 </div>
										 
									  <div class="selectbox">
													 <select>
															<option>Contact Details</option>
															<option>Contact Details</option>
												  </select>
									  </div>
									
							 </div>
							 <div class="hm-franchise-right">
										<div class="franchise-map">
												<img src="assets/images/map.svg" alt="map" title="" width="606" height="525">
											 <div class="dot dot1"></div>
											 <div class="dot dot2"></div>
											 <div class="dot dot3"></div>
									 </div>
							 </div>
				  </div>
		 </div>
	</section>
	
	<!-- content -->
	 <section class="content-wrapper mb-100">
    <div class="container">
      <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
        <div class="ctent-block">
									 <div class="label-title">Talbot Auto Doors</div>
          <div class="heading-50">The Leaders in Automatic Sliding and Swing Doors & Gates</div>
          <p>Talbot Automatic Doors and Gates is your trusted local service for high-quality automatic doors. If you’re looking for automatic touchless doors and gates, we are the team for you. Sydney-based, our team has 30+ years of industry experience going into everything we do. We can provide you with touchless door entry systems that are hands-free, hygienic, and covid-safe compliant for disabled use and NDIS support. Get auto doors and gates for the modern world with our range of hygienic automatic doors and gates!</p>	
									<p>With our reliable automatic gate installation, Sydney customers can feel confident in the quality of our workmanship and the fairness of our prices. Our range includes both residential and commercial gates. Sydney homes and business owners alike can trust in our product range to add safety (and value) to their property with our quality automatic gate installation. Sydney locals need only call us on <a href="tel:1300560608">1300 560 608</a> to book their installation appointment.</p>
									
        </div>
        <div class="ctent-img">
          <img src="assets/images/liverpool-central.jpg" alt="liverpool-central" title="" width="670" height="600">
        </div>
      </div>
    </div>
  </section>
</main>
<?php get_footer();