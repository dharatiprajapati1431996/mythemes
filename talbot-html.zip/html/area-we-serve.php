<?php require_once __DIR__ . '/includes/includes.php'; ?>

<?php get_header(); ?>

<main class="area-page woocommerce">
	
 <!-- Inner banner  -->
 <section class="inner-banner area-banner">
  <img src="assets/images/area-banner.jpg" alt="contact banner image" title="" width="1920" height="650" class="bgimg">
  <div class="container">
   <div class="inbanner-content">
   
				 <div class="area-topbanner">
     	<div class="heading-40 text-center">Find A Automatic Sliding Doors Near Me</div>
						<div class="search-suburb search-box">
										<form class="suburb-search-form" method="post" action="/">
													<input type="search" name="suburb_locations" value="" placeholder="Suburb / Postcode" class="ui-autocomplete-input">
													<button type="button" class="button button-theme">Go</button>
										</form>
							</div>
				 </div>
					<ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
         <span class="breadcrumb_last" aria-current="page">Areas We Serve</span>
        </span>
       </span>
      </li>
     </ul>
				
  </div>
  </div>
 </section>
	
 <!--- content -->
  <section class="content-wrapper tophome-bg">
    <div class="container">
      <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
        <div class="ctent-block">
									 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
									 <p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
									<p>We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
									
									<div class="btn-row">
										<a href="#" class="button button-theme">Get a Free Quote</a>
										<a href="tel:1300560608" class="button button-grey-border"><img src="assets/images/icon/phone-b.svg" alt="phone icon" title="" width="14" height="14">1300 560 608</a>
									</div>
									
        </div>
        <div class="ctent-img">
          <img src="assets/images/area-image.jpg" alt="area-image" title="" width="670" height="500">
        </div>
      </div>
    </div>
  </section>
		 
  <!-- area -->
	 <section class="sec-area pt-pb100 bg-grey-yellow top-curve">
			 <div class="container">
						 <div class="area-cnt-wr">
									<div class="ar-cnt-left">
									   <div class="heading-40">Areas We Serve</div>
								 </div>
								 <div class="ar-cnt-right">
											<p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
								 </div>
					  </div>
						
					  	<div class="heading-24">New South Wales</div>
								<ul class="suburb-list">
  <li>
    <a href="">Balmain</a>
  </li>
  <li>
    <a href="">Bankstown</a>
  </li>
  <li>
    <a href="">Blacktown</a>
  </li>
  <li>
    <a href="">Bondi</a>
  </li>
  <li>
    <a href="">Campbelltown</a>
  </li>
  <li>
    <a href="">Eastern Creek</a>
  </li>
  <li>
    <a href="">Glebe</a>
  </li>
  <li>
    <a href="">Lugarno</a>
  </li>
  <li>
    <a href="">Liverpool</a>
  </li>
  <li>
    <a href="">Mascot</a>
  </li>
  <li>
    <a href="">Erskine Park</a>
  </li>
  <li>
    <a href="">Mosman</a>
  </li>
  <li>
    <a href="">Newtown</a>
  </li>
  <li>
    <a href="">North Sydney</a>
  </li>
  <li>
    <a href="">Penrith</a>
  </li>
  <li>
    <a href="">Randwick</a>
  </li>
  <li>
    <a href="">Rose Bay</a>
  </li>
  <li>
    <a href="">Ryde</a>
  </li>
  <li>
    <a href="">South Hurstville</a>
  </li>
  <li>
    <a href="">Sutherland</a>
  </li>
  <li>
    <a href="">Western Sydney</a>
  </li>
  <li>
    <a href="">Wetherill Park</a>
  </li>
  <li>
    <a href="">Alexandria</a>
  </li>
  <li>
    <a href="">Belmore</a>
  </li>
  <li>
    <a href="">Cammeray</a>
  </li>
  <li>
    <a href="">Camperdown</a>
  </li>
  <li>
    <a href="">Canterbury</a>
  </li>
  <li>
    <a href="">Chippendale</a>
  </li>
  <li>
    <a href="">Coogee</a>
  </li>
  <li>
    <a href="">Crows Nest</a>
  </li>
  <li>
    <a href="">Earlwood</a>
  </li>
  <li>
    <a href="">Greenacre</a>
  </li>
  <li>
    <a href="">Haymarket</a>
  </li>
  <li>
    <a href="">Kingsford</a>
  </li>
  <li>
    <a href="">Lakemba</a>
  </li>
  <li>
    <a href="">Maroubra</a>
  </li>
  <li>
    <a href="">Marsfield</a>
  </li>
  <li>
    <a href="">Punchbowl</a>
  </li>
  <li>
    <a href="">Regents Park</a>
  </li>
  <li>
    <a href="">Rosebery</a>
  </li>
  <li>
    <a href="">Roselands</a>
  </li>
  <li>
    <a href="">Sefton</a>
  </li>
  <li>
    <a href="">Surry Hills</a>
  </li>
  <li>
    <a href="">Ultimo</a>
  </li>
  <li>
    <a href="">Waterloo</a>
  </li>
  <li>
    <a href="">Zetland</a>
  </li>
  <li>
    <a href="">Baulkham Hills</a>
  </li>
  <li>
    <a href="">Castle Hill</a>
  </li>
  <li>
    <a href="">Chatswood</a>
  </li>
  <li>
    <a href="">Kellyville</a>
  </li>
  <li>
    <a href="">Macquarie Park</a>
  </li>
  <li>
    <a href="">Norwest</a>
  </li>
  <li>
    <a href="h">Pennant Hills</a>
  </li>
  <li>
    <a href="">Avoca Beach</a>
  </li>
  <li>
    <a href="">Bateau Bay</a>
  </li>
  <li>
    <a href="">Belmont</a>
  </li>
  <li>
    <a href="">Cardiff</a>
  </li>
  <li>
    <a href="">Central Coast</a>
  </li>
  <li>
    <a href="">Cessnock</a>
  </li>
  <li>
    <a href="">Erina</a>
  </li>
  <li>
    <a href="">Gosford</a>
  </li>
  <li>
    <a href="">Kincumber</a>
  </li>
  <li>
    <a href="">Lake Macquarie</a>
  </li>
  <li>
    <a href="">Lower Hunter</a>
  </li>
  <li>
    <a href="">Maitland</a>
  </li>
  <li>
    <a href="h">Morisset</a>
  </li>
  <li>
    <a href="">Nelson Bay</a>
  </li>
  <li>
    <a href="">Newcastle</a>
  </li>
  <li>
    <a href="">Summerland Point</a>
  </li>
  <li>
    <a href="">Terrigal</a>
  </li>
  <li>
    <a href="">The Entrance</a>
  </li>
  <li>
    <a href="">Toronto</a>
  </li>
  <li>
    <a href="">Umina Beach</a>
  </li>
  <li>
    <a href="">Warners Bay</a>
  </li>
  <li>
    <a href="">Woy Woy</a>
  </li>
  <li>
    <a href="">Annandale</a>
  </li>
  <li>
    <a href="">Ashfield</a>
  </li>
  <li>
    <a href="">Belrose</a>
  </li>
  <li>
    <a href="">Birchgrove</a>
  </li>
  <li>
    <a href="">Brookvale</a>
  </li>
  <li>
    <a href="">Cleveland</a>
  </li>
  <li>
    <a href="">Cromer</a>
  </li>
  <li>
    <a href="">Dee Why</a>
  </li>
  <li>
    <a href="">Dobroyd Point</a>
  </li>
  <li>
    <a href="">Dulwich Hill</a>
  </li>
  <li>
    <a href="">Enmore</a>
  </li>
  <li>
    <a href="">Forestville</a>
  </li>
  <li>
    <a href="">Frenchs Forest</a>
  </li>
  <li>
    <a href="">Haberfield</a>
  </li>
  <li>
    <a href="">Leichhardt</a>
  </li>
  <li>
    <a href="">Lewisham</a>
  </li>
  <li>
    <a href="">Lilyfield</a>
  </li>
  <li>
    <a href="">Manly</a>
  </li>
  <li>
    <a href="">Marrickville</a>
  </li>
  <li>
    <a href="">Mona Vale</a>
  </li>
  <li>
    <a href="">Newport</a>
  </li>
  <li>
    <a href="#">Northern Beaches</a>
  </li>
  <li>
    <a href="#">Rozelle</a>
  </li>
  <li>
    <a href="#">Stanmore</a>
  </li>
  <li>
    <a href="#">Summerhill</a>
  </li>
  <li>
    <a href="#">Warriewood</a>
  </li>
  <li>
    <a href="#">Wollongong</a>
  </li>
</ul>
						  
					   <div class="divider"></div>
					
					 <div class="heading-24">Queensland</div>
								<ul class="suburb-list">
  <li>
    <a href="">Balmain</a>
  </li>
  <li>
    <a href="">Bankstown</a>
  </li>
  <li>
    <a href="">Blacktown</a>
  </li>
  <li>
    <a href="">Bondi</a>
  </li>
  <li>
    <a href="">Campbelltown</a>
  </li>
  <li>
    <a href="">Eastern Creek</a>
  </li>
  <li>
    <a href="">Glebe</a>
  </li>
  <li>
    <a href="">Lugarno</a>
  </li>
  <li>
    <a href="">Liverpool</a>
  </li>
  <li>
    <a href="">Mascot</a>
  </li>
  <li>
    <a href="">Erskine Park</a>
  </li>
  <li>
    <a href="">Mosman</a>
  </li>
  <li>
    <a href="">Newtown</a>
  </li>
  <li>
    <a href="">North Sydney</a>
  </li>
  <li>
    <a href="">Penrith</a>
  </li>
  <li>
    <a href="">Randwick</a>
  </li>
  <li>
    <a href="">Rose Bay</a>
  </li>
  <li>
    <a href="">Ryde</a>
  </li>
  <li>
    <a href="">South Hurstville</a>
  </li>
  <li>
    <a href="">Sutherland</a>
  </li>
  <li>
    <a href="">Western Sydney</a>
  </li>
  <li>
    <a href="">Wetherill Park</a>
  </li>
  <li>
    <a href="">Alexandria</a>
  </li>
  <li>
    <a href="">Belmore</a>
  </li>
  <li>
    <a href="">Cammeray</a>
  </li>
  <li>
    <a href="">Camperdown</a>
  </li>
  <li>
    <a href="">Canterbury</a>
  </li>
  <li>
    <a href="">Chippendale</a>
  </li>
  <li>
    <a href="">Coogee</a>
  </li>
  <li>
    <a href="">Crows Nest</a>
  </li>
  <li>
    <a href="">Earlwood</a>
  </li>
  <li>
    <a href="">Greenacre</a>
  </li>
  <li>
    <a href="">Haymarket</a>
  </li>
  <li>
    <a href="">Kingsford</a>
  </li>
  <li>
    <a href="">Lakemba</a>
  </li>
  <li>
    <a href="">Maroubra</a>
  </li>
  <li>
    <a href="">Marsfield</a>
  </li>
  <li>
    <a href="">Punchbowl</a>
  </li>
  <li>
    <a href="">Regents Park</a>
  </li>
  <li>
    <a href="">Rosebery</a>
  </li>
  <li>
    <a href="">Roselands</a>
  </li>
  <li>
    <a href="">Sefton</a>
  </li>
  <li>
    <a href="">Surry Hills</a>
  </li>
  <li>
    <a href="">Ultimo</a>
  </li>
  <li>
    <a href="">Waterloo</a>
  </li>
  <li>
    <a href="">Zetland</a>
  </li>
  <li>
    <a href="">Baulkham Hills</a>
  </li>
  <li>
    <a href="">Castle Hill</a>
  </li>
  <li>
    <a href="">Chatswood</a>
  </li>
  <li>
    <a href="">Kellyville</a>
  </li>
  <li>
    <a href="">Macquarie Park</a>
  </li>
  <li>
    <a href="">Norwest</a>
  </li>
  <li>
    <a href="h">Pennant Hills</a>
  </li>
  <li>
    <a href="">Avoca Beach</a>
  </li>
  <li>
    <a href="">Bateau Bay</a>
  </li>
  <li>
    <a href="">Belmont</a>
  </li>
  <li>
    <a href="">Cardiff</a>
  </li>
  <li>
    <a href="">Central Coast</a>
  </li>
  <li>
    <a href="">Cessnock</a>
  </li>
  <li>
    <a href="">Erina</a>
  </li>
  <li>
    <a href="">Gosford</a>
  </li>
  <li>
    <a href="">Kincumber</a>
  </li>
  <li>
    <a href="">Lake Macquarie</a>
  </li>
  <li>
    <a href="">Lower Hunter</a>
  </li>
  <li>
    <a href="">Maitland</a>
  </li>
  <li>
    <a href="h">Morisset</a>
  </li>
  <li>
    <a href="">Nelson Bay</a>
  </li>
  <li>
    <a href="">Newcastle</a>
  </li>
  <li>
    <a href="">Summerland Point</a>
  </li>
  <li>
    <a href="">Terrigal</a>
  </li>
  <li>
    <a href="">The Entrance</a>
  </li>
  <li>
    <a href="">Toronto</a>
  </li>
  <li>
    <a href="">Umina Beach</a>
  </li>
  <li>
    <a href="">Warners Bay</a>
  </li>
  <li>
    <a href="">Woy Woy</a>
  </li>
  <li>
    <a href="">Annandale</a>
  </li>
  <li>
    <a href="">Ashfield</a>
  </li>
  <li>
    <a href="">Belrose</a>
  </li>
  <li>
    <a href="">Birchgrove</a>
  </li>
  <li>
    <a href="">Brookvale</a>
  </li>
  <li>
    <a href="">Cleveland</a>
  </li>
  <li>
    <a href="">Cromer</a>
  </li>
  <li>
    <a href="">Dee Why</a>
  </li>
  <li>
    <a href="">Dobroyd Point</a>
  </li>
  <li>
    <a href="">Dulwich Hill</a>
  </li>
  <li>
    <a href="">Enmore</a>
  </li>
  <li>
    <a href="">Forestville</a>
  </li>
  <li>
    <a href="">Frenchs Forest</a>
  </li>
  <li>
    <a href="">Haberfield</a>
  </li>
  <li>
    <a href="">Leichhardt</a>
  </li>
  <li>
    <a href="">Lewisham</a>
  </li>
  <li>
    <a href="">Lilyfield</a>
  </li>
  <li>
    <a href="">Manly</a>
  </li>
  <li>
    <a href="">Marrickville</a>
  </li>
  <li>
    <a href="">Mona Vale</a>
  </li>
  <li>
    <a href="">Newport</a>
  </li>
  <li>
    <a href="#">Northern Beaches</a>
  </li>
  <li>
    <a href="#">Rozelle</a>
  </li>
  <li>
    <a href="#">Stanmore</a>
  </li>
  <li>
    <a href="#">Summerhill</a>
  </li>
  <li>
    <a href="#">Warriewood</a>
  </li>
  <li>
    <a href="#">Wollongong</a>
  </li>
</ul>	 
						
					 <div class="map-area">
							<iframe src="https://www.google.com/maps/d/embed?mid=1ii8-nbOG-WdUdeGhPeqkMlqcjQC5N0FT&ehbc=2E312F" width="100%" height="640"></iframe>
					 </div>
					
			 </div>
	 </section>
	
	<!-- talbot door franchising call action -->
	<?php block('franchising-callaction'); ?>
	
	<!-- talbot door franchising -->
	<section class="pt-pb100 hm-franchise-wr">
	  <div class="container">
			   <div class="hm-franchise">
								<div class="hm-franchise-left">
											<div class="heading-50">Talbot Door Franchising</div>
										 <div class="client-numbers" id="counterdiv">
        					<ul class="cust-list">
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="3"> 0 </span>
																						</div>
																			  <label>Head offices in Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="11"> 0 </span>
																										
																						</div>
																			<label>Regional offices across the Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="150"> 0 </span><span class="plus_no">+</span>
																										
																						</div>
																			<label>Experts working across the country</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																				  <div class="cust-detail">
																										<span class="cust-no counter-value" data-count="1200"> 0 </span> <span class="plus_no">+</span>
																									
																						</div>
																				<label>Completed projects across Australia</label>
																		</div>
														</li>
										</ul>        
										 </div>
										 
									  <div class="selectbox">
													 <select>
															<option>Contact Details</option>
															<option>Contact Details</option>
												  </select>
									  </div>
									
							 </div>
							 <div class="hm-franchise-right">
										<div class="franchise-map">
												<img src="assets/images/map.svg" alt="map" title="" width="606" height="525">
											 <div class="dot dot1"></div>
											 <div class="dot dot2"></div>
											 <div class="dot dot3"></div>
									 </div>
							 </div>
				  </div>
		 </div>
	</section>
	

	
</main>
<?php get_footer();