<?php require_once __DIR__ . '/includes/includes.php'; ?> 
<?php get_header(); ?> 

<main class="productdetail-page">
	
 <section class="pr-detail-top" >
  <div class="container">
   <div class="prdetail-topwr">
    <div class="prdetail-topwr-left">
     <ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
         <a href="#">Products</a>
         <a href="#">Automatic Doors</a>
         <a href="#">Sliding Doors</a>
         <span class="breadcrumb_last" aria-current="page">ASL 250 - Heavy Duty</span>
        </span>
       </span>
      </li>
     </ul>
     <div class="heading-50">ASL 250 - Heavy Duty</div>
    </div>
    <div class="prdetail-topwr-right">
     <p>The ASL250 series automatic door system is an affordable, reliable & intelligent door system, perfect for a wide range of commercial applications. Capable of working with door leaves up to 300Kg for single, biparting and telescopic door configuration with door leaves.</p>
    </div>
   </div>
  </div>
 </section>
	
 <!-- image -->
 <section class="pr-detail-sl site-header">
  <div class="container">
   <ul class="pr-detail-ul">
    <li>
     <div class="pr-detail-li">
      <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="1472" height="650">
     </div>
    </li>
   </ul>
  </div>
 </section>
	
 <!-- link section -->
  <div class="container">
			<div class="quicklink-div">
					<a href="javascript:void(0)" class="quicklink-trigger">Quick Link</a>
					<a href="javascript:void(0)" class="closemenu">
						<img src="assets/images/close-black.png" alt="close" loading="lazy" width="11" height="11">
					</a>
					<div class="side-navigation">
						<ul class="c-ul">
							<li><a href="#feature">Features</a></li>
							<li><a href="#component" >Quality Components</a></li>
							<li><a href="#full-glazing-service" >Full Glazing service</a></li>
							<li><a href="#key-feature">Key Features</a></li>
							<li><a href="#download" >Downloads</a></li>
							<li class="enquiry-button"><a href="#enquiry-now" >Enquiry Now</a></li>
						</ul>
					</div>
				</div>
				 
			  <div class="pr-detail-wr mb-100">
			  	 <div class="pr-detail-left">
									
								 
								
									<!-- feature content -->
								<div data-id="feature" class="content-section">
										<div class="p-title">Product Features</div>
									 <p>The ASL-250 sliding door system has been independently tested by NATA to 1 Million cycles and is fully accredited to AS5007-2007. With a wide range of compatible activation and safety features this system is perfect for any commercial auto door application.</p>
								</div>
								
								<!-- component content -->
								<div data-id="component" class="content-section">
										<div class="p-title">Quality Components</div>
									 <p>Highly efficient long life and high torque brushless DC motor alongside an intelligent microprocessor that automatically detects door weight and adjusts accordingly to ensure smooth door operation.</p>
								</div>
								
								<!-- full-glazing-service -->
								<div data-id="full-glazing-service" class="content-section">
										<div class="p-title">Full Glazing service</div>
										<p>Our in-house fabrication & glazing team can provide everything from framed or frameless door leaves to full shopfronts</p>
								</div>
								
								<!-- key-feature -->
								<div data-id="key-feature" class="content-section">
										<div class="key-label">Key Features</div>
									 <div class="key-border">
										  <ul>
															<li>Our door range uses cutting edge technology with a unique microprocessor system which can rapidly and accurately detect the door size and weight; and set the best operation parameters to make sure the door operates smoothly</li>
													  <li>Long life, high torque brushless DC motor drive system. The helical gear transmission ensures stable and reliable operation with continued use on heavy door leaves.</li>
													  <li>Interlocking option which prevents doors in an airlock situation from opening until the other door has fully closed.</li>
													  <li>Obstruction sensitivity - if when closing it meets an obstruction the doors will automatically re-open as per the AS 5007-2007. When the power is off, the doors are easily manually opened or closed.</li>
													  <li>Includes provision for BMS and fire signal link</li>
													  <li>Available in anodised aluminium or powder coated finishes.</li>
											 </ul>
									 </div>
								</div>
								
								<!-- download -->
								<div data-id="download" class="content-section">
										<div class="dw-wrap">
										  <div class="p-title">Downloads</div>
											 <a href="#" class="link">Request for CAD DWG file.</a>
									 </div>
									
									 <div class="dw-ul">
											 <div class="dw-li">
													 <a href="#">
													 	<div class="dw-img">
																	<img src="assets/images/download-image.jpg" alt="download image" title="" width="" height="">
													  </div>
													  <div class="dw-bottom">
																  <div class="pdf-icon">PDF</div>
																  <div class="pdf-title">ASW 100 Drawing</div>
													  </div>
														</a>	
											 </div>
											<div class="dw-li">
													 <a href="#">
													 	<div class="dw-img">
																	<img src="assets/images/download-image1.jpg" alt="download image" title="" width="" height="">
													  </div>
													  <div class="dw-bottom">
																  <div class="pdf-icon">PDF</div>
																  <div class="pdf-title">ASW 100 Brochure</div>
													  </div>
														</a>	
											 </div>
											<div class="dw-li">
													 <a href="#">
													 	<div class="dw-img">
																	<img src="assets/images/download-image2.jpg" alt="download image" title="" width="" height="">
													  </div>
													  <div class="dw-bottom">
																  <div class="pdf-icon">PDF</div>
																  <div class="pdf-title">ASW 100 Installation Manual</div>
													  </div>
														</a>	
											 </div>
									 </div>
									
								</div>
								
								<div class="pr-techswap">
											<div class="tech-specification">
												<div class="heading-30">Technical Specifications</div>
										  <p>Our in-house fabrication &amp; glazing team can provide everything from framed or frameless door leaves to full shopfronts</p>
											
										  <table>
															<tbody><tr>
																	 <th>Door operating speed:</th>
																	 <td>0.3 - 0.5m/s Adjustable</td>
													  </tr>
													 <tr>
																	 <th>Door leaf weight: </th>
																	 <td>300kg</td>
													  </tr>
													<tr>
																	 <th>Manual open/close force:</th>
																	 <td> &lt;100N </td>
													  </tr>
													<tr>
																	 <th>Operator noise:</th>
																	 <td> &lt;55Db </td>
													  </tr>
													<tr>
																	 <th>Working Voltage:</th>
																	 <td>240V 50 - 60 Hz </td>
													  </tr>
													<tr>
																	 <th>Motor:</th>
																	 <td>24v 100W (Brushless)</td>
													  </tr>
													<tr>
																	 <th>Motor Dimensions:</th>
																	 <td>140mm x 162.5mm</td>
													  </tr>
										  </tbody></table>
										
								 </div>
								 </div>
								
								<!-- enquiry-now -->
								<div data-id="enquiry-now" class="enquire-wrap">
											<div class="enquiry-form">
														<div class="heading-30 text-white">Service Enquire form</div>
																										 <form>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Name">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="email" class="form-control" placeholder="Email Address">
															   </div>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Phone">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Postcode">
															   </div>
																	<div class="form-group">
																				<div class="inputFileHolder">
                <div class="fileinputs">
                  <span class="wpcf7-form-control-wrap" data-name="attch_file">
																			<input size="40" class="wpcf7-form-control wpcf7-text file txt_box_upload inputfile form-control" id="attachment" aria-invalid="false" value="" type="text" name="attch_file">
																	</span>
                  <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc,.jpg,.jpeg,.png,.gif" aria-invalid="false" type="file" name="attachment1">
                    <div class="fakefile">
                      <div class="fakebtn">
                        <img src="assets/images/icon/file-attachment.svg" alt="" title="" width="20" height="23">
                      </div>
                    </div>
                    <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input size="40" class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc" aria-invalid="false" type="file" name="resume">
                    </span>
                    <div class="fakefile">
                      <div class="fakebtn"><img src="assets/images/icon/file-attachment.svg" alt="" title="" width="20" height="23"></div>
                    </div>
                  </span>
                  <span class="filename">Upload Image</span>
                </div>
              </div>
																		  
																		  <label>File types Allowed: gif, png, jpg, jpeg | Max size: 5MB</label>
																		 
            					</div>
																		<div class="form-group">
															   		<textarea class="form-control" placeholder="Message"></textarea>
															   </div>
															   <div class="sub-btnblk">
																				<input type="submit" value="Submit">
															   </div>
													 </form>
											 </div>
								</div>
						 </div>
						 <div class="pr-detail-right">
								
								 <div class="tech-specification">
												<div class="heading-30">Technical Specifications</div>
										  <p>Our in-house fabrication & glazing team can provide everything from framed or frameless door leaves to full shopfronts</p>
											
										  <table>
															<tr>
																	 <th>Door operating speed:</th>
																	 <td>0.3 - 0.5m/s Adjustable</td>
													  </tr>
													 <tr>
																	 <th>Door leaf weight: </th>
																	 <td>300kg</td>
													  </tr>
													<tr>
																	 <th>Manual open/close force:</th>
																	 <td> &lt;100N </td>
													  </tr>
													<tr>
																	 <th>Operator noise:</th>
																	 <td> &lt;55Db </td>
													  </tr>
													<tr>
																	 <th>Working Voltage:</th>
																	 <td>240V 50 - 60 Hz </td>
													  </tr>
													<tr>
																	 <th>Motor:</th>
																	 <td>24v 100W (Brushless)</td>
													  </tr>
													<tr>
																	 <th>Motor Dimensions:</th>
																	 <td>140mm x 162.5mm</td>
													  </tr>
										  </table>
										
								 </div>
									
								<!-- -->
								<div class="call-action-helpway">
									<img src="assets/images/help-way-image.jpg" alt="help-way-image" title="" width="604" height="412">
									<div class="callact-box">
									<div class="cact-title">Help is on the way</div>
									<img src="assets/images/icon/support-icon.svg" alt="support-icon" title="" width="59" height="50">
									<div class="cact-subtitle">Urgent 24/7 support</div>
									<p>For urgent call-out support, call us at <a href="tel:1300560608">1300 560 608</a> Our expert team is ready to provide fast and reliable solutions for any door-related emergency, </p>
									
										<div class="btn-row">
												<a href="tel:1300560608" class="button button-white"><img src="assets/images/icon/phone-icon.svg" alt="phone-icon" title="" width="27" height="27">NSW: 1300 560 608</a>
												<a href="#" class="button button-black">Request a Quote</a>
										 </div>
									</div>
								</div>
								
						 </div>
			  </div>
			
		</div>
 
	<!-- completed project -->
	<section class="pr-ul-sec bg-grey-yellow pt-pb100 top-curve">
		 <div class="container">
				  <div class="heading-30">Completed Projects</div>
				  <div class="project-ul-wrap">
								<div class="project-li">
										<div class="project-liwr">
												<div class="project-img">
													 <img src="assets/images/project-image.jpg" alt="project image" width="350" height="350">
											 </div>
											 <div class="project-content">
														<div class="project-title">Biparting Sliding Doors With Side Swing Door</div>
													 <div class="project-ul">
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/user-icon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Client</div>
																			 <div class="pr-info">Commercial</div>
																	 </div>
															 </div>
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/date-icon.svg" alt="date icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Date</div>
																			 <div class="pr-info">November 2015</div>
																	 </div>
															 </div>
																<div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/map-markericon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Info</div>
																			 <div class="pr-info">Parkside Plaza - Miranda</div>
																	 </div>
															 </div>
													 </div>
											 </div>
									 </div>
							 </div>
							 
							 <div class="project-li">
										<div class="project-liwr">
												<div class="project-img">
													 <img src="assets/images/project-image-1.jpg" alt="project image" width="350" height="350">
											 </div>
											 <div class="project-content">
														<div class="project-title">Bifold Gate & Fence Panels</div>
													 <div class="project-ul">
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/user-icon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Client</div>
																			 <div class="pr-info">Residential Project</div>
																	 </div>
															 </div>
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/date-icon.svg" alt="date icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Date</div>
																			 <div class="pr-info">November 2015</div>
																	 </div>
															 </div>
																<div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/map-markericon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Info</div>
																			 <div class="pr-info">Revesby</div>
																	 </div>
															 </div>
													 </div>
											 </div>
									 </div>
							 </div> 
															<div class="project-li">
										<div class="project-liwr">
												<div class="project-img">
													 <img src="assets/images/project-image.jpg" alt="project image" width="350" height="350">
											 </div>
											 <div class="project-content">
														<div class="project-title">Biparting Sliding Doors With Side Swing Door</div>
													 <div class="project-ul">
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/user-icon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Client</div>
																			 <div class="pr-info">Commercial</div>
																	 </div>
															 </div>
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/date-icon.svg" alt="date icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Date</div>
																			 <div class="pr-info">November 2015</div>
																	 </div>
															 </div>
																<div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/map-markericon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Info</div>
																			 <div class="pr-info">Parkside Plaza - Miranda</div>
																	 </div>
															 </div>
													 </div>
											 </div>
									 </div>
							 </div>
							 
							 <div class="project-li">
										<div class="project-liwr">
												<div class="project-img">
													 <img src="assets/images/project-image-1.jpg" alt="project image" width="350" height="350">
											 </div>
											 <div class="project-content">
														<div class="project-title">Bifold Gate & Fence Panels</div>
													 <div class="project-ul">
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/user-icon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Client</div>
																			 <div class="pr-info">Residential Project</div>
																	 </div>
															 </div>
															 <div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/date-icon.svg" alt="date icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Date</div>
																			 <div class="pr-info">November 2015</div>
																	 </div>
															 </div>
																<div class="pr-li">
																		<div class="pr-icon">
																			<img src="assets/images/icon/map-markericon.svg" alt="user icon" title="" width="20" height="20">
																	 </div>
																	 <div class="pr-desc">
																				<div class="pr-name">Info</div>
																			 <div class="pr-info">Revesby</div>
																	 </div>
															 </div>
													 </div>
											 </div>
									 </div>
							 </div> 
				  </div>
		 </div>
		
		 <?php block('client-logo'); ?>
		
	</section>
	
</main> 

<?php get_footer();