<footer>
	 <div class="container">
	  <div class="footer-top">
						<div class="footer-top-left">
						 <div class="heading-40 text-white">Repair and service for Residential and Commercial</div>
				  </div>
				  <div class="footer-top-right">
								<a href="tel:1300560608" class="button button-white"><img src="assets/images/icon/phone.svg" alt="" title="" width="11" height="11">1300 560 608</a>
							 <a href="#" class="button button-theme">Get a Free Quote</a>
				  </div>
	  </div>
	  <div class="footer-middle">
					<div class="footer-middle-wrap">
							 <div class="ft-md-left">
											<a href="#">
									  		<img src="assets/images/talbot-logo-image.svg" alt="talbot-logo-image" title="" width="198" height="52">
									  </a>
										
									  <div class="ft-address-box">
													<div class="ft-address-label">NSW Address (Head Office)</div>
												 <div class="ft-address-ul">
														 <div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																 <div class="ftadd-detail">8/63 Norman St,Peakhurst, NSW 2210</div>
														 </div>
														<div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/phone-b.svg" alt="map-marker" title="" width="14" height="14"></div>
																 <div class="ftadd-detail"><a href="tel:1300560608">1300 560 608</a></div>
														 </div>
														<div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																 <div class="ftadd-detail"><a href="mailto:sales@talbotautodoors.com.au">sales@talbotautodoors.com.au</a></div>
														 </div>
												 </div>
									  </div>
									   
									   <div class="ft-address-box">
													<div class="ft-address-label">QLD Address</div>
												 <div class="ft-address-ul">
														 <div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																 <div class="ftadd-detail">Unit GO28, 130 East-West Arterial Rd, Hendra QLD 4011</div>
														 </div>
														<div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/phone-b.svg" alt="map-marker" title="" width="14" height="14"></div>
																 <div class="ftadd-detail"><a href="tel:1300560608">1300 560 608</a></div>
														 </div>
														<div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																 <div class="ftadd-detail"><a href="mailto:qld@talbotautodoors.com.au">qld@talbotautodoors.com.au</a></div>
														 </div>
												 </div>
									  </div>
									
									 <div class="ft-address-box">
													<div class="ft-address-label">VIC Address</div>
												 <div class="ft-address-ul">
														 <div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																 <div class="ftadd-detail">12 Cambridge Street,Seaholme, Vic 3018</div>
														 </div>
														<div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/phone-b.svg" alt="map-marker" title="" width="14" height="14"></div>
																 <div class="ftadd-detail"><a href="tel:0422936188">0422 936 188</a></div>
														 </div>
														<div class="ft-address-li">
																 <div class="ftadd-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																 <div class="ftadd-detail"><a href="mailto:steven@talbotautodoors.com.au">steven@talbotautodoors.com.au</a></div>
														 </div>
												 </div>
									  </div>
									
						  </div>
						  <div class="ft-md-right">
										<div class="ft-list">
											 <div class="ft-title">Our Services </div>
											 <div class="ft-block">
														<ul>
																	<li><a href="#">Routine Preventative Maintenance</a></li>
															  <li><a href="#">Emergency Repairs</a></li>
															  <li><a href="#">Retrofit Upgrades</a></li>
															  <li><a href="#">New Installations</a></li>
													 </ul>
											 </div>
									 </div>
									<div class="ft-list">
											 <div class="ft-title">Automatic Doors</div>
											 <div class="ft-block">
														<ul>
																	<li><a href="#">Sliding Doors </a></li>
															  <li><a href="#">Swing Doors</a></li>
															  <li><a href="#">Revolving Doors</a></li>
															  <li><a href="#">Accessible Door Solutions</a></li>
													 </ul>
											 </div>
									 </div>
									<div class="ft-list">
											 <div class="ft-title">Automatic Gates</div>
											 <div class="ft-block">
														<ul>
																	<li><a href="#">Bi-Fold Gates</a></li>
															  <li><a href="#">Telescopic Gates</a></li>
															  <li><a href="#">Boom Gates</a></li>
															  <li><a href="#">Curved Gates</a></li>
															  <li><a href="#">Sliding Garage Doors</a></li>
													 </ul>
											 </div>
									 </div>
									<div class="ft-list">
											 <div class="ft-title">Quick Links</div>
											 <div class="ft-block">
														<ul>
																	<li><a href="#">Home</a></li>
															  <li><a href="#">Franchise Opportunities </a></li>
															  <li><a href="#">Areas We Serve</a></li>
															  <li><a href="#">Contact </a></li>
													 </ul>
											 </div>
									 </div>
									 <div class="ft-block-logo">
											 <div class="ft-logo"><img src="assets/images/NATA-logo.png" alt="NATA-logo" title="" width="181" height="88"></div>
											 <div class="ft-logo"><img src="assets/images/CM-logo.png" alt="CM-logo" title="" width="135" height="61"></div>
									 </div>
						  </div>
				 </div>
	  </div>
	  <div class="footer-bottom">
		   <p>&copy; Copyright 2025 Talbot Auto Doors. All Rights Reserved.</p>
	  </div>
		 </div>	
		<button class="scrollTop vis" style="opacity: 1;"><i class="fa fa-angle-up" aria-hidden="true"></i> </button>
</footer>

<?php wp_footer(); ?>

</body>

</html>