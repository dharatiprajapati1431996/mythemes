<?php require_once __DIR__ . '/includes/includes.php'; ?> 
<?php get_header(); ?> 
<main class="service-page">
 <!-- Inner banner  -->
 <section class="inner-banner">
  <img src="assets/images/contact-banner.jpg" alt="contact banner image" title="" width="1920" height="650" class="bgimg">
  <div class="container">
   <div class="inbanner-content">
    <div class="inbanner-cnt-left">
     <div class="heading-50">Contact Us</div>
    </div>
    <div class="inbanner-cnt-right">
     <ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
         <span class="breadcrumb_last" aria-current="page">Contact Us</span>
        </span>
       </span>
      </li>
     </ul>
    </div>
   </div>
  </div>
 </section>
 <section class="top-space-curve">
 
		<section class="contact-wrap">
			 <div class="container">
						<div class="cnt-wrap mb-100">
								<div class="cnt-left enquire-wrap">
										<div class="enquiry-form">
														<div class="heading-30 text-white">Get in Touch</div>
													 <form>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Name">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="email" class="form-control" placeholder="Email Address">
															   </div>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Phone">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Postcode">
															   </div>
																	<div class="form-group">
																				<div class="inputFileHolder">
                <div class="fileinputs">
                  <span class="wpcf7-form-control-wrap" data-name="attch_file">
																			<input size="40" class="wpcf7-form-control wpcf7-text file txt_box_upload inputfile form-control" id="attachment" aria-invalid="false" value="" type="text" name="attch_file">
																	</span>
                  <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc,.jpg,.jpeg,.png,.gif" aria-invalid="false" type="file" name="attachment1">
                    <div class="fakefile">
                      <div class="fakebtn">
                        <img src="assets/images/icon/file-attachment.svg" alt="" title="" width="20" height="23">
                      </div>
                    </div>
                    <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input size="40" class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc" aria-invalid="false" type="file" name="resume">
                    </span>
                    <div class="fakefile">
                      <div class="fakebtn"><img src="assets/images/icon/file-attachment.svg" alt="" title="" width="20" height="23"></div>
                    </div>
                  </span>
                  <span class="filename">Upload Image</span>
                </div>
              </div>
																		  
																		  <label>File types Allowed: gif, png, jpg, jpeg | Max size: 5MB</label>
																		 
            					</div>
																		<div class="form-group">
															   		<textarea class="form-control" placeholder="Message"></textarea>
															   </div>
															   <div class="sub-btnblk">
																				<input type="submit" value="Submit">
															   </div>
													 </form>
											 </div>
							 </div>
							 <div class="cnt-right">
									 <div class="count-right">
											 <div class="heading-26 text-center text-white">Open Your Doors to The Future</div>
											 <div class="cnt-contact-label">Talbot Door Franchising</div>
												<div class="client-numbers" id="counterdiv">
													<ul class="cust-list">
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="3"> 0 </span>
																						</div>
																			  <label>Head offices in Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="11"> 0 </span>
																										
																						</div>
																			<label>Regional offices across the Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="150"> 0 </span><span class="plus_no">+</span>
																										
																						</div>
																			<label>Experts working across the country</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																				  <div class="cust-detail">
																										<span class="cust-no counter-value" data-count="1200"> 0 </span> <span class="plus_no">+</span>
																									
																						</div>
																				<label>Completed projects across Australia</label>
																		</div>
														</li>
										</ul>        
											</div>
											 <div class="selectbox mb-20">
													 <select>
															<option>Contact Details</option>
															<option>Contact Details</option>
												  </select>
									  </div>
												<div class="button button-black button-full">Apply for Franchise Now</div>
									 </div>
							 </div>
					 </div>
					
					 <div class="divider"></div>
					
			 </div>
		</section>
		
		<!-- Our Location -->
  <?php block('location-section'); ?>
		
		
 </section>
</main> 
<?php get_footer();