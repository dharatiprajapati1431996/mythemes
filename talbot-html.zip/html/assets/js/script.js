$(document).ready(function () {
	
  /*Scroll top*/
  var scrollTop = $(".scrollTop");
  $(window).scroll(function () {
    var topPos = $(this).scrollTop();
    if (topPos > 0) {
      $(scrollTop).css("opacity", "1", "transform", "scale(1)");
      $(".scrollTop").addClass("vis");
    } else {
      $(scrollTop).css("opacity", "0", "transform", "scale(0)");
      $(".scrollTop").removeClass("vis");
    }
  });
  $(scrollTop).click(function () {
    $("html, body").animate(
      {
        scrollTop: 0,
      },
      600
    );
    return false;
  });
	
  // FOOTER
  $(".ft-title").click(function () {
    if ($(window).width() < 992) {
      let $this = $(this);

      $this.toggleClass("showhide");

      let $wrapper = $this.closest(".ftblock");
      let $heads = $wrapper.find(".ft-title");

      $heads.not($this).removeClass("showhide");
      $heads.not(".showhide").next().stop().slideUp(300);
      $heads.filter(".showhide").next().stop().slideDown(300);
    }
  });
  
 	$('.marquee').slick({
        speed: 9000,
        autoplay: true,
        autoplaySpeed: 0,
        centerMode: false,
        cssEase: 'linear',
        slidesToShow: 1,
        draggable: true,
        focusOnSelect: true,
        slidesToScroll: 1,
        variableWidth: true,
        infinite:true,
        initialSlide: 1,
        arrows: false 
    });
});


/*script for search box */
		$('.searchtop_icon').click(function(e) {
		  if ($('.searchtop_icon').hasClass('opened')) {
		    	$('.searchtop_icon').removeClass('opened').addClass('closed');
		    	$('.search-container').removeClass('opened').addClass('closed');
		    	$('#search-terms').focus();
		  } else {
		    	$('.searchtop_icon').removeClass('closed').addClass('opened');
		    	$('.search-container').removeClass('closed').addClass('opened');
		  }
		   e.stopPropagation();
		});