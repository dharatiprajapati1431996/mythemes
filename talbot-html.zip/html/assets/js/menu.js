$(document).ready(function () {

	/*-----MENU DROPDOWN-----*/

	$('.menu-link ul li:has(ul)').addClass("haschild");
	var caicon = $('<i class="fa fa-angle-down menudrop" aria-hidden="true"></i>');
	$('.menu-link ul li:has(ul) > a').append(caicon);
	$('.menu-link ul li:has(ul) > a').next().addClass("childmenu");


$('.menu-link  .dropmenu ul>li.level').on('mouseenter', function () {
				$(this).siblings().removeClass('menu-item-hover');
				$(this).addClass('menu-item-hover');
	});
	

	
	
	$('.menudrop').on('click', function (e) {
		var label = $(this).parent();
		var parent = label.parent('.haschild');
		var list = label.siblings('.childmenu');

		e.preventDefault();
		if (parent.hasClass('isopen')) {
			list.slideUp('fast');
			parent.removeClass('isopen');
		} else {

			parent.parent().find('li.haschild').removeClass('isopen');
			parent.parent().find('li.haschild .childmenu').slideUp(350);

			list.slideDown('fast');
			parent.addClass('isopen');
		}
	});

	/*-----BURGER MENU-----*/
	$(".togglebtn, .overlay").click(function () {
		$(".togglebtn, .overlay,.menu-link").toggleClass("active");
		if ($(".overlay").hasClass("active")) {
			$(".overlay").fadeIn();
			$('html').addClass('menuhidden');

		} else {
			$(".overlay").fadeOut();
			$('html').removeClass('menuhidden');

		}
	});



	 /*-----when there is no inner banner -----*/
  if($('main').hasClass("productdetail-page")){ 
     $("body").addClass("header-black");
			}
	
});
			 
	 


	/*-----FIXED HEADER-----*/
$(window).scroll(function () {
		if (($(window).scrollTop() > 180) && ($(window).width() >= 576)) {
			$('body').addClass('fixed-header');
		} else {
			$('body').removeClass('fixed-header');
		}
	});




	


   
    

    