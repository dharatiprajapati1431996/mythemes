$(document).ready(function(){

			$('.testimonial-ul').slick({
						dots: false,
      arrows:true,    
      infinite: true,
      speed: 300,
      slidesToShow: 2,
      slidesToScroll: 1,
		     prevArrow:"<div class='prev slick-prev''><img class='a-left' src='assets/images/testimoanil-ar-left.svg' width='15' height='15'></div>",
    			nextArrow:"<div class='next slick-next'><img class='a-right' src='assets/images/testimoanil-ar-right.svg' width='15' height='15'></div>",
      responsive: [
        {
          breakpoint:992,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
											 
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
										
          }
        }
        
      ]
    });
    

});

