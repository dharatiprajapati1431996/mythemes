$(document).ready(function() {
   $('#location-tab').easyResponsiveTabs({
    type:'default', 
    width:'auto',
    fit:true, 
    activate:function(event){ }
  });
});

