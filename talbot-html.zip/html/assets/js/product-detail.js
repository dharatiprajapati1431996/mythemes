$(window).scroll(function () {
	var headerHeight = $('.site-header').innerHeight();
   if ($(window).scrollTop() >= headerHeight) {
      $('.side-navigation').addClass('fixed');
    } else {
      $('.side-navigation').removeClass('fixed');
    }
});

jQuery(document).ready(function ($) {
	function navigate() {
		var $elem = $('[data-id="' + location.hash.replace('#', '') + '"]');
		if ($elem.length) {
			setTimeout(function () {
				var offset = $elem.offset().top - $('.header-top').height();
				var addoffset = 70;

				if ($(window).width() <= 767) {
					addoffset = 200;
				}

				$('html, body').animate({
					scrollTop: offset - addoffset
				});
			}, 1000);
		}
	}
	navigate();

	$('a[href*="#"]').click(function () {
		location.href = $(this).attr('href');
		navigate();
	});


	
	
		$('.project-ul-wrap').slick({
						dots: false,
      arrows:true,    
      infinite: true,
      speed: 300,
      slidesToShow: 2,
      slidesToScroll: 1,
			    prevArrow:"<div class='prev slick-prev''><img class='a-left' src='assets/images/testimoanil-ar-left.svg' width='15' height='15'></div>",
    			nextArrow:"<div class='next slick-next'><img class='a-right' src='assets/images/testimoanil-ar-right.svg' width='15' height='15'></div>",
      responsive: [
        {
          breakpoint:992,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
											 
          }
        },
							{
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll:1,
											centerMode:true,
											centerPadding:'60px',
          }
        }
        
      ]
    });
	

});

