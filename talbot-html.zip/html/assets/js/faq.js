jQuery(document).ready(function($){
	$(".step-accordion").smk_Accordion({
			activeIndex:1,  
			showIcon:true, //boolean
			animation:true, //boolean
			closeAble:true, //boolean
			slideSpeed:200 //integer, miliseconds
	});

		$(".franchise-accordion").smk_Accordion({
				activeIndex:1,  
				showIcon:true, //boolean
				animation:true, //boolean
				closeAble:true, //boolean
				slideSpeed:200 //integer, miliseconds
	});
	
});
