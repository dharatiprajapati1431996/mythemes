$(document).ready(function () {

  /* home banner*/
  $(".js-hmbanner").slick({
    autoplay:false,
    slidesToShow: 1,
    arrows:false,
    fade: true,
    dots:false,
  });

 /*our product on click display section */
	$('.pr-link-li').first().addClass('active');

	$('.pr-link-li').click(function(){
  var $this = $(this);
  $siblings = $this.parent().children(),
  position = $siblings.index($this);
  console.log (position);
  
  $('.pr-link-content .pr-link-tab').removeClass('active').eq(position).addClass('active');
  
  $siblings.removeClass('active');
  $this.addClass('active');
})
	
});

