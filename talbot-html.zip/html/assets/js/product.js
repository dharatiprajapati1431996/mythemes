$(document).ready(function(){
	
		$('#commercialTab').easyResponsiveTabs({ 
				type: 'vertical',   
				fit: true,   
				closed: 'accordion', 
				activate: function(){}
		});

});
