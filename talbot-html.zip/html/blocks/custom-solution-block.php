		<section class="custom-callaction-sec mb-100">
			 <div class="container">
							<div class="custom-callact-sec">
								 <img src="assets/images/custom-callaction-bgimage.jpg" alt="custom-callaction-bgimage" title="" width="1472" height="200" class="bgimg">
								 <div class="custom-callwr">
								 		<div class="cust-logo">
											<img src="assets/images/custom-solution-logo.svg" alt="custom-solution-logo" title="" width="370" height="66">
								 </div>
								 		<div class="cust-right">
											 <div class="cust-content">
																<p>Custom-sized to precisely fit into doorways and portals industrial and commercial doors come in both automatic and swing varieties, allowing you to find the right type to suit your needs and requirements.</p>
												</div>
											 <div class="cust-btn">
												<a href="tel:1300560608" class="button button-white"><img src="assets/images/icon/phone-icon.svg" alt="phone-icon" title="" width="27" height="27">NSW: 1300 560 608</a>
												<a href="#" class="button button-theme">Get a Free Quote</a>
										 </div>
								 </div>
									</div>	
					  </div>
			 </div>
		</section>