	<section class="service-sec mb-100">
	  <div class="container">
						<div class="heading-50 text-center">Explore our Services</div>
				  <div class="service-ul"> 
							 <div class="service-li">
									 <a href="#">
											<div class="service-li-block">
													<div class="service-img-wr">
														<img src="assets/images/routine-maintenance.jpg" alt="routine-maintenance" title="" width="358" height="460">
														<div class="s-title">Routine Preventative Maintenance</div>
												 </div> 
												 <div class="service-explore">
															Explore<img src="assets/images/icon/arrow-right.svg" alt="arrow-right" width="14" height="14">
												 </div>
									  </div>
										</a>	
							 </div>
							<div class="service-li">
									 <a href="#">
											<div class="service-li-block">
													<div class="service-img-wr">
														<img src="assets/images/emergency-repairs.jpg" alt="emergency-repairs" title="" width="358" height="460">
														<div class="s-title">Emergency<br> Repairs</div>
												 </div> 
												 <div class="service-explore">
															Explore<img src="assets/images/icon/arrow-right.svg" alt="arrow-right" width="14" height="14">
												 </div>
									  </div>
										</a>	
							 </div>
							<div class="service-li">
									 <a href="#">
											<div class="service-li-block">
													<div class="service-img-wr">
														<img src="assets/images/new-installation.jpg" alt="new-installation" title="" width="358" height="460">
														<div class="s-title">New<br> Installations</div>
												 </div> 
												 <div class="service-explore">
															Explore<img src="assets/images/icon/arrow-right.svg" alt="arrow-right" width="14" height="14">
												 </div>
									  </div>
										</a>	
							 </div>
							<div class="service-li">
									 <a href="#">
											<div class="service-li-block">
													<div class="service-img-wr">
														<img src="assets/images/retrofit-upgrades.jpg" alt="retrofit-upgrades" title="" width="358" height="460">
														<div class="s-title">Retrofit<br> Upgrades</div>
												 </div> 
												 <div class="service-explore">
															Explore<img src="assets/images/icon/arrow-right.svg" alt="arrow-right" width="14" height="14">
												 </div>
									  </div>
										</a>	
							 </div>
				  </div>
		 </div>
	</section>