<!-- banner section start -->
<section class="sec-hmbanner">
  <ul class="js-hmbanner">
							<li>
										<div class="hmbanner-li">
												 <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-desk" width="1920" height="913">
											  <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-mob" width="1920" height="913">
													<div class="ol-hmbanner">
                <div class="container">
																		  <div class="olhmban-wrap-bx">
                     <div class="olhmban-wrap">
                    		 <div class="olhmban-title">
																								Trusted Local Service For High-quality and Automatic Doors
																						 </div>
																						 <a href="#" class="button button-white">Get a Free Quote <img src="assets/images/icon/arrow-right.svg" alt="arrow-right" title="" width="14" height="14"></a>
																					</div>
																				</div>	
                 </div>
             </div>
											</div>
						  </li>
							<li>
										<div class="hmbanner-li">
												 <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-desk" width="1920" height="913">
												 <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-mob" width="1920" height="913">	
											<div class="ol-hmbanner">
                 <div class="container">
																		  <div class="olhmban-wrap-bx">
                     <div class="olhmban-wrap">
                    		 <div class="olhmban-title">
																								Trusted Local Service For High-quality and Automatic Doors
																						 </div>
																						 <a href="#" class="button button-white">Get a Free Quote <img src="assets/images/icon/arrow-right.svg" alt="arrow-right" title="" width="14" height="14"></a>
																					</div>
																				</div>	
                 </div>
             </div>
											</div>
						  </li>
				</ul>
		
	 <!-- bottom banner -->
	 <div class="hmbanner-bottom">
			<div class="container">
						<div class="hmbanner-bottom-wr">
									<div class="hmban-link">
											<ul class="hmban-ul">
														<li><a href="#">Automatic Doors</a></li>
												  <li><a href="#">Automatic Gates</a></li>
												  <li><a href="#">Custom Solutions</a></li>
										 </ul>
							  </div>
							 <div class="hmban-arrow">
											<a href="#"><img src="assets/images/icon/arrow-white.svg" alt="arrow-white" title="" width="27" height="27"></a>
							  </div>
				  </div>
			</div>
	 </div>
	
</section>
<!-- banner section end -->