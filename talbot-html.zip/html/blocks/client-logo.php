  <section class="client-logo-sec mb-100">
   <div class="container">
    <div class="heading-30 text-center">Some of Our Clients</div>
    <div class="c-logo-ul">
     <div class="c-logo-li">
      <div class="c-logo-li-wr">
       <img src="assets/images/knight-frank-logo.png" alt="knight frank logo" title="" width="168" height="84">
      </div>
     </div>
     <div class="c-logo-li">
      <div class="c-logo-li-wr">
       <img src="assets/images/cbre-logo.png" alt="cbre-logo" title="" width="168" height="84">
      </div>
     </div>
     <div class="c-logo-li">
      <div class="c-logo-li-wr">
       <img src="assets/images/jll-logo.png" alt="jll-logo" title="" width="168" height="84">
      </div>
     </div>
     <div class="c-logo-li">
      <div class="c-logo-li-wr">
       <img src="assets/images/chesterton-logo.png" alt="chesterton-logo" title="" width="168" height="84">
      </div>
     </div>
     <div class="c-logo-li">
      <div class="c-logo-li-wr">
       <img src="assets/images/dtz-logo.png" alt="dtz-logo" title="" width="168" height="84">
      </div>
     </div>
     <div class="c-logo-li">
      <div class="c-logo-li-wr">
       <img src="assets/images/colliers-logo.png" alt="Colliers-logo" title="" width="168" height="84">
      </div>
     </div>
    </div>
   </div>
  </section>