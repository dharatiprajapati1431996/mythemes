		<section class="sec-location mb-100">
			 <div class="container">
								
					  <!-- -->
					  <div class="label-title mb-0">Talbot Auto Doors</div>
							<div class="heading-34 mb-0">Our Location</div>	
						
			    <div id="location-tab">
         <ul class="resp-tabs-list">
                <li>NSW Address (Head Office)</li>
                <li>Queensland</li>
                <li>Victoria</li>
            </ul>
								 <div class="resp-tabs-container">
          <div class="location-tp">
													<div class="location-tab">
																<div class="location-tab-wr">
																		 <img src="assets/images/south-wales-image.jpg" alt="south-wales-image" title="" width="1472" height="700" class="bgimg">
																	  <div class="location-box-wr">
																				  <div class="location-box">
																								 <div class="location-title">New South Wales</div>
																							   <ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>Head Office</label>
																																8/63 Norman St, Peakhurst, NSW 2210 Australia.
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:1300560608">1300 560 608</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:sales@talbotautodoors.com.au">sales@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																										<ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>Western Sydney</label>
																																Tek Temel
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:0404088310">0404 088 310</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:westernsydney@talbotautodoors.com.au">westernsydney@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																										<ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>North West Sydney, North Sydney</label>
																																Lee Buckley
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:0410700511">0410 700 511</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:lee@talbotautodoors.com.au">lee@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																							 		<ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>Head Office</label>
																																8/63 Norman St, Peakhurst, NSW 2210 Australia.
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:1300560608">1300 560 608</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:sales@talbotautodoors.com.au">sales@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																										<ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>Western Sydney</label>
																																Tek Temel
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:0404088310">0404 088 310</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:westernsydney@talbotautodoors.com.au">westernsydney@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																										<ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>North West Sydney, North Sydney</label>
																																Lee Buckley
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:0410700511">0410 700 511</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:lee@talbotautodoors.com.au">lee@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																				  </div>
																	  </div>
														  </div>
													</div>
										</div>
										<div class="location-tp">
													<div class="location-tab">
																<div class="location-tab-wr">
																		 <img src="assets/images/south-wales-image.jpg" alt="south-wales-image" title="" width="1472" height="700" class="bgimg">
																	  <div class="location-box-wr">
																				  <div class="location-box">
																								 <div class="location-title">Queensland</div>
																							   <ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>Head Office</label>
																																Unit GO28, 130 East-West Arterial Rd,Hendra QLD 4011
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:1300560608">1300 560 608</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:qld@talbotautodoors.com.au">qld@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																					 </div>
																	  </div>
														  </div>
													</div>
										</div>
										<div class="location-tp">
													<div class="location-tab">
																<div class="location-tab-wr">
																		 <img src="assets/images/south-wales-image.jpg" alt="south-wales-image" title="" width="1472" height="700" class="bgimg">
																	  <div class="location-box-wr">
																				  <div class="location-box">
																								 <div class="location-title">VICTORIA</div>
																							   <ul class="location-ul">
																							  		 <li>
																														<div class="l-icon"><img src="assets/images/icon/map-marker.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<label>Head Office</label>
																																12 Cambridge Street, Seaholme, Vic 3018
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/phone.svg" alt="map-marker" title="" width="11" height="11"></div>
																													 <div class="l-dtl">
																													 		<a href="tel:0422936188">0422936188</a>
																													 </div>
																										  </li>
																										 <li>
																														<div class="l-icon"><img src="assets/images/icon/envelope-icon.svg" alt="map-marker" title="" width="22" height="22"></div>
																													 <div class="l-dtl">
																													 		<a href="mailto:steven@talbotautodoors.com.au">steven@talbotautodoors.com.au</a>
																													 </div>
																										  </li>
																							  </ul>
																					 </div>
																	  </div>
														  </div>
													</div>
										</div>
								 </div>
						</div>
			 </div>
		</section>
