	<section class="whychoose-sec mb-100">
	  <div class="container">
					 <div class="whychoose-wrap">
								<div class="common-block-wrap">
										<div class="common-block-left">
												<div class="heading-40 text-white">Why Choose Talbot Automatic Doors and Gates?</div>
									 </div>
									 <div class="common-block-right">
												<p>Our trained technicians provide routine services to ensure faults are rectified before any failure and compromise to the building security occurs. We offer a full door service including stairwell and tenancy hydraulic closing doors.</p>
									 </div>
							 </div>
							
							 <div class="whychoose-ul">
									<div class="whychoose-li">
											<div class="whychoose-liwr">
												 <div class="whychoose-icon"><img src="assets/images/icon/integrity-icon.svg" alt="integrity-icon" title="" width="90" height="86"></div>
												 <div class="whychoose-bottom">
																<div class="whychs-label">Integrity</div>
														  <div class="whychs-detail">
																		<p>Talbot is built on honesty, care and integrity. Talbot management </p>
														  </div>
												 </div>
										 </div>
									</div>
									<div class="whychoose-li">
											<div class="whychoose-liwr">
												 <div class="whychoose-icon"><img src="assets/images/icon/whs-icon.svg" alt="whs-icon" title="" width="90" height="86"></div>
												 <div class="whychoose-bottom">
																<div class="whychs-label">WH&S</div>
														  <div class="whychs-detail">
																		<p>Talbot takes work health and safety very seriously and ensures</p>
														  </div>
												 </div>
										 </div>
									</div>
									<div class="whychoose-li">
											<div class="whychoose-liwr">
												 <div class="whychoose-icon"><img src="assets/images/icon/technical-competence-icon.svg" alt="technical-competence-icon" title="" width="90" height="86"></div>
												 <div class="whychoose-bottom">
																<div class="whychs-label">Technical Competence</div>
														  <div class="whychs-detail">
																		<p>Talbot technicians are all trained electricians and have further specialist </p>
														  </div>
												 </div>
										 </div>
									</div>
									<div class="whychoose-li">
											<div class="whychoose-liwr">
												 <div class="whychoose-icon"><img src="assets/images/icon/systemizatlon-icon.svg" alt="systemizatlon-icon" title="" width="90" height="86"></div>
												 <div class="whychoose-bottom">
																<div class="whychs-label">Systemization</div>
														  <div class="whychs-detail">
																		<p>Our market leading web based job tracking system ensures that all work is recorded</p>
														  </div>
												 </div>
										 </div>
									</div>
									<div class="whychoose-li">
											<div class="whychoose-liwr">
												 <div class="whychoose-icon"><img src="assets/images/icon/emergency.svg" alt="emergency-icon" title="" width="90" height="86"></div>
												 <div class="whychoose-bottom">
																<div class="whychs-label">24/7 emergency</div>
														  <div class="whychs-detail">
																		<p>Our One Stop comprehensive Door, Shutter and Gate service allows your routine</p>
														  </div>
												 </div>
										 </div>
									</div>
							 </div>
							
				  </div>
		 </div>
	</section>