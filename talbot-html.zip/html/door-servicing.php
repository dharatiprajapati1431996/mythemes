<?php require_once __DIR__ . '/includes/includes.php'; ?> <?php get_header(); ?> <main class="service-page">
 <!-- Inner banner  -->
 <section class="inner-banner">
  <img src="assets/images/service-detail-banner-image.jpg" alt="service detail banner image" title="" width="1920" height="650" class="bgimg">
  <div class="container">
   <div class="inbanner-content">
    <div class="inbanner-cnt-left">
     <div class="heading-50">Door Servicing</div>
    </div>
    <div class="inbanner-cnt-right">
     <ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
         <a href="#">Services</a>
         <span class="breadcrumb_last" aria-current="page">Door Servicing</span>
        </span>
       </span>
      </li>
     </ul>
    </div>
   </div>
  </div>
 </section>
 <section class="top-space-curve">
  <!-- content section -->
  <section class="content-wrapper mb-100">
   <div class="container">
    <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
     <div class="ctent-block">
      <div class="heading-26">Pedestrian door servicing is required at least 3 time per years as per the Australian Auto Door standard.</div>
      <p>Talbot Automatic Doors and gates have a team of specialist technicians that are trained in the service, maintenance and repairs of all doors, gates, and shutters.</p>
      <p>Our technician provides service reports confirming that the safety of the doors is working correctly and proof that your doors have been correctly maintained. Any recommended works will be quoted and sent to your for approval.</p>
      <p>Our automatic gates and doors servicing include a comprehensive checklist on the various types of doors. Detailed below are the items checked on the various doors, gates and roller shutters.</p>
     </div>
     <div class="ctent-img">
      <div class="ctent-logo-wr">
       <img src="assets/images/door-servicing-image.jpg" alt="door-servicing-image" title="" width="670" height="417">
      </div>
     </div>
    </div>
   </div>
  </section>
  <!-- automatic Door and gate service -->
  <section class="auto-doorservice mb-100">
   <div class="container">
    <div class="auto-doorservice-wr">
     <div class="doorservice-left">
      <div class="heading-30">Automatic Door And Gate Servicing </div>
      <p>The life of your door or gate is extended by having it routinely serviced and maintained by Talbot Auto Doors. We have a number of mobile service technicians with experience servicing a wide range of door types and brands.</p>
      <div class="btn-row">
       <a href="#" class="button button-theme">Get a Free Quote</a>
       <a href="tel:1300560608" class="button button-grey-border">
        <img src="assets/images/icon/call-black-icon.svg" alt="call-icon" title="" width="14" height="14">1300 560 608 </a>
      </div>
     </div>
     <div class="doorservice-right">
      <div class="dr-ul">
       <div class="dr-li">
								 <div data-fancybox data-src="#open-slidingdoor" class="dr-liwr">
         		<div class="dr-icon">
          <img src="assets/images/icon/sliding-door-icon.svg" alt="sliding-door-icon" title="" width="50" height="40">
         </div>
         		<div class="dr-dtl"> Automatic Sliding Doors <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         		</div>
         </div>
								 <!-- popup -->
        	<div class="hidden-popup">
         	<div class="doorservice-popup" id="open-slidingdoor">
          			<div class="dservice-top">
														<div class="dr-icon"><img src="assets/images/icon/sliding-door-icon.svg" alt="sliding-door-icon" title="" width="50" height="40"></div>Automatic Sliding Doors
													</div>
										
													<div class="dservice-bottom">
															<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
												 </div>	
          </div>
         </div>
							</div>
							
       <div class="dr-li">
        <div class="dr-liwr" data-fancybox data-src="#open-swingdoor">
         <div class="dr-icon">
          		<img src="assets/images/icon/swing-door-icon.svg" alt="swing-door-icon" title="" width="50" height="40">
         </div>
         <div class="dr-dtl"> Automatic Swing Door <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         </div>
        </div>
								 <!-- popup -->
								<div class="hidden-popup">
         	<div class="doorservice-popup" id="open-swingdoor">
          			<div class="dservice-top">
														<div class="dr-icon">	<img src="assets/images/icon/swing-door-icon.svg" alt="swing-door-icon" title="" width="50" height="40"></div>Automatic Swing Door
													</div>
										
													<div class="dservice-bottom">
															<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
												 </div>	
          </div>
         </div>
       </div>
							
       <div class="dr-li">
        <div class="dr-liwr">
         <div class="dr-icon">
          <img src="assets/images/icon/roller-icon.svg" alt="roller-icon" title="" width="50" height="40">
         </div>
         <div class="dr-dtl"> Roller Shutter <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         </div>
        </div>
       </div>
       <div class="dr-li">
        <div class="dr-liwr">
         <div class="dr-icon">
          <img src="assets/images/icon/panel-icon.svg" alt="panel-icon" title="" width="50" height="40">
         </div>
         <div class="dr-dtl"> Panel Lift Shutters <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         </div>
        </div>
       </div>
       <div class="dr-li">
        <div class="dr-liwr">
         <div class="dr-icon">
          <img src="assets/images/icon/sliding-gate.svg" alt="sliding-door-icon" title="" width="50" height="40">
         </div>
         <div class="dr-dtl"> Automatic Sliding Gate <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         </div>
        </div>
       </div>
       <div class="dr-li">
        <div class="dr-liwr">
         <div class="dr-icon">
          <img src="assets/images/icon/swing-gate-icon.svg" alt="plus-circle-icon" title="" width="50" height="40">
         </div>
         <div class="dr-dtl"> Automatic Swing Gates <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         </div>
        </div>
       </div>
       <div class="dr-li">
        <div class="dr-liwr">
         <div class="dr-icon">
          <img src="assets/images/icon/boom-gate-icon.svg" alt="boom-gate-icon" title="" width="50" height="40">
         </div>
         <div class="dr-dtl"> Boom Gates <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         </div>
        </div>
       </div>
       <div class="dr-li">
        <div class="dr-liwr">
         <div class="dr-icon">
          <img src="assets/images/icon/bi-fold-icon.svg" alt="bi-fold-icon" title="" width="50" height="40">
         </div>
         <div class="dr-dtl"> Bi-Fold Door <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  <!-- content section -->
  <section class="content-wrapper mb-100">
   <div class="container">
    <div class="flex-container wrap justify-content-between ctent-block-wr">
     <div class="ctent-block">
      <div class="heading-26">Routine Servicing</div>
      <p>It doesn’t matter if you have roller shutters, automatic doors or even sliding gates; it’s essential to undertake routine servicing at various intervals. This is generally based on monthly, quarterly, biannual or annual service cycles depending on the door or gate usage. We also provide ad hoc door repair and servicing when no routine service contract is in place.</p>
      <div class="heading-26">Retrofitting</div>
      <p>With older automatic sliding doors, it is often more economic to to simply replace the elctrics of the door system keeping the existing doors leaves and track. This is know as a retrofit. Talbots replace the old failed or unreliables doors controller and motor and drive system with new, using the existing track and door leaves.</p>
      <p>We retrofit and provide servicing for automatic sliding doors, and we also build frameless glass door control systems. If your existing controller has failed and the supplier has quoted on its replacement, get an alternative quote from us first. We’re confident that we’ll beat it! We retrofit ADIS doors BWN, Dorma and many other systems with our Talbot new controllers and motors for as little as AUS $3500 excl GST!</p>
      <p>Talbot Automatic Doors and Gates also repairs and replaces automatic gates in Sydney. We provide new drive systems and hinges as well as an onsite welding service.</p>
      <p>We provide on-time, on the clock routine servicing to products such as roller shutters and entry doors Sydney-wide. contact us for an automatic door service.</p>
     </div>
     <div class="ctent-img">
      <div class="ctent-logo-wr">
       <img src="assets/images/routine-service-image.jpg" alt="routine-service-image" title="" width="670" height="550">
      </div>
     </div>
    </div>
    <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
     <div class="ctent-block">
      <div class="heading-26">Brands Of Automatic Doors We Service And Sliding Gates / Door Systems Supported</div>
      <div class="tw-column-wr">
       <div class="two-column">
        <div class="tw-title">Brands of Automatic Doors</div>
        <ul>
         <li>BWN / Dorma</li>
         <li>ADIS</li>
         <li>Auto Ingress</li>
         <li>Access Entry</li>
         <li>GezeTormax</li>
         <li>Ingersol Rand</li>
         <li>AGP – Record</li>
         <li>Elsema</li>
         <li>Besam</li>
         <li>Self-opening Doors</li>
         <li>Hokuyo</li>
         <li>Ownic</li>
        </ul>
       </div>
       <div class="two-column">
        <div class="tw-title">Sliding Gates / Door Systems Supported</div>
        <ul>
         <li>Beninca</li>
         <li>Liftmaster</li>
         <li>Magnetic</li>
         <li>FAACDITEC / ABA</li>
         <li>Automatic Technology</li>
         <li>Key Motors</li>
         <li>Toll Park</li>
         <li>Ezi Systems</li>
        </ul>
       </div>
      </div>
     </div>
     <div class="ctent-img">
      <div class="ctent-logo-wr">
       <img src="assets/images/auto-door-image.jpg" alt="auto-door-image" title="" width="670" height="550">
      </div>
     </div>
    </div>
   </div>
  </section>
  <!-- call action -->
  <section class="custom-callaction-sec repair-callaction mb-100">
   <div class="container">
    <div class="custom-callact-sec">
     <img src="assets/images/custom-callaction-bgimage.jpg" alt="custom-callaction-bgimage" title="" width="1472" height="200" class="bgimg">
     <div class="custom-callwr">
      <div class="cust-logo">
       <img src="assets/images/square-icon.svg" alt="sqaure icon" title="" width="56" height="56">
       <div class="cust-logo-wr">
        <div class="sm-title">Repairs & Service</div>
        <div class="heading-34">Help is on the way</div>
       </div>
      </div>
      <div class="cust-right">
       <div class="cust-content">
        <p>Talbot Auto Doors provide a number of products and services suitable for residential customers, specialising in automatic doors and gates.</p>
       </div>
       <div class="cust-btn">
        <a href="tel:1300560608" class="button button-white">
         <img src="assets/images/icon/phone-icon.svg" alt="phone-icon" title="" width="27" height="27">NSW: 1300 560 608 </a>
        <a href="#" class="button button-theme">Get a Free Quote</a>
       </div>
      </div>
     </div>
    </div>
   </div>
  </section>
  <!-- testimonial -->
   <section class="sec-testimonial mb-100">
   <div class="container">
    <div class="label-title mb-0">Clients Testimonials</div>
    <div class="heading-34">What Our Clients Are Saying</div>
    <ul class="testimonial-ul">
     <li class="testimonial-li">
      <div class="test-li-wrap">
       <div class="test-top">
        <p>Talbots designed a really interesting bi-fold gate for an usual driveway. It works well and when it needed some maintenance, they were there within 24 hours and always helpful. A great team of professionals</p>
       </div>
       <div class="test-bottom">
        <img src="assets/images/rating.svg" alt="rating" title="" width="99" height="16">
        <div class="test-name">Stephen Peters</div>
       </div>
      </div>
     </li>
     <li class="testimonial-li">
      <div class="test-li-wrap">
       <div class="test-top">
        <p>Process from start to finish second to none. And the after sales service has been amazing! Latest experience was a text Friday evening and gate was fixed Monday morning. Our fault it broke not theirs but they fixed it quickly anyway and at no cost! Highly recommend!</p>
       </div>
       <div class="test-bottom">
        <img src="assets/images/rating.svg" alt="rating" title="" width="99" height="16">
        <div class="test-name">Simon Orbell</div>
       </div>
      </div>
     </li>
					<li class="testimonial-li">
      <div class="test-li-wrap">
       <div class="test-top">
        <p>Talbots designed a really interesting bi-fold gate for an usual driveway. It works well and when it needed some maintenance, they were there within 24 hours and always helpful. A great team of professionals</p>
       </div>
       <div class="test-bottom">
        <img src="assets/images/rating.svg" alt="rating" title="" width="99" height="16">
        <div class="test-name">Stephen Peters</div>
       </div>
      </div>
     </li>
     <li class="testimonial-li">
      <div class="test-li-wrap">
       <div class="test-top">
        <p>Process from start to finish second to none. And the after sales service has been amazing! Latest experience was a text Friday evening and gate was fixed Monday morning. Our fault it broke not theirs but they fixed it quickly anyway and at no cost! Highly recommend!</p>
       </div>
       <div class="test-bottom">
        <img src="assets/images/rating.svg" alt="rating" title="" width="99" height="16">
        <div class="test-name">Simon Orbell</div>
       </div>
      </div>
     </li>
    </ul>
   </div>
  </section>
		
		
		<!-- whychoose section -->
		<section class="whychoose-sec pt-pb100 mb-100">
			 <div class="container">
						<div class="whychoose-top mb-70">
								<div class="whychs-topdetail">	
									<div class="heading-34 text-white">Why Choose Talbot Automatic Doors and Gates?</div>
							 </div>	
							 <div class="whychs-detail">
									<p>Our trained technicians provide routine services to ensure faults are rectified before any failure and compromise to the building security occurs. We offer a full door service including stairwell and tenancy hydraulic closing doors.</p>
							 </div>
					 </div>
					 <div class="whychoose-bottom">
								 <div class="whychs-img">
											<img src="assets/images/whychoose-image.jpg" alt="whychoose-image" title="" width="560" height="708">
							  </div>
							  <div class="whychs-content">
											 <ul class="whychs-ul">
															<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/integrity-whychoose-icon.svg" alt="integrity-whychoose-icon" title="" width="60" height="60">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">Integrity</div>
																					<p>Talbot is built on honesty, care and integrity. Talbot management guarantees that all maintenance and proposed works are transparent and costed competitively. Our goal is a strategic partnership with the facilities manager to deliver value and peace of mind to the building owner.</p>
																			 </div>
																 </div>
													 </li>
													 <li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/wh-whychoose-image.svg" alt="whychoose-icon" title="" width="51" height="60">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">WH&S</div>
																					<p>Talbot takes work health and safety very seriously and ensures that all our technicians are properly inducted on any site we work on. Our Company is compliant with CM3 and other trades monitoring systems,</p>
																			 </div>
																 </div>
													 </li>
													<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/technical-competence-icon.svg" alt="technical-competence-icon" title="" width="90" height="86">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">Technical Competence</div>
																					<p>Talbot technicians are all trained electricians and have further specialist door training that covers the vast variety of door brands installed in Australia. Our technicians are also trained to work on roller shutters, sectional shutters, swing and sliding gates, boom gates, floor and transom hydraulic door closures and electric locking. Our online technical support has been developed over the past 25 years to provide detailed systems manuals on virtually every system we have come across.</p>
																			 </div>
																 </div>
													 </li>
													<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/systemization-icon.svg" alt="systemization-icon" title="" width="55" height="55">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">Systemization</div>
																					<p>Our market leading web based job tracking system ensures that all work is recorded; detailing the works done, the time on site and the technician responsible. This is all done in real time, with technicians using their tablet to login when arriving on site and logout when complete. They enter the job notes at the same time, which can then be emailed to the building manager.</p>
																			 </div>
																 </div>
													 </li>
													<li>
																	 <div class="whychs-li">
																				<div class="why-icon">
																					<img src="assets/images/icon/emergency-whychoose-icon.svg" alt="emergency icon" title="" width="61" height="52">
																			 </div>
																			 <div class="why-content">
																						<div class="why-title">24/7 emergency</div>
																					<p>Our One Stop comprehensive Door, Shutter and Gate service allows your routine maintenance and 24/7 emergency call outs to be managed by one company.</p>
																			 </div>
																 </div>
													 </li>
										 </ul>
										
										<div class="btn-row">
												<a href="tel:1300560608" class="button button-white"><img src="assets/images/icon/call-black-icon.svg" alt="call-black-icon" title="" width="14" height="14">1300 560 608</a>
											 <a href="#" class="button button-theme">Get a Free Quote</a>
										</div>
										
							  </div>
					 </div>
			 </div>
		</section>
		

		<!-- Our Location -->
  <?php block('location-section'); ?>
		
  <!-- some of our clients --> 
		<?php block('client-logo'); ?>
		
		
 </section>
</main> <?php get_footer();