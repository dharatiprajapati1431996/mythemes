<?php require_once __DIR__ . '/includes/includes.php'; ?> 
<?php get_header(); ?> 

<main class="franchise-page">
	
 <!-- Inner banner  -->
 <section class="inner-banner">
  <img src="assets/images/franchise-banner.jpg" alt="franchise banner image" title="" width="1920" height="650" class="bgimg">
  <div class="container">
   <div class="inbanner-content">
    <div class="inbanner-cnt-left">
     <div class="heading-50">Franchise Opportunities</div>
    </div>
    <div class="inbanner-cnt-right">
     <ul class="woo_breadcums">
      <li>
       <span>
        <span>
         <a href="#">Home</a>
         <span class="breadcrumb_last" aria-current="page">Franchise Opportunities</span>
        </span>
       </span>
      </li>
     </ul>
    </div>
   </div>
  </div>
 </section>
	
 <section class="top-space-curve">

  <!-- content section -->
  <section class="content-wrapper mb-100">
   <div class="container">
    <div class="flex-container wrap justify-content-between ctent-block-wr">
     <div class="ctent-block">
									<p>You may not consider doors in everyday life. Why would you? You open a door so you can walk through it, blissfully unaware of the convenience you’ve just been afforded. Doors have a purpose. They are designed to make it possible for us to enter and exit a building. Doors lock out those who are not welcome, and grant entry to those who are. Doors offer safety, ease and comfort; and what many people fail to realise is that doors establish first impressions for your business and home. By representing yourself with pride and uncompromising aesthetic, you’ll control the atmosphere and increase the visual appeal of your architecture.</p>
								<p>Talbot Doors is an automatic door service and installation company established in 1985, and have provided a 		valuable service to the Facility Management Industry ever since. With our own unique range of auto doors and 		  	gate designs and our list of reputable loyal clients, we’ve proven ourselves to be Australia’s trusted company  	for gates and automatic doors in both the residential and commercial markets. Our expertise, specialty products 	and genuine customer service are what sets us apart from large scale organisations. Today, the company works 			closely with many iconic Sydney buildings, earning a reputation for quality and reliability.
							</p>
     </div>
     <div class="ctent-img">
      <div class="ctent-logo-wr">
       <img src="assets/images/franchise-image.jpg" alt="franchise-image" title="" width="670" height="450">
      </div>
     </div>
    </div>
    <div class="flex-container wrap flex-row-reverse justify-content-between ctent-block-wr">
     <div class="ctent-block">
       <p>The Talbot team love what they do because they’re part of an organisation that values and empowers them to perform fulfilling work. We believe in looking after our team so our team can look after our clients. We’re there to solve the immediate problem but also make sure it doesn’t happen again. We take the time to offer preventable, sustainable solutions that consider your operations as a whole.</p>
						<p>Having created solid relationships with large commercial operations such as Colliers, Knight Frank, and the UGL United Group who were responsible for the Sydney Airport and a growing number of private clients, Talbot Doors have laid the foundations for franchise growth. We’re looking for passionate and ambitious individuals to carry through the Talbot Doors vision in New South Wales and beyond.</p>
						<p>If you’re equipped with basic electrician skills and are looking to put your customer relations and business management skills to good use, then a Talbot Doors franchise could be the opportunity you’re looking for.</p>
     </div>
     <div class="ctent-img">
      <div class="ctent-logo-wr">
        <img src="assets/images/franchise-image-1.jpg" alt="franchise-image" title="" width="670" height="450">
      </div>
     </div>
    </div>
   </div>
  </section>
		
		<!-- -->
		<section class="secfranchise-bg pt-pb100 top-curve mb-100">
				<div class="container"> 
							<div class="franchise-ul">
									<div class="franchise-li">
											<div class="franchise-li-wr">
													<div class="fr-icon">
															<img src="assets/images/icon/leadership-icon.svg" alt="leadership-icon" title="" width="68" height="68">
											 	</div>
												 <div class="fr-info">
																<div class="fr-title">Thought Leadership</div>
															 <p>Turn ideas into reality and know how to replicate success. We are the go-to people when it comes to automatic sliding doors and gates for your home or commercial premises. Innovating with scalable ideas, we don’t just challenge within our own business, we change the industry.</p>
													 </div>
										 </div>
								 </div>
								 <div class="franchise-li">
											<div class="franchise-li-wr">
													<div class="fr-icon">
													 <img src="assets/images/icon/quality-workmanship-icon.svg" alt="quality-workmanship-icon" title="" width="68" height="68">
												 </div>
												 	<div class="fr-info">
																<div class="fr-title">Quality Workmanship</div>
															 <p>Our skillset and reliability are what sets us apart. Taking pride in quality outcomes without compromising aesthetics, we’re there to solve any problem, and also make sure it doesn’t happen again. We take on projects with confidence and give the time to offer customised solutions.</p>
													 </div>
										 </div>
								 </div>
							
								<div class="franchise-li">
											<div class="franchise-li-wr">
													 <div class="fr-icon">
												   	<img src="assets/images/icon/relationship-icon.svg" alt="relationship-icon" title="" width="68" height="68">
												  </div>
												 	<div class="fr-info">
																<div class="fr-title">Relationships</div>
															 <p>The Talbot team love what they do. We build long-term partnerships, with both suppliers and clients based on consistent quality and reliability. We are an organisation that values and empowers its staff to perform fulfilling work. We believe in looking after our team so they can look after our clients.</p>
													 </div>
										 </div>
								 </div>
									<div class="franchise-li">
											<div class="franchise-li-wr">
													 <div class="fr-icon">
												  			<img src="assets/images/icon/service-icon.svg" alt="service-icon" title="" width="68" height="68"> 
												  </div>
												 	<div class="fr-info">
																<div class="fr-title">Service</div>
															 <p>Commitment and care every single time. We treat no clients the same, which is why after 30 years we’re still about relationships built on reliable, solution-focused service. Day or night, we come when we say we will. We believe in looking after our team so that our team can look after our clients.</p>
													 </div>
										 </div>
								 </div>
					 </div>
			</div>
		</section>
		
		<!-- -->
		<section class="franchise-faq mb-100">
				<div class="container">
							<div class="heading-40">Talbot Auto Doors Franchise Benefits</div>
					  		<div class="franchise-accordion">
          		<div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/niche-market-icon.svg" alt="niche-market-icon" title="" width="50" height="50"></div>
																		<div class="fr-title">Growing Niche Market</div>
																</div>
																	<div class="faq-head-right">
																		<p>A multi-faceted business that’s growing year on year, Talbot Doors is an automatic door service and installation company that addresses the poor service standards in the Facility Management Industry. Building Managers need rapid response times to fix broken doors and prevent any or safety issues. They foster relationships with providers they can trust. Building Managers have become more reliant on subcontractors who tend to see their job as a transaction rather than a relationship. </p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Having created solid relationships with large commercial operations including Colliers, Knight Frank and the UGL United Group, Talbot Doors have laid the foundations for franchise growth. The emergence of smart home automation will see the market evolve into a solutions-orientated industry. </p>
																			<p>Automatic doors will become part of a greater ecosystem of products that are interconnected. Talbot Doors has no competition from international markets and is a specialised service not easily replicated in Australia. Automation and modernisation are essential to the design process of new commercial properties. Over 40% of the industry’s revenue comes from maintenance services. Talbot Doors has a unique opportunity to populate the maintenance space, offering solution based services that don’t simply repair, but ensure the problem doesn’t happen again.</p>
																		</div>	
               </div>
            </div>
										  <div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/rewarding-work-icon.svg" alt="rewarding work icon" title="" width="" height=""width="50" height="50"></div>
																		<div class="fr-title">Rewarding Work</div>
																</div>
																	<div class="faq-head-right">
																		<p>A multi-faceted business that’s growing year on year, Talbot Doors is an automatic door service and installation company that addresses the poor service standards in the Facility Management Industry. </p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
																		</div>	
               </div>
            </div>
										
										 <div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/business-icon.svg" alt="business icon" title="" width="50" height="50"></div>
																		<div class="fr-title">A Successful Business</div>
																</div>
																	<div class="faq-head-right">
																		<p>Talbot Doors has been servicing automatic doors and gates since 1985. Its founder, Brian Talbot, saw the need for a specialised automotive service and took over a small customer base that included a few influential and loyal clients.</p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
																		</div>	
               </div>
            </div>
										
										<div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/service-offer-icon.svg" alt="service icon" title="" width="50" height="50"></div>
																		<div class="fr-title">Service On Offer</div>
																</div>
																	<div class="faq-head-right">
																		<p>Installation: The Talbot Doors installation service covers both the commercial and residential markets. Talbot Doors have a unique product offering that allows Franchisees a distinct point of difference in the market. </p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
																		</div>	
               </div>
            </div>
										
										<div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/marketing-icon.svg" alt="marketing icon" title="" width="50" height="50"></div>
																		<div class="fr-title">Marketing</div>
																</div>
																	<div class="faq-head-right">
																		<p>The automatic door industry is populated by a few well reputed international players. With a 20 year history, Talbot Doors’ brand recognition is strong and continuously growing.</p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
																		</div>	
               </div>
            </div>
										
										<div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/training-icon.svg" alt="training icon" title="" width="50" height="50"></div>
																		<div class="fr-title">System, Training and Support</div>
																</div>
																	<div class="faq-head-right">
																		<p>The backbone of Talbot Doors lies in a strong technological and operational framework. These systems support the scalability of the Talbot Doors Franchise Network. </p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
																		</div>	
               </div>
            </div>
										
										<div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/costs-icon.svg" alt="cost icon" title="" width="50" height="50"></div>
																		<div class="fr-title">Establishment Costs</div>
																</div>
																	<div class="faq-head-right">
																		<p>The Talbot Doors franchise opportunity comes with no international competitors and low technical barriers to becoming a Talbot technician. To establish a new Talbot Doors location, the cost begins at $120,000. </p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
																		</div>	
               </div>
            </div>
										
										<div class="accordion_in">
               <div class="faq-head">
																	<div class="faq-head-left">
																			<div class="fr-icon"><img src="assets/images/icon/talbot-technicians.svg" alt="" title="" width="50" height="50"></div>
																		<div class="fr-title">Talbot Technicians</div>
																</div>
																	<div class="faq-head-right">
																		<p>Talbot Doors is within a niche and growing industry that’s not in competition with international competitors. As a Franchisee you will build rewarding relationships with clients in both the commercial building and private dwelling sectors.</p>
																</div>
															</div>
               <div class="acc_content">
																  <div class="fr-dtl">
                	 <p>Web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user. This is dummy text, </p>
																		</div>	
               </div>
            </div>
								</div>  
			 </div>
		</section>	
		
		<!-- team -->
		<section class="team-sec mb-80">
			 <div class="container">
						 <div class="label-title text-center">Talbotauto Doors</div>
					  <div class="heading-40 text-center">Our Team of Experts Are Here to Help</div>
						 
					  <div class="team-ul">
									<div class="team-li">
											 <div class="team-li-wr" data-fancybox data-src="#open-team-member">
														<div class="team-li-img">
															 <img src="assets/images/doug-surmon.jpg" alt="doug-surmon" title="" width="460" height="400">
													 </div>
													 <div class="team-li-bottom">
																 <div class="team-btm-wr">
																		 <div class="member-nm">Doug Surmon</div>
																		 <div class="designation">Director</div>
															  </div>
															  <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
													 </div>
										  </div>
											<!-- popup -->
												<div class="hidden-popup">
													<div class="team-popup" id="open-team-member">
																<div class="team-top">
																	 <div class="member-nm">Doug Surmon</div>
																		 <div class="designation">Director</div>
																</div>

																<div class="team-bottom">
																		<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
																</div>	
													</div>
												</div>
									</div>
								 
								 <div class="team-li">
											 <div class="team-li-wr" data-fancybox data-src="#open-team-member2">
														<div class="team-li-img">
															 <img src="assets/images/diarmait-surmon.jpg" alt="Diarmait Surmon" title="" width="460" height="400">
													 </div>
													 <div class="team-li-bottom">
																 <div class="team-btm-wr">
																		 <div class="member-nm">Diarmait Surmon</div>
																		 <div class="designation">Director</div>
															  </div>
															  <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
													 </div>
										  </div>
											<!-- popup -->
												<div class="hidden-popup">
													<div class="team-popup" id="open-team-member2">
																<div class="team-top">
																	 <div class="member-nm">Diarmait Surmon</div>
																		 <div class="designation">Director</div>
																</div>

																<div class="team-bottom">
																		<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
																</div>	
													</div>
												</div>
									</div>
								
												<div class="team-li">
											 <div class="team-li-wr" data-fancybox data-src="#open-team-member3">
														<div class="team-li-img">
															 <img src="assets/images/angelo-travato.jpg" alt="angelo-travato" title="" width="460" height="400">
													 </div>
													 <div class="team-li-bottom">
																 <div class="team-btm-wr">
																		 <div class="member-nm">Angelo Travato</div>
																		 <div class="designation">Systems & Accounting Manager</div>
															  </div>
															  <img src="assets/images/icon/plus-circle-icon.svg" alt="plus-circle-icon" title="" width="30" height="30">
													 </div>
										  </div>
											<!-- popup -->
												<div class="hidden-popup">
													<div class="team-popup" id="open-team-member3">
																<div class="team-top">
																	 <div class="member-nm">Angelo Travato</div>
																		 <div class="designation">Systems & Accounting Manager</div>
																</div>

																<div class="team-bottom">
																		<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
																</div>	
													</div>
												</div>
									</div>
				
						 </div>
					
			 </div>
		</section>

		<!-- enquire -->
		<section class="sec-enquire bg-grey-yellow pt-pb100">
				 <div class="container">
						 <div class="enquire-wrap">
									 <div class="enq-left">
												  <img src="assets/images/square-icon.svg" alt="sqaure icon" title="" width="56" height="56" class="enq-img">
												 <div class="heading-30">Open Your Doors to the Future</div>
											  <div class="title-bottom">Talbot Door Franchising</div>
												
											  <p>If you’re equipped with basic electrician skills and are looking to put your customer relations and business management skills to good use, then a Talbot Doors franchise could be the opportunity you’re looking for.</p>
											
											<div class="client-numbers" id="counterdiv">
													<ul class="cust-list">
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="3"> 0 </span>
																						</div>
																			  <label>Head offices in Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="11"> 0 </span>
																										
																						</div>
																			<label>Regional offices across the Australia</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																						<div class="cust-detail">
																										<span class="cust-no counter-value" data-count="150"> 0 </span><span class="plus_no">+</span>
																										
																						</div>
																			<label>Experts working across the country</label>
																		</div>
														</li>
														<li>
																		<div class="list-box">
																				  <div class="cust-detail">
																										<span class="cust-no counter-value" data-count="1200"> 0 </span> <span class="plus_no">+</span>
																									
																						</div>
																				<label>Completed projects across Australia</label>
																		</div>
														</li>
										</ul>        
											</div> 
											
												<div class="selectbox mb-20">
													 <select>
															<option>Contact Details</option>
															<option>Contact Details</option>
												  </select>
									  </div>
											
											<div class="button button-theme button-full">Apply for Franchise Now</div>
											
								  </div>
								  <div class="enq-right">
												<div class="enquiry-form">
														<div class="heading-30 text-white">Enquire Now</div>
																										 <form>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Name">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="email" class="form-control" placeholder="Email Address">
															   </div>
																		<div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Phone">
															   </div>
															   <div class="form-group form-group50">
															   		<input type="text" class="form-control" placeholder="Postcode">
															   </div>
																	<div class="form-group">
																				<div class="inputFileHolder">
                <div class="fileinputs">
                  <span class="wpcf7-form-control-wrap" data-name="attch_file">
																			<input size="40" class="wpcf7-form-control wpcf7-text file txt_box_upload inputfile form-control" id="attachment" aria-invalid="false" value="" type="text" name="attch_file">
																	</span>
                  <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc,.jpg,.jpeg,.png,.gif" aria-invalid="false" type="file" name="attachment1">
                    <div class="fakefile">
                      <div class="fakebtn">
                        <img src="assets/images/icon/file-attachment.svg" alt="" title="" width="20" height="23">
                      </div>
                    </div>
                    <span class="wpcf7-form-control-wrap" data-name="resume">
                    <input size="40" class="wpcf7-form-control wpcf7-file fileInput formcontrol" id="fileInput1" accept=".txt,.pdf,.doc" aria-invalid="false" type="file" name="resume">
                    </span>
                    <div class="fakefile">
                      <div class="fakebtn"><img src="assets/images/icon/file-attachment.svg" alt="" title="" width="20" height="23"></div>
                    </div>
                  </span>
                  <span class="filename">Upload Image</span>
                </div>
              </div>
																		  
																		  <label>File types Allowed: gif, png, jpg, jpeg | Max size: 5MB</label>
																		 
            					</div>
																		<div class="form-group">
															   		<textarea class="form-control" placeholder="Message"></textarea>
															   </div>
															   <div class="sub-btnblk">
																				<input type="submit" value="Submit">
															   </div>
													 </form>
											 </div>
								  </div>
						 </div>
			  </div>
		</section>

	</section>
</main> 

<?php get_footer();