<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper product-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner breadcrumb-with-form">
        <div class="inner-banner relative">
            <img src="assets/images/tonne-crane-hire-inner.jpg" alt="tonne-crane-hire-inner" title="" width="1920" height="676" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                            <div class="heading-70">Franna Mac-25 SL</div>
                            <div class="semi-head">Terex Franna MAC 25T SL – Pick & Carry Crane</div>

                            <div class="button-group">
                                <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                    03 9310 5440</a>
                                <a href="#" class="button button-theme">Get In Touch</a>
                            </div>
                    </div>
                    <div class="bread-right">
                        <?php block('get-form'); ?>
                    </div>
                </div>
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums full-breadcurmb">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="fleet.php">Fleet</a>
                            <span class="breadcrumb_last" aria-current="page">60 tonne Crane Hire</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->

    <section class="inpage mb-100 content-wrapper">
        <div class="container">

            <div class="product-wrapper flex-container wrap align-items-start">
                <div class="product-left sticky">
                    <div class="product-slide-box">

                        <a href="#" class="zoom-prod">
                            <img src="assets/images/svg/zoom.svg" alt="zoom" title="" width="17" height="17">
                        </a>

                        <img src="assets/images/terex.png" alt="terex" title="" width="" height="">

                        <div class="model-num">25T</div>
                    </div>


                    <div class="usp-wrap">
                        <ul class="usp-list">
                            <li>
                                <div class="usp-box">
                                    <div class="icon">
                                        <img src="assets/images/svg/services-availabilty.svg" alt="Service Availability" title="" width="38" height="38">
                                    </div>
                                    <div class="heading-18">24/7 Service Availability</div>
                                </div>
                            </li>
                            <li>
                                <div class="usp-box">
                                    <div class="icon">
                                        <img src="assets/images/svg/expert-operators.svg" alt="Expert Operators" title="" width="45" height="37">
                                    </div>
                                    <div class="heading-18">Expert Operators & Riggers</div>
                                </div>
                            </li>
                            <li>
                                <div class="usp-box">
                                    <div class="icon">
                                        <img src="assets/images/svg/fully-licensed.svg" alt="Fully Licensed" title="" width="36" height="44">
                                    </div>
                                    <div class="heading-18">Fully Licensed & Insured</div>
                                </div>
                            </li>
                        </ul>
                    </div>

                </div>
                <div class="product-right ctent-column">
                    <p>The Terex Franna MAC 25T SL is a versatile and robust pick-and-carry crane, known for its excellent lifting power and unmatched maneuverability. Ideal for a wide range of projects, this machine is built for performance in tight spaces and challenging conditions.</p>

                    <div class="heading-22">Key Features:</div>
                    <ul>
                        <li>Maximum Lifting Capacity: 25 tonnes</li>
                        <li>Boom Length: Up to 18.4 metres</li>
                        <li>Maximum Hook Height: Approximately 18 metres</li>
                        <li>Superlift (SL) Counterweight: Increases lifting capacity by up to 30% in select configurations</li>
                        <li>Articulation: 40° left and right, for maximum site flexibility</li>
                    </ul>

                    <div class="heading-22">Applications:</div>

                    <ul>
                        <li>The MAC 25T SL is ideal for:</li>
                        <li>Construction and infrastructure projects</li>
                        <li>Industrial and plant maintenance</li>
                        <li>Utility and civil works</li>
                        <li>Mining and heavy equipment relocation</li>
                        <li>General material handling</li>
                    </ul>

                    <div class="heading-22">Safety and Efficiency:</div>
                    <p>With a compact design and custom SL counterweight system, the MAC 25T SL is engineered for stability and safety on even the most confined or complex sites. Its advanced rigging options and operator-friendly features allow for faster, safer, and more cost-effective lifts.</p>

                    <div class="button-group">
                        <a href="#" class="button button-theme">Enquire Now</a>
                        <a href="#" class="button button-primary"><img src="assets/images/svg/download.svg" alt="download" title="" width="" height=""> Download Mac 25 SL load chart</a>
                    </div>

                </div>
            </div>
            
            <div class="divider mb-100"></div>

            <div class="other-fleet-wrapper">
                <div class="heading-46 extra-bold">Other Fleet Ready for Any Job</div>

                <div class="fleet-list other-fleet-js">
                    <div class="item-box">
                        <a href="#">
                            <div class="maint-image">
                                <div class="heading-18">All Terrain/Mobile Crane</div>

                                <div class="img-wrap">
                                    <img src="assets/images/liebherr-LTM-1080.png" alt="liebherr-LTM-1080" title="" width="" height=""> 
                                </div>

                                <div class="model-num">80T</div>
                            </div>
                        </a>
                    </div>
                    <div class="item-box">
                        <a href="#">
                            <div class="maint-image">
                                <div class="heading-18">Franna Crane</div>
                                <div class="img-wrap">
                                    <img src="assets/images/grove-gmk5130.png" alt="Grove GKM-5130-1" title="" width="" height="">
                                </div> 
                                <div class="model-num">130T</div>

                            </div>
                        </a>
                    </div>

                    <div class="item-box">
                        <a href="#">
                            <div class="maint-image">
                                <div class="heading-18">Crane Truck</div>
                                <div class="img-wrap">
                                    <img src="assets/images/20-tonne-franna.png" alt="20 Tonne Franna" title="" width="" height=""> 
                                </div>
                                <div class="model-num">20T</div>
                            </div>
                        </a>
                    </div>

                    <div class="item-box">
                        <a href="#">
                            <div class="maint-image">
                                <div class="heading-18">Semi Truck</div>
                                
                                <div class="img-wrap">
                                    <img src="assets/images/terex-MAC-25.png" alt="Terex MAC-25" title="" width="" height=""> 
                                </div>
                                <div class="model-num">25T</div>
                            </div>  
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <?php block('text-slider'); ?>

    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();