<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML Theme</title>
    <?php wp_head(); ?>
</head>
<body>
<!-- Start Header -->
 <header class="mainheader">
        <a class="togglebtn"><span></span></a>
        <div class="overlay"></div>


        <!-- bottom header -->
        <div class="header-top">
            <div class="container">
                <div class="header-topwrap">
                    <div class="hd-logo">
                        <a href="home.php">
                            <img src="assets/images/panna-cranes-logo.svg" alt="Panna Cranes" title="" width="204" height="58">
                        </a>
                    </div>

                    <div class="menu-link">
                            <nav>
                                <ul>
                                    <li><a href="home.php">Home</a></li>
                                    <li><a href="about.php">About</a></li>
                                    <li class="has-sub service-dropdown">
                                        <a href="services.php">Services</a>
                                        <div class="sub-menu megamenu">
                                            <div class="menu-wrapper">
                                                <ul class="sub-dropdown sub-menulink">
                                                    <li><a href="#">General Crane Hire</a></li>
                                                    <li><a href="#">Lift Planning And Engineering</a></li>
                                                    <li><a href="#">Safety</a></li>
                                                    <li><a href="#">Civil Construction</a></li>
                                                    <li><a href="#">Light Pole Installation</a></li>
                                                    <li><a href="#">Machinery Relocation</a></li>
                                                    <li><a href="#">Signs, Transportation, And Relocation </a></li>
                                                    <li><a href="#">Structural Steel  Installation And Rigging</a></li>
                                                    <li><a href="#">Glass Lifting  Installation & Transportation </a></li>
                                                    <li><a href="#">Concrete Panel Lifting Installation & Transportation</a></li>
                                                    <li><a href="#">Air Conditioning </a></li>
                                                    <li><a href="#">Transformer And Switchboard Lifting Installation & Transportation </a></li>
                                                    <li><a href="#">Railway  Work </a></li>
                                                    <li><a href="#">Construction Materials For  Domestic & Commercial Sites</a></li>
                                                </ul>


                                                <div class="menu-cta-wrap relative">
                                                    <img src="assets/images/menu-cta-bg.jpg" alt="menu-cta-bg" title="" width="445" height="574" class="bgimg">

                                                    <div class="menu-cta-inner">

                                                        <div class="heading-24">Provides quality Machinery and Trailer Hire services to Melbourne and surrounding.</div>

                                                        <div class="button-group">
                                                            <a href="tel:03 9310 5440" class="button button-outline"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">03 9310 5440</a>
                                                            <a href="#" class="button button-orange">Get In Touch</a>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                    </li>
                                    <li><a href="panna-at-work.php"> Panna At Work</a></li>
                                    <li class="has-sub product-dropdown">
                                        <a href="fleet.php">Fleet</a>
                                        <div class="sub-menu megamenu">
                                            <ul class="sub-dropdown sub-menulink fleet-list">
                                                <li>
                                                    <a href="#">
                                                        <div class="heading-18">All Terrain/Mobile Crane</div>
                                                        <div class="img-wrap">
                                                            <img src="assets/images/liebherr-LTM-1080.png" alt="liebherr-LTM-1080" title="" width="" height=""> 
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        <div class="heading-18">Franna Crane</div>
                                                        <div class="img-wrap">
                                                           <img src="assets/images/grove-gmk5130.png" alt="Grove GKM-5130-1" title="" width="" height="">
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        <div class="heading-18">Crane Truck</div>
                                                        <div class="img-wrap">
                                                            <img src="assets/images/20-tonne-franna.png" alt="20 Tonne Franna" title="" width="" height="">
                                                        </div>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        <div class="heading-18">Semi Truck</div>
                                                        <div class="img-wrap">
                                                           <img src="assets/images/terex-MAC-25.png" alt="Terex MAC-25" title="" width="" height="">
                                                        </div>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>


                                    <li><a href="blog.php">Blogs</a></li>
                                    <li class="has-sub areas-dropdown">
                                        <a href="areas-we-serve.php">Areas</a>
                                            <div class="sub-menu megamenu">
                                                <ul class="sublink menu-level1">
                                                        <div class="heading-28 uppercase">Areas we serve</div>

                                                        <li class="menu-item-hover">
                                                            <a href="#">We operate Victoria Wide</a>
                                                                <div class="sub-menu menu-level2">

                                                                    <div class="heading-24">We operate Victoria Wide</div>

                                                                    <ul class="sub-menulink ">
                                                                           <li><a href="#">Sunshine</a></li>
                                                                           <li><a href="#">Tullamarine</a></li>
                                                                           <li><a href="#">Essendon</a></li>
                                                                           <li><a href="#">Coburg</a></li>
                                                                           <li><a href="#">Craigieburn</a></li>
                                                                           <li><a href="#">Maribyrnong</a></li>
                                                                           <li><a href="#">Mernda</a></li>
                                                                           <li><a href="#">Yarraville</a></li>
                                                                           <li><a href="#">Morang</a></li>
                                                                           <li><a href="#">Campbellfield</a></li>
                                                                           <li><a href="#">Derrimut</a></li>
                                                                           <li><a href="#">Footscray</a></li>
                                                                           <li><a href="#">Heidelberg</a></li>
                                                                           <li><a href="#">Laverton</a></li>
                                                                           <li><a href="#">Melton</a></li>
                                                                           <li><a href="#">Epping</a></li>
                                                                           <li><a href="#">Preston</a></li>
                                                                           <li><a href="#">St Albans</a></li>
                                                                           <li><a href="#">Sunbury</a></li>
                                                                           <li><a href="#">Taylors Lakes</a></li>
                                                                           <li><a href="#">Thomastown</a></li>
                                                                           <li><a href="#">Tottenham</a></li>
                                                                           <li><a href="#">Truganina</a></li>
                                                                    </ul>
                                                                </div>
                                                        </li>
                                                        <li>
                                                            <a href="#">40 Tonne Frann</a>
                                                                <div class="sub-menu menu-level2">
                                                                    <div class="heading-24">40 tonne Frann</div>
                                                                    <ul class="sub-menulink">
                                                                       <li><a href="#">40 tonne Crane <span>Campbellfield</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Coburg</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Craigieburn</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Epping</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Essendon</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Footscray</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Tullamarine</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Maribyrnong</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Melton</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Mernda</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Preston</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>South Morang</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>St Albans</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Yarraville</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Sunbury</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Sunshine</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Taylors Lakes</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Thomastown</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Tottenham</span></a></li>
                                                                       <li><a href="#">40 tonne Crane <span>Truganina</span></a></li>
                                                                   </ul>
                                                                </div>
                                                        </li>
                                                        <li>
                                                            <a href="#">60 Tonne Franna</a>
                                                                <div class="sub-menu menu-level2">
                                                                    <div class="heading-24">60 tonne Franna</div>
                                                                    <ul class="sub-menulink ">
                                                                        <li><a href="#">60 tonne Crane<span>Campbellfield</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Coburg</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Craigieburn</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Epping</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Essendon</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Footscray</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Tullamarine</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Maribyrnong</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Melton</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Mernda</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Preston</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>South Morang</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>St Albans</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Yarraville</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Sunbury</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Sunshine</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Taylors Lakes</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Thomastown</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Tottenham</span></a></li>
                                                                        <li><a href="#">60 tonne Crane<span>Truganina</span></a></li>
                                                                    </ul>
                                                                </div>
                                                        </li>
                                                        
                                                </ul>
                                            </div>
                                    </li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </nav>
                    </div>
                   
                    <div class="head-call-wrap">
                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-primary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- End Header -->