<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper about-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                        <div class="semi-head">Your Trusted Partner in Crane Hire</div>
                        <div class="heading-50">About Us</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">About Us</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
            <div class="flex-container wrap mb-100 align-items-start">
                <div class="panel-left">
                    <div class="service-show-mobile hidden">
                        <?php block('services-list'); ?>
                    </div>


                    <div class="content-wrapper">
                        <div class="flex-container wrap">
                            <div class="small-ctent">
                                <div class="heading-22">Reliable Transport Solutions Across Victoria</div>
                                <p>Panna Cranes Pty Ltd was established in March 2002 by Managing Director Jamie Cuffe. Before this time the business was owned and run by Vin Panettieri who for 30 years had serviced the crane and transport industry known as Panna Crane & Truck Hire. Since the transfer Panna Cranes has grown to become a trusted and well respected member of the Construction and Transport Industries. With an ever growing fleet and extremely competent staff Panna Cranes is sure to attend to your every need 24hrs a day 7 days a week.</p>
                            </div>
                            <div class="small-img">
                                <img src="assets/images/reliable-cranes.jpg" alt="reliable-cranes" title="" width="454" height="236">
                            </div>
                        </div>

                        <div class="flex-container wrap flex-row-reverse">
                            <div class="small-ctent">
                                <div class="heading-22">Growth</div>
                                <p>Panna Cranes is committed to providing a service to all of its clients above their expectations. We will endeavour to grow with your Company’s needs, suppling practical, modern equipment and competent well trained staff. Panna Cranes strives towards a level of growth and service whilst maintaining our reputation of reliability an dependability to place it at the fore front of cranage and transport in the Australian market.</p>

                                <p>Panna Cranes provides quality Machinery Relocations and Trailer Hire services to Melbourne and surrounding areas.</p>
                            </div>
                            <div class="small-img">
                                <img src="assets/images/carne-provide-service.jpg" alt="carne-provide-service" title="" width="454" height="236">
                            </div>
                        </div>


                        <div class="divider mb-100"></div>


                        <div class="why-inner-client">
                            <div class="intro">
                                <div class="heading-46">Why Clients Rely on Panna Cranes</div>
                                <p>We’re Not Just a Crane Service — We’re Your Project Partner</p>
                            </div>

                            <?php block('client-list'); ?>

                        </div>



                    </div>
                </div>
                <div class="panel-right sticky">
                    

                    <?php block('lifting-factor-panel'); ?>

                    <?php block('services-list'); ?>


                </div>
            </div>

            <div class="divider"></div>

        </div>
    </section>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();