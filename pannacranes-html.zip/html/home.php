<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="homepg">

    <?php block('home/banner'); ?>


    <section class="crans-sec">
        <div class="container">
            <div class="crans-wrapper">
                <ul class="crane-list crane-js">
                    <li>
                        <div class="crane-box">
                            <div class="prod-img">
                                <img src="assets/images/liebherr-LTM.png" alt="liebherr-LTM" title="" width="" height="">
                            </div>
                            <div class="heading-18">Liebherr LTM 1080</div>
                        </div>
                    </li>
                    <li>
                        <div class="crane-box">
                            <div class="prod-img">
                                <img src="assets/images/grove-gmk-5130.png" alt="Grove Gmk5130" title="" width="" height="">
                            </div>
                            <div class="heading-18">Grove Gmk5130</div>
                        </div>
                    </li>
                    <li>
                        <div class="crane-box">
                            <div class="prod-img">
                                <img src="assets/images/terex-20.png" alt="Franna AT20" title="" width="" height="">
                            </div>
                            <div class="heading-18">Franna AT20</div>
                        </div>
                    </li>
                    <li>
                        <div class="crane-box">
                            <div class="prod-img">
                                <img src="assets/images/terex-mac-25-sl.png" alt="Franna Mac-25 SL" title="" width="" height="">
                            </div>
                            <div class="heading-18">Franna Mac-25 SL</div>
                        </div>
                    </li>
                    <li>
                        <div class="crane-box">
                            <div class="prod-img">
                                <img src="assets/images/franna-mac-25.png" alt="Franna Mac-25 SL" title="" width="" height="">
                            </div>
                            <div class="heading-18">Franna Mac-25 SL</div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>


    <!-- Start top content -->
    <section class="content-wrapper mb-100">
        <div class="container">
            <div class="flex-container wrap mb-100 align-items-start">
                <div class="col-6 ctent-column block-left">
                    <div class="semi-head">Welcome To Panna Cranes</div>
                    <div class="heading-46">Provides quality Machinery and Trailer Hire services to Melbourne and surrounding.</div>
                    <p>Panna Cranes Pty Ltd was established in March 2002 by Managing Director Jamie Cuffe. Before this time the business was owned and run by Vin Panettieri who for 30 years had serviced the crane and transport industry </p>

                    <a href="#" class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></a>
                </div>
                <div class="col-6 block-right">
                    <ul class="factor-block">
                        <li>
                            <div class="factbox">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/crane-icon.svg" alt="crane icon" title="" width="" height="">
                                </div>

                                <span class="arrow-down">
                                    <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                </span>

                                <p>Specializing in all areas of Construction for your Mobile Crane & Transport needs.</p>
                            </div>
                        </li>
                        <li>
                            <div class="factbox">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/setting.svg" alt="setting" title="" width="" height="">
                                </div>

                                <span class="arrow-down">
                                    <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                </span>

                                <p>Machinery installations  relocations Commercial Industrial & Domestic Crane Hire.</p>
                            </div>
                        </li>
                        <li>
                            <div class="factbox">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/crane-construction.svg" alt="crane construction" title="" width="" height="">
                                </div>

                                <span class="arrow-down">
                                    <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                </span>

                                <p>Crane Trucks & Semis Oversize Loads Moved all Permits Arranged Freeway Construction</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>


            <div class="divider"></div>
        </div>
    </section>
    <!-- End top content -->

    <?php block('home/our-transport-services'); ?>

    <?php block('home/why-clients'); ?>

    <?php block('text-slider'); ?>

    <?php block('home/maintained-fleet'); ?>
    
    <?php block('contect-cta'); ?>

    <?php block('home/testimonial-hm'); ?>

    <!-- Start content wrapper -->
    <section class="content-wrapper mb-100">
        <div class="container">
            <div class="flex-container wrap">
                <div class="img-block sticky image-pattern">
                    <img src="assets/images/crane-hire.jpg" alt="crane-hire" title="" width="720" height="600">
                </div>
                <div class="ctent-block ctent-column">
                    <div class="heading-36">Crane Hire Melbourne</div>
                    <p>Are you searching for safe and competent mobile crane hire in Melbourne? With nearly 15 years of
                        experience providing outstanding crane hire in Melbourne and across Victoria, the crew at Panna
                        Cranes is committed to meeting your worksite’s requirements. With a focus on high-quality crane
                        hire, Essendon, Sunshine, Tullamarine and other worksites throughout Victoria can benefit from
                        our well-maintained and varied range of machinery. For the best 24 hour crane hire in Melbourne,
                        there’s simply no looking past Panna Cranes</p>

                    <div class="heading-22">Crane Truck Hire Melbourne</div>
                    <p>With our passion and commitment for delivering a comprehensive crane hire service to our
                        customers the team at Panna Cranes strives to provide affordable crane truck hire. If you need
                        crane trucks in Melbourne, you can trust our Panna Cranes to deliver an honest and comprehensive
                        set of hire rates based on time required and the machinery or vehicle needed.</p>

                    <div class="heading-22">Mini, Mobile & Franna Crane Hire - Melbourne</div>

                    <p>No matter the size of your worksite, the team at Panna Cranes prides itself in being able to
                        deliver effective and affordable equipment to help you get the job done. Thanks to our
                        personalised mini, mobile and Franna crane hire in Melbourne, project managers and other
                        managers across Victoria can breathe easy</p>

                    <a href="#" class="button button-primary">Read More <img src="assets/images/svg/caret.svg"
                            alt="caret-orange" title="" width="9" height="10"></a>
                </div>
            </div>
        </div>
    </section>
    <!-- End content wrapper -->

    <?php block('blog-hm'); ?>

    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();