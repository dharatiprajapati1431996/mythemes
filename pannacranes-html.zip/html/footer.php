<footer>
    <div class="ft-top">
        <div class="container">
            <div class="flex-container wrap justify-between">
                <div class="ft-left">
                    <a href="home.php" class="ft-logo">
                        <img src="assets/images/panna-cranes.svg" alt="panna-cranes" title="" width="273" height="72">
                    </a>
                </div>
                <div class="ft-center">
                    <div class="heading-36">Let’s Lift Your Next Project Together</div>
                    <p>Call us any time, day or night — we’re ready when you are.</p>
                </div>
                <div class="button-group">
                    <a href="tel:03 9310 5440" class="button button-secondary"><img
                            src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                        03
                        9310 5440</a>
                    <a href="#" class="button button-theme">Get In Touch</a>
                </div>
            </div>
        </div>
    </div>

    <div class="ft-bottom">
        <div class="container">
            <div class="flex-container wrap align-items-start justify-between acc-nav">
                <div class="ft-address">
                    <div class="heading-20 ft-head">Contact details</div>
                    <ul class="contact-info">
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/location.svg" alt="location" title="" width="13"
                                        height="16">
                                </div>
                                <div class="ft-info">
                                    <p>72 Allied Drive, Tullamarine VIC 3043.</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/phone.svg" alt="phone" title="" width="19" height="19">
                                </div>
                                <div class="ft-info">
                                    <a href="tel:03 9310 5440">03 9310 5440</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/fax.svg" alt="fax" title="" width="17" height="17">
                                </div>
                                <div class="ft-info">
                                    <p>03 9310 5441</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/email.svg" alt="email" title="" width="21" height="16">
                                </div>
                                <div class="ft-info">
                                    <a href="mailto:pannacranes@bigpond.com">pannacranes@bigpond.com</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                    <div class="follow-wrap">
                        <div class="heading-20 ft-head">follow us now</div>
                        <ul class="follow-list">
                            <li><a href="#"><img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="24"
                                        height="24"></a></li>
                            <li><a href="#"><img src="assets/images/svg/instagram.svg" alt="instagram" title=""
                                        width="24" height="24"></a></li>
                        </ul>
                    </div>


                </div>
                <div class="ft-quick">
                    <div class="heading-20 ft-head acc-nav-head">Quick Links</div>
                    <ul class="quick-link">
                        <li><a href="home.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="#">Panna At Work</a></li>
                        <li><a href="#">Fleet</a></li>
                        <li><a href="blog.php">Blogs</a></li>
                        <li><a href="areas.php">Areas</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="ft-services">
                    <div class="heading-20 ft-head acc-nav-head">Our Services</div>
                    <ul class="quick-link">
                        <li><a href="#">General Crane Hire</a></li>
                        <li><a href="#">Lift Planning and Engineering</a></li>
                        <li><a href="#">Safety</a></li>
                        <li><a href="#">Railway Work</a></li>
                        <li><a href="#">Civil Construction</a></li>
                        <li><a href="#">Light Pole Installation</a></li>
                        <li><a href="#">Machinery Relocation</a></li>
                    </ul>
                </div>
                <div class="ft-content">
                    <p>Glass Lifting Installation & Transportation </p>
                    <p>Concrete Panel Lifting Installation & Transportation Air Conditioning </p>
                    <p>Transformer and Switchboard Lifting Installation & Transportation </p>
                    <p>Structural Steel Installation and Rigging </p>
                    <p>Construction Materials For Domestic & Commercial Sites</p>
                    <p>Signs, Transportation, And Relocation</p>
                </div>
            </div>
        </div>

        <img src="assets/images/footer-text.svg" alt="footer-text" title="" width="1640" height="73"
            class="footer-bottom-text">

    </div>





    <!-- START COPYRIGHT -->
    <div class="copyright text-center">
        <div class="container">
            <p>Copyright © 2025 Panna Cranes. All Rights Reserved.</p>
        </div>
    </div>
    <!-- END COPYRIGHT -->

</footer>

<button class="scrollTop"><i class="fa fa-angle-up" aria-hidden="true"></i> </button>


<?php wp_footer(); ?>
</body>

</html>