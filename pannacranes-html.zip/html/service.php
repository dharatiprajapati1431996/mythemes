<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper services-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                        <div class="semi-head">Heavy Lifts Made Easy</div>
                        <div class="heading-50">Services</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Services</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
           
           <div class="heading-46 extra-blod">Our Crane & Transport Services</div>



           <ul class="services-grid flex wrap service-grid-inner">
                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/general-crane-hire-img.jpg" alt="General Crane Hire" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/machinery-icon.svg" alt="machinery-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">General Crane Hire</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/lift-planning-engineering.jpg" alt="Lift Planning Engineering" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/rigging-icon.svg" alt="rigging-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Lift Planning Engineering</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/safety.jpg" alt="safety" title="" width="390" height="360">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/panel-insta-icon.svg" alt="panel-insta-icon" title="" width="" height="">
                            </div>


                            <div class="heading-24">Safety</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/civil-construction.jpg" alt="Civil Construction" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/switchboards-icon.svg" alt="switchboards-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Civil Construction</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/light-pole-installation.jpg" alt="Light Pole Installation" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/machinery-icon.svg" alt="machinery-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Light Pole Installation</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/machinery-relocation-img1.jpg" alt="Machinery Relocation" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/rigging-icon.svg" alt="rigging-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Machinery Relocation</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/signs-transportation.jpg" alt="Signs Transportation" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/panel-insta-icon.svg" alt="panel-insta-icon" title="" width="" height="">
                            </div>


                            <div class="heading-24">Signs, Transportation, And Relocation </div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/machinery-relocation-img.jpg" alt="Machinery Relocation" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/switchboards-icon.svg" alt="switchboards-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Machinery Relocation</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/structural-steel-installation.jpg" alt="Structural Steel  Installation" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/machinery-icon.svg" alt="machinery-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Structural Steel  Installation And Rigging</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/glass-lifting-Installation.jpg" alt="Glass Lifting  Installation" title="" width="500" height="360">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/rigging-icon.svg" alt="rigging-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Glass Lifting  Installation & Transportation </div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/concrete-panel-lifting.jpg" alt="concrete-panel-lifting" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/panel-insta-icon.svg" alt="panel-insta-icon" title="" width="" height="">
                            </div>


                            <div class="heading-24">Concrete Panel Lifting Installation & Transportation</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/air-conditioning-img.jpg" alt="air-conditioning" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/switchboards-icon.svg" alt="switchboards-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Air Conditioning </div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/transformer-switchboard.jpg" alt="Transformer And Switchboard" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/machinery-icon.svg" alt="machinery-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Transformer And Switchboard Lifting Installation & Transportation </div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/railway-work.jpg" alt="Railway Work" title="" width="500" height="360">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/rigging-icon.svg" alt="rigging-icon" title="" width="" height="">
                            </div>

                            <div class="heading-24">Railway Work</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#" class="item-box line-shape">
                        <div class="ser-img">
                            <img src="assets/images/construction-domestic.jpg" alt="construction-domestic" title="" width="390" height="281">
                        </div>
                        <div class="ser-info">
                            <div class="icon">
                                <img src="assets/images/svg/panel-insta-icon.svg" alt="panel-insta-icon" title="" width="" height="">
                            </div>


                            <div class="heading-24">Construction Materials For Domestic & Commercial Sites</div>
                            <span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
                        </div>
                    </a>
                </li>

            </ul>

        </div>
    </section>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();