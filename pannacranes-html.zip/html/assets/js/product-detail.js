$( document ).ready(function() {
	

		// fleet 
		$('.other-fleet-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 4,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1440,
					settings: {
						slidesToShow: 3,
					}
				},
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 2,
					}
				},
				{
					breakpoint: 481,
					settings: {
						slidesToShow: 1,
					}
				}
			]
		});


});
