$(document).ready(function () {


	/*Scroll top*/
	var scrollTop = $(".scrollTop");
	$(window).scroll(function () {
		var topPos = $(this).scrollTop();
		if (topPos > 0) {
			$(scrollTop).css("opacity", "1");
		} else {
			$(scrollTop).css("opacity", "0");
		}
	});
	$(scrollTop).click(function () {
		$('html, body').animate({
			scrollTop: 0
		}, 600);
		return false;
	});


	/*-----MENU DROPDOWN-----*/

	$('.menu-link ul li:has(ul)').addClass("haschild");
	var caicon = $('<i class="fa fa-angle-down menudrop" aria-hidden="true"></i>');
	$('.menu-link ul li:has(ul) > a').append(caicon);
	$('.menu-link ul li:has(ul) > a').next().addClass("childmenu");

	$('.menu-link .sub-menu.megamenu  .sublink  li').on('mouseenter', function () {
		$(this).siblings().removeClass('menu-item-hover');
		$(this).addClass('menu-item-hover');
	});



 if (($(window).width() <= 1199)) {
			$('.menudrop').on('click', function (e) {
			var label = $(this).parent();
			var parent = label.parent('.haschild');
			var list = label.siblings('.childmenu');
			e.preventDefault();
			if (parent.hasClass('isopen')) {
				list.slideUp('fast');
				parent.removeClass('isopen');
			} else {
				parent.parent().find('li.haschild').removeClass('isopen');
				parent.parent().find('li.haschild .childmenu').slideUp(350);
				list.slideDown('fast');
				parent.addClass('isopen');
			}
		});
	} 
	else 
	{
			$('.menudrop').on('click', function (e) {
				e.preventDefault();
				var label = $(this).parent();
				var parent = label.parent('.haschild');
				var list = label.siblings('.childmenu');
				if (parent.hasClass('isopen')) {
						list.hide();
						parent.removeClass('isopen');
						$('body').removeClass("menuoverlay");
				} 
			else 
				{
						parent.parent().find('li.haschild').removeClass('isopen');
						label.parent().parent().find("li .childmenu").hide();
						parent.addClass('isopen');
						label.parent().parent().find("li.isopen .childmenu").show();
						$('body').addClass("menuoverlay");
			}
		});
	}

	$('li.has-sub').hover(
			function () {
				$('body').addClass('menuoverlay');
			},
			function () {
				$('body').removeClass('menuoverlay');
			}
	);
	
	/*-----BURGER MENU-----*/
	$(".togglebtn, .overlay").click(function () {
		$(".togglebtn, .overlay,.menu-link").toggleClass("active");
		if ($(".overlay").hasClass("active")) {
			$(".overlay").fadeIn();
			$('html').addClass('menuhidden');

		} else {
			$(".overlay").fadeOut();
			$('html').removeClass('menuhidden');

		}
	});



	/*-----FIXED HEADER-----*/

	$(window).scroll(function () {
		if (($(window).scrollTop() > 180) && ($(window).width() >= 320)) {
			$('body').addClass('fixed-header');
		} else {
			$('body').removeClass('fixed-header');
		}
	});


	// FANCYBOX
    // $("[data-fancybox]").fancybox({
    //     // Options will go here
    //     slideShow  : false,
    //     fullScreen : false,
    //     thumbs     : true,
    //     closeBtn   : true, 
    //     slideShow  : true,  
    // });
	

	
	//  Footer Accordion

	$(".acc-nav .acc-nav-head").click (function(){
		if ($(window).width() < 992) {
			let $this = $(this);
			
			$this.toggleClass('showhide');

			let $wrapper = $this.closest('.acc-nav');
			let $heads = $wrapper.find('.acc-nav-head');

			$heads.not($this).removeClass('showhide');
			$heads.not('.showhide').next().stop().slideUp(300);
			$heads.filter('.showhide').next().stop().slideDown(300);
		}
	});



	//  Services Accordion 

	$(".service-show-mobile .service-nav-head").click (function(){
		if ($(window).width() < 992) {
			let $this = $(this);
			
			$this.toggleClass('showhide');

			let $wrapper = $this.closest('.service-show-mobile');
			let $heads = $wrapper.find('.service-nav-head');

			$heads.not($this).removeClass('showhide');
			$heads.not('.showhide').next().stop().slideUp(300);
			$heads.filter('.showhide').next().stop().slideDown(300);
		}
	});



	// OUR PRODUCT
		$('.companies-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 7,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1600,
					settings: {
						slidesToShow: 5
					}
				},
				{
					breakpoint: 1440,
					settings: {
						slidesToShow: 4
					}
				},
				{
					breakpoint: 1200,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 2,
					}
				}
			]
		});
   

 

});


 
 