$( document ).ready(function() {

		// OUR PRODUCT
		$('.client-customer-wrapper .client-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 2,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1200,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 1,
					}
				}
			]
		});
	

});
