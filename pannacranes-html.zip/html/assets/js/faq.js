$(document).ready(function () {

//FAQ
$(".faq_accordion").smk_Accordion({
    closeAble: true, //boolean
    //closeOther: false, //boolean
    activeIndex: 1 //second section open
});


// ADD ACTIVE AND REMOVE CLASS
$(".faq-items li  ").click(function () {
    $(".faq-items li.active").removeClass('active')
    $(this).addClass('active')
 });

 // PROJECT FIXED TOP
    $(function() {
        //caches a jQuery object containing the header element
        var header = $("body");
        $(window).scroll(function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 500) {
                header.removeClass('remove_fixed_tab').addClass("tab_fixed");
            } else {
                header.removeClass("tab_fixed").addClass('remove_fixed_tab');
            }
        });
    });

});
    

