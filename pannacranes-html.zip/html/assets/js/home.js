$( document ).ready(function() {
	$('.js_hmbanner').slick({
		arrows: false,
		dots: false,
		slidesToShow: 1,
		slidesToScroll: 1,
		horizontal: true,
		infinite: true,
		autoplay: true,
		fade: true,
		pauseOnHover: false,
		autoplaySpeed: 5000,
		responsive: [
			{
				breakpoint: 601,
				settings: {
					arrows: false,
					dots: false
				}
			}
		]
	});

		


		$('.slider-text').slick({
				speed: 40000,
			    autoplay: true,
			    autoplaySpeed: 0,
			    centerMode: false,
			    cssEase: 'linear',
			    slidesToShow: 1,
			    slidesToScroll: 1,
			    variableWidth: true,
			    infinite: true,
			    initialSlide: 1,
			    arrows: false,
			    buttons: false
		  });


		// blog
		$('.crane-js').slick({
			arrows: false,
			dots: false,
			slidesToShow: 5,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1440,
					settings: {
						slidesToShow: 4,
					}
				},
				{
					breakpoint: 1200,
					settings: {
						slidesToShow: 3,
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 2,
					}
				},
				{
					breakpoint: 361,
					settings: {
						slidesToShow: 1,
					}
				}
			]
		});



		// fleet 
		$('.fleet-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 4,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1440,
					settings: {
						slidesToShow: 3,
					}
				},
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 2,
					}
				},
				{
					breakpoint: 481,
					settings: {
						slidesToShow: 1,
					}
				}
			]
		});



		// Client 
		$('.client-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 3,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1200,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 1,
						adaptiveHeight: true, 
					}
				}
			]
		});



		// blog
		$('.blog-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 3,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1200,
					settings: {
						slidesToShow: 2
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 1,
						centerMode: true,
  						centerPadding: '30px',
					}
				}
			]
		});



		// OUR PRODUCT
		$('.services-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 4,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1200,
					settings: {
						slidesToShow: 3
					}
				},
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 2,
					}
				},
				{
					breakpoint: 576,
					settings: {
						slidesToShow: 1,
						centerMode: true,
  						centerPadding: '30px',
					}
				}
			]
		});
	

});
