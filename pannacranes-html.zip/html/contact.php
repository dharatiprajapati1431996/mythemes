<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper contact-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                        <div class="semi-head">Over 20 Years of Safe, Reliable, and 24/7 Lifting Solutions for All Industries</div>
                        <div class="heading-50">Contact Us</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03
                                9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Contact Us</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
            <div class="flex-container wrap align-items-start">
                <div class="panel-left">
                    <div class="contact-wrap flex-container wrap align-items-start">
                        <div class="cont-left">
                            <div class="intro">
                                <div class="heading-22">Reach Out for Reliable Crane & Transport Solutions</div>
                                <p>Looking for reliable crane hire or expert machinery relocation services in Melbourne and across Victoria? Our team is here to help—no job is too big or too small.</p>
                            </div>

                            <div class="divider"></div>

                            <div class="ctact-detail">
                                <div class="heading-22">Contact Details:</div>

                                <ul class="contact-info">
                                    <li>
                                        <div class="ft-box">
                                            <div class="ft-icon">
                                                <img src="assets/images/svg/location-black.svg" alt="location" title="" width="13" height="16">
                                            </div>
                                            <div class="ft-info">
                                                <p>72 Allied Drive, Tullamarine VIC 3043.</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ft-box">
                                            <div class="ft-icon">
                                                <img src="assets/images/svg/phone-call-black.svg" alt="phone" title="" width="19" height="19">
                                            </div>
                                            <div class="ft-info">
                                                <a href="tel:03 9310 5440">03 9310 5440</a>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ft-box">
                                            <div class="ft-icon">
                                                <img src="assets/images/svg/fax-black.svg" alt="fax" title="" width="17" height="17">
                                            </div>
                                            <div class="ft-info">
                                                <p>03 9310 5441</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ft-box">
                                            <div class="ft-icon">
                                                <img src="assets/images/svg/mail-black.svg" alt="email" title="" width="21" height="16">
                                            </div>
                                            <div class="ft-info">
                                                <a href="mailto:pannacranes@bigpond.com">pannacranes@bigpond.com</a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                            <div class="divider"></div>

                            <ul class="follow-list">
                                <li><a href="#"><img src="assets/images/svg/facebook-black.svg" alt="facebook" title="" width="24" height="24"></a></li>
                                <li><a href="#"><img src="assets/images/svg/instagram-black.svg" alt="instagram" title="" width="24" height="24"></a></li>
                            </ul>

                        </div>
                        <div class="map-block">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3156.2880641244883!2d144.86830057670585!3d-37.712915728282525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65958fb292a81%3A0x5d77b0323ef692cf!2s72%20Allied%20Dr%2C%20Tullamarine%20VIC%203043%2C%20Australia!5e0!3m2!1sen!2sin!4v1751438665680!5m2!1sen!2sin" width="100%" height="554" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
                <div class="panel-right sticky">
                    <div class="form-wrap box-wrap">
                        <div class="intro text-center">
                            <div class="heading-36">Get in Touch</div>
                            <p>Available for hire feel free to contact us today</p>
                        </div>

                        <form class="form_box">
                            <div class="form-group">
                                <input class="form-control" type="text" name="name" placeholder="Name">
                            </div>
                            <div class="row">
                                <div class="form-group width50">
                                    <input class="form-control" type="phone" name="phone" placeholder="Phone">
                                </div>
                                <div class="form-group width50">
                                    <input class="form-control" type="email" name="phone" placeholder="Email">
                                </div>
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" name="suburb" placeholder="Suburb">
                            </div>
                            
                            <div class="form-group">
                                <select name="" id="services" class="form-control">
                                    <option value="">Select Service or Feet</option>
                                    <option value=""></option>
                                    <option value=""></option>
                                    <option value=""></option>
                                </select>
                            </div>

                            <div class="form-group message_area width100">
                                <textarea class="form-control" placeholder="Message" name="your-message"></textarea>
                            </div>
                            <div class="submit_btn">
                                <input type="submit" name="" value="submit" class="btnsubmit">
                            </div>
                        </form>

                        <div class="ratting-wrap">
                            <div class="google-column fact-column">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/google-ratting.svg" alt="google-ratting" title="" width="45" height="46">
                                </div>
                                <div class="fact-info">
                                    <img src="assets/images/svg/star.svg" alt="star" title="" width="68" height="11" class="star">
                                    3.9 Ratings 
                                    <span>41 Google Reviews </span>
                                </div>
                            </div>
                            <div class="ser-availabilty fact-column">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/24-services.svg" alt="24-services" title="" width="50" height="50">
                                </div>
                                <div class="fact-info">
                                    24/7 Service Availability
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();