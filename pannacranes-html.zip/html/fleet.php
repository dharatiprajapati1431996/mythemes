<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper fleet-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                        <div class="semi-head">Heavy Lifts Made Easy</div>
                        <div class="heading-50">Fleet</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container">
            <ul class="woo_breadcums full-breadcurmb">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Fleet</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
           
            <ul class="fleet-prod-list flex wrap">
                <li>
                    <div class="prod-item">
                        <div class="prod-img">
                            <img src="assets/images/terrain-mobile-crane.png" alt="Terrain/Mobile Crane" title="" width="" height="">
                        </div>
                        <div class="prod-info">
                            <div class="col-left">
                                <div class="heading-34">All Terrain/ Mobile Crane</div>
                                <a href="#" class="button button-primary">More Details</a>
                            </div>

                            <div class="col-right">
                                <ul class="prod-nav-link">
                                    <li><a href="#">Tadano AC3060 60T</a></li>
                                    <li><a href="#">Liebherr LTM 1080 80T</a></li>
                                    <li><a href="#">Grove GMK5130 130T</a></li>
                                    <li><a href="#">Kobelco RK70 city crane 7T</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
                 <li>
                    <div class="prod-item">
                        <div class="prod-img">
                            <img src="assets/images/franna-crane.png" alt="franna-crane" title="" width="" height="">
                        </div>
                        <div class="prod-info">
                            <div class="col-left">
                                <div class="heading-34">Franna<br> Crane</div>
                                <a href="#" class="button button-primary">More Details</a>
                            </div>

                            <div class="col-right">
                                <ul class="prod-nav-link">
                                    <li><a href="#">Franna AT-14</a></li>
                                    <li><a href="#">Franna AT-20</a></li>
                                    <li><a href="#">Franna Mac-25</a></li>
                                    <li><a href="#">Franna Mac-25 SL</a></li>
                                    <li><a href="#">Franna AT-40</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
                 <li>
                    <div class="prod-item">
                        <div class="prod-img">
                            <img src="assets/images/crane-truck.png" alt="Crane Truck" title="" width="" height="">
                        </div>
                        <div class="prod-info">
                            <div class="col-left">
                                <div class="heading-34">Crane<br> Truck</div>
                                <a href="#" class="button button-primary">More Details</a>
                            </div>

                            <div class="col-right">
                                <ul class="prod-nav-link">
                                    <li><a href="#">Volvo HMF 4020 K6 + Fly FJ600 </a></li>
                                    <li><a href="#">Western Star semi Crane HMF 4020 K4</a></li>
                                    <li><a href="#">Mercedes HMF 5020 K5</a></li>
                                    <li><a href="#">Hino HMF 2820 K6</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
                 <li>
                    <div class="prod-item">
                        <div class="prod-img">
                            <img src="assets/images/semi-truck.png" alt="semi-truck" title="" width="" height="">
                        </div>
                        <div class="prod-info">
                            <div class="col-left">
                                <div class="heading-34">Semi<br> Truck</div>
                                <a href="#" class="button button-primary">More Details</a>
                            </div>

                            <div class="col-right">
                                <p>At Panna Cranes, we also offer general semi hire and heavy haulage solutions with our fleet of extendable step deck trailers.</p>

                                <ul class="prod-nav-link">
                                    <li><a href="#">General semi hireheavy haulage</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();