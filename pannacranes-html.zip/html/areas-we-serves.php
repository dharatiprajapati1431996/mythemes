<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper areas-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                  <div class="bread-left">
                    <div class="semi-head">Lifting, Moving, and Building with Precision</div>
                    <div class="heading-50">Search for Crane Solutions in Your Area</div>

                    <form class="suburb-search-form" method="post" action="/">
                        <input type="search" name="suburb_locations" value="" placeholder="Enter Suburb" class="ui-autocomplete-input" autocomplete="off">
                        <button type="button"><img src="assets/images/svg/search.svg" alt="search" title="" width="18" height="18"></button>
                        <ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" unselectable="on" style="display: none;"></ul>
                    </form>
                  </div>
                </div>
               
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Areas We Serve</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100 content-wrapper">
        <div class="container">
            <div class="flex-container wrap align-items-start">
                <div class="panel-left">
                   <div class="service-show-mobile hidden">
                        <?php block('services-list'); ?>
                    </div>
                   <div class="areas-top-content mb-100">
                       <div class="flex-container wrap">
                           <div class="areas-left">
                               <div class="heading-22">Areas We Serve</div>
                               <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. </p>

                               <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                           </div>
                           <div class="areas-right">
                               <img src="assets/images/cranes-loading.jpg" alt="cranes-loading" title="" width="452" height="260">
                           </div>
                       </div>
                   </div>


                   <div class="divider mb-100"></div>

                   <div class="areas-location-wrapper">
                        <div class="flex-container wrap">
                            <div class="areas-ctent">
                               <div class="heading-36">We operate Victoria Wide</div>

                               <ul class="areas-list">
                                   <li><a href="#">Sunshine</a></li>
                                   <li><a href="#">Tullamarine</a></li>
                                   <li><a href="#">Essendon</a></li>
                                   <li><a href="#">Coburg</a></li>
                                   <li><a href="#">Craigieburn</a></li>
                                   <li><a href="#">Maribyrnong</a></li>
                                   <li><a href="#">Mernda</a></li>
                                   <li><a href="#">Yarraville</a></li>
                                   <li><a href="#">Morang</a></li>
                                   <li><a href="#">Campbellfield</a></li>
                                   <li><a href="#">Derrimut</a></li>
                                   <li><a href="#">Footscray</a></li>
                                   <li><a href="#">Heidelberg</a></li>
                                   <li><a href="#">Laverton</a></li>
                                   <li><a href="#">Melton</a></li>
                                   <li><a href="#">Epping</a></li>
                                   <li><a href="#">Preston</a></li>
                                   <li><a href="#">St Albans</a></li>
                                   <li><a href="#">Sunbury</a></li>
                                   <li><a href="#">Taylors Lakes</a></li>
                                   <li><a href="#">Thomastown</a></li>
                                   <li><a href="#">Tottenham</a></li>
                                   <li><a href="#">Truganina</a></li>
                               </ul>

                           </div>
                           <div class="areas-img sticky">
                               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3156.2880641244883!2d144.86830057670585!3d-37.712915728282525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65958fb292a81%3A0x5d77b0323ef692cf!2s72%20Allied%20Dr%2C%20Tullamarine%20VIC%203043%2C%20Australia!5e0!3m2!1sen!2sin!4v1751539549202!5m2!1sen!2sin" width="100%" height="366" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                           </div>
                        </div>

                        <div class="divider mb-100"></div>

                        <div class="flex-container wrap flex-row-reverse">
                            <div class="areas-ctent">
                               <div class="heading-36">40 tonne Franna - We operate Victoria Wide</div>

                               <ul class="areas-list">
                                   <li><a href="#">40 tonne Crane <span>Campbellfield</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Coburg</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Craigieburn</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Epping</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Essendon</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Footscray</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Tullamarine</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Maribyrnong</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Melton</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Mernda</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Preston</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>South Morang</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>St Albans</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Yarraville</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Sunbury</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Sunshine</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Taylors Lakes</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Thomastown</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Tottenham</span></a></li>
                                   <li><a href="#">40 tonne Crane <span>Truganina</span></a></li>
                               </ul>

                           </div>
                           <div class="areas-img sticky">
                              <img src="assets/images/operate-img.jpg" alt="operate-img" title="" width="398" height="366">
                           </div>
                        </div>

                        <div class="divider mb-100"></div>


                        <div class="flex-container wrap">
                            <div class="areas-ctent">
                               <div class="heading-36">60 tonne Franna - We operate Victoria Wide</div>

                                <ul class="areas-list">
                                    <li><a href="#">60 tonne Crane<span>Campbellfield</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Coburg</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Craigieburn</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Epping</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Essendon</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Footscray</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Tullamarine</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Maribyrnong</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Melton</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Mernda</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Preston</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>South Morang</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>St Albans</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Yarraville</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Sunbury</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Sunshine</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Taylors Lakes</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Thomastown</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Tottenham</span></a></li>
                                    <li><a href="#">60 tonne Crane<span>Truganina</span></a></li>
                                </ul>

                                <div class="button-group">
                                    <a href="tel:03 9310 5440" class="button button-primary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">03 9310 5440</a>
                                    <a href="#" class="button button-theme">Get In Touch</a>
                                </div>

                           </div>
                           <div class="areas-img sticky">
                              <img src="assets/images/operate-img1.jpg" alt="operate-img" title="" width="398" height="366">
                           </div>
                        </div>
                   </div>
                </div>

                <div class="panel-right sticky">
                    <?php block('get-form'); ?>

                    <?php block('services-list'); ?>
                    
                </div>
            </div>
        </div>
    </section>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();