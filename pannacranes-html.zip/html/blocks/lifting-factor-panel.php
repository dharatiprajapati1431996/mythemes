<div class="box-wrap building-box mb-60">
                        <div class="heading-30">Lifting, Moving, and Building with Precisions</div>

                        <ul class="factor-block inner-factor-list">
                            <li>
                                <div class="factbox">
                                    <div class="fact-icon">
                                        <img src="assets/images/svg/crane-icon.svg" alt="crane icon" title="" width="66" height="65">
                                    </div>

                                    <p>Specializing in all areas of Construction for your Mobile Crane & Transport needs.</p>
                                </div>
                            </li>
                            <li>
                                <div class="factbox">
                                    <div class="fact-icon">
                                        <img src="assets/images/svg/setting.svg" alt="setting" title="" width="55" height="55">
                                    </div>

                                    <p>Machinery installations  relocations Commercial Industrial & Domestic Crane Hire.</p>
                                </div>
                            </li>
                            <li>
                                <div class="factbox">
                                    <div class="fact-icon">
                                        <img src="assets/images/svg/crane-construction.svg" alt="crane construction" title="" width="67" height="63">
                                    </div>

                                    <p>Crane Trucks & Semis Oversize Loads Moved all Permits Arranged Freeway Construction</p>
                                </div>
                            </li>
                        </ul>
                    </div>