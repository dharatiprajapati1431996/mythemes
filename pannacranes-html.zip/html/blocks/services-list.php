<div class="box-wrap service-list-box">
    <div class="heading-34 service-nav-head">Our Services</div>

    <ul class="service-link mb-0">
        <li><a href="#">General Crane Hire</a></li>
        <li><a href="#">Lift Planning And Engineering</a></li>
        <li><a href="#">Safety</a></li>
        <li><a href="#">Civil Construction</a></li>
        <li><a href="#">Light Pole Installation</a></li>
        <li><a href="#">Machinery Relocation</a></li>
        <li><a href="#">Signs, Transportation, And Relocation </a></li>
        <li><a href="#">Structural Steel  Installation And Rigging</a></li>
        <li><a href="#">Glass Lifting  Installation & Transportation </a></li>
        <li><a href="#">Concrete Panel Lifting Installation & Transportation</a></li>
        <li><a href="#">Air Conditioning </a></li>
        <li><a href="#">Transformer And Switchboard Lifting Installation & Transportation </a></li>
        <li><a href="#">Railway  Work </a></li>
        <li><a href="#">Construction Materials For  Domestic & Commercial  Sites</a></li>
    </ul>
</div>