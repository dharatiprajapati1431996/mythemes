<!--  Start latest blog -->
<section class="hm-blog mb-100 py-100 light-gray-bg">
    <div class="container">
        <div class="heading-46 extra-blod">Latest Blog Posts</div>


        <ul class="blog-grid blog-js">
            <li>
                <div class="blog-card">
                    <div class="blog-image">
                        <img src="assets/images/reliable-crane.jpg" alt="reliable-crane" title="" width="511" height="">
                    </div>
                    <div class="blog-post">
                        <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title=""
                                width="16" height="18"> 10 Apr 2024 </div>
                        <div class="heading-18">Reliable Crane Hire Services In Melbourne – Why Panna Cranes Leads The
                            Way</div>

                        <p>Looking for dependable crane hire in Melbourne? Panna Cranes is your go-to partner for safe,
                            efficient</p>

                        <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg"
                                alt="caret-orange" title="" width="9" height="10"></a>
                    </div>
                </div>
            </li>
            <li>
                <div class=" blog-card">
                    <div class="blog-image">
                        <img src="assets/images/crane-truck.jpg" alt="crane-truck" title="" width="511" height="">
                    </div>
                    <div class="blog-post">
                        <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title=""
                                width="16" height="18">10 Jun 2025 </div>
                        <div class="heading-18">Crane Truck Hire In Melbourne – Affordable, Flexible & Reliable</div>

                        <p>When it comes to crane truck hire in Melbourne, Panna Cranes understands that flexibility and
                            affordability are just as important as reliability.</p>

                        <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg"
                                alt="caret-orange" title="" width="9" height="10"></a>
                    </div>
                </div>
            </li>
            <li>
                <div class="blog-card">
                    <div class="blog-image">
                        <img src="assets/images/crane-companies.jpg" alt="crane-companies" title="" width="511"
                            height="">
                    </div>
                    <div class="blog-post">
                        <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title=""
                                width="16" height="18">10 May 2024</div>
                        <div class="heading-18">Crane Companies In Melbourne – What Makes Panna Cranes A Standout Choice
                        </div>

                        <p>In a competitive market of crane companies in Melbourne, Panna Cranes distinguishes itself.
                        </p>

                        <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg"
                                alt="caret-orange" title="" width="9" height="10"></a>
                    </div>
                </div>
            </li>
        </ul>

        <div class="text-center mt-50">
            <a href="#" class="button button-primary">View All Blog <img src="assets/images/svg/caret.svg"
                    alt="caret-orange" title="" width="9" height="10"></a>
        </div>
    </div>
</section>
<!--  End latest blog -->