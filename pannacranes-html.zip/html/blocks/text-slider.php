
<!-- Start text slider  -->
<section class="text-slider darkblue mb-100">
	<div class="slider-text">
		<div class="text-logo">Panna Cranes</div> 
		<div class="text-logo">Expert Operators & Riggers</div>
		<div class="text-logo">Machinery Relocations and Trailer Hire services</div>
		<div class="text-logo">Panna Cranes</div> 
		<div class="text-logo">Expert Operators & Riggers</div>
		<div class="text-logo">Machinery Relocations and Trailer Hire services</div>
	</div>
</section>
<!-- End text slider  -->