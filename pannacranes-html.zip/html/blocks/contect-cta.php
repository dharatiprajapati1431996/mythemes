
<!-- Start expert Operators -->
<section class="contect-cta mb-100 py-100 relative">
	<div class="parallax-item">
		<img src="assets/images/banner.jpg" alt="cta-bg" title="" width="1920" height="800" class="img-parallax" data-speed="-1">
	</div>
	<div class="container">
		<div class="cta-wrapper line-shape flex-container wrap">
			<div class="cta-left">
				<div class="semi-head">Expert Operators & Riggers</div>
				<div class="heading-30">Panna Cranes provides quality Machinery Relocations and Trailer Hire services to Melbourne and surrounding areas.</div>

				<p>We’re Not Just a Crane Service — We’re Your Project Partner</p>

				<div class="button-group">
                    <a href="tel:03 9310 5440" class="button button-primary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                        03
                        9310 5440</a>
                    <a href="#" class="button button-theme">Get In Touch</a>
                </div>


			</div>
			<div class="cta-right">
				<img src="assets/images/badge.svg" alt="badge" title="" width="200" height="200" class="badge">
				<img src="assets/images/crane.png" alt="crane" title="" width="723" height="536" class="crane-img">
			</div>
		</div>
	</div>
</section>
<!-- End expert Operators -->