
		<ul class="choose-grid flex wrap">
			<li>
				<div class="choose-box">
					<div class="choose-icon">
						<img src="assets/images/svg/services-availabilty.svg" alt="Service Availability" title="" width="55" height="54">
					</div>
					<div class="choose-info">
						<div class="heading-18">24/7 Service Availability</div>
						<p>With 24/7 availability, our cranes and crew are just a call away, anytime you need us.</p>
					</div>
				</div>
			</li>

			<li>
				<div class="choose-box">
					<div class="choose-icon">
						<img src="assets/images/svg/expert-operators.svg" alt="Expert Operators" title="" width="54" height="44">
					</div>
					<div class="choose-info">
						<div class="heading-18">Expert Operators & Riggers</div>
						<p>Our certified operators and riggers bring precision, safety, and expertise to every lift.</p>
					</div>
				</div>
			</li>

			<li>
				<div class="choose-box">
					<div class="choose-icon">
						<img src="assets/images/svg/modern-fleet.svg" alt="Modern Fleet" title="" width="36" height="63">
					</div>
					<div class="choose-info">
						<div class="heading-18">Modern Fleet Of Cranes & Trailers</div>
						<p>Our modern fleet of cranes and trailers ensures safe, efficient, reliable lifting solutions.</p>
					</div>
				</div>
			</li>

			<li>
				<div class="choose-box">
					<div class="choose-icon">
						<img src="assets/images/svg/strong-safety.svg" alt="Strong Safety" title="" width="50" height="50">
					</div>
					<div class="choose-info">
						<div class="heading-18">Strong Safety Record</div>
						<p>Our impeccable safety record reflects our commitment to protecting people.</p>
					</div>
				</div>
			</li>

			<li>
				<div class="choose-box">
					<div class="choose-icon">
						<img src="assets/images/svg/fully-licensed.svg" alt="Fully Licensed" title="" width="52" height="65">
					</div>
					<div class="choose-info">
						<div class="heading-18">Fully Licensed & Insured</div>
						<p>As a fully licensed and insured crane service provider, we deliver peace of mind with every lift.</p>
					</div>
				</div>
			</li>

			<li>
				<div class="choose-box">
					<div class="choose-icon">
						<img src="assets/images/svg/family-owned.svg" alt="Family-Owned" title="" width="57" height="51">
					</div>
					<div class="choose-info">
						<div class="heading-18">Family-Owned, Decades Of Experience</div>
						<p>Established in 2002, Panna Cranes is a family-owned business that has built a reputation.</p>
					</div>
				</div>
			</li>


		</ul>