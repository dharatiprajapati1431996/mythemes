 <!-- banner section start -->

 <section class="banner">

        <div class="js_hmbanner">
            <div class="slideingdiv">
                <img src="assets/images/banner.jpg" alt="banner" title="" width="1920" height="800" class="desktop-banner" />
                <img src="assets/images/banner.jpg" alt="banner" title="" width="767" height="450" class="mobile-banner" />
                    <div class="bannertext">
                    <div class="hmbo_wrap container">
                        <div class="webox flex-container wrap justify-between align-items-start">
                            <div class="banner-left">
                                <div class="heading-70">Melbourne’s Trusted Crane & Transport Specialists</div>

                                <div class="head-xs">Over 20 Years of Safe, Reliable, and 24/7 Lifting Solutions for All Industries</div>

                               <div class="button-group">
                                    <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">03 9310 5440</a>
                                    <a href="#" class="button button-theme">Get In Touch</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


        </div>



        <div class="banner-form">
            <?php block('get-form'); ?>
        </div>

    
    </section> 
    

 <!-- banner section end -->