
<!-- Start Our Transport Services -->
<section class="our-servies mb-100 pb-100">
	<div class="container">

		<div class="heading-46">Our Crane & Transport Services</div>

		<ul class="services-grid flex wrap services-js">
			<li>
				<a href="#" class="item-box line-shape">
					<div class="ser-img">
						<img src="assets/images/machinery-relocation.jpg" alt="machinery-relocation" title="" width="500" height="360">
					</div>
					<div class="ser-info">
						<div class="icon">
							<img src="assets/images/svg/machinery-icon.svg" alt="machinery-icon" title="" width="" height="">
						</div>

						<div class="heading-28">Machinery Relocation</div>
						<p>Our modern fleet of cranes and trailers ensures safe, efficient, and reliable lifting solutions.</p>

						<span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
					</div>
				</a>
			</li>
			<li>
				<a href="#" class="item-box line-shape">
					<div class="ser-img">
						<img src="assets/images/structural-steel-rigging.jpg" alt="structural-steel-rigging" title="" width="500" height="360">
					</div>
					<div class="ser-info">
						<div class="icon">
							<img src="assets/images/svg/rigging-icon.svg" alt="rigging-icon" title="" width="" height="">
						</div>

						<div class="heading-28">Structural Steel Rigging</div>
						<p>Are you planning on completing a construction project and want to keep your workers safe </p>

						<span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
					</div>
				</a>
			</li>
			<li>
				<a href="#" class="item-box line-shape">
					<div class="ser-img">
						<img src="assets/images/panel-installation.jpg" alt="panel-installation" title="" width="500" height="360">
					</div>
					<div class="ser-info">
						<div class="icon">
							<img src="assets/images/svg/panel-insta-icon.svg" alt="panel-insta-icon" title="" width="" height="">
						</div>


						<div class="heading-28">Glass & Panel Installation</div>
						<p>Our exceptionally maintained cranes and equipment you can trust Panna Cranes</p>

						<span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
					</div>
				</a>
			</li>
			<li>
				<a href="#" class="item-box line-shape">
					<div class="ser-img">
						<img src="assets/images/air-conditioning.jpg" alt="air-conditioning" title="" width="500" height="360">
					</div>
					<div class="ser-info">
						<div class="icon">
							<img src="assets/images/svg/switchboards-icon.svg" alt="switchboards-icon" title="" width="" height="">
						</div>

						<div class="heading-28">Air Conditioning & Switchboards</div>
						<p>At Panna Cranes we endeavour to deliver a comprehensive lifting and hoisting service </p>

						<span class="alink">Read More <img src="assets/images/svg/caret.svg" alt="caret" title="" width="9" height="10"></span>
					</div>
				</a>
			</li>
		</ul>


		<div class="text-center">
			<a href="#" class="button button-primary">Explore All Services <img src="assets/images/svg/caret.svg" alt="caret-orange" title="" width="9" height="10"></a>
		</div>
		
	</div>
</section>
<!-- End Our Transport Services -->