<!-- START CLIENT Say -->
<section class="testimonial-hm mb-100">
    <div class="container">
        <div class="heading-46 text-center">What Our Clients Say</div>

        <div class="customer-wrapper mb-60">
            <ul class="customer-list client-js">
                <li>
                    <div class="client-box light-blue">
                        <img src="assets/images/svg/quotes.svg" alt="quotes" title="" width="41" height="34"
                            class="quote-icon">

                        <div class="review-box">
                            <p>I’ve been on countless sites where the rigging took what felt like days. Panna Cranes
                                didn’t
                                mess around and erected a safe and stable rigging installation that kept my guys safe.
                                Panna
                                Cranes are who you want on your site for reliable rigging.</p>
                        </div>

                        <div class="name-container">
                            <div class="name-wrap">
                                <div class="icon">T</div>
                                <div class="name-right">
                                    <div class="name">Tracey</div>
                                    <img src="assets/images/svg/star.svg" alt="star" title="" width="67" height="11">
                                </div>
                            </div>

                            <div class="google-icon">
                                <img src="assets/images/svg/google-icon.svg" alt="google-icon" title="" width="37"
                                    height="38">
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="client-box light-orange">
                        <img src="assets/images/svg/quotes.svg" alt="quotes" title="" width="41" height="34"
                            class="quote-icon">

                        <div class="review-box">
                            <p>Thanks to Panna Cranes my employees can work in summer without suffering in the heat. They were able to lift and install our large air conditioning units onto the roof in no time at all. As soon as they started working I knew that I was in good hands.</p>
                        </div>

                        <div class="name-container">
                            <div class="name-wrap">
                                <div class="icon">S</div>
                                <div class="name-right">
                                    <div class="name">Steve</div>
                                    <img src="assets/images/svg/star.svg" alt="star" title="" width="67" height="11">
                                </div>
                            </div>

                            <div class="google-icon">
                                <img src="assets/images/svg/google-icon.svg" alt="google-icon" title="" width="37"
                                    height="38">
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="client-box">
                        <img src="assets/images/svg/quotes.svg" alt="quotes" title="" width="41" height="34"
                            class="quote-icon">

                        <div class="review-box">
                            <p>I have used Panna for tank relocations for a number of years now. Some of the relocations have had extremely tight space constraints and they have demonstrated great skill. I have also found them to be great people to deal with.</p>
                        </div>

                        <div class="name-container">
                            <div class="name-wrap">
                                <div class="icon">G</div>
                                <div class="name-right">
                                    <div class="name">Greg Weston</div>
                                    <img src="assets/images/svg/star.svg" alt="star" title="" width="67" height="11">
                                </div>
                            </div>

                            <div class="google-icon">
                                <img src="assets/images/svg/google-icon.svg" alt="google-icon" title="" width="37"
                                    height="38">
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>

        <div class="head-line google-ratting"><span class="google-wrap"><img src="assets/images/svg/google-icon.svg"
                    alt="google-icon" title="" width="25" height="26"><img src="assets/images/svg/star.svg" alt="star"
                    title="" width="67" height="11"> <span class="ratting-tex">3.9 Ratings </span> 41 Google Reviews
            </span> </div>

    </div>
</section>

<!-- End CLIENT Say -->