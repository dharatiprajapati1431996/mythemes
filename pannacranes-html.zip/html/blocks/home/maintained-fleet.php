
<!-- Start Modern well maintained Fleet -->
<section class="maintained-fleet relative pb-150">
	<div class="container">
		<div class="intro text-center">
			<div class="heading-46">Modern, Well-Maintained Fleet Ready for Any Job</div>
			<p>Our cranes and transport equipment are designed for safety, reliability, and efficiency</p>
		</div>

		<div class="fleet-list fleet-js">
			<div class="item-box">
				<a href="#">
					<div class="maint-image">
						<div class="heading-18">All Terrain/Mobile Crane</div>

						<div class="img-wrap">
							<img src="assets/images/liebherr-LTM-1080.png" alt="liebherr-LTM-1080" title="" width="" height=""> 
						</div>

						<div class="model-num">80T</div>
					</div>
					<div class="maint-info">
						<div class="heading-18">LEIBHERR LTM 1080</div>
						<p>maximum lifting capacity of 80 tonnes</p>
					</div>
				</a>
			</div>
			<div class="item-box">
				<a href="#">
					<div class="maint-image">
						<div class="heading-18">Franna Crane</div>
						<div class="img-wrap">
							<img src="assets/images/grove-gmk5130.png" alt="Grove GKM-5130-1" title="" width="" height="">
						</div> 
						<div class="model-num">130T</div>

					</div>
					<div class="maint-info">
						<div class="heading-18">Grove GKM-5130-1</div>
						<p>maximum lifting capacity of 130 tonnes</p>
					</div>
				</a>
			</div>

			<div class="item-box">
				<a href="#">
					<div class="maint-image">
						<div class="heading-18">Crane Truck</div>
						<div class="img-wrap">
							<img src="assets/images/20-tonne-franna.png" alt="20 Tonne Franna" title="" width="" height=""> 
						</div>
						<div class="model-num">20T</div>
					</div>
					<div class="maint-info">
						<div class="heading-18">20 Tonne Franna</div>
						<p>maximum lifting capacity of 20 tonnes</p>
					</div>
				</a>
			</div>

			<div class="item-box">
				<a href="#">
					<div class="maint-image">
						<div class="heading-18">Semi Truck</div>
						
						<div class="img-wrap">
							<img src="assets/images/terex-MAC-25.png" alt="Terex MAC-25" title="" width="" height=""> 
						</div>
						<div class="model-num">25T</div>
					</div>	
					<div class="maint-info">
						<div class="heading-18">Terex MAC-25</div>
						<p>maximum lifting capacity of 25 tonnes</p>
					</div>
				</a>
			</div>
		</div>

		<div class="text-center">
			<a href="#" class="button button-primary">See All Cranes <img src="assets/images/svg/caret.svg" alt="caret-orange" title="" width="9" height="10"></a>
		</div>
	</div>


	<img src="assets/images/machinery-text.svg" alt="machinery-text" title="" width="" height="" class="machinery-text-bottom">

</section>
<!-- End Modern well maintained Fleet -->