<!-- Start Trusted By leading companies -->
<section class="brand-companies mb-100">
    <div class="container">

        <div class="heading-22 head-line text-center"><span>Trusted by Leading Companies</span> </div>


        <ul class="companies-logo companies-js">
            <li>
                <div class="logo-box">
                    <img src="assets/images/cranesafe-logo.png" alt="cranesafe-logo" title="" width="146" height="34">
                </div>
            </li>
            <li>
                <div class="logo-box">
                    <img src="assets/images/logo.png" alt="logo" title="" width="78" height="35">
                </div>
            </li>
            <li>
                <div class="logo-box">
                    <img src="assets/images/metro-trains-melbourne.png" alt="metro-trains-melbourne" title="" width="49"
                        height="55">
                </div>
            </li>
            <li>
                <div class="logo-box">
                    <img src="assets/images/logo.png" alt="logo" title="" width="78" height="35">
                </div>
            </li>
            <li>
                <div class="logo-box">
                    <img src="assets/images/cica.png" alt="cica" title="" width="144" height="79">
                </div>
            </li>
            <li>
                <div class="logo-box">
                    <img src="assets/images/logo.png" alt="logo" title="" width="78" height="35">
                </div>
            </li>
            <li>
                <div class="logo-box">
                    <img src="assets/images/logo.png" alt="logo" title="" width="78" height="35">
                </div>
            </li>
        </ul>
    </div>
</section>
<!-- End Trusted By leading companies -->