<div class="form-wrap box-wrap">
                                    <div class="intro text-center">
                                        <div class="heading-36">Get in Touch</div>
                                        <p>Available for hire feel free to contact us today</p>
                                    </div>

                                    <form class="form_box">
                                        <div class="row">
                                            <div class="form-group width50">
                                                <input class="form-control" type="text" name="name" placeholder="Name">
                                            </div>
                                            <div class="form-group width50">
                                                <input class="form-control" type="email" name="phone" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group width50">
                                                <input class="form-control" type="number" name="name" placeholder="Phone">
                                            </div>
                                            <div class="form-group width50">
                                                <select name="" id="services" class="form-control">
                                                    <option value="">Select Service</option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group message_area width100">
                                            <textarea class="form-control" placeholder="Message" name="your-message"></textarea>
                                        </div>
                                        <div class="submit_btn">
                                            <input type="submit" name="" value="submit" class="btnsubmit">
                                        </div>
                                    </form>

                                    <div class="ratting-wrap">
                                        <div class="google-column fact-column">
                                            <div class="fact-icon">
                                                <img src="assets/images/svg/google-ratting.svg" alt="google-ratting" title="" width="45" height="46">
                                            </div>
                                            <div class="fact-info">
                                                <img src="assets/images/svg/star.svg" alt="star" title="" width="68" height="11" class="star">
                                                3.9 Ratings 
                                                <span>41 Google Reviews </span>
                                            </div>
                                        </div>
                                        <div class="ser-availabilty fact-column">
                                            <div class="fact-icon">
                                                <img src="assets/images/svg/24-services.svg" alt="24-services" title="" width="50" height="50">
                                            </div>
                                            <div class="fact-info">
                                                24/7 Service Availability
                                            </div>
                                        </div>
                                    </div>
                                </div>