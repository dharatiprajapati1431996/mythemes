<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper service-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner">
        <div class="inner-banner relative">
            <img src="assets/images/blog-inner.jpg" alt="blog-inner" title="" width="1920" height="474" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                            <div class="semi-head">Big Moves, Smart Solutions</div>
                            <div class="heading-50">Latest Blog Posts</div>

                            <div class="button-group">
                                <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                    03 9310 5440</a>
                                <a href="#" class="button button-theme">Get In Touch</a>
                            </div>
                    </div>
                    
                </div>
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums full-breadcurmb">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Blog</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->

    <section class="inpage mb-100">
        <div class="container">
            <ul class="blog-grid blog-inner-grid">
                <li>
                    <div class="blog-card">
                        <div class="blog-image">
                            <img src="assets/images/reliable-crane.jpg" alt="reliable-crane" title="" width="511" height="">
                        </div>
                        <div class="blog-post">
                            <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title="" width="16" height="18"> 10 Apr 2024 </div>
                            <div class="heading-18">Reliable Crane Hire Services In Melbourne – Why Panna Cranes Leads The
                                Way</div>

                            <p>Looking for dependable crane hire in Melbourne? Panna Cranes is your go-to partner for safe,
                                efficient</p>

                            <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg" alt="caret-orange" title="" width="9" height="10"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class=" blog-card">
                        <div class="blog-image">
                            <img src="assets/images/crane-truck.jpg" alt="crane-truck" title="" width="511" height="">
                        </div>
                        <div class="blog-post">
                            <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title="" width="16" height="18">10 Jun 2025 </div>
                            <div class="heading-18">Crane Truck Hire In Melbourne – Affordable, Flexible &amp; Reliable</div>

                            <p>When it comes to crane truck hire in Melbourne, Panna Cranes understands that flexibility and
                                affordability are just as important as reliability.</p>

                            <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg" alt="caret-orange" title="" width="9" height="10"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="blog-card">
                        <div class="blog-image">
                            <img src="assets/images/crane-companies.jpg" alt="crane-companies" title="" width="511" height="">
                        </div>
                        <div class="blog-post">
                            <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title="" width="16" height="18">10 May 2024</div>
                            <div class="heading-18">Crane Companies In Melbourne – What Makes Panna Cranes A Standout Choice
                            </div>

                            <p>In a competitive market of crane companies in Melbourne, Panna Cranes distinguishes itself.
                            </p>

                            <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg" alt="caret-orange" title="" width="9" height="10"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="blog-card">
                        <div class="blog-image">
                            <img src="assets/images/reliable-crane.jpg" alt="reliable-crane" title="" width="511" height="">
                        </div>
                        <div class="blog-post">
                            <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title="" width="16" height="18"> 10 Apr 2024 </div>
                            <div class="heading-18">Reliable Crane Hire Services In Melbourne – Why Panna Cranes Leads The
                                Way</div>

                            <p>Looking for dependable crane hire in Melbourne? Panna Cranes is your go-to partner for safe,
                                efficient</p>

                            <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg" alt="caret-orange" title="" width="9" height="10"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class=" blog-card">
                        <div class="blog-image">
                            <img src="assets/images/crane-truck.jpg" alt="crane-truck" title="" width="511" height="">
                        </div>
                        <div class="blog-post">
                            <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title="" width="16" height="18">10 Jun 2025 </div>
                            <div class="heading-18">Crane Truck Hire In Melbourne – Affordable, Flexible &amp; Reliable</div>

                            <p>When it comes to crane truck hire in Melbourne, Panna Cranes understands that flexibility and
                                affordability are just as important as reliability.</p>

                            <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg" alt="caret-orange" title="" width="9" height="10"></a>
                        </div>
                    </div>
                </li>
                
                <li>
                    <div class="blog-card">
                        <div class="blog-image">
                            <img src="assets/images/crane-companies.jpg" alt="crane-companies" title="" width="511" height="">
                        </div>
                        <div class="blog-post">
                            <div class="post-date"><img src="assets/images/svg/calendar.svg" alt="calendar" title="" width="16" height="18">10 May 2024</div>
                            <div class="heading-18">Crane Companies In Melbourne – What Makes Panna Cranes A Standout Choice
                            </div>

                            <p>In a competitive market of crane companies in Melbourne, Panna Cranes distinguishes itself.
                            </p>

                            <a href="#" class="alink">Read More <img src="assets/images/svg/caret-orange.svg" alt="caret-orange" title="" width="9" height="10"></a>
                        </div>
                    </div>
                </li>
            </ul>

            <div class="text-center mt-50">
                <a href="#" class="button button-primary">View All Blog <img src="assets/images/svg/caret.svg" alt="caret-orange" title="" width="9" height="10"></a>
            </div>
        </div>
    </section>

    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();