<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper thank_youpg ">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                        <div class="semi-head">Your Trusted Partner in Crane Hire</div>
                        <div class="heading-50">Thank You</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="container">
            <ul class="woo_breadcums full-breadcurmb">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Thank You</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">

            <div class="flex-container thank_you_content wrap">
                <div class="error-left">
                    <div class="heading-36">We’ve Received Your Inquiry!</div>
                    <p>We're excited to help you build your perfect space.</p>
                    <p>Thank you for reaching out to Superior Granny Flats! One of our team members will get back to you
                        shortly to discuss your project and answer any questions you may have.</p>
                    <p>In the meantime, feel free to explore more about what we offer:</p>

                    <ul>
                        <li><a href="#">Browse our latest projects</a></li>
                        <li><a href="#">Learn more about our process</a></li>
                        <li><a href="#">Read testimonials from our happy clients</a></li>
                    </ul>

                    <p>Have an urgent inquiry? Give us a call at <a href="tel:03 9310 5440">03 9310 5440</a> for
                        immediate assistance.</p>
                </div>

                <div class="error-right">
                    <img src="assets/images/thankyou.png" alt="404" title="404" width="500" height="500">
                </div>
            </div>

        </div>
    </section>

</main>
<?php get_footer();