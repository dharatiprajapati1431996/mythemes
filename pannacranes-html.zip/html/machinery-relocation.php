<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper service-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                        <div class="semi-head">Lifting Victoria’s Projects to New Heights</div>
                        <div class="heading-50">Machinery Relocation</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Services</a>
                            <span class="breadcrumb_last" aria-current="page">Machinery Relocation</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100 content-wrapper">
        <div class="container">
            <div class="flex-container wrap mb-100 align-items-start">
                <div class="panel-left">
                    <div class="service-show-mobile hidden">
                        <?php block('services-list'); ?>
                    </div>
                    
                    <div class="content-wrapper">
                       <div class="heading-22">Reliable Transport Solutions Across Victoria</div>
                       <p>Panna Cranes are the experts in machinery relocations across Melbourne. Machinery transport can be a complicated and costly task, but not with Panna Cranes. We have the expertise to transport machinery in Melbourne, and across Victoria.</p>

                       <div class="heading-22">Machinery Movers Melbourne</div>

                       <p>If you’ve got a big job to take care of, leave it in the hands of the top machinery movers in Melbourne, Panna Cranes.</p>

                       <div class="image-wrap blue-pattern-box mb-50">
                            <img src="assets/images/machinery-movers-cranes.jpg" alt="machinery-movers-cranes" title="" width="1016" height="600">
                       </div>

                       <div class="factor-full-wrap mb-70">
                           <ul class="factor-block">
                                <li>
                                    <div class="factbox">
                                        <div class="fact-icon">
                                            <img src="assets/images/svg/crane-icon.svg" alt="crane icon" title="" width="" height="">
                                        </div>

                                        <span class="arrow-down">
                                            <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                        </span>

                                        <p>Specializing in all areas of Construction for your Mobile Crane &amp; Transport needs.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="factbox">
                                        <div class="fact-icon">
                                            <img src="assets/images/svg/setting.svg" alt="setting" title="" width="" height="">
                                        </div>

                                        <span class="arrow-down">
                                            <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                        </span>

                                        <p>Machinery installations  relocations Commercial Industrial &amp; Domestic Crane Hire.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="factbox">
                                        <div class="fact-icon">
                                            <img src="assets/images/svg/crane-construction.svg" alt="crane construction" title="" width="" height="">
                                        </div>

                                        <span class="arrow-down">
                                            <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                        </span>

                                        <p>Crane Trucks &amp; Semis Oversize Loads Moved all Permits Arranged Freeway Construction</p>
                                    </div>
                                </li>
                            </ul>
                       </div>

                        <div class="client-inner-cta dark-blue-gradient mb-70 flex-container wrap">
                            <div class="client-cta-left">
                                <div class="heading-46">Why Clients Rely on Panna Cranes</div>
                                <p>We’re Not Just a Crane Service — We’re Your Project Partner</p>

                                <div class="button-group">
                                    <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                        03 9310 5440</a>
                                    <a href="#" class="button button-orange">Get In Touch</a>
                                </div>
                            </div>
                            <div class="client-cta-right">
                                <img src="assets/images/svg/expert-icon.svg" alt="expert-icon" title="" width="" height="" class="icon">
                                <div class="heading-18">Expert Operators & Riggers</div>
                                <p>Our certified operators and riggers bring precision, safety, and expertise to every lift.</p>
                            </div>
                        </div>


                        <div class="client-customer-wrapper">
                            <div class="heading-46">What Our Clients Say</div>

                            <ul class="customer-list client-js">
                                <li>
                                    <div class="client-box light-blue">
                                        <img src="assets/images/svg/quotes.svg" alt="quotes" title="" width="41" height="34" class="quote-icon">

                                        <div class="review-box">
                                            <p>I’ve been on countless sites where the rigging took what felt like days. Panna Cranes
                                                didn’t
                                                mess around and erected a safe and stable rigging installation that kept my guys safe.
                                                Panna
                                                Cranes are who you want on your site for reliable rigging.</p>
                                        </div>

                                        <div class="name-container">
                                            <div class="name-wrap">
                                                <div class="icon">T</div>
                                                <div class="name-right">
                                                    <div class="name">Tracey</div>
                                                    <img src="assets/images/svg/star.svg" alt="star" title="" width="67" height="11">
                                                </div>
                                            </div>

                                            <div class="google-icon">
                                                <img src="assets/images/svg/google-icon.svg" alt="google-icon" title="" width="37" height="38">
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="client-box light-orange">
                                        <img src="assets/images/svg/quotes.svg" alt="quotes" title="" width="41" height="34" class="quote-icon">

                                        <div class="review-box">
                                            <p>I’ve been on countless sites where the rigging took what felt like days. Panna Cranes
                                                didn’t
                                                mess around and erected a safe and stable rigging installation that kept my guys safe.
                                                Panna
                                                Cranes are who you want on your site for reliable rigging.</p>
                                        </div>

                                        <div class="name-container">
                                            <div class="name-wrap">
                                                <div class="icon">T</div>
                                                <div class="name-right">
                                                    <div class="name">Tracey</div>
                                                    <img src="assets/images/svg/star.svg" alt="star" title="" width="67" height="11">
                                                </div>
                                            </div>

                                            <div class="google-icon">
                                                <img src="assets/images/svg/google-icon.svg" alt="google-icon" title="" width="37" height="38">
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="client-box">
                                        <img src="assets/images/svg/quotes.svg" alt="quotes" title="" width="41" height="34" class="quote-icon">

                                        <div class="review-box">
                                            <p>I’ve been on countless sites where the rigging took what felt like days. Panna Cranes
                                                didn’t
                                                mess around and erected a safe and stable rigging installation that kept my guys safe.
                                                Panna
                                                Cranes are who you want on your site for reliable rigging.</p>
                                        </div>

                                        <div class="name-container">
                                            <div class="name-wrap">
                                                <div class="icon">T</div>
                                                <div class="name-right">
                                                    <div class="name">Tracey</div>
                                                    <img src="assets/images/svg/star.svg" alt="star" title="" width="67" height="11">
                                                </div>
                                            </div>

                                            <div class="google-icon">
                                                <img src="assets/images/svg/google-icon.svg" alt="google-icon" title="" width="37" height="38">
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
                <div class="panel-right sticky">

                    <?php block('get-form'); ?>

                    <?php block('services-list'); ?>


                </div>
            </div>

            <div class="divider"></div>

        </div>
    </section>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();