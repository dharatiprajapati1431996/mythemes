<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper suburb-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner breadcrumb-with-form">
        <div class="inner-banner relative">
            <img src="assets/images/suburb-inner.jpg" alt="Crane crane" title="" width="1920" height="674" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                            <div class="semi-head">Mobile Crane, Machinery & Oversize Load Experts</div>
                            <div class="heading-70">Crane Hire Heidelberg</div>
                            

                            <div class="button-group">
                                <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                    03 9310 5440</a>
                                <a href="#" class="button button-theme">Get In Touch</a>
                            </div>
                    </div>
                    <div class="bread-right">
                        <?php block('get-form'); ?>
                    </div>
                </div>
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums full-breadcurmb">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="areas-we-serves.php">Areas We Serve</a>
                            <span class="breadcrumb_last" aria-current="page">Heidelberg</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


     <!-- Start top content -->
    <section class="content-wrapper mb-100">
        <div class="container">
            <div class="flex-container wrap mb-100 align-items-start">
                <div class="col-6 ctent-column block-left">
                    <p>Searching for quality crane hire services in Heidelberg? Then you’ve come to the right place.</p>

                    <p>At Panna Cranes we offer a wide range of mobile cranes, lifting equipment, and machinery movers for hire at a competitive price, just as we’ve done since opening our doors in 2002. Our 24-hour crane hire services allow our customers to keep their domestic or commercial development and construction projects moving forward without any frustrating scheduling issues or stoppages.</p>

                    
                    <div class="button-group">
                        <a href="tel:03 9310 5440" class="button button-primary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">03 9310 5440</a>
                        <a href="#" class="button button-theme">Get In Touch</a>
                    </div>


                </div>
                <div class="col-6 block-right">
                    <ul class="factor-block">
                        <li>
                            <div class="factbox">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/crane-icon.svg" alt="crane icon" title="" width="" height="">
                                </div>

                                <span class="arrow-down">
                                    <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                </span>

                                <p>Specializing in all areas of Construction for your Mobile Crane & Transport needs.</p>
                            </div>
                        </li>
                        <li>
                            <div class="factbox">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/setting.svg" alt="setting" title="" width="" height="">
                                </div>

                                <span class="arrow-down">
                                    <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                </span>

                                <p>Machinery installations  relocations Commercial Industrial & Domestic Crane Hire.</p>
                            </div>
                        </li>
                        <li>
                            <div class="factbox">
                                <div class="fact-icon">
                                    <img src="assets/images/svg/crane-construction.svg" alt="crane construction" title="" width="" height="">
                                </div>

                                <span class="arrow-down">
                                    <img src="assets/images/svg/arrow-down.svg" alt="arrow-down" title="" width="" height="">
                                </span>

                                <p>Crane Trucks & Semis Oversize Loads Moved all Permits Arranged Freeway Construction</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>


            <div class="divider"></div>
        </div>
    </section>
    <!-- End top content -->


    <!-- Start content wrapper -->
    <section class="content-wrapper mb-100">
        <div class="container">
            <div class="flex-container wrap">
                <div class="img-block sticky image-pattern">
                    <img src="assets/images/crane-hire.jpg" alt="crane-hire" title="" width="720" height="600">
                </div>
                <div class="ctent-block ctent-column">
                    <p>Customers looking to lift, install, or transport glass, transformers and switchboards, construction materials, air conditioning units, concrete panels, commercial signs, and structural steel, can find the right piece of machinery for the job here at Panna Cranes.</p>

                    <p>For more information on our semi trailer and Franna crane hire services, Heidelberg customers simply have to get in touch with our qualified team today.</p>

                   <div class="heading-36">A Sought-After Name for Crane Truck Hire Across Heidelberg</div>

                   <p>Panna Cranes is proud to be a trusted name for crane truck hire across Heidelberg and the surrounding suburbs, providing customers with dependable machinery to help them get any job done.</p>

                   <p>We’re committed to delivering tried and tested machinery that meets the highest safety and reliability standards. Our team uses practices such as Job Safety Analysis to outline all potential risks for the job at hand, helping to keep our customers, their cargo and goods, and our cranes, safe.</p>

                   <p>Our team share years of industry experience, and work closely with each customer to ensure they find the right crane to suit the demands of their upcoming project. We also supply crane trucks for major railway development and restoration works.</p>

                   <p>Call us today on <a href="tel:03 9310 5440">03 9310 5440</a> to learn more about our available services, or to speak with a member of our friendly team.</p>

                     <div class="button-group">
                        <a href="tel:03 9310 5440" class="button button-primary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">03 9310 5440</a>
                        <a href="#" class="button button-theme">Get In Touch</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End content wrapper -->


    <?php block('contect-cta'); ?>


    <!-- Start content wrapper -->
    <section class="content-wrapper mb-100 areas-suburb-location">
        <div class="container">
            <div class="flex-container wrap flex-row-reverse">
                <div class="img-block sticky image-pattern">
                    <img src="assets/images/cranes-top-view.jpg" alt="cranes-top-view" title="" width="720" height="410">
                </div>
                <div class="ctent-block ctent-column">
                    <div class="heading-36">Areas We Serve - We operate Victoria Wide</div>
                        <ul class="areas-list">
                            <li><a href="#">Sunshine</a></li>
                            <li><a href="#">Tullamarine</a></li>
                            <li><a href="#">Essendon</a></li>
                            <li><a href="#">Coburg</a></li>
                            <li><a href="#">Craigieburn</a></li>
                            <li><a href="#">Maribyrnong</a></li>
                            <li><a href="#">Mernda</a></li>
                            <li><a href="#">Yarraville</a></li>
                            <li><a href="#">Morang</a></li>
                            <li><a href="#">Campbellfield</a></li>
                            <li><a href="#">Derrimut</a></li>
                            <li><a href="#">Footscray</a></li>
                            <li><a href="#">Heidelberg</a></li>
                            <li><a href="#">Laverton</a></li>
                            <li><a href="#">Melton</a></li>
                            <li><a href="#">Epping</a></li>
                            <li><a href="#">Preston</a></li>
                            <li><a href="#">St Albans</a></li>
                            <li><a href="#">Sunbury</a></li>
                            <li><a href="#">Taylors Lakes</a></li>
                            <li><a href="#">Thomastown</a></li>
                            <li><a href="#">Tottenham</a></li>
                            <li><a href="#">Truganina</a></li>
                        </ul>
                   
                </div>
            </div>
        </div>
    </section>
    <!-- End content wrapper -->

    <?php block('text-slider'); ?>

    <?php block('home/testimonial-hm'); ?>

    <!-- Start content wrapper -->
    <section class="content-wrapper mb-100">
        <div class="container">
            <div class="flex-container wrap flex-row-reverse">
                <div class="img-block sticky image-pattern">
                    <img src="assets/images/crannes-white.jpg" alt="crannes-white" title="" width="720" height="600">
                </div>
                <div class="ctent-block ctent-column">
                    <div class="heading-36">Frequently Asked Questions</div>

                    <div class="faq-wrapper">
                        <div class="faq-ul">
                            <div class="faq-li">
                                <div class="heading-18">What Is The Maximum Reach Of Your 60 Tonne Cranes?</div>
                                <p>Our 60 tonne cranes boast an impressive maximum reach of up to 68 metres, making them well-suited for high-rise projects and handling loads at significant heights.</p>
                            </div>
                            <div class="faq-li">
                                <div class="heading-18">Can Your Cranes Navigate Heavy Loads In Tight Spaces?</div>
                                <p>Absolutely! Our 60 tonne crane fleet includes specialised options designed for operating in confined areas. We offer compact models that can manoeuvre in tight spaces without compromising on lifting capacity.</p>
                            </div>
                            <div class="faq-li">
                                <div class="heading-18">Are There Additional Charges For Transporting A 60 Tonne Crane To My Site?</div>
                                <p>Transportation costs may vary depending on the distance and accessibility of your site location. We provide transparent pricing and will clearly communicate any additional charges upfront to avoid any surprises.</p>
                            </div>
                        </div>
                    </div>
                   
                   
                    <div class="button-group">
                        <a href="tel:03 9310 5440" class="button button-primary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">03 9310 5440</a>
                        <a href="#" class="button button-theme">Get In Touch</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End content wrapper -->

    <?php block('blog-hm'); ?>

    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();