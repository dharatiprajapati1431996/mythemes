<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper blog-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                        <div class="semi-head">Complete Crane & Transport Solutions</div>
                        <div class="heading-40">Reliable Crane Hire Services in Melbourne – Why Panna Cranes Leads the Way</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Fleet</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
            <div class="flex-container wrap align-items-start">
                <div class="panel-left content-wrapper">
                    <div class="blog-wrapper mb-60">
                        <div class="flex-container wrap mb-90 align-items-start">
                            <div class="blog-left">

                                <div class="service-show-mobile hidden">
                                    <?php block('services-list'); ?>
                                </div>


                                <div class="post-date">
                                    <img src="assets/images/svg/calendar.svg" alt="calendar" title="" width="16" height="18">10 Jun 2025
                                </div>
                                <div class="heading-18">This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. </div>

                                <div class="heading-18">Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User.</div>
                            </div>
                            <div class="blog-right">
                                <img src="assets/images/crane-truck.jpg" alt="crane-truck" title="" width="511" height="343">  
                            </div>
                        </div>



                        <div class="heading-26">A Sought-After Name for Crane Truck Hire Across Heidelberg</div>

                        <p>This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User. This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User.</p>

                        <p>This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User.</p>

                        <p>This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User. This Is Dummy Text, </p>

                        <p>We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User.</p>

                        <ul>
                            <li>This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages</li>
                            <li>We Use It At Supple During Web Designing In Case</li>
                            <li>We Use This Dummy Text To Give You An Idea How Text On This Page Would Look</li>
                            <li>We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User.</li>
                            <li>Don't Worry About This Dummy Text.</li>
                        </ul>

                        <p>This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User. This Is Dummy Text, We Use It At Supple During Web Designing In Case We Don't Have Content For New NON SEO Pages And It Is Changed During Development Of The New Site. Hence, Don't Worry About This Dummy Text. We Use This Dummy Text To Give You An Idea How Text On This Page Would Look Like As A Site User.</p>
                    </div>


                    <div class="client-inner-cta dark-blue-gradient mb-70 flex-container wrap">
                            <div class="client-cta-left">
                                <div class="heading-46">Why Clients Rely on Panna Cranes</div>
                                <p>We’re Not Just a Crane Service — We’re Your Project Partner</p>

                                <div class="button-group">
                                    <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                        03 9310 5440</a>
                                    <a href="#" class="button button-orange">Get In Touch</a>
                                </div>
                            </div>
                            <div class="client-cta-right">
                                <img src="assets/images/svg/expert-icon.svg" alt="expert-icon" title="" width="" height="" class="icon">
                                <div class="heading-18">Expert Operators &amp; Riggers</div>
                                <p>Our certified operators and riggers bring precision, safety, and expertise to every lift.</p>
                            </div>
                    </div>
                </div>



                <div class="panel-right sticky">

                    <?php block('get-form'); ?>

                    <?php block('services-list'); ?>


                </div>
            </div>
        </div>
    </section>


    <?php block('blog-hm'); ?>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();