<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper service-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner">
        <div class="inner-banner relative">
            <img src="assets/images/work-gallery-inner.jpg" alt="work-gallery-inner" title="" width="1920" height="474" class="bgimg">

            <div class="container">
                <div class="flex-container wrap">
                    <div class="bread-left">
                            <div class="semi-head">Experienced Operators. Advanced Equipment. On-Time Service.</div>
                            <div class="heading-50">Panna At Work</div>

                            <div class="button-group">
                                <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                    03 9310 5440</a>
                                <a href="#" class="button button-theme">Get In Touch</a>
                            </div>
                    </div>
                    
                </div>
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Panna At Work</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->

    <section class="inpage mb-100">
        <div class="container">
           
            <div class="text-center mt-50">
                <a href="#" class="button button-primary">More Details</a>
            </div>
        </div>
    </section>

    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();