<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper service-page">

    <!-- Inner Banner Section -->
    <section class="breadcrumb-banner ">
        <div class="inner-banner relative">
            <img src="assets/images/contact-inner.jpg" alt="contact-inner" title="" width="1920" height="" class="bgimg">

            <div class="container">
               <div class="flex-container wrap">
                   <div class="bread-left">
                        <div class="semi-head">Heavy Lifts Made Easy</div>
                        <div class="heading-50">Franna Crane</div>

                        <div class="button-group">
                            <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                03 9310 5440</a>
                            <a href="#" class="button button-theme">Get In Touch</a>
                        </div>
                   </div>
               </div>
            </div>
        </div>
     
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="fleet.php">Fleet</a>
                            <span class="breadcrumb_last" aria-current="page">Franna Crane</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
            <div class="flex-container wrap mb-100 align-items-start">
                <div class="panel-left">
                    <div class="service-show-mobile hidden">
                        <div class="box-wrap service-list-box">
                            <div class="heading-34 uppercase service-nav-head">Our Fleet</div>

                            <ul class="service-link mb-0">
                                <li><a href="#">All Terrain/Mobile Crane</a></li>
                                <li class="active"><a href="#">Franna Crane</a></li>
                                <li><a href="#">Safety</a></li>
                                <li><a href="#">Crane Truck</a></li>
                                <li><a href="#">Semi Truck</a></li>
                            </ul>
                        </div>
                        
                    </div>
                    
                    <div class="fleet-prod-wrapper">
                        <div class="fleet-list fleet-inner-list">
                            <div class="item-box">
                                <div class="prod-box">
                                    <div class="maint-image">
                                        <div class="img-wrap">
                                            <img src="assets/images/franna-AT-14.png" alt="Franna AT-14" title="" width="" height=""> 
                                        </div>

                                        <div class="model-num">14T</div>
                                    </div>
                                    <div class="maint-info">
                                        <div class="heading-22">Franna AT-14</div>
                                        <ul>
                                            <li>Maximum Lifting Capacity: 14 tonnes</li>
                                            <li>Boom Length: Up to 13.8 metres</li>
                                            <li>Exceptional Tight-Access Performance...</li>
                                        </ul>
                                        <div class="button-group">
                                            <a href="#" class="button button-gray">More Details</a>
                                            <a href="#" class="button button-theme">Enquire Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                           <div class="item-box">
                                <div class="prod-box">
                                    <div class="maint-image">
                                        <div class="img-wrap">
                                            <img src="assets/images/franna-AT-20.png" alt="Franna AT-20" title="" width="" height="">
                                        </div> 
                                        <div class="model-num">20T</div>

                                    </div>
                                    <div class="maint-info">
                                        <div class="heading-22">Franna AT-20</div>
                                         <ul>
                                            <li>Maximum Lifting Capacity: 20 tonnes</li>
                                            <li>Boom Length: Up to 17.9 metres</li>
                                            <li>Maximum Hook Height: Approximately 17 metres</li>
                                        </ul>
                                        <div class="button-group">
                                            <a href="#" class="button button-gray">More Details</a>
                                            <a href="#" class="button button-theme">Enquire Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div> 

                            <div class="item-box">
                                <div class="prod-box">
                                    <div class="maint-image">
                                        <div class="img-wrap">
                                            <img src="assets/images/franna-AT-40.png" alt="Franna AT-40" title="" width="" height=""> 
                                        </div>
                                        <div class="model-num">40T</div>
                                    </div>
                                    <div class="maint-info">
                                        <div class="heading-22">Franna AT-40</div>
                                        <ul>
                                            <li>Maximum Lifting Capacity: 40 tonnes</li>
                                            <li>Boom Length: Up to 19.8 metres</li>
                                            <li>Maximum Hook Height: Approximately 20 metres</li>
                                        </ul>
                                        <div class="button-group">
                                            <a href="#" class="button button-gray">More Details</a>
                                            <a href="#" class="button button-theme">Enquire Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item-box">
                                <div class="prod-box">
                                    <div class="maint-image">
                                        <div class="img-wrap">
                                            <img src="assets/images/frannaMac-25.png" alt="Franna Mac-25" title="" width="" height=""> 
                                        </div>
                                        <div class="model-num">25T</div>
                                    </div>
                                    <div class="maint-info">
                                        <div class="heading-22">Franna Mac-25</div>
                                        <ul>
                                            <li>Maximum Lifting Capacity: 25 tonnes</li>
                                            <li>Boom Length: Up to 18.4 metres</li>
                                            <li>Maximum Hook Height: Approximately 18 metres</li>
                                        </ul>
                                        <div class="button-group">
                                            <a href="#" class="button button-gray">More Details</a>
                                            <a href="#" class="button button-theme">Enquire Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item-box">
                                <div class="prod-box">
                                    <div class="maint-image">
                                        <div class="img-wrap">
                                            <img src="assets/images/franna-Mac-25-SL.png" alt="Franna Mac-25 SL" title="" width="" height=""> 
                                        </div>
                                        <div class="model-num">25T</div>
                                    </div>
                                    <div class="maint-info">
                                        <div class="heading-22">Franna Mac-25 SL</div>
                                        <ul>
                                            <li>Maximum Lifting Capacity: 25 tonnes</li>
                                            <li>Boom Length: Up to 18.4 metres</li>
                                            <li>Maximum Hook Height: Approximately 18 metres</li>
                                        </ul>
                                        <div class="button-group">
                                            <a href="#" class="button button-gray">More Details</a>
                                            <a href="#" class="button button-theme">Enquire Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                    </div>



                    <div class="client-inner-cta dark-blue-gradient mb-70 flex-container wrap">
                            <div class="client-cta-left">
                                <div class="heading-46">Why Clients Rely on Panna Cranes</div>
                                <p>We’re Not Just a Crane Service — We’re Your Project Partner</p>

                                <div class="button-group">
                                    <a href="tel:03 9310 5440" class="button button-secondary"><img src="assets/images/svg/phone-black.svg" alt="phone-black" title="" width="19" height="19">
                                        03 9310 5440</a>
                                    <a href="#" class="button button-orange">Get In Touch</a>
                                </div>
                            </div>
                            <div class="client-cta-right">
                                <img src="assets/images/svg/expert-icon.svg" alt="expert-icon" title="" width="" height="" class="icon">
                                <div class="heading-18">Expert Operators &amp; Riggers</div>
                                <p>Our certified operators and riggers bring precision, safety, and expertise to every lift.</p>
                            </div>
                    </div>
                </div>



                <div class="panel-right sticky">

                    <?php block('get-form'); ?>

                    <div class="box-wrap service-list-box">
                        <div class="heading-30 uppercase">Our Fleet</div>

                        <ul class="service-link mb-0">
                            <li><a href="#">All Terrain/Mobile Crane</a></li>
                            <li class="active"><a href="#">Franna Crane</a></li>
                            <li><a href="#">Safety</a></li>
                            <li><a href="#">Crane Truck</a></li>
                            <li><a href="#">Semi Truck</a></li>
                        </ul>
                    </div>


                </div>
            </div>

            <div class="divider"></div>

        </div>
    </section>


    <?php block('trusted-companies'); ?>

</main>
<?php get_footer();