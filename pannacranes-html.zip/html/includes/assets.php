<?php

$GLOBALS['assets'] = [
    'common' => [
        'styles' => [
            'variables',
            'font-awesome.min',
            'slick',
            'slick-theme',
			'jquery.fancybox',
            'reset',
            'normalize',
            'utiliti',
            'variables',
		    'common',
            'header'
        ],
        'scripts' => ['jquery-3.7.1.min', 'slick','jquery.fancybox.min', 'script'],
    ],
    'home' => [
        'styles' => ['home', 'blog' ,'testimonial' , 'service' ],
        'scripts' => ['home' , 'parallax'],
    ],
    'about' => [
        'styles' => ['about'],
        'scripts' => [],
    ],
    'machinery-relocation' => [
        'styles' => ['testimonial'],
        'scripts' => ['slider'],
    ],
    'fleet' => [
        'styles' => ['product'],
        'scripts' => [''],
    ],
    'product-detail' => [
        'styles' => ['product'],
        'scripts' => ['home' , 'product-detail'],
    ],
    'franna-crane' => [
        'styles' => ['product'],
        'scripts' => ['slider'],
    ],
    'service' => [
        'styles' => ['service'],
        'scripts' => [],
    ],
    'service-detail' => [
        'styles' => ['testimonial' , 'blog' , 'service'],
        'scripts' => ['home'],
    ],
    'blog' => [
        'styles' => [ 'blog'],
        'scripts' => [],
    ],
    'blog-detail' => [
        'styles' => [ 'blog'],
        'scripts' => ['home'],
    ],
    'areas-we-serves' => [
        'styles' => [ 'areas' , 'service'],
        'scripts' => [],
    ],
    'suburb' => [
        'styles' => [ 'areas' , 'service' , 'blog' ,'testimonial'],
        'scripts' => ['home'],
    ],
    'contact' => [
        'styles' => ['contact'],
        'scripts' => [],
    ],

];