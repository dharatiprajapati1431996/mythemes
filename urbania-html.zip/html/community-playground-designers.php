<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper landscape-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/community-banner.jpg" alt="community-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Community Playground Designers</div>
    				<p>Designing inclusive community playgrounds that inspire connection, creativity, and active outdoor play.</p>
                    <div class="btn-row">
                        <a href="#" class="button button-white-broder" tabindex="0">View Projects</a>
                        <a href="#" class="button button-white" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
                    </div>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Capabilities</a>
                            <a href="#">Playspaces</a>
                            <span class="breadcrumb_last" aria-current="page">Community Playground Designers</span>
                        </span>
                    </span>
                </li>
            </ul>
            
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage content-wrapper mb-100">
        <div class="container">

            <div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                   <p>At Urbania, we're passionate community playground designers dedicated to transforming ordinary spaces into extraordinary play environments. Our mission goes beyond simply installing equipment–we create inclusive, imaginative playgrounds that bring communities together and foster children's development through innovative design. </p>

                   <p>As Australia's premier playground supplier, we collaborate with schools, local councils, and community groups to deliver bespoke playspaces that exceed expectations. By combining creativity with safety standards, we design playgrounds that children love and communities treasure.</p>

                   <a href="#" class="button button-theme" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image12.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>

            <div class="flex-container wrap justify-content-between ctent-block-wr">
                <div class="ctent-block">
                  <div class="heading-34">Community Playground Designers You Can Trust!</div>
                  <p>We specialise in creating vibrant public spaces that serve diverse community needs while prioritising safety, inclusivity, and engagement.</p>

                  <p>Our community playground designers know to include:</p>

                  <ul>
                      <li>Custom playground design and installation for all community settings</li>
                      <li>Imaginative themed playscapes that spark creativity</li>
                      <li>Safe-play environments for risk-based play that meet Australian Standards</li>
                      <li>Inclusive and accessible designs for children of all abilities</li>
                      <li>Premium timber playgrounds and contemporary street furniture</li>
                      <li>Nature play equipment, including water play features</li>
                      <li>Complete project management from concept to completion</li>
                  </ul>

                   <a href="#" class="button button-theme" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image13.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>


            <div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                   <div class="heading-34">Your Expert Community Playground Design Specialists</div>
                   <p>Our community playground designers bring decades of combined experience to every project. We've successfully completed playground installations across <a href="#">Brisbane</a>, <a href="#">Melbourne</a>, <a href="#">Sydney</a>, <a href="#">Perth</a>, and <a href="#">Hobart</a>, earning recognition as trusted local community playground suppliers.</p>

                   <div class="heading-24">Our Design Process</div>
                   <ol>
                       <li>Our first consultation is to understand your vision and budget</li>
                       <li>Site assessment and community needs analysis are performed</li>
                       <li>Collaborative design development with stakeholder input</li>
                       <li>Detailed schematics and transparent costings presented</li>
                       <li>Professional installation by certified tradespeople</li>
                       <li>Final inspection and project handover</li>
                       <li>Ongoing support backed by our 20-year warranty</li>
                   </ol>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image14.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>

        </div>
    </section>

<!-- call action -->
    <section class="sec-callaction mb-100">
        <img src="assets/images/contact-call-action-image.jpg" alt="contact-call-action-image" title="" width="1920"
            height="600" class="bgimg">
        <div class="container">
            <div class="callact-wrap">
                <div class="heading-44 text-white mb-10">Contact Our Play Space & Landscape Experts Today</div>
                <div class="callact-content">Let us bring your play spaces, streetscapes, and landscapes to life with
                    innovative, sustainable design.</div>
                <div class="btnlist">
                    <a href="#" class="button button-white-broder" tabindex="-1">View Projects</a>
                    <a href="#" class="button button-white" tabindex="-1">Get in Touch</a>
                </div>
            </div>
        </div>
    </section>


    <section class="playspace-design-centres mb-100">
        <div class="container">
            <div class="center-intro text-center">
                <div class="heading-34">Why Choose Urbania as Your Community Playground Designers?</div>
                <p>Selecting the right development partner can make all the difference for your project’s success. Here's what sets Urbania’s community playground designers apart:  </p>
            </div>

            <ul class="step-grid">
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <div class="heading-20">Proven Industry Experience:</div>
                        <p>Specialising in child-centric play environments that develop essential life skills.</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <div class="heading-20">Inclusive Design:</div>
                        <p>Creating accessible spaces where children of all abilities can play together.</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <div class="heading-20">Premium Materials:</div>
                        <p>Using durable, high-quality products suited to Australian weather. </p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <div class="heading-20">Safety Focus:</div>
                        <p>Strong commitment to risk management and Australian Standards compliance. </p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <div class="heading-20">Innovative Solutions:</div>
                        <p>Bringing contemporary design aesthetics to community outdoor play space designers. </p>
                    </div>
                </li>
            </ul>

            <div class="text-center center-intro">
                <p>Ready to create an inspiring playground that brings your community together? Our community playground designers can help you realise your vision. <a href="#">Contact</a> Urbania today on <a href="tel:1300 920 439">1300 920 439</a> or email <a href="mailto:info@urbania.com.au">info@urbania.com.au</a> to discuss your community playground project!</p>
            </div>
        </div>
    </section>


    <div class="container">
        <div class="divider"></div>
    </div> 

    <?php block('instagram');?>

</main>
<?php get_footer();