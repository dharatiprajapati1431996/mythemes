<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper contact-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/contact-banner.jpg" alt="contact-inner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Contact</div>
    				<p>Reach out to our team for support, project guidance, or general inquiries.</p>
    			</div>

    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Contact</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
        	<div class="inner-container">
        		<div class="contact-wrapper flex-container wrap mb-100">
	        		<div class="ctact-left">
	        			<div class="intro">
	        				<div class="heading-44">Talk to urbania</div>
	        				<p>From playgrounds to parklands, street furniture to urban landscapes, Urbania can help you and your organisation create amazing outdoor spaces and places.</p>
	        			</div>

	        			<div class="divider"></div>

	        			<ul class="ctact-list">
	        				<li>
	        					<div class="box">
	        						<div class="ctact-icon">
	        							<img src="assets/images/svg/map.svg" alt="map" title="" width="" height="">   
	        						</div>
	        						<div class="ctact-info">
	        							<span class="label">Head Office</span>
	        							<p>11 Melrose Court, Tullamarine, VIC 3043</p>
	        						</div>
	        					</div>
	        				</li>
	        				<li>
	        					<div class="box">
	        						<div class="ctact-icon">
	        							<img src="assets/images/svg/call.svg" alt="call" title="" width="" height="">   
	        						</div>
	        						<div class="ctact-info">
	        							<span class="label">Phone</span>
	        							<a href="tel:1300 920 439">1300 920 439</a>
	        						</div>
	        					</div>
	        				</li>
	        				<li>
	        					<div class="box">
	        						<div class="ctact-icon">
	        							<img src="assets/images/svg/email.svg" alt="email" title="" width="" height="">   
	        						</div>
	        						<div class="ctact-info">
	        							<span class="label">Email</span>
	        							<a href="mailto:info@urbania.com.au">info@urbania.com.au</a>
	        						</div>
	        					</div>
	        				</li>
	        			</ul>

	        			<ul class="follow-list">
	        				<li>
	        					<a href="#"><img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="" height=""> </a>
	        				</li>
	        				<li>
	        					<a href="#"><img src="assets/images/svg/instagram.svg" alt="instagram" title="" width="" height=""> </a>
	        				</li>
	        				<li>
	        					<a href="#"><img src="assets/images/svg/linkedin.svg" alt="linkedin" title="" width="" height=""> </a>
	        				</li>
	        			</ul>

	        			<div class="car-wrap">
	        				<img src="assets/images/urbania-car.png" alt="" title="" width="552px" height="207">
	        			</div>

	        		</div>
	        		<div class="ctact-right ">
	        			<div class="bg-light form-block">
	        				<form>
								<div class="row">
									<div class="form-group width50">
										<label>Name*</label>
										<input type="text" class="form-control" placeholder="Enter you name">
									</div>
									<div class="form-group width50">
										<label>Email*</label>
										<input type="email" class="form-control" placeholder="Example@gmail.com.au">
									</div>
								</div>
								<div class="row">
									<div class="form-group width50">
										<label>Phone*</label>
										<input type="text" class="form-control" placeholder="0000 000 000">
									</div>
									<div class="form-group width50">
										<label>Organisation*</label>
										<input type="text" class="form-control" placeholder="Enter organisation">
									</div>
								</div> 
								<div class="form-group">
									<label>How can Urbania help you?</label>
									<textarea class="form-control"></textarea>
								</div>
								<div class="row">
									<div class="form-group width50">
										<label>Do you have a project you would like to discuss?</label>
										<input type="text" class="form-control" placeholder="">
									</div>
									<div class="form-group width50">
										<label>When is a good time to call you?</label>
										<input type="text" class="form-control" placeholder="">
									</div>
								</div> 
								<div class="submitbtn">
									<input type="submit" class="button submitbtn button-theme" value="Submit">
								</div>
							</form>
	        			</div>
	        			
	        		</div>
	        	</div>

	        	<div class="map-wrapper">
	        		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3156.646448908793!2d144.88257997670536!3d-37.704501427802995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65bc4d9335419%3A0x677d97a6e03d31d8!2s11%20Melrose%20Ct%2C%20Tullamarine%20VIC%203043%2C%20Australia!5e0!3m2!1sen!2sin!4v1769232901203!5m2!1sen!2sin" width="100%" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	        	</div>
        	</div>
        </div>
    </section>

    <div class="container">
    	<div class="divider"></div>
    </div>


    <?php block('instagram');?>

</main>
<?php get_footer();