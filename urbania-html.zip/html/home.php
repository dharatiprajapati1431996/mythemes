<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="home-page">

    <?php block('home/banner');?>

    <!-- logo wrap -->
    <section class="toplogo-sec mb-100">
        <div class="container">
            <div class="toplogo-wrap">
                <div class="toplogo-left">
                    <div class="tpleft-title">Trusted & Certified Specialists in Playgrounds and Outdoor Spaces</div>
                </div>
                <div class="toplogo-right">
                    <ul class="tplogo-ul">
                        <li><img src="assets/images/compass-assurance-services-logo.png"
                                alt="compass-assurance-services-logo" title="" width="114" height="114"></li>
                        <li><img src="assets/images/compass-assurance-service-green-logo.png"
                                alt="compass-assurance-services-logo" title="" width="114" height="114"></li>
                        <li><img src="assets/images/compass-assurance-service-blue-logo.png"
                                alt="compass-assurance-services-logo" title="" width="114" height="114"></li>
                        <li><img src="assets/images/play-australia-logo.png" alt="play-australia-logo" title=""
                                width="114" height="109"></li>
                        <li><img src="assets/images/landscaping-victoria-logo.png" alt="landscaping-victoria-logo"
                                title="" width="179" height="85"></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- our services -->
    <section class="sec-hmservice mb-80">
        <div class="container">
            <div class="small-title">Our Services</div>
            <div class="heading-44">From <span>concept to completion,</span> we offer tailored solutions for play
                spaces, streetscapes, <span>and</span> landscapes</div>

            <ul class="service-ul">
                <li>
                    <a href="#">
                        <div class="service-li">
                            <div class="service-bximg">
                                <img src="assets/images/landscape-image.jpg" alt="landscape-image" title="" width="540"
                                    height="700">
                            </div>
                            <div class="service-bxbottom">
                                <div class="service-title">Landscape</div>

                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div class="service-li">
                            <div class="service-bximg">
                                <img src="assets/images/playspaces-image.jpg" alt="playspaces-image" title=""
                                    width="540" height="700">
                            </div>
                            <div class="service-bxbottom">
                                <div class="service-title">Playspaces</div>

                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div class="service-li">
                            <div class="service-bximg">
                                <img src="assets/images/street-furniture-image.jpg" alt="street-furniture-image"
                                    title="" width="540" height="700">
                            </div>
                            <div class="service-bxbottom">
                                <div class="service-title">Street Furniture</div>

                            </div>
                        </div>
                    </a>
                </li>
            </ul>


        </div>
    </section>

    <?php block('home/call-cta');?>
   

    <!-- why choose urbania -->
    <section class="sec-whychoose">
        <div class="container">
            <div class="content-width mb-60">
                <div class="heading-44"><span>Why Choose</span> Urbania as Your Landscape & Playspace Designers <span>in
                        Australia?</span></div>
                <div class="font18">When selecting playground designers for your project in Australia, consider our
                    unique advantages:</div>
            </div>

            <div class="whychoose-wrap mb-100">
                <div class="whychs-left">
                    <ul class="whychs-ul">
                        <li>
                            <div class="whychs-li">
                                <div class="whychs-icon"><img src="assets/images/svg/proven-knowledge.svg"
                                        alt="proven-knowledge-icon" title="" width="77" height="80"></div>
                                <div class="whychs-detail">
                                    <div class="why-label">Proven Knowledge</div>
                                    <div class="why-info">We have decades of experience creating commercial playgrounds
                                        across Australia.</div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="whychs-li">
                                <div class="whychs-icon"><img src="assets/images/svg/safety-first.svg"
                                        alt="safety-first-icon" title="" width="77" height="80"></div>
                                <div class="whychs-detail">
                                    <div class="why-label">Safety First</div>
                                    <div class="why-info">All designs comply with Australian Standards AS 4685, and
                                        finished structures are certified by an independent, registered Australian
                                        Certifier. </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="whychs-li">
                                <div class="whychs-icon"><img src="assets/images/svg/inclusive-design.svg"
                                        alt="inclusive-design-icon" title="" width="77" height="80"></div>
                                <div class="whychs-detail">
                                    <div class="why-label">Inclusive Design</div>
                                    <div class="why-info">Every child deserves great outdoor play opportunities, no
                                        matter their ability. </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="whychs-center">
                    <div class="whychs-imgwrap">
                        <img src="assets/images/whychoose-image.jpg" alt="whychoose-image" title="" width="274"
                            height="560" class="img-left-radius">
                        <img src="assets/images/whychoose-image-1.jpg" alt="whychoose-image" title="" width="274"
                            height="560" class="img-right-radius">
                    </div>
                </div>
                <div class="whychs-right">
                    <ul class="whychs-ul">
                        <li>
                            <div class="whychs-li">
                                <div class="whychs-icon"><img src="assets/images/svg/quality-materials.svg"
                                        alt="quality-materials-icon" title="" width="77" height="80"></div>
                                <div class="whychs-detail">
                                    <div class="why-label">Quality Materials</div>
                                    <div class="why-info">We only use premium playground supplies built for Australian
                                        weather and soil conditions. Timber playgrounds are our specialty!</div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="whychs-li">
                                <div class="whychs-icon"><img src="assets/images/svg/complete-services-icon.svg"
                                        alt="service-icon" title="" width="77" height="80"></div>
                                <div class="whychs-detail">
                                    <div class="why-label">Complete Services</div>
                                    <div class="why-info">From initial playground ideas to ongoing maintenance, we are
                                        with you for every step of your playground’s journey.</div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="whychs-li">
                                <div class="whychs-icon"><img src="assets/images/svg/20-year-warranty-icon.svg"
                                        alt="warranty-icon" title="" width="77" height="80"></div>
                                <div class="whychs-detail">
                                    <div class="why-label">20-Year Warranty</div>
                                    <div class="why-info">Industry-leading 20-year warranty on all Richter Spielgeräte
                                        timber play equipment.</div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="btm-text">An outdoor state of mind.</div>
        </div>
    </section>

    <!-- featured project -->
    <section class="sec-hmproject pt-pb100 mb-100 bg-light">
        <div class="container">
            <div class="heading-44">Featured Projects</div>

            <ul class="project-ul">
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/vineyard-farmhouse-image.jpg" alt="" title=""
                                    width="760" height="500"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">The Vineyard Farmhouse</div>
                                <ul class="project-location">
                                    <li><a href="#">NSW</a></li>
                                    <li><a href="#">Vineyard</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg" alt="" title="" width="25" height="15"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/michelle-guglielmo-park-image.jpg"
                                    alt="michelle-guglielmo-park-image" title="" width="760" height="500"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Michelle Guglielmo Park</div>
                                <ul class="project-location">
                                    <li><a href="#">VIC</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg" alt="" title="" width="25" height="15"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/kirrip-biik-park-image.jpg" alt="kirrip-biik-park-image"
                                    title="" width="760" height="500"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Kirrip Biik Park</div>
                                <ul class="project-location">
                                    <li><a href="#">NSW</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg" alt="" title="" width="25" height="15"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/templestowe-memorial-reserve-image.jpg"
                                    alt="templestowe-memorial-reserve-image" title="" width="760" height="500"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Templestowe Memorial Reserve</div>
                                <ul class="project-location">
                                    <li><a href="#">NSW</a></li>
                                    <li><a href="#">Garden</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg" alt="" title="" width="25" height="15"></a>
                        </div>
                    </div>
                </li>
            </ul>

            <div class="text-center"><a href="#" class="button button-black-border">Explore Our Projects</a></div>

        </div>
    </section>


    <!-- Our Process -->
    <section class="sec-hmprocess mb-100">
        <div class="container">
            <div class="process-cnt-wrap mb-80">
                <div class="process-cnt-left">
                    <div class="small-title">Our Process</div>
                    <div class="heading-44">Our Professional Play & Landscape Design Services</div>
                    <p>Our designers specialise in creating <b>unique outdoor spaces</b> that blend engaging play areas
                        with
                        inspiring landscapes. We go beyond traditional playground equipment, delivering projects that
                        bring communities together while integrating beautiful, functional landscapes. As official
                        Australian partners of <b>Richter Spielgeräte, Durbanis, and moveArt,</b> we combine world-class
                        play
                        equipment with thoughtful landscape design for every project.</p>
                </div>
                <div class="process-cnt-img">
                    <img src="assets/images/process-image.jpg" alt="process-image" title="" width="705" height="345">
                </div>
            </div>

            <!-- process icon -->
            <ul class="process-ul">
                <li>
                    <div class="process-li">
                        <div class="pr-icon">
                            <img src="assets/images/svg/consultation-icon.svg" alt="consultation-icon" title=""
                                width="79" height="84">
                        </div>
                        <div class="pr-info">
                            <div class="pr-title">01. Consultation</div>
                            <div class="pr-detail">
                                We discuss your vision, budget, and site requirements.
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="process-li">
                        <div class="pr-icon">
                            <img src="assets/images/svg/concept-icon.svg" alt="concept-icon" title="" width="79" height="84">
                        </div>
                        <div class="pr-info">
                            <div class="pr-title">02. Concept</div>
                            <div class="pr-detail">
                                Our studio creates detailed concepts, which are presented to you.
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="process-li">
                        <div class="pr-icon">
                            <img src="assets/images/svg/review-icon.svg" alt="review-icon" title="" width="79" height="84">
                        </div>
                        <div class="pr-info">
                            <div class="pr-title">03. Review</div>
                            <div class="pr-detail">
                                You review and refine designs to meet your exact needs.
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="process-li">
                        <div class="pr-icon">
                            <img src="assets/images/svg/installation-icon.svg" alt="installation-icon" title=""
                                width="79" height="84">
                        </div>
                        <div class="pr-info">
                            <div class="pr-title">04. Installation</div>
                            <div class="pr-detail">
                                We handle the installation, fully certified to Australian standards.
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="process-li">
                        <div class="pr-icon">
                            <img src="assets/images/svg/handover-icon.svg" alt="handover-icon" title="" width="79" height="84">
                        </div>
                        <div class="pr-info">
                            <div class="pr-title">05. Handover</div>
                            <div class="pr-detail">
                                At final inspection, you receive certification and a maintenance schedule.
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>

    <!-- work image -->
    <section class="sec-hmwork mb-100">
        <div class="container">
            <div class="hmwork-wrap">
                <img src="assets/images/work-image.jpg" alt="work-image" title="" width="1720" height="700"
                    class="bgimg btmlft-radius">
                <div class="hmwork-box">
                    <div class="heading-44 text-white mb-10">Who We Work With</div>
                    <div class="font20 text-white">Partnering with communities, councils, and developers across
                        Australia.</div>
                    <ul class="workul">
                        <li>Landscape Architects</li>
                        <li>Schools & Education</li>
                        <li>Architects</li>
                        <li>Parks & Recreation Departments</li>
                        <li>Builders</li>
                        <li>Hospitality, Resorts & Caravan Parks</li>
                        <li>Property Developers</li>
                        <li>Urban Designers</li>
                        <li>Local Government & Councils</li>
                    </ul>

                    <a href="#" class="button button-white-broder">Find Our More</a>

                </div>
            </div>
        </div>
    </section>


    <!-- value partners and clients -->
    <section class="sec-hmclient mb-100">
        <div class="container">
            <div class="heading-34 text-center">Our Valued Partners and Clients</div>
            <ul class="client-ul">
                <li>
                    <div class="client-logo">
                        <img src="assets/images/glas-logo.png" alt="glas-logo" title="" width="226" height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/durbanis-logo.png" alt="durbanis-logo" title="" width="226"
                            height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/merri-bek-logo.png" alt="merri-bek-logo" title="" width="226"
                            height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/legana-logo.png" alt="legana-logo" title="" width="226" height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/manningham-logo.png" alt="manningham-logo" title="" width="226"
                            height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/vos-logo.png" alt="vos-logo" title="" width="226" height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/port-phillip-logo.png" alt="port-phillip-logo" title="" width="226"
                            height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/nillumbik-logo.png" alt="nillumbik-logo" title="" width="226"
                            height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/john-holland-logo.png" alt="john-holland-logo" title="" width="226"
                            height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/stratis-logo.png" alt="stratis-logo" title="" width="226" height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/glascott-logo.png" alt="glascott-logo" title="" width="226"
                            height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/place-logo.png" alt="place-logo" title="" width="226" height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/stratis-logo.png" alt="stratis-logo" title="" width="226" height="123">
                    </div>
                </li>
                <li>
                    <div class="client-logo">
                        <img src="assets/images/place-logo.png" alt="place-logo" title="" width="226" height="123">
                    </div>
                </li>
            </ul>
        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div>

    <!-- insights shaping the future of outdoor -->
    <section class="sec-hmarticle mb-100">
        <div class="container">
            <div class="content-width">
                <div class="heading-44">Insights Shaping the Future of Outdoor Spaces and Play</div>
            </div>

            <ul class="article-ul">
                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-1.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">A Creative Playspace Inspired by Aussie Farm Life</div>
                                <div class="article-description">
                                    <p>From a farmhouse tower to a magical slide inspired by an Aussie grain silo, the
                                        playspace we created for The Vineyard has been a huge hit with families, as
                                        you’ll see in this joy capturing video. </p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-2.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Why Every Community Needs a Quality Playground Space</div>
                                <div class="article-description">
                                    <p>According to Early Childhood Australia, pre-school kids should be spending at
                                        least 80 mins a day in physical activities like, running, jumping & climbing...
                                    </p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-3.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Bringing Children Back to Nature Through Playful Spaces</div>
                                <div class="article-description">
                                    <p>Children are spending more time than ever in front of screens. While technology
                                        has its benefits, the importance of unplugging and heading outdoors cannot be
                                        overstated.</p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>
                 <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-1.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">A Creative Playspace Inspired by Aussie Farm Life</div>
                                <div class="article-description">
                                    <p>From a farmhouse tower to a magical slide inspired by an Aussie grain silo, the
                                        playspace we created for The Vineyard has been a huge hit with families, as
                                        you’ll see in this joy capturing video. </p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>


            <div class="text-center"><a href="#" class="button button-black-border">View All Articles</a></div>

        </div>
    </section>

    <!-- Frequently asked -->
    <section class="sec-hmfaq mb-100 pt-pb100">
        <img src="assets/images/faq-bgimg.jpg" alt="faq-bgimg" title="" width="1920" height="600" class="bgimg">
        <div class="container">
            <div class="hmfaq-wrap align-items-center">
                <div class="hmfaq-left">
                    <div class="heading-44">Frequently Asked Questions</div>
                    <div class="heading-20">Everything you need to know about our playground design, streetscapes, and community-focused outdoor solutions.</div>
                    <div class="btn-row">
                        <a href="#" class="button button-white-broder" tabindex="0">View Projects</a>
                        <a href="#" class="button button-white" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
                    </div>
                </div>
                <div class="hmfaq-right">
                    <div class="faq_accordion smk_accordion acc_with_icon">
                        <div class="accordion_in">
                            <div class="acc_head">
                               Are your playspaces compliant with Australian safety standards?
                            </div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>
                        <div class="accordion_in">
                            <div class="acc_head">
                                Can you create inclusive playgrounds?
                            </div>
                            <div class="acc_content">
								<p>Absolutely. Inclusive design is central to our approach. We consider accessibility, sensory experiences, and diverse physical and cognitive abilities to make sure all children can play, learn, and grow together.</p>
                            </div>
                        </div>
						<div class="accordion_in">
                            <div class="acc_head">
                                What warranties do you offer?
                            </div>
                            <div class="acc_content">
								<p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- content -->
    <section class="content-wrapper mb-100">
        <div class="container">
            <div class="flex-container wrap justify-content-between ctent-block-wr">
                <div class="ctent-block">
                    <div class="heading-34">Playground Design Services</div>
                    <p>Many of the skills we need as adults are developed in the playground. At Urbania, we create
                        imaginary worlds where kids can take risks, overcome fears and make new friends through our
                        expert playground design services. Australia’s schools, councils and childcare centres have
                        relied on us for years to create playspaces that all children, regardless of their ability, can
                        enjoy.
                    </p>
                    <p> Our team combines their creative vision with practical knowledge to deliver playground designs
                        that inspire children and strengthen communities across the country.
                    </p>
                    <p>To find out more about our design and building services, please contact our team online or by
                        calling <a href="tel:1300920439">1300 920 439.</a></p>

                    <div class="heading-20">Our Professional Play Space Design Services</div>
                    <p>Our designers specialise in creating unique outdoor play spaces that go beyond traditional
                        equipment. As part of our play space design services, we offer: </p>

                    <ul>
                        <li>Custom playground design that takes into account your needs and budget</li>
                        <li>Adventure playground concepts that challenge and engage children,
                            including playground slides, climbing elements, and crawlspaces</li>
                    </ul>

                </div>
                <div class="ctent-img">
					<img src="assets/images/content-image10.jpg" alt="content image" title="" width="860" height="600">
				</div>
            </div>
									
			<div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                    <div class="heading-34">Commercial Playground Design in Australia Serving Every Sector</div>
                    <p>Our designers have worked with a range of different clients to create engaging environments for children to learn, explore, and grow. These include:</p>
					<div class="heading-20">School Playground Design</div>
					<p>Transforming school grounds with creative playground designs that support physical development, social skills and imaginative play. Our education-focused approach makes certain that every element serves a developmental purpose.</p>
																		
					<div class="heading-20">Early Learning Playgrounds</div>
					<p>Specialised play space designs for childcare centres that nurture growth through age-appropriate, safe challenges and sensory experiences.</p>
																	
					<div class="heading-20">Public Playground Design</div>
					<p>Working with local councils, we create inclusive community spaces where families gather and children of all abilities can play together safely.</p>
					<div class="heading-20">Enrich Your Community with Our Playground Design Services</div>
					<p>Whether you're planning a children's playground for a school, seeking an outdoor playground for kids at your childcare centre, or developing a more public space, our playground evelopment specialists are ready to bring your vision to life. </p>
                </div>
                <div class="ctent-img">
					<img src="assets/images/content-image1.jpg" alt="content image" title="" width="860" height="600">
				</div>
            </div>
        </div>
    </section>


    <div class="container">
        <div class="divider"></div>
    </div>
	
	<?php block('instagram');?>



</main>
<?php get_footer();