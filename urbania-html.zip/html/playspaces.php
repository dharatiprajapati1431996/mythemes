<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper landscape-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/playspaces-banner.jpg" alt="playspaces-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Playspaces</div>
    				<p>Designing imaginative playspaces that inspire exploration, creativity, and meaningful outdoor play.</p>
                    <div class="btn-row">
                        <a href="#" class="button button-white-broder" tabindex="0">View Projects</a>
                        <a href="#" class="button button-white" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
                    </div>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Capabilities</a>
                            <span class="breadcrumb_last" aria-current="page">Playspaces</span>
                        </span>
                    </span>
                </li>
            </ul>
            
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage content-wrapper mb-100">
        <div class="container">

            <div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                   <div class="heading-34">Bespoke Playspace Design for Schools</div>

                   <p>We believe that everyone deserves a great outdoors, and at Urbania, we’ve made it our mission to create bespoke playspace designs for schools. </p>

                   <p>Our experienced landscapers, trades, craftsmen and play specialists are second to none when it comes to transforming playgrounds for kids that are beyond anything you possibly could imagine. </p>

                   <p>We are a member of Landscaping Victoria–contact us for a landscape to match your imagination.</p>

                   <a href="#" class="button button-theme" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image6.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>



            <div class="recent-project-wrapper">
                <div class="heading-44 text-center">Some of our recent landscaping projects.</div>

                <ul class="project-ul project-grid">
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-19.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Playground for Councils</div>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-20.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Playground for Early Learning Centres</div>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-21.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Playground for Property Developers</div>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-22.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Playground for Schools</div>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-23.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Accessible Playgrounds</div>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-24.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Community Playgrounds</div>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-25.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Nature Playgrounds</div>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div> 

            <div class="divider"></div>

            <div class="flex-container wrap justify-content-between ctent-block-wr">
                <div class="ctent-block">
                   <div class="heading-34">Bespoke Playground Design for LGAS</div>
                   <p>Our expert design team has designed and created bespoke playgrounds that are much loved by their local communities. No matter your budget or vision, we can tailor a playground package for you.  </p>

                   <p>Urbania is the Australian partner and official installer of three of the world’s most renowned names in outdoors and play:</p>

                   <ul>
                       <li>Nature Play Equipment by Richter Spielgeräte</li>
                       <li>Contemporary Street-Furniture by Durbanis </li>
                       <li>Play & Social Sculptures by moveArt</li>
                   </ul>
                  
                   <a href="#" class="button button-theme" tabindex="0">Learn more about our materials here!</a>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image7.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>


            <div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                   <div class="heading-34">Some of our services include:</div>

                   <ul>
                       <li>Custom playground design and installation.</li>
                       <li>Imaginative themed playscapes for children. </li>
                       <li>Play equipment supply for childcare centres, schools and parks.</li>
                       <li>Risk-assessed, safe-play environments.</li>
                       <li>Inclusive and <a href="#">accessible safe play design.</a></li>
                       <li>Timber product design and supply for playgrounds and landscaping.</li>
                       <li>Outdoor seating, benches, shelters, and shelter installations.</li>
                       <li>Contemporary street furniture supply and installation.</li>
                   </ul>
                  
                   <a href="#" class="button button-theme" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14"> Get in Touch</a>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image8.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>

        </div>
    </section>

    <!-- <div class="container">
        <div class="divider"></div>
    </div> -->


    <section class="playspace-design-centres mb-100">
        <div class="container">
            <div class="center-intro text-center">
                <div class="heading-34">Bespoke Playspace Design for Early Learning Centres</div>
                <p>Are you a manager of an early learning centre and want to change up your spaces? We can enhance early childhood education with outdoor play. With our bespoke <a href="#">playspace design for early learning centres.</a> </p>
            </div>

            <div class="heading-24 text-center">How can you get started?</div>

            <ul class="step-grid">
                <li>
                    <div class="step-box">
                        <div class="num"><span>01</span></div>

                        <p>Once you have a figure in mind, we’ll sit down with you and set out the project parameters, and discuss your preferred materials, the playground location and any site-specific complexities. Just think of it as a getting to know you session.</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="num"><span>02</span></div>

                        <p>Our initial design session is done in consultation with you. We’ll show you some standard ‘off the shelf’ equipment, then rough out an indicative design concept. Once we have something we agree on, we’ll do a site visit before preparing initial costs for you. </p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="num"><span>03</span></div>

                        <p>Our drafting team will then draw up a detailed schematic of the playground concept, which we will present to you along with detailed costings.</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="num"><span>04</span></div>

                        <p>Once plans are approved and your deposit has been paid, we will agree on a start date for the project, as well as finalise specifics around materials, colours, etc.</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="num"><span>05</span></div>

                        <p>Once your bespoke playground is completed, we will meet you on-site for a final inspection.  We’ll then arrange a time to officially hand over the project.</p>
                    </div>
                </li>
            </ul>

            <div class="text-center">
                <p>Speaking of guarantees, every Urbania playground is backed by our 20-year play equipment warranty.</p>
            </div>
        </div>
    </section>




    <!-- call action -->
    <section class="sec-callaction mb-100">
        <img src="assets/images/contact-call-action-image.jpg" alt="contact-call-action-image" title="" width="1920"
            height="600" class="bgimg">
        <div class="container">
            <div class="callact-wrap">
                <div class="heading-44 text-white mb-10">Contact Our Play Space & Landscape Experts Today</div>
                <div class="callact-content">Let us bring your play spaces, streetscapes, and landscapes to life with
                    innovative, sustainable design.</div>
                <div class="btnlist">
                    <a href="#" class="button button-white-broder" tabindex="-1">View Projects</a>
                    <a href="#" class="button button-white" tabindex="-1">Get in Touch</a>
                </div>
            </div>
        </div>
    </section>


    <section class="content-wrapper mb-100">
        <div class="container">
            <div class="flex-container wrap justify-content-between ctent-block-wr">
                <div class="ctent-block">
                   <div class="heading-34">Bespoke Playspace Design for Schools: Why Choose Us?</div>
                   <p>There are many reasons to reach out to us if you’re looking for a trustworthy company with experience in bespoke <a href="#">playspace design for schools.</a> We have: </p>

                   <ul>
                       <li>Expertise in creating imaginative, child-centric play environments.</li>
                       <li>A focus on developing life skills through play.</li>
                       <li>Strong commitment to safety and risk management in playgrounds.</li>
                       <li>An inclusive design approach to catering to children of all abilities.</li>
                       <li>Durable, high-quality materials are used for all builds.</li>
                       <li>A commitment to innovation in playground and street furniture design.</li>
                       <li>Collaborative and consultative project management style.</li>
                   </ul>
                  
                   <a href="#" class="button button-theme" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14"> Get in Touch</a>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image9.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div> 

    <?php block('instagram');?>

</main>
<?php get_footer();