<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper areas-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/areas-banner.jpg" alt="areas-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Find Playground Design Services Near Me</div>

                    <form class="suburb-search-form" method="post" action="/">
                        <input type="search" name="suburb_locations" value="" placeholder="Suburb/postcode" class="ui-autocomplete-input" autocomplete="off">
                        <button type="button"><img src="assets/images/svg/search.svg" alt="search" title="" width="22" height="24"></button>
                        <ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" unselectable="on" style="display: none;"></ul>
                    </form>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Areas</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage content-wrapper mb-100">
        <div class="container">
             <div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                    <p>Urbania creates exceptional indoor and outdoor environments that bring communities together. Our playground design services reach major Australian cities, delivering imaginative playscapes and modern street furniture to schools, early learning centres, and local government authorities nationwide. </p>
                    <p>From Melbourne's vibrant streets to Brisbane's sunny playgrounds, we've become Australia's leading outdoor transformation specialists.</p>

                    <a href="#" class="button button-theme"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
                </div>
                <div class="ctent-img sticky">
                    <img src="assets/images/content-image10.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>
        </div>
    </section>

    <section class="inpage location-areas mb-100">
        <div class="container">
            <div class="text-center heading-34">Our Locations and Areas We Serve</div>

            <ul class="location-grid">
                <li>
                    <div class="locatbox">
                        <div class="heading-18"><img src="assets/images/svg/map.svg" alt="map" title="" width="13" height="16"> Melbourne</div>
                        <p>Our Tullamarine headquarters acts as the creative hub for Victoria's most innovative playground designs. We've transformed countless school playgrounds, community parks, and early learning centres throughout Greater Melbourne, bringing our signature blend of safety, creativity, and inclusivity to every project.</p>
                    </div>
                </li>
                <li>
                    <div class="locatbox">
                         <div class="heading-18"><img src="assets/images/svg/map.svg" alt="map" title="" width="13" height="16"> Sydney</div>
                        <p>Sydney's diverse communities benefit from our customised playground design services. Whether we're working on a harbourside park or a western suburbs school, we understand Sydney's varied landscapes and demographics' specific requirements.</p>
                    </div>
                </li>
                <li>
                    <div class="locatbox">
                         <div class="heading-18"><img src="assets/images/svg/map.svg" alt="map" title="" width="13" height="16"> Brisbane</div>
                        <p>Queensland's capital provides year-round outdoor play opportunities. Our Brisbane playground design services create durable, weather-resistant play environments that can withstand the subtropical climate while delivering endless adventure.</p>
                    </div>
                </li>
                <li>
                    <div class="locatbox">
                         <div class="heading-18"><img src="assets/images/svg/map.svg" alt="map" title="" width="13" height="16"> Perth</div>
                        <p>Western Australia's outdoor lifestyle perfectly complements our mission. We deliver playground design services that celebrate Perth's connection to nature, incorporating natural play elements and sustainable materials.</p>
                    </div>
                </li>
                <li>
                    <div class="locatbox">
                         <div class="heading-18"><img src="assets/images/svg/map.svg" alt="map" title="" width="13" height="16"> Hobart</div>
                        <p>Tasmania's capital benefits from our commitment to creating inclusive, engaging outdoor spaces that foster community connection and childhood development.</p>
                    </div>
                </li>
            </ul>

        </div>
    </section>


    <section class="content-wrapper mb-100">
        <div class="container">
             <div class="flex-container wrap justify-content-between ctent-block-wr">
                <div class="ctent-block">
                    <div class="heading-34">Wide-ranging Playground Design Services</div>
                    <p>We deliver end-to-end services that include: </p>

                    <ul>
                        <li>Custom playground design and installation</li>
                        <li>Nature play equipment, including entirely timber playgrounds</li>
                        <li>Risk-assessed, safe-play environments that include water play</li>
                        <li>Inclusive design for all abilities</li>
                        <li>Complete landscaping services </li>
                    </ul>

                    <p>Each location receives the same dedication to excellence, whether we're designing for inner-city schools or regional community centres.</p>

                    <a href="#" class="button button-theme"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
                </div>
                <div class="ctent-img sticky">
                    <img src="assets/images/content-image11.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>
        </div>
    </section>


    <section class="sec-callaction mb-100">
        <img src="assets/images/contact-call-action-image.jpg" alt="contact-call-action-image" title="" width="1920" height="600" class="bgimg">
        <div class="container">
            <div class="callact-wrap">
                <div class="heading-44 text-white mb-10">Ready to Transform Your Space?</div>
                <div class="callact-content">Wherever you're located within the areas we serve, Urbania brings imagination to life. Our playground design services adapt to your specific needs, budget, and vision. </div>

                <div class="callact-content"><a href="#">Contact us</a> today at <a href="tel:1300 920 439">1300 920 439</a> or email <a href="mailto:info@urbania.com.au">info@urbania.com.au</a> to discuss how we can transform your outdoor space into an extraordinary community asset.</div>

                <div class="btnlist">
                    <a href="#" class="button button-white-broder" tabindex="-1">View Projects</a>
                    <a href="#" class="button button-white" tabindex="-1">Get in Touch</a>
                </div>
            </div>
        </div>
    </section>


<section class="playspace-design-centres mb-100">
        <div class="container">
            <div class="center-intro text-center">
                <div class="heading-34">Why Choose Urbania? Check Out the Areas We Serve</div>
                <p>Our nationwide presence means we understand local requirements while still maintaining our consistent quality standards. Here's what sets us apart:  </p>
            </div>

            <ul class="step-grid">
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <p>20-year warranty on all play equipment</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <p>Member of Landscaping Victoria</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <p>Australian Standards compliant (AS 4685) </p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <p>Experienced multidisciplinary teams</p>
                    </div>
                </li>
                <li>
                    <div class="step-box">
                        <div class="cricle">
                            <img src="assets/images/svg/checked-black.svg" alt="checked-black" title="" width="" height="">
                        </div>
                        <p>Complete management of your build</p>
                    </div>
                </li>
            </ul>

            <div class="text-center center-intro">
                <p>We've successfully completed projects for schools, early learning centres, local councils, and community groups across all service areas, earning trust through transparent communication and exceptional results.</p>
            </div>
        </div>
    </section>


    <div class="container">
        <div class="divider"></div>
    </div>


    <section class="areas-sec mb-100">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block">
                    <div class="heading-34">Areas We Serve: Transforming Outdoor Spaces Across Australia </div>

                    <div class="areas-location-wrap">
                        <div class="areas-col">
                            <div class="heading-18">Landscape Playground</div>
                            <ul class="areas-list">
                                <li><a href="#">Landscape Playground Brisbane</a></li>
                                <li><a href="#">Landscape Playground Hobart</a></li>
                                <li><a href="#">Landscape Playground Melbourne</a></li>
                                <li><a href="#">Landscape Playground Perth</a></li>
                                <li><a href="#">Landscape Playground Sydney</a></li>
                            </ul>
                        </div>
                        <div class="areas-col">
                            <div class="heading-18">Nature Playground</div>
                            <ul class="areas-list">
                                <li><a href="#">Nature Playground Brisbane</a></li>
                                <li><a href="#">Nature Playground Hobart</a></li>
                                <li><a href="#">Nature Playground Melbourne</a></li>
                                <li><a href="#">Nature Playground Perth</a></li>
                                <li><a href="#">Nature Playground Sydney</a></li>
                            </ul>
                        </div>
                        <div class="areas-col">
                            <div class="heading-18">Playground Design</div>
                            <ul class="areas-list">
                                <li><a href="#">Playground Design Brisbane</a></li>
                                <li><a href="#">Playground Design Hobart</a></li>
                                <li><a href="#">Playground Design Melbourne</a></li>
                                <li><a href="#">Playground Design Perth</a></li>
                                <li><a href="#">Playground Design Sydney</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="ctent-img sticky">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3156.646448908793!2d144.88257997670536!3d-37.704501427802995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65bc4d9335419%3A0x677d97a6e03d31d8!2s11%20Melrose%20Ct%2C%20Tullamarine%20VIC%203043%2C%20Australia!5e0!3m2!1sen!2sin!4v1769686352732!5m2!1sen!2sin" width="100%" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div>

    <?php block('instagram');?>
    
</main>
<?php get_footer();