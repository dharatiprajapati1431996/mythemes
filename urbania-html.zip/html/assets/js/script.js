$(document).ready(function () {

  /*Scroll top*/
  var scrollTop = $(".scrollTop");
  $(window).scroll(function () {
    var topPos = $(this).scrollTop();
    if (topPos > 0) {
      $(scrollTop).css("opacity", "1", "transform", "scale(1)");
      $(".scrollTop").addClass("vis");
    } else {
      $(scrollTop).css("opacity", "0", "transform", "scale(0)");
      $(".scrollTop").removeClass("vis");
    }
  });
  $(scrollTop).click(function () {
    $("html, body").animate(
      {
        scrollTop: 0,
      },
      600
    );
    return false;
  });



  // FOOTER
  // $(".footer-bottom-wr .ft-title").click(function () {
  //   if ($(window).width() < 576) {
  //     let $this = $(this);

  //     $this.toggleClass("showhide");

  //     let $wrapper = $this.closest(".ft-content");
  //     let $heads = $wrapper.find(".footer-bottom-wr .ft-title");

  //     $heads.not($this).removeClass("showhide");
  //     $heads.not(".showhide").next().stop().slideUp(300);
  //     $heads.filter(".showhide").next().stop().slideDown(300);
  //   }
  // });


  // testimonial
  $("ul.testimonial-ul").slick({
    arrows: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 1,
    horizontal: true,
    infinite: true,
    autoplay: false,
    pauseOnHover: false,

    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 2,

        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,

        },
      },
    ],
  });


  // project 
  $(".sec-hmproject ul.project-ul").slick({
    arrows: false,
    dots: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    horizontal: true,
    infinite: true,
    autoplay: false,
    pauseOnHover: false,

    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,

        },
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 1,
          centerMode: true,
          centerPadding: '20px',
        },
      },
    ],
  });

  // Fancybox Config
  $('[data-fancybox]').fancybox({
      touch: false,
      smallBtn: true
    });


});
