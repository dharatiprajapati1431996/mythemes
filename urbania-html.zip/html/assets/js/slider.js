$(document).ready(function () {



  // project 
  $("ul.article-slider").slick({
    arrows: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 1,
    horizontal: true,
    infinite: true,
    autoplay: true,
    pauseOnHover: false,

    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,

        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  });



  // Search tags toggle
  
  $(".toggle-btn").click(function () {
    $(".search-tags-wrapper").stop(true, true).slideToggle(300);
  });




   // KEYFACTOR

  const init = {
    autoplay: true,
    infinite: true,
    cssEase: "linear",
    slidesToShow: 5,
    slidesToScroll: 1,
    true:false,
    dot:false,
    arrows: false,
    autoplaySpeed: 3000,
        responsive: [
          {
            breakpoint: 1336,
            settings: {
                  slidesToShow: 3,
            }
            },
           
          {
            breakpoint: 992,
            settings: {
                slidesToShow: 3,
            }
          },
          {
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
            }
          }
      ]
    };
  
    $(() => {
    const win = $(window);
    const slider = $(".keyfator-slider");
  
    win.on("load resize", () => {
      if (win.width() < 1600) {
        slider.not(".slick-initialized").slick(init);
        } else if (slider.hasClass("slick-initialized")) {
        slider.slick("unslick");
        }
      });
    });


  // Related Project
  $(".related-project-sec ul.project-ul ").slick({
    arrows: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 1,
    horizontal: true,
    infinite: true,
    autoplay: true,
    pauseOnHover: false,

    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,

        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  });


});
