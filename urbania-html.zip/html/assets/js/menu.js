$(document).ready(function () {


	/*-----MENU DROPDOWN-----*/
	$('.menu-link ul li:has(ul)').addClass("haschild");
	var caicon = $('<i class="fa fa-angle-down menudrop" aria-hidden="true"></i>');
	$('.menu-link ul li:has(ul) > a').append(caicon);
	$('.menu-link ul li:has(ul) > a').next().addClass("childmenu");
	$('.menu-link .sublink > li > ul > li').on('mouseenter', function () {
		$(this).siblings().removeClass('menu-item-hover');
		$(this).addClass('menu-item-hover');
		$('.current-menu-parent').removeClass('active');
		$('.current_page_item').removeClass('active')
	});
	$('.menudrop').on('click', function (e) {
		var label = $(this).parent();
		var parent = label.parent('.haschild');
		var list = label.siblings('.childmenu');
		e.preventDefault();
		if (parent.hasClass('isopen')) {
			list.hide();
			parent.removeClass('isopen')
		} else {
			parent.parent().find('li.haschild').removeClass('isopen');
			parent.parent().find('li.haschild .childmenu').hide();
			list.show();
			parent.addClass('isopen')
		}
	});



	if ($(window).width() >= 1120) {
		$(".menu-link nav > ul > li.has-sub").hover(
			function () {
				$('body').addClass("menuoverlay");
				$(window).trigger('resize');
			},
			function () {
				$('body').removeClass("menuoverlay");
			}
		);
	}
	
	/*-----BURGER MENU-----*/
	$(".togglebtn, .overlay").click(function () {
		$(".togglebtn, .overlay,.menu-link").toggleClass("active");
		if ($(".overlay").hasClass("active")) {
			$(".overlay").fadeIn();
			$('html').addClass('menuhidden');

		} else {
			$(".overlay").fadeOut();
			$('html').removeClass('menuhidden');

		}
	});



	/*-----FIXED HEADER-----*/

	$(window).scroll(function () {
		if (($(window).scrollTop() > 180) && ($(window).width() >= 300)) {
			$('body').addClass('fixed-header');
		} else {
			$('body').removeClass('fixed-header');
		}
	});

	
	  $(window).width() >= 1200 && (
    $.each($(".menu-link .menu-level1"), function () {
      // Adds 'active-submenu' to the first submenu item if none is active on page load.
      $(this).find("> .has-sub.active-submenu").length || $(this).find("> .has-sub:first-child").addClass("active-submenu");
    
       
      
    }),

    // Adds 'active-submenu' to the hovered item with a submenu, and removes it from its siblings.
    $(".menu-link .menu-level1 > .has-sub").on("mouseenter", function () {
      $(this).addClass("active-submenu").siblings().removeClass("active-submenu");
    }),

    // This is the key part that removes the 'active-submenu' class.
    // It listens for a mouse leaving the main menu item, or entering a simple menu item.
    $(".menu-link .menu-level1 > li").on("mouseleave", function () {
      // Check if the related target (where the mouse is moving to) is outside the menu
      // or a different menu item to prevent flickering.
      if (!$(this).find(event.relatedTarget).length) {
        $(this).removeClass("active-submenu");
      }
    }),

    // When a simple menu item (without a submenu) is hovered, it removes the active class from all other menu items.
    $(".menu-link .menu-level1 > li:not(.has-sub)").on("mouseenter", function () {
      $(this).siblings().removeClass("active-submenu");
    })
  );


	  // +++++++++++++++++++++++++++++++  Search var for desktop 

  	// Mobile search toggle 
        $('a.search-on-link').on('click', function(e) {
           e.preventDefault(); // Prevent default link behavior

            // Toggle visibility of the .search-show-mobile div
            $('.search-show').toggleClass('hidden');

            // Add or remove the active class on the parent .head-ecommerce div
            $('.search-header').toggleClass('show-search-bar');
        });


});