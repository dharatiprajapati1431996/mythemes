jQuery(document).ready(function($){
	$(".faq_accordion").smk_Accordion({
		showIcon: true, 
		animation: true, 
		closeAble: true, 
		slideSpeed: 200 ,
		 activeIndex : 1
	});

});
