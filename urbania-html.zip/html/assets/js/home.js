$(document).ready(function () {

  /* home banner*/
  $(".js-hmbanner").slick({
    autoplay: true,
    slidesToShow: 1,
    arrows: false,
    fade: true,
    dots: true,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          arrows: false,
          dots: false,
        }
      }
    ]
  });

  /*  Clients */
  $('ul.client-ul').slick({
      rows: 2,
      dots: false,
      arrows: true,
      infinite: true,
      speed: 300,
      slidesToShow: 6,
      slidesToScroll: 6,
      autoplay:true,
      responsive: [
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 4,

            },
          },
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 3,

            },
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: 2,
            },
          },
        ],
  });


   // Arricle slider

    $(".sec-hmarticle ul.article-ul").slick({
        arrows: true,
        dots: false,
        slidesToShow: 3,
        slidesToScroll: 1,
        horizontal: true,
        infinite: true,
        autoplay: true,
        pauseOnHover: false,
        autoplaySpeed: 3000,
        responsive: [
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 2,

            },
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: 1,
            },
          },
        ],
    });

});

