<?php

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/assets.php';
