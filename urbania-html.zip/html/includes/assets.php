<?php

$GLOBALS['assets'] = [
    'common' => [
        'styles' => [
            'variables',
            'font-awesome.min',
             'jquery.fancybox.min',
            'slick.min',
            'slick-theme.min','reset',
            'normalize',
            'utiliti',
            'style',
            'header',
            'modal-pop-up'
        ],
        'scripts' => ['jquery-3.6.1.min','jquery.fancybox.min','slick.min','menu', 'script'],
    ],

    'home' => [
        'styles' => ['smk-accordion','faq','service','testimonial','project','article','home'],
        'scripts' => ['smk-accordion','faq','home'],
    ],
	  'about' => [
        'styles' => ['testimonial','about'],
        'scripts' => [],
    ],	
    'services' => [
        'styles' => ['service'],
        'scripts' => [],
    ],
    'sheet-membrane' => [
        'styles' => ['service','service-detail'],
        'scripts' => [],
    ],
     'areas' => [
        'styles' => ['area'],
        'scripts' => [],
    ],
    'gallery' => [
        'styles' => ['jquery.fancybox.min','gallery'],
        'scripts' => ['jquery.fancybox.min'],
    ],
    'suburb' => [
        'styles' => ['service','area'],
        'scripts' => [],
    ],
    'contact' => [
        'styles' => ['contact'],
        'scripts' => [],
    ],
    'catalogues' => [
        'styles' => ['catalogues'],
        'scripts' => [],
    ],
    'blog' => [
        'styles' => ['article'],
        'scripts' => [],
    ],
    'blog-detail' => [
        'styles' => ['article'],
        'scripts' => ['slider'],
    ],
    'projects' => [
        'styles' => ['project'],
        'scripts' => ['slider'],
    ],
    'projects-detail' => [
        'styles' => ['our-partners' , 'project'],
        'scripts' => ['slider'],
    ],
    'our-partners' => [
        'styles' => ['our-partners'],
        'scripts' => [],
    ],
    'pratners-detail' => [
        'styles' => ['our-partners' , 'project'],
        'scripts' => ['slider'],
    ],
    'landscape' => [
        'styles' => ['landscape' , 'smk-accordion','faq' , 'project'],
        'scripts' => ['smk-accordion','faq'],
    ],
    'playspaces' => [
        'styles' => ['landscape' , 'project' , 'home'],
        'scripts' => [],
    ],
    'community-playground-designers' => [
        'styles' => ['landscape' , 'project' , 'home'],
        'scripts' => [],
    ],
    'areas' => [
        'styles' => ['areas' , 'home' , 'landscape'],
        'scripts' => [],
    ],
    'suburb' => [
        'styles' => ['areas' , 'home' , 'landscape'],
        'scripts' => ['slider'],
    ],
];