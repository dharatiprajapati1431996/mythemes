<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper partners-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/partner-banner.png" alt="partner-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Our Partners</div>
    				<p>Explore expert insights and stories shaping the future of play and urban spaces.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">About</a>
                            <span class="breadcrumb_last" aria-current="page">Our Partners</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage partner-sec">
        <div class="container">
        	<div class="heading-44"><span>Our partners</span> help us create safe, sustainable, and imaginative <span>outdoor play</span> environments.</div>

            <ul class="partners-grid">
                <li>
                    <a href="#" class="partners-col">
                        <div class="partner-img">
                            <img src="assets/images/image-01.jpg" alt="image-01" title="" width="540" height="450">

                            <img src="assets/images/svg/richter-schnecke.svg" alt="richter-schnecke" title="" width="" height="" class="partner-logo">
                        </div>
                        <div class="partner-detail">
                            <div class="heading-22">Richter Spielgeräte</div>
                            <p>Urbania is the Australian partner and authorised installer of the acclaimed playground creator Richter Spielgeräte...</p>
                            <span class="alink"><img src="assets/images/svg/arrow-green.svg" alt="arrow-green" title="" width="" height=""> </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="partners-col">
                        <div class="partner-img">
                            <img src="assets/images/image-02.jpg" alt="image-02" title="" width="540" height="450">
                            <img src="assets/images/svg/move-art.svg" alt="move-art" title="" width="" height="" class="partner-logo">
                        </div>
                        <div class="partner-detail">
                            <div class="heading-22">Richter Spielgeräte</div>
                            <p>Nothing creates intrigue and interest in a public space quite like a moveArt playsculpture. Developed in Switzerland, their organic forms were inspired...</p>
                            <span class="alink"><img src="assets/images/svg/arrow-green.svg" alt="arrow-green" title="" width="" height=""> </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="partners-col">
                        <div class="partner-img">
                            <img src="assets/images/image-03.jpg" alt="image-03" title="" width="540" height="450">
                            <img src="assets/images/svg/durbanis.svg" alt="durbanis" title="" width="" height="" class="partner-logo">
                        </div>
                        <div class="partner-detail">
                            <div class="heading-22">Durbanis</div>
                            <p>Designed and manufactured in the Catalonia region of Spain, Durbanis is renowned the world over for it outdoor and urban furniture...</p>
                            <span class="alink"><img src="assets/images/svg/arrow-green.svg" alt="arrow-green" title="" width="" height=""> </span>
                        </div>
                    </a>
                </li>
            </ul>


            <div class="divider"></div>
        </div>
    </section>

    <?php block('instagram');?>
    
</main>
<?php get_footer();