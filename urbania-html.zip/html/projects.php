<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper projects-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/project-banner.jpg" alt="project-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">The Vineyard Farmhouse</div>
    				<p>Experience timeless farmhouse design inspired by vineyard landscapes and natural textures.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Projects</a>
                            <span class="breadcrumb_last" aria-current="page">The Vineyard Farmhouse</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage content-wrapper mb-100">
        <div class="container">
            <div class="search-wrapper">
                <div class="heading-44 heading-flex toggle-btn"><img src="assets/images/svg/plus-icon.svg" alt="plus" title="" width="" height=""> Refine Search</div>

                <div class="search-tags-wrapper">
                    <div class="tags-row">
                        <div class="heading-20">Branch</div>
                        <div class="checkbox-group">
                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Adelaide
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Brisbane
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Canberra
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Darwin
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Geelong
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Gold Coast
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Kinglake
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Melbourne
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Perth
                            </label>

                             <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Sydney
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Tasmania
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Townsville
                            </label>
                        </div>
                    </div>

                    <div class="tags-row">
                        <div class="heading-20">Sector</div>
                        <div class="checkbox-group">
                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Aged Care
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Commercial
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Defence
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Education
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Government
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Healthcare
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Hotels & Hospitality
                            </label>

                            <label class="checkbox-item">
                              <input type="checkbox">
                              <span class="checkmark"></span>
                              Retail
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <ul class="project-ul project-grid">
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-07.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">The Vineyard Farmhouse</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">NSW</a></li>
                                    <li><a href="#">Vineyard</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-08.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Michelle Guglielmo Park</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-09.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Kirrip Biik Park</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">NSW</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-10.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Templestowe Memorial Reserve</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">NSW</a></li>
                                    <li><a href="#">Garden</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-11.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Dickens Street Activation</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Street</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-12.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Legana Primary School</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">TAS</a></li>
                                    <li><a href="#">Playground</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-13.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Diamond Creek Regional Playspace</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Playspace</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-14.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Wonguim Wilam Playspace</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Playspace</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-15.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Brighton High School Tasmania</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">BHA</a></li>
                                    <li><a href="#">Learning Street</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-16.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Moreland & Coburg Station</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Playspace</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-17.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Whittlesea Public Gardens</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">BHA</a></li>
                                    <li><a href="#">Playspace</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-18.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Devonport Waterfront Park</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">TAS</a></li>
                                    <li><a href="#">Waterfront Park</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
            </ul>

            <div class="text-center">
                <a href="#" class="button button-black-border">Load More Projects</a>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div>

    <?php block('instagram');?>

</main>
<?php get_footer();