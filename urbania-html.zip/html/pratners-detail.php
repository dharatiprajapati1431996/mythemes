<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper partners-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/partner-detail-banner.jpg" alt="partner banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Richter Spielgeräte</div>
    				<p>Richter’s handcrafted timber playscapes age naturally, offering safe, imaginative play for all environments.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">About</a>
                            <a href="#">Our Partners</a>
                            <span class="breadcrumb_last" aria-current="page">Richter Spielgeräte</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
        	<div class="flex-container wrap content-wrapper">
                <div class="ctent-column">
                    <div class="heading-34">Children learn through play</div>
                    <p>Urbania is the Australian partner and authorised installer of the acclaimed playground creator Richter Spielgeräte. Crafted by hand from sustainably sourced timber in Germany, their extraordinary playscapes encourage exploration and ignite the imagination.</p>

                    <p>Unlike playgrounds of old, Richter Spielgeräte embraces the natural ageing and character of natural materials like timber. So they never use lacquers or un-natural coatings, which can be damaging to the natural environment. </p>

                    <p>Chances are you’ve probably seen Richter play equipment without even realising it. They’re literally everywhere, including indoor shopping malls, garden centres, museums, holiday parks and even zoos. </p>
                    <p>Perfectly suited to the vagaries of the Australian climate, all their equipment is manufactured to meet or even exceed the relevant Australian playground standards.</p>

                    <a href="#" class="button button-theme"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
                </div>  
                <div class="img-column sticky">
                    <img src="assets/images/image-04.jpg" alt="image-04" title="" width="1135" height="670">

                    <img src="assets/images/svg/richter-schnecke.svg" alt="richter-schnecke" title="" width="166" height="166" class="partner-logo">
                </div>  
            </div>
          
        </div>
    </section>

    <section class="gallery-sec mb-100">
        <div class="container">
            <ul class="gallery-grid">
                <li>
                    <a href="assets/images/gallery-01.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-01.jpg" alt="gallery-01" title="" width="550"
                                height="366">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-02.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-02.jpg" alt="gallery-02" title="" width="550"
                                height="550">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-03.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-03.jpg" alt="gallery-03" title="" width="550"
                                height="366">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-04.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-04.jpg" alt="gallery-04" title="" width="550"
                                height="825">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-05.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-05.jpg" alt="gallery-05" title="" width="550"
                                height="366">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-06.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-06.jpg" alt="gallery-06" title="" width="550"
                                height="440">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-07.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-07.jpg" alt="gallery-07" title="" width="550"
                                height="366">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-08.jpg" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">
                        <img src="assets/images/gallery-08.jpg" alt="gallery-08" title="" width="550"
                                height="366">
                    </a>
                </li>
            </ul>

            <div class="text-center">
                <a href="#" class="button button-black-border">Load More</a>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div>


    <section class="project-sec mb-100">
        <div class="container">
            <div class="heading-44">Richter Projects</div>

            <ul class="project-ul project-grid">
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-01.jpg" alt="project" title=""
                                    width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Wonguim Wilam Playspace</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Rural Village</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-02.jpg"
                                    alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Maritime Cove</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-03.jpg"
                                    alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Moreland & Coburg Station</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Playspaces</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-04.jpg"
                                    alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Diamond Creek Regional Playspace</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">NSW</a></li>
                                    <li><a href="#">Playspace</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-05.jpg"
                                    alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Royal Park Nature Playground</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>

                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-06.jpg"
                                    alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Whittlesea Public Gardens</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">NSW</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
            </ul>

            <div class="text-center">
                <a href="#" class="button button-black-border">Load More Projects</a>
            </div>
        </div>
    </section>


    <div class="container">
        <div class="divider"></div>
    </div>

    <?php block('instagram');?>

</main>
<?php get_footer();