 <!-- call action -->
    <section class="sec-callaction mb-100">
        <img src="assets/images/contact-call-action-image.jpg" alt="contact-call-action-image" title="" width="1920"
            height="600" class="bgimg">
        <div class="container">
            <div class="callact-wrap">
                <div class="heading-44 text-white mb-10">Contact Our Play Space & Landscape Experts Today</div>
                <div class="callact-content">Let us bring your play spaces, streetscapes, and landscapes to life with
                    innovative, sustainable design.</div>
                <div class="btnlist">
                    <a href="#" class="button button-white-broder" tabindex="-1">View Projects</a>
                    <a href="#" class="button button-white" tabindex="-1">Get in Touch</a>
                </div>
            </div>
        </div>
    </section>