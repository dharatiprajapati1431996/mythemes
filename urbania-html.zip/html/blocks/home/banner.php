<!-- banner section start -->
<section class="sec-hmbanner">
    <ul class="js-hmbanner">
        <li>
            <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-desk" width="1920" height="900">
            <img src="assets/images/mobile-banner.png" alt="banner-image" class="ban-mob" width="768" height="768">
            <div class="ol-hmbanner">
                <div class="container">
                    <div class="olhmban-wrap">
                        <div class="olhmshape">
                            <div class="olhmban-title">Fun Playgrounds & Beautiful Landscapes</div>
                            <div class="olhm-content">
                                <p>Creating safe, inspiring spaces that bring communities together.</p>
                            </div>
                            <div class="btn-row">
                                <a href="#" class="button button-white-broder">View Projects</a>
                                <a href="#" class="button button-white">Get in Touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        <li>
            <img src="assets/images/banner-image1.jpg" alt="banner-image" class="ban-desk" width="1920" height="900">
            <img src="assets/images/mobile-banner-02.png" alt="banner-image" class="ban-mob" width="768" height="768">
            <div class="ol-hmbanner">
                <div class="container">
                    <div class="olhmban-wrap">
                        <div class="olhmshape">
                            <div class="olhmban-title">Fun Playgrounds & Beautiful Landscapes</div>
                            <div class="olhm-content">
                                <p>Creating safe, inspiring spaces that bring communities together.</p>
                            </div>
                            <div class="btn-row">
                                <a href="#" class="button button-white-broder">View Projects</a>
                                <a href="#" class="button button-white">Get in Touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
         <li>
            <img src="assets/images/banner-image2.jpg" alt="banner-image" class="ban-desk" width="1920" height="900">
            <img src="assets/images/mobile-banner-03.png" alt="banner-image" class="ban-mob" width="768" height="768">
            <div class="ol-hmbanner">
                <div class="container">
                    <div class="olhmban-wrap">
                        <div class="olhmshape">
                            <div class="olhmban-title">Fun Playgrounds & Beautiful Landscapes</div>
                            <div class="olhm-content">
                                <p>Creating safe, inspiring spaces that bring communities together.</p>
                            </div>
                            <div class="btn-row">
                                <a href="#" class="button button-white-broder">View Projects</a>
                                <a href="#" class="button button-white">Get in Touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        <li>
            <img src="assets/images/banner-image3.jpg" alt="banner-image" class="ban-desk" width="1920" height="900">
            <img src="assets/images/mobile-banner-04.png" alt="banner-image" class="ban-mob" width="768" height="768">
            <div class="ol-hmbanner">
                <div class="container">
                    <div class="olhmban-wrap">
                        <div class="olhmshape">
                            <div class="olhmban-title">Fun Playgrounds & Beautiful Landscapes</div>
                            <div class="olhm-content">
                                <p>Creating safe, inspiring spaces that bring communities together.</p>
                            </div>
                            <div class="btn-row">
                                <a href="#" class="button button-white-broder">View Projects</a>
                                <a href="#" class="button button-white">Get in Touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    </ul>
</section>
<!-- banner section end -->