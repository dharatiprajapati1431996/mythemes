<section class="keyfactor-sec mb-60">
	<div class="container">
		<ul class="keyfact-grid keyfator-slider">
			<li>
				<div class="keyfact-box">
					<div class="keyfactor-icon">
						<img src="assets/images/svg/proven-knowledge-icon.svg" alt="proven-knowledge-icon" title="" width="51" height="52">
					</div>
					<div class="key-label">Proven Knowledge</div>
				</div>
			</li>
			<li>
				<div class="keyfact-box">
					<div class="keyfactor-icon">
						<img src="assets/images/svg/safety-first-icon.svg" alt="safety-first-icon" title="" width="51" height="52">
					</div>
					<div class="key-label">Safety First</div>
				</div>
			</li>
			<li>
				<div class="keyfact-box">
					<div class="keyfactor-icon">
						<img src="assets/images/svg/inclusive-design-icon.svg" alt="inclusive-design-icon" title="" width="51" height="52">
					</div>
					<div class="key-label">Inclusive Design</div>
				</div>
			</li>
			<li>
				<div class="keyfact-box">
					<div class="keyfactor-icon">
						<img src="assets/images/svg/quality-materials-icon.svg" alt="quality-materials-icon" title="" width="51" height="52">
					</div>
					<div class="key-label">Quality Materials</div>
				</div>
			</li>
			<li>
				<div class="keyfact-box">
					<div class="keyfactor-icon">
						<img src="assets/images/svg/service-icon.svg" alt="service-icon" title="" width="51" height="52">
					</div>
					<div class="key-label">Complete Services</div>
				</div>
			</li>
			<li>
				<div class="keyfact-box">
					<div class="keyfactor-icon">
						<img src="assets/images/svg/warranty-icon.svg" alt="warranty-icon" title="" width="51" height="52">
					</div>
					<div class="key-label">20-Year Warranty</div>
				</div>
			</li>
		</ul>
	</div>
</section>