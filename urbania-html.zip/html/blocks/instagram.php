 <!-- instagram section -->
	   <section class="sec-instagram mb-100">
					 <div class="container">
								 <div class="heading-34"><i class="fa fa-instagram" aria-hidden="true"></i>Follow Urbania, See our projects come to life.</div>
							
							<div class="insta-wrap">
							 	<img src="assets/images/instagram-image.jpg" alt="instagram image" title="" width="1720" height="342">
							</div>
							
							 <div class="text-center">
								   <a class="top-alink button button-black-border" href="#">@urbania_au</a>
							 </div>
							
					 </div>
	   </section>