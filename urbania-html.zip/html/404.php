<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper errorpg">

        <!-- Inner Banner Section -->
    <section class="breadcums-banner">
        <div class="banner-image">
            <img src="assets/images/contact-banner.jpg" alt="contact-inner" title="" width="1920" height="480" class="bgimg">

            <div class="container">
                <div class="banner-content">
                    <div class="heading-44">404</div>
                    <p>Reach out to our team for support, project guidance, or general inquiries.</p>
                </div>

            </div>
        </div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">404</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->



    <section class="inpage ">
        <div class="container">

            <div class="flex-container thank_you_content wrap mb-100">
                <div class="error-left">
                    <div class="heading-34">Oops! Page Not Found.</div>
                    <p>It looks like the page you're looking for doesn't exist.
                        But don't worry, we're here to help you find your way!</p>

                    <p>You can:</p>
                    <ul>
                        <li><a href="#">Return to the homepage</a> and explore from there.</li>
                        <li><a href="#">Check out our Products</a></li>
                        <li><a href="#">Contact us</a> if you need assistance.</li>
                    </ul>

                </div>
                <div class="error-right">
                    <img src="assets/images/404.png" alt="404" title="" width="504" height="504">
                </div>
            </div>

            <div class="divider"></div>

        </div>
    </section>

    <?php block('instagram'); ?>


</main>
<?php get_footer();