<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper blog-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/blog-banner.jpg" alt="blog-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Proud Winners of 2025 National AILA Awards</div>
    				<p>Explore expert insights and stories shaping the future of play and urban spaces.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Resources</a>
                            <a href="#">Blog</a>
                            <span class="breadcrumb_last" aria-current="page">Proud Winners of 2025 National AILA Awards</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
        	<div class="article-inner-wrapper mb-100">
                <img src="assets/images/national-aila-award.jpg" alt="national-aila-award" title="" width="1200" height="700"> 

                <div class="heading-22">GLAS Landscape Architects</div>

                <p>NATIONAL AWARD WINNERS: 2025 AILA National Landscape Architecture Awards GLAS is honoured to have received two National Landscape Architecture Awards at the 2025 Australian Institute of Landscape Architects (AILA) National Awards.</p>

                <p>Community Contribution – Landscape Architecture Award for Tiny Patches</p>

                <div class="heading-22">Jury Citation:</div>

                <p>Tiny Patches is a small yet powerful project that demonstrates how no intervention is too modest to spark meaningful change. This creative and provocative project drew on research to call for a reimagining of urban landscapes in the face of biodiversityloss. The playful and provocative exhibition challenged conventional design thinking and called for urban landscapes – even those in highly developed contexts – to be reshaped with biodiversity and community life in mind. The jury commends the project for its First Nations leadership, creativity, beauty and message, noting how it pushes the boundaries of landscape architecture while inspiring us to see value in even the smallest contributions.</p>

                <div class="heading-18">Project team and collaborators:</div>

                <p>Project team and collaborators:<br>
                    Photographer, Drew Echberg<br>
                    Ecologist, Dr Amy Hahs<br>
                    Ecologist, Dr Luis Mata </p>

                <p>Climate Positive Design - Landscape Architecture Award for Michelle Guglielmo Park</p>


                <div class="image-column">
                    <div class="img-col">
                        <img src="assets/images/article-image-10.jpg" alt="article" title="" width="580" height="540">
                    </div>
                    <div class="img-col">
                        <img src="assets/images/article-image-11.jpg" alt="article" title="" width="580" height="540">
                    </div>
                </div>

                <div class="heading-22">Jury citation:</div>
                <p>This project exemplifies the prioritisation of environmental and social sustainability in landscape architecture projects, no matter the size. While a relatively small space, the careful use of salvaged and local materials, integrated WSUD, maximised soil volumes, and species selections enhance the environmental resilience of the place. Embedded artworks and space for community video projections make this a place for social gathering and celebration of local artists. The design team have thoughtfully crafted a place of vegetated refuge for the community in a highly urbanised neighbourhood.</p>

                <p>Merri-bek City Council</p>
                <div class="heading-18">Project team and collaborators:</div>
                <p>Merri-bek City Council <br>
                    Marcus Construction <br>
                    OPS Engineers (Civil) <br>
                    Arup (Lighting)</p>

                <p>A heartfelt thank you to our amazing client Angelica Kerama and Joanna Bush at Merri-bek City Council, and everyone involved in bringing these projects to life, and congratulations to all 37 national winners across 16 categories!</p>
            </div>

            <div class="divider"></div>

            <div class="related-ariticle">
                <div class="heading-44 text-center">Related Blog</div>

                <ul class="article-ul article-slider">
                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-1.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">A Creative Playspace Inspired by Aussie Farm Life</div>
                                    <div class="article-description">
                                        <p>From a farmhouse tower to a magical slide inspired by an Aussie grain silo, the
                                            playspace we created for The Vineyard has been a huge hit with families, as
                                            you’ll see in this joy capturing video. </p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-2.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">Why Every Community Needs a Quality Playground Space</div>
                                    <div class="article-description">
                                        <p>According to Early Childhood Australia, pre-school kids should be spending at
                                            least 80 mins a day in physical activities like, running, jumping & climbing...
                                        </p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-3.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">Bringing Children Back to Nature Through Playful Spaces</div>
                                    <div class="article-description">
                                        <p>Children are spending more time than ever in front of screens. While technology
                                            has its benefits, the importance of unplugging and heading outdoors cannot be
                                            overstated.</p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-4.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">Key Attractions at Dorothea Dix Park Playground</div>
                                    <div class="article-description">
                                        <p>Vier mehrstöckige Klettertürme, ein großzügiger Wasserspielbereich mit einem Mühlenhaus, ein einzigartiges Sinneslabyrinth und eine 27 Meter lange Schaukel zählen zu den Hauptattraktionen.</p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-5.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">Proud Winners of 2025 National AILA Awards</div>
                                    <div class="article-description">
                                        <p>NATIONAL AWARD WINNERS: 2025 AILA National LandscapeArchitecture Awards GLAS is honoured to have received two National Landscape Architecture Awards at the 2025 Australian.
                                        </p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>
                    
                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-6.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">Brighton High’s Popular New Climbslide Feature</div>
                                    <div class="article-description">
                                        <p>The moveart Climbslide installed at the new Brighton High in Tasmania has become a magnet for students looking to gather, chat and catch up during lunch break. It's one of the highlights of an awarding.</p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-7.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">Award Recognition for GLAS Landscape Architects</div>
                                    <div class="article-description">
                                        <p>Congratulations to GLAS Landscape Architects on their Climate Positive Design – Landscape Architecture Award for Michelle Guglielmo Park!</p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-8.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">Landscaping Highlights at Michelle Guglielmo Park</div>
                                    <div class="article-description">
                                        <p>This ODS article has a great overview of the Michelle Guglielmo community space, that Urbania did the landscaping for. We installed large areas of timber decking, gorgeous natural stone pathways.</p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>
                    
                    <li>
                        <a href="#">
                            <div class="article-li">
                                <div class="article-img">
                                    <img src="assets/images/article-image-9.jpg" alt="article-image" title="" width="540"
                                        height="320">
                                </div>
                                <div class="article-box">
                                    <div class="article-title">A Cinematic Transformation at Burnie Art Center</div>
                                    <div class="article-description">
                                        <p>Imagine if our Canopees were part of a movie set… That’s exactly the vibe BURNIE CITY COUNCIL created with their recently installed Canopees, as part of the renovation of Burnie’s Art Center.</p>
                                    </div>
                                    <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                            alt="green-arrow" title="" width="25" height="15"></div>
                                </div>
                            </div>
                        </a>
                    </li>
                </ul>

            </div>

        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div>

    <?php block('instagram');?>

</main>
<?php get_footer();