<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper landscape-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/landscape-banner.jpg" alt="landscape-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Landscape</div>
    				<p>Creating meaningful outdoor environments that blend natural beauty with functional design.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Capabilities</a>
                            <span class="breadcrumb_last" aria-current="page">Landscape</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage content-wrapper mb-100">
        <div class="container">
           
           <div class="flex-container wrap mb-100">
               <div class="column-left">
                   <div class="heading-44">Specialists in landscape thinking and doing.</div>
                   <p>With a strong foundation in making and building, Urbania brings a smart, cost-conscious approach to every landscaping project. Our highly experienced team knows how to shape spaces that work and deliver them on time and budget. </p>

                   <p>Whether it's transforming a blank canvas or reimagining an existing site, we bring creativity and technical expertise to every project. From large-scale public landscapes to intimate green spaces, we have a deep respect for the natural environment. </p>

                   <a href="#" class="button button-theme"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>

               </div>
               <div class="column-right sticky">
                   <div class="vedio-wrap">
                       <div class="vedio-col">
                           <a href="assets/images/sample-video.mp4" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">

                            <div class="watch-wrap"><span class="play-button"><img src="assets/images/svg/play-button.svg"
                                        alt="Play Button" title="" width="46" height="46"> </span> Michelle Guglielmo Park</div>

                            <img src="assets/images/michelle-guglielmo.jpg" alt="michelle-guglielmo" title="" width="500"
                                height="410">
                        </a>
                       </div>
                       <div class="vedio-col">
                           <a href="assets/images/sample-video.mp4" class="fancybox" rel="group" data-fancybox="group"
                            tabindex="0">

                            <div class="watch-wrap"><span class="play-button"><img src="assets/images/svg/play-button.svg"
                                        alt="Play Button" title="" width="46" height="46"> </span> Templestowe Memorial Reserve</div>

                            <img src="assets/images/templestowe-memorial.jpg" alt="templestowe-memorial" title="" width="500"
                                height="410">
                        </a>
                       </div>
                   </div>
               </div>
           </div>

            <div class="divider"></div>

            <div class="flex-container wrap mb-100 inner-faq-wrapper">
                <div class="column-left">
                    <img src="assets/images/play-ground.jpg" alt="play-ground" title="" width="670" height="810" class="radius-right">
                </div>
                <div class="column-right">
                    <div class="heading-34">Our Landscaping & Construction Services.</div>

                    <div class="faq_accordion smk_accordion acc_with_icon">
                        <div class="accordion_in">
                            <div class="acc_head">Playgrounds & Playspaces </div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Landscaping Solutions</div>
                            <div class="acc_content">
                                <ul>
                                    <li>Full end-to-end landscaping packages</li>
                                    <li>Softscaping: gardens, turf, and planting </li>
                                    <li>Hardscaping: paving, retaining walls, and concreting</li>
                                </ul>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Decks & Boardwalks</div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Recreation & Sports Facilities</div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Streetscapes & Public Precincts</div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Shelters & Shade Structures</div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Custom Metal Fabrication</div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Comprehensive Project Delivery</div>
                            <div class="acc_content">
                                <p>This is dummy text, we use it at Supple during web designing in case we don't have contentfor new NON SEO pages and it is changed during development of the new site.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="recent-project-wrapper">
                <div class="heading-44">Some of our recent landscaping projects.</div>

                <ul class="project-ul project-grid">
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-08.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Michelle Guglielmo Park</div>
                                    <ul class="project-location">
                                        <li><a href="#" class="theme-box">VIC</a></li>
                                        <li><a href="#">Landscape</a></li>
                                    </ul>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-10.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Templestowe Memorial Reserve</div>
                                    <ul class="project-location">
                                        <li><a href="#" class="theme-box">NSW</a></li>
                                        <li><a href="#">Garden</a></li>
                                    </ul>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="project-li">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project-11.jpg" alt="project" title="" width="550" height="360"></a>
                            </div>
                            <div class="project-bottom">
                                <div class="pr-left">
                                    <div class="project-title">Dickens Street Activation</div>
                                    <ul class="project-location">
                                        <li><a href="#" class="theme-box">VIC</a></li>
                                        <li><a href="#">Street</a></li>
                                    </ul>
                                </div>
                                <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div> 


    <?php block('instagram');?>

</main>
<?php get_footer();