<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper projects-detail-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/project-detail-banner.jpg" alt="project-detail-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">The Vineyard Farmhouse</div>
    				<p>Experience timeless farmhouse design inspired by vineyard landscapes and natural textures.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Projects</a>
                            <span class="breadcrumb_last" aria-current="page">The Vineyard Farmhouse</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage content-wrapper">
        <div class="container">
            <div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                     <div class="heading-34">The Vineyard: A Vibrant Destination with a Bespoke Playspace</div>

                    <p>Nestled in Vineyard, a rapidly growing outer suburb northwest of Sydney, lies a destination that celebrates the area’s rich viticultural heritage. Spanning an impressive eight-hectare site, The Vineyard, reimagined by Zenith Hotels, has become a beloved family-friendly hospitality hub, inviting guests to relax, connect, and create cherished memories.</p>

                    <p>The Vineyard offers an array of experiences to delight every visitor. Savor a delicious meal in the warm and inviting bistro, enjoy a refreshing drink at the indoor or outdoor bars, or unwind in the lush beer garden, perfect for leisurely afternoons. </p>

                    <p>The standout feature of the venue is the Vineyard Farmhouse, a bespoke playspace brought to life through a collaborative effort between Urbania, esteemed landscape architect Studio Geogouras, and trusted partners in play, Richter Spielgeräte. This carefully designed and constructed play area features Richter Spielgeräte equipment, tailored to engage children of various ages and abilities. </p>

                    <p>The space fosters creativity, exploration, and joy, offering a safe and inclusive environment where families can bond and make memories. The Vineyard Farmhouse showcases innovative design and community focus, making The Vineyard not just a destination, but a place where laughter and connection flourish.</p>
                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image3.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>


            <div class="flex-container wrap justify-content-between ctent-block-wr">
                <div class="ctent-block">
                    <div class="heading-34">Crafted Design and Materials</div>

                    <p>Drawing from the storied winemaking traditions of the Vineyard region, the Vineyard Farmhouse playspace is a bespoke creation by Urbania, designed in close partnership with Studio Geogouras and brought to life with Richter Spielgeräte’s expertise. Studio Geogouras envisioned a space that echoes the area’s viticultural past, incorporating red Viroc cladding to reflect the deep, grape-stained hues of wine barrels and subtle red soft-fall surfaces to nod to this heritage. Constructed with Richter Spielgeräte’s signature Larch Timber, the playspace harmonises with its natural surroundings, emphasising sustainability. </p>

                    <p>The main Vineyard Farmhouse reaches over 10 meters in height, and is home to a sleek stainless steel tunnel slide create an engaging and dynamic environment, all  built to meet Australian safety standards for play.</p>

                    <a href="#" class="button button-theme">Materials - Larch</a>

                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image4.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>

            <div class="flex-container wrap justify-content-between ctent-block-wr flex-row-reverse">
                <div class="ctent-block">
                     <div class="heading-34">Vineyard Farmhouse: Engaging Play Equipment</div>

                    <p>The bespoke Vineyard Farmhouse playspace captivates children with an array of thoughtfully designed equipment, blending endless fun with nods to the region’s winemaking heritage. </p>

                    <p>At its heart, the Vineyard Barn Tower rises with multiple levels for exploration, complemented by a striking Hexagonal Spiral Tower and a stainless steel connection tunnel linked by a net bridge. Custom wine barrel-inspired features, adorned with red Modinex Viroc cladding featuring laser-cut wording, evoke the essence of vineyard life, while a small timber tractor and play tables spark imaginative role-play.  </p>

                    <p>A standout stainless steel tunnel slide, reminiscent of an Aussie grain silo, delivers thrilling descents, and the Kling Klang sensory musical element adds a delightful sensory experience. A drawing board encourages creative expression, ensuring age-appropriate challenges for younger visitors and more adventurous pursuits for older children. Installed with precision using a 100-tonne crane, this playspace offers a dynamic, inclusive environment that sparks joy and curiosity.</p>
                </div>
                <div class="ctent-img">
                    <img src="assets/images/content-image5.jpg" alt="content image" title="" width="860" height="600">
                </div>
            </div>


            <div class="contributors-wrapper mb-100">
                <div class="logo-block">
                    <img src="assets/images/urbania-image.png" alt="urbania" title="" width="" height="">
                </div>
                <div class="contribut-right">
                    <ul class="contribut-list">
                        <li>
                            <div class="contbox">
                                <div class="label">Richter Spielgeräte</div>
                                <p>Play Equipment Design and Supply</p>
                            </div>
                        </li>
                        <li>
                            <div class="contbox">
                                <div class="label">Studio Georgouras</div>
                                <p>Landscape Architect</p>
                            </div>
                        </li>
                        <li>
                            <div class="contbox">
                                <p>Zenith Hotels</p>
                               <p><span class="label">Modinex</span> - Viroc Cladding Supply</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>



            <ul class="gallery-grid">
                <li>
                    <a href="assets/images/gallery-09.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                        <img src="assets/images/gallery-09.jpg" alt="gallery Image" title="" width="550" height="825">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-10.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                        <img src="assets/images/gallery-10.jpg" alt="gallery Image" title="" width="550" height="825">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-11.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                        <img src="assets/images/gallery-11.jpg" alt="gallery Image" title="" width="550" height="977">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-12.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                        <img src="assets/images/gallery-12.jpg" alt="gallery Image" title="" width="550" height="825">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-13.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                        <img src="assets/images/gallery-13.jpg" alt="gallery Image" title="" width="550" height="825">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-14.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                        <img src="assets/images/gallery-14.jpg" alt="gallery Image" title="" width="550" height="825">
                    </a>
                </li>
                <li>
                    <a href="assets/images/gallery-15.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                        <img src="assets/images/gallery-15.jpg" alt="gallery Image" title="" width="550" height="291">
                    </a>
                </li>
                
            </ul>

            <div class="divider"></div>
        </div>
    </section>



    <section class="related-project-sec mb-100">
        <div class="container">
            <div class="heading-44">Related Projects</div>

            <ul class="project-ul project-grid">
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-01.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Wonguim Wilam Playspace</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Rural Village</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-02.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Maritime Cove</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Landscape</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="project-li">
                        <div class="project-img">
                            <a href="#"><img src="assets/images/project-03.jpg" alt="project" title="" width="550" height="360"></a>
                        </div>
                        <div class="project-bottom">
                            <div class="pr-left">
                                <div class="project-title">Moreland &amp; Coburg Station</div>
                                <ul class="project-location">
                                    <li><a href="#" class="theme-box">VIC</a></li>
                                    <li><a href="#">Playspaces</a></li>
                                </ul>
                            </div>
                            <a class="pr-view" href="#">View Project<img src="assets/images/svg/arrow-green.svg"></a>
                        </div>
                    </div>
                </li>
            </ul>

            <div class="text-center">
                <a href="#" class="button button-black-border">Explore All Projects</a>
            </div>
        </div>
    </section>


    <div class="container">
        <div class="divider"></div>
    </div>

    <?php block('instagram');?>

</main>
<?php get_footer();