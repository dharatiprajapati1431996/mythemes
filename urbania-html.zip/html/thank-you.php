<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper thank_youpg ">


    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
        <div class="banner-image">
            <img src="assets/images/contact-banner.jpg" alt="contact-inner" title="" width="1920" height="480" class="bgimg">

            <div class="container">
                <div class="banner-content">
                    <div class="heading-44">Thank You</div>
                    <p>Reach out to our team for support, project guidance, or general inquiries.</p>
                </div>

            </div>
        </div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Thank You</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage ">
        <div class="container">

            <div class="flex-container thank_you_content wrap mb-100">
                <div class="error-left">
                    <div class="heading-34">We’ve Received Your Inquiry!</div>
                    <p>Thank you for getting in touch with Urbania. Your message has been successfully submitted, and
                        one of our team members will contact you shortly to assist with your organisation create amazing outdoor spaces and places.</p>

                    <p>In the meantime, you can explore more from Topware:</p>
                    <ul>
                        <li><a href="#">Visit Our Dedicated Bathroom Showroom </a></li>
                        <li><a href="#">Shop Bathroom Products Online </a></li>
                        <li><a href="#">Explore Premium Brands & Latest Collections </a></li>
                    </ul>

                    <p>If your enquiry is urgent, please call us at <a href="tel:1300 920 439">1300 920 439</a> for
                        immediate support.</p>
                </div>
                <div class="error-right">
                    <img src="assets/images/thankyou.png" alt="404" title="" width="504" height="504">
                </div>
            </div>

            <div class="divider"></div>

        </div>
    </section>

    <?php block('instagram'); ?>

</main>
<?php get_footer();