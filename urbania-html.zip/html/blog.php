<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper blog-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/blog-banner.jpg" alt="blog-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Latest Blog</div>
    				<p>Explore expert insights and stories shaping the future of play and urban spaces.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <a href="#">Resources</a>
                            <span class="breadcrumb_last" aria-current="page">Blog</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
        	<ul class="article-ul">
                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-1.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">A Creative Playspace Inspired by Aussie Farm Life</div>
                                <div class="article-description">
                                    <p>From a farmhouse tower to a magical slide inspired by an Aussie grain silo, the
                                        playspace we created for The Vineyard has been a huge hit with families, as
                                        you’ll see in this joy capturing video. </p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-2.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Why Every Community Needs a Quality Playground Space</div>
                                <div class="article-description">
                                    <p>According to Early Childhood Australia, pre-school kids should be spending at
                                        least 80 mins a day in physical activities like, running, jumping & climbing...
                                    </p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-3.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Bringing Children Back to Nature Through Playful Spaces</div>
                                <div class="article-description">
                                    <p>Children are spending more time than ever in front of screens. While technology
                                        has its benefits, the importance of unplugging and heading outdoors cannot be
                                        overstated.</p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-4.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Key Attractions at Dorothea Dix Park Playground</div>
                                <div class="article-description">
                                    <p>Vier mehrstöckige Klettertürme, ein großzügiger Wasserspielbereich mit einem Mühlenhaus, ein einzigartiges Sinneslabyrinth und eine 27 Meter lange Schaukel zählen zu den Hauptattraktionen.</p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-5.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Proud Winners of 2025 National AILA Awards</div>
                                <div class="article-description">
                                    <p>NATIONAL AWARD WINNERS: 2025 AILA National LandscapeArchitecture Awards GLAS is honoured to have received two National Landscape Architecture Awards at the 2025 Australian.
                                    </p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>
                
                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-6.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Brighton High’s Popular New Climbslide Feature</div>
                                <div class="article-description">
                                    <p>The moveart Climbslide installed at the new Brighton High in Tasmania has become a magnet for students looking to gather, chat and catch up during lunch break. It's one of the highlights of an awarding.</p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-7.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Award Recognition for GLAS Landscape Architects</div>
                                <div class="article-description">
                                    <p>Congratulations to GLAS Landscape Architects on their Climate Positive Design – Landscape Architecture Award for Michelle Guglielmo Park!</p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-8.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">Landscaping Highlights at Michelle Guglielmo Park</div>
                                <div class="article-description">
                                    <p>This ODS article has a great overview of the Michelle Guglielmo community space, that Urbania did the landscaping for. We installed large areas of timber decking, gorgeous natural stone pathways.</p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>
                
                <li>
                    <a href="#">
                        <div class="article-li">
                            <div class="article-img">
                                <img src="assets/images/article-image-9.jpg" alt="article-image" title="" width="540"
                                    height="320">
                            </div>
                            <div class="article-box">
                                <div class="article-title">A Cinematic Transformation at Burnie Art Center</div>
                                <div class="article-description">
                                    <p>Imagine if our Canopees were part of a movie set… That’s exactly the vibe BURNIE CITY COUNCIL created with their recently installed Canopees, as part of the renovation of Burnie’s Art Center.</p>
                                </div>
                                <div class="readmore">Read More<img src="assets/images/svg/arrow-green.svg"
                                        alt="green-arrow" title="" width="25" height="15"></div>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>

            <div class="text-center"><a href="#" class="button button-black-border">Load More Articles</a></div>

        </div>
    </section>

    <div class="container">
        <div class="divider"></div>
    </div>


    <?php block('instagram');?>
</main>
<?php get_footer();