<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper catalogues-page">

    <!-- Inner Banner Section -->
    <section class="breadcums-banner">
    	<div class="banner-image">
    		<img src="assets/images/catalogues-banner.jpg" alt="catalogues-banner" title="" width="1920" height="480" class="bgimg">

    		<div class="container">
    			<div class="banner-content">
    				<div class="heading-44">Catalogues</div>
    				<p>Browse our catalogues for detailed product information, design ideas, and specifications.</p>
    			</div>
    		</div>
    	</div>
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="home.php">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Catalogues</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100">
        <div class="container">
        	<div class="center-intro text-center mb-50">
                <div class="heading-44">Interested in what we do? We’d love to hear from you.</div>
                <p>Enter your details below and we will email a product catalogue across to you.</p>
            </div>

            <div class="catalogues-grid">
                <div class="grid-item">
                    <div class="catalog-box">
                        <div class="catalog-img">
                            <img src="assets/images/richter-spielgeräte-gmbH.png" alt="richter-spielgeräte-gmbH" title="" width="" height="">
                        </div>
                        <div class="catalog-info">
                            <div class="heading-18">Richter Spielgeräte GmbH</div>
                            <a href="#" class="alink"><img src="assets/images/svg/download.svg" alt="download" title="" width="" height=""> Download Now</a>
                        </div>
                    </div>
                </div>

                <div class="grid-item">
                    <div class="catalog-box">
                        <div class="catalog-img">
                            <img src="assets/images/awaken-the-personality-of your-space.png" alt="awaken-the-personality-of your-space" title="" width="" height="">
                        </div>
                        <div class="catalog-info">
                            <div class="heading-18">Awaken the personality of your space</div>
                            <a href="#" class="alink"><img src="assets/images/svg/download.svg" alt="download" title="" width="" height=""> Download Now</a>
                        </div>
                    </div>
                </div>

                <div class="grid-item">
                    <div class="catalog-box">
                        <div class="catalog-img">
                            <img src="assets/images/durbanis-inout.png" alt="durbanis" title="" width="" height="">
                        </div>
                        <div class="catalog-info">
                            <div class="heading-18">Durbanis</div>
                            <a href="#" class="alink"><img src="assets/images/svg/download.svg" alt="download" title="" width="" height=""> Download Now</a>
                        </div>
                    </div>
                </div>


                <div class="grid-item">
                    <div class="catalog-box">
                        <div class="catalog-img">
                            <img src="assets/images/durbanis.png" alt="durbanis" title="" width="" height="">
                        </div>
                        <div class="catalog-info">
                            <div class="heading-18">Durbanis</div>
                            <a href="#" class="alink"><img src="assets/images/svg/download.svg" alt="download" title="" width="" height=""> Download Now</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <div class="container">
        <div class="divider"></div>
    </div>



    <?php block('instagram');?>

</main>
<?php get_footer();