<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0, maximum-scale=5.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="icon" href="assets/images/favicon-icon" type="image/x-icon">
  <title>Urbania | Innovative Playspaces &amp; Urban Design Australia</title> <?php wp_head(); ?>
 </head>
 <body>
  <!-- Header -->
  <header class="mainheader">
   <a class="togglebtn">
    <span></span>
   </a>
   <div class="overlay"></div>
   <div class="middleheader">
    <div class="container">
     <div class="middleheader-wrap">
      <div class="logo">
       <a href="home.php">
        <img src="assets/images/urbania-logo.svg" alt="urbania-logo" title="" width="233" height="46">
       </a>
      </div>

      <div class="hd-middle">
       <div class="menu-link">
        <nav>
         <ul>
          <li>
           <a href="#">Home</a>
          </li>
										
          <li class="has-sub service-dropdown">
           <a href="#">Capabilities</a>
            <div class="sub-menu megamenu">
							<div class="megamenu-wrap">
								<ul class="sublink  menu-level1">
										<li class="menu-item-hover has-sub">
											<a href="#">Landscape</a>
												<div class="sub-menu menu-level2">
													  <ul class="sublink-ul">
																	 <li><a href="#">Michelle Guglielmo Park</a></li>
                                   <li><a href="#">Templestowe Memorial Reserve</a></li>
                                   <li><a href="#">Dickens Street Activation</a></li>
													  </ul>
												</div>
										</li>
										<li class="has-sub">
												<a href="#">Playspaces</a>
													<div class="sub-menu menu-level2">
														<ul class="sublink-ul">
															<li><a href="#">Playground for Councils</a></li>
															<li><a href="#">Playground for Early Learning Centres</a></li>
															<li><a href="#">Playground for Property Developers</a></li>
															<li><a href="#">Playground for Schools</a></li>
															<li><a href="#">Accessible Playgrounds</a></li>
															<li><a href="#">Community Playgrounds</a></li>
															<li><a href="#">Nature Playgrounds</a></li>
														</ul>
													</div>
										</li>
                    <li><a href="#">Street Furniture</a></li>
								</ul>

								<div class="menu-right">
									<div class="menu-dropdown">
										<img src="assets/images/menu-image.jpg" alt="menu-image" title="" width="300" height="295" class="bgimg">
										<div class="menu-callaction">
												<div class="heading-24">Contact Our Expert Playground Designers to Start Today</div>
													<div class="btn-row">
                            <a href="#" class="button button-white-broder" tabindex="0">View Projects</a>
                            <a href="#" class="button button-white" tabindex="0"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
                          </div>
										</div>
									</div>
								</div>
                
							</div>
						</div>
          </li>
										
          <li>
           <a href="#">Projects</a>
          </li>
          <li class="has-sub">
           <a href="#">About</a>
							<div class="sub-menu">
									<ul class="sub-dropdown">
												<li><a href="#"> Our Partners</a></li>
									</ul>
							</div>
          </li>
          <li class="has-sub">
            <a href="#">Resources</a>
              <div class="sub-menu">
               <ul class="sub-dropdown">
                <li><a href="#">Blog</a></li>
               </ul>
              </div>
          </li>
										
          <li class="has-sub areamenu">
           <a href="#">Areas</a>
	            <div class="sub-menu megamenu">
								<ul class="sublink menu-level1">
									<div class="heading-34">Areas We Serve</div>
										<li class="menu-item-hover has-sub">
											<a href="#">Landscape Playground</a>
												<div class="sub-menu menu-level2">
													<div class="menu-tagline">Landscape Playground</div>
													 <ul class="sublink-ul">
															<li><a href="#">Landscape Playground Brisbane</a></li>
															<li><a href="#">Landscape Playground Hobart</a></li>
															<li><a href="#">Landscape Playground Melbourne</a></li>
															<li><a href="#">Landscape Playground Perth</a></li>
															<li><a href="#">Landscape Playground Sydney</a></li>
													</ul>
											 </div>
										</li>
										<li class="has-sub">
											<a href="#">Nature Playground</a>
												<div class="sub-menu menu-level2">
														 <div class="menu-tagline">Nature Playground</div>
														 <ul class="sublink-ul">
																<li><a href="#">Nature Playground Brisbane</a></li>
																<li><a href="#">Nature Playground Hobart</a></li>
																<li><a href="#">Nature Playground Melbourne</a></li>
																<li><a href="#">Nature Playground Perth</a></li>
																<li><a href="#">Nature Playground Sydney</a></li>
														</ul>
												</div>
										</li>
										<li class="has-sub">
											<a href="#">Playground Design</a>
											<div class="sub-menu menu-level2">
													 <div class="menu-tagline">Playground Design</div>
													 <ul class="sublink-ul">
															<li><a href="#">Playground Design Brisbane</a></li>
															<li><a href="#">Playground Design Hobart</a></li>
															<li><a href="#">Playground Design Melbourne</a></li>
															<li><a href="#">Playground Design Perth</a></li>
															<li><a href="#">Playground Design Sydney</a></li>
													</ul>
											</div>
										</li>
								</ul>
              </div> 
	         </li>
					<li><a href="#">Contact</a></li>
         </ul>
        </nav>
       </div>
      </div>

      <div class="hd-right search-header">
         <ul class="hdright-ul">
            <li><a href="#" class="search-mobile search-on-link"><div class="hd-searchicon"><img src="assets/images/svg/search-icon.svg" alt="search icon" title="" width="14" height="14"></div></a></li>
            <li>
              <a href="tel:1300920439">
                  <div class="call-detail">
                    <div class="cicon"><img src="assets/images/svg/call-icon.svg" alt="call-icon" title="" width="13" height="13"></div>
                    <div class="cdetail">
                       <span>Call us now</span>
                       <div class="call-number">1300 920 439</div>
                    </div>
                  </div>
              </a>
            </li>
            <li><a href="#get-in-touch" data-fancybox="" class="button button-white close-btn fancybox"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a>
            </li>
         </ul>

         <!-- Start Search Bar -->
         <div class="search-wrap search-show hidden">
          <div class="aws-container">
                                  <form class="aws-search-form aws-show-clear">
                                      <div class="aws-wrapper">
                                          <label class="aws-search-label" for="6560217296fcb">Search products,
                                              brands...</label>
                                          <input type="search" name="s" id="6560217296fcb" value="" class="aws-search-field" placeholder="Search products, brands..." autocomplete="off">
                                          <div class="aws-search-clear"> <span>×</span> </div>
                                          <div class="aws-loader"></div>
                                      </div>
                                      <div class="aws-search-btn aws-form-btn">
                                          <span class="aws-search-btn_icon">
                                              <svg xmlns="http://www.w3.org/2000/svg" width="17.858" height="17.847" viewBox="0 0 17.858 17.847">
                                                  <g id="Group_4194" data-name="Group 4194" transform="translate(1 1)">
                                                      <path id="Path_16" data-name="Path 16" d="M17.743,11.121A6.621,6.621,0,1,1,11.121,4.5,6.621,6.621,0,0,1,17.743,11.121Z" transform="translate(-4.5 -4.5)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                                                      <path id="Path_17" data-name="Path 17" d="M29.121,29.11l-4.146-4.135" transform="translate(-13.677 -13.677)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                                                  </g>
                                              </svg>
                                          </span>
                                      </div>
                                  </form>
          </div>
          <div class="search-icon ">
              <svg xmlns="http://www.w3.org/2000/svg" width="21.4" height="21.4" viewBox="0 0 21.4 21.4">
                  <g id="Icon_feather-search" data-name="Icon feather-search" transform="translate(1 1)">
                      <path id="Path_28" data-name="Path 28" d="M21.376,12.938A8.438,8.438,0,1,1,12.938,4.5,8.438,8.438,0,0,1,21.376,12.938Z" transform="translate(-4.5 -4.5)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                      <path id="Path_29" data-name="Path 29" d="M29.563,29.563l-4.588-4.588" transform="translate(-10.577 -10.577)" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                  </g>
              </svg>
          </div>
      </div>
      <!-- End Search Bar -->
      </div>

     </div>
    </div>
   </div>
  </header>
  <!-- Header -->


  <!-- Start Modal pop up -->
    <div id="get-in-touch">
        <div class="popup-body">
            <div class="pop-up-left">
                <div class="title">
                    <div class="heading-34">Download Booklet</div>
                </div>

                <div class="contact-details">
                    <div class="contact-wrap">
                        <div class="ft-text">
                            <img src="assets/images/svg/map.svg" alt="map" title="" width="" height=""> Head Office 11 Melrose Court, Tullamarine, VIC 3043
                        </div>
                    </div>
                    <div class="contact-wrap">
                        <a href="tel:1300 920 439" class="ft-text">
                            <img src="assets/images/svg/call.svg" alt="call" title="" width="" height=""> 1300 920 439
                        </a>
                    </div>
                    <div class="contact-wrap">
                        <a href="mailto:info@urbania.com.au" class="ft-text">
                            <img src="assets/images/svg/email.svg" alt="email" title="" width="" height=""> info@urbania.com.au
                        </a>
                    </div>
                </div>
                <ul class="follow-list">
	        		<li>
	        			<a href="#"><img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="" height=""> </a>
	        		</li>
	        		<li>
	        			<a href="#"><img src="assets/images/svg/instagram.svg" alt="instagram" title="" width="" height=""> </a>
	        		</li>
	        		<li>
	        			<a href="#"><img src="assets/images/svg/linkedin.svg" alt="linkedin" title="" width="" height=""> </a>
	        		</li>
	        	</ul>
            </div>
            <div class="pop-up-right">
                <div class="contact-form-box">
                    <form class="form-box">

						<div class="form-group">
							<label>Name*</label>
							<input type="text" class="form-control" placeholder="Enter your name">
						</div>
						<div class="form-group">
							<label>Company*</label>
							<input type="text" class="form-control" placeholder="Enter company name">
						</div>
						
						<div class="form-group">
							<label>Email*</label>
                            <input type="email" name="Phone" class="form-control" placeholder="example@gmail.com.au">
                        </div>
                        <div class="submitbtn">
							<input type="submit" class="button submitbtn button-black" value="Submit">
						</div>
                    </form>
                </div>
            </div>
        </div>
    </div>

  <!-- End Modal pop up -->