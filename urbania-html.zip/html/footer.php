<footer>
	<div class="footer-top-wrap">
		<div class="container">
			<!-- footer top -->
				<div class="footer-top">
							<div class="ft-top-wrap">
								<div class="ft-top-left">
									<div class="heading-26">Ready to Bring Your Imagination to Life?</div>
								</div>
								<div class="ft-top-right">
									<ul class="hdright-ul">
							            <li>
							              <a href="tel:1300920439">
							                  <div class="call-detail">
							                    <div class="cicon"><img src="assets/images/svg/call-icon.svg" alt="call-icon" title="" width="13" height="13"></div>
							                    <div class="cdetail">
							                       <span>Call us now</span>
							                       <div class="call-number">1300 920 439</div>
							                    </div>
							                  </div>
							              </a>
							            </li>
							            <li><a href="#" class="button button-white"><img src="assets/images/svg/map-marker-icon.svg" alt="map-marker-icon" title="" width="11" height="14">Get in Touch</a></li>
        							</ul>
								</div>
							</div>
			 	</div>
				
			<!-- footer bottom -->
				<div class="footer-bottom">
							<div class="ft-btm-wap">
								<div class="ft-btm-left">
									<a href="#">
										<img src="assets/images/urbania-logo-footer.svg" alt="urbania-logo" title="" width="234" height="46">
									</a>
									<ul class="ftact-list">
				        				<li>
				        					<div class="box">
				        						<div class="ctact-icon">
				        							<img src="assets/images/svg/map.svg" alt="map" title="" width="15" height="19">   
				        						</div>
				        						<div class="ctact-info">
				        								<p>Head Office 11 Melrose Court, Tullamarine, VIC 3043</p>
				        						</div>
				        					</div>
				        				</li>
				        				<li>
				        					<div class="box">
				        						<div class="ctact-icon">
				        							<img src="assets/images/svg/call.svg" alt="call" title="" width="16" height="16">   
				        						</div>
				        						<div class="ctact-info">
				        								<a href="tel:1300 920 439">1300 920 439</a>
				        						</div>
				        					</div>
				        				</li>
				        				<li>
				        					<div class="box">
				        						<div class="ctact-icon">
				        							<img src="assets/images/svg/email.svg" alt="email" title="" width="18" height="15">   
				        						</div>
				        						<div class="ctact-info">
				        								<a href="mailto:info@urbania.com.au">info@urbania.com.au</a>
				        						</div>
				        					</div>
				        				</li>
				        			</ul>
									<ul class="follow-list">
				        				<li>
				        					<a href="#"><img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="11" height="21"> </a>
				        				</li>
				        				<li>
				        					<a href="#"><img src="assets/images/svg/instagram.svg" alt="instagram" title="" width="17" height="17"> </a>
				        				</li>
				        				<li>
				        					<a href="#"><img src="assets/images/svg/linkedin.svg" alt="linkedin" title="" width="17" height="17"> </a>
				        				</li>
	        						</ul>
											
								</div>
								<div class="ft-btm-right">
									<div class="ftlink-block">
										<div class="ftlink-list">
											<div class="ftlink-title">Quick Links</div>
												<div class="ftlink-detail">
													<ul class="ft-ul">
														<li><a href="#">Home</a></li>
														<li><a href="#">Projects</a></li>
														<li><a href="#">About</a></li>
														<li><a href="#">Resources</a></li>
														<li><a href="#">Areas</a></li>
														<li><a href="#">Contact</a></li>
													</ul>
												</div>
										</div>
										<div class="ftlink-list">
											<div class="ftlink-title">Capabilities</div>
											<div class="ftlink-detail">
											  	<ul class="ft-ul">
														<li><a href="#">Landscape</a></li>
														<li><a href="#">Playspaces</a></li>
														<li><a href="#">Street Furniture</a></li>
												</ul>
											</div>
										</div>
									</div>
											
									<div class="ft-logo">
										<ul class="ftlogo-ul">
											<li><img src="assets/images/compass-assurance-services-logo.png" alt="compass-assurance-services" title="" width="114" height="114"></li>

											<li><img src="assets/images/compass-assurance-service-green-logo.png" alt="compass-assurance-service-green" title="" width="114" height="114"></li>

											<li><img src="assets/images/compass-assurance-service-blue-logo.png" alt="compass-assurance-service-blue" title="" width="114" height="114"></li>

											<li><img src="assets/images/play-australia-logo.png" alt="play-australia" title="" width="114" height="109"></li>

											<li><img src="assets/images/landscaping-victoria-greenlogo.png" alt="landscaping-victoria-greenlogo" title="" width="145" height="69"></li>
										</ul>
									</div>
									<div class="ft-content-block">
										<p>We would like to acknowledge the Wurundjeri people of the Kulin nation, who are the traditional custodians of the land on which Melbourne stands.</p>
									</div>
													
								</div>
							</div>
			 	</div>
		</div>
	</div>	
		
	 <div class="footer-copy">
		<div class="container">
			<p>Copyright &copy; 2025 urbania. All Rights Reserved. <a href="" target="_blank" rel="noopener" class="signature"><img src="assets/images/signature.png" alt="signature" width="" height="" class=""></a></p>
		</div>
	</div>
	
</footer>


<div class="scrollTop"><i class="fa fa-angle-up" aria-hidden="true"></i> </div>

<?php wp_footer(); ?>

</body>

</html>