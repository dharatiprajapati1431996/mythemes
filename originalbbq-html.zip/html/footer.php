<footer>

    <div class="ft-top">
        <div class="container">
        	<div class="flex-container wrap items-start">
        		<div class="ft-block1">
        			<a href="home.php" class="logo-footer">
        				<img src="assets/images/original-bbqbox.svg" alt="original bbqbox" title="" width="91" height="94">
        			</a>

        			<div class="nav-call-link">
        				<a href="tel:0467 826 130" class="alink"><span class="icon"><img src="assets/images/svg/phone.svg" alt="phone" title="" width="7" height="7"></span> 0467 826 130</a>
        				<a href="mailto:info@originalbbqbox.com.au" class="alink"><span class="icon"><img src="assets/images/svg/email.svg" alt="email" title="" width="8" height="7"></span> info@originalbbqbox.com.au</a>
        			</div>
        		</div>
        		<div class="ft-block2">
        			<div class="ft-nav">
        				<div class="col-5">
        					<div class="ft-label">Quick Links</div>
        					<ul class="navbar-link">
        						<li><a href="#">Home</a></li>
        						<li><a href="#">Meat / Shop</a></li>
        						<li><a href="#">Meat Packs</a></li>
        						<li><a href="#">About</a></li>
        						<li><a href="#">How It Works</a></li>
        						<li><a href="#">Contact</a></li>
        					</ul>
        				</div>
        				<div class="col-5">
        					<div class="ft-label">Product Range</div>
        					<ul class="navbar-link">
        						<li><a href="#">Curated Meat Boxes</a></li>
        						<li><a href="#">Custom Boxes</a></li>
        						<li><a href="#">Individual Cuts</a></li>
        						<li><a href="#">BBQ Pantry</a></li>
        					</ul>
        				</div>
        			</div>
        			<div class="ft-search">
        				<div class="ft-label">Promotions, new products and sales. Directly to your inbox.</div>
        				<p>By completing this form, you are signing up to receive our emails and can unsubscribe at any time.</p>

        				<div class="search-wrap">
        					<form class="searchcontrol">
		                        <input type="text" class="form-control" placeholder="Your email">
		                        <input class="submit" value="Sign UP" type="submit">
		                    </form>
        				</div>

        				<div class="follow-link">
        					<a href="#"><img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="27" height="27"> </a>
        					<a href="#"><img src="assets/images/svg/instagram.svg" alt="instagram" title="" width="27" height="27"></a>
        				</div>

        			</div>
        		</div>


        		<!-- <div class="ft-center"></div>
        		<div class="ft-search"></div> -->
        	</div>
        </div>
    </div>
    <div class="ft-bottom">
    	<div class="container">
    		<div class="flex-container wrap justify-between">
    			<div class="master-card-wrap">
    			     <ul class="master-card-list">
                         <li>
                             <img src="assets/images/afterpay.png" alt="afterpay" title="" width="38" height="25">  
                         </li>
                         <li>
                             <img src="assets/images/american-express.png" alt="american-express" title="" width="38" height="25">  
                         </li>
                         <li>
                             <img src="assets/images/apple-pay.png" alt="apple-pay" title="" width="38" height="25">  
                         </li>
                         <li>
                             <img src="assets/images/G-pay.png" alt="G-pay" title="" width="38" height="25">  
                         </li>
                         <li>
                             <img src="assets/images/master-card.png" alt="master-card" title="" width="38" height="25">  
                         </li>
                         <li>
                             <img src="assets/images/shop.png" alt="shop" title="" width="38" height="25">  
                         </li>
                         <li>
                             <img src="assets/images/unionpay-card.png" alt="unionpay-card" title="" wwidth="38" height="25">  
                         </li>
                         <li>
                             <img src="assets/images/visa.png" alt="visa" title="" width="38" height="25">  
                         </li>
                     </ul>
    			</div>

    			<div class="bottom-link">
    				<ul class="navbar-link">
        				<li><a href="#">Privacy Policy</a></li>
        				<li><a href="#">Terms & Conditions</a></li>
    				</ul>
    			</div>
    		</div>
    	</div>
    </div>




    <!-- START COPYRIGHT -->
    <div class="copyright text-center">
        <div class="container">
            <p>Copyright © 2024 original bbq box – <span>All Rights Reserved</span></p>
        </div>
    </div>
    <!-- END COPYRIGHT -->


</footer>

<button class="scrollTop"><i class="fa fa-angle-up" aria-hidden="true"></i> </button>


<?php wp_footer(); ?>
</body>

</html>