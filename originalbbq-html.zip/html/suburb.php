<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="suburb-pg page-wrapper woocommerce">

	<!-- Inner Banner Section -->
	<section class="inner-banner relative">
		<img class="banner_bg" src="assets/images/meat-delivery-banner.jpg" height="450" width="1920" alt="image">
		<div class=" inner_banner_info">
			<div class="heading-40 white">Meat Delivery Cheltenham</div>

			<div class="keyfactor-wrapper">
				<div class="keyfact-box">
					<div class="key-icon">
						<img src="assets/images/svg/easy-online-order.svg" alt="easy-online-order" title="" width="" height="">
					</div>
					<div class="key-info">
						<p>Easy online ordering process</p>
					</div>
				</div>

				<div class="keyfact-box">
					<div class="key-icon">
						<img src="assets/images/svg/environment-friendly.svg" alt="Environmentally friendly" title="" width="" height="">
					</div>
					<div class="key-info">
						<p>Environmentally friendly</p>
					</div>
				</div>

				<div class="keyfact-box">
					<div class="key-icon">
						<img src="assets/images/svg/certified-humane-care.svg" alt="Certified humane" title="" width="" height="">
					</div>
					<div class="key-info">
						<p>Certified humane animal care</p>
					</div>
				</div>

				<div class="keyfact-box">
					<div class="key-icon">
						<img src="assets/images/svg/free-shipping.svg" alt="Free Shipping" title="" width="" height="">
					</div>
					<div class="key-info">
						<p>Free Shipping on all curated box orders</p>
					</div>
				</div>
			</div>

			<div class="button-group">
				<a href="#" class="button btn-theme">Shop Now</a>
				<a href="#" class="button btn-outline-white">Build Your Box</a>
			</div>
		</div>
	</section>
	<!-- Inner Banner Section -->

	<div class="sm-woo_breadcums">
		<div class="container">
			<ul class="woo_breadcums">
				<li>
					<span>
						<span>
							<a href="home.php">Home</a>
							<a href="area-we-serve.php">Areas We Serve</a>
							<span class="breadcrumb_last" aria-current="page">Meat Delivery Cheltenham</span>
						</span>
					</span>
				</li>
			</ul>
		</div>
	</div>

	<!--  START CONTENT -->
	<section class="content-sec py-100 bottom-line">
		<div class="container">
			<div class="flex-container wrap flex-row-reverse">
				<div class="ctent-block">
					<p>Are you seeking premium meat delivery to Cheltenham? The Original BBQ Box. With the rise of online shopping, you can conveniently order high-quality meat and get it delivered directly to your doorstep without any hassle.</p>
					<p>Our services are crafted to offer you the best selection of meat available, coupled with a seamless and efficient delivery process. Order online today and experience the difference of a fresh, delicious cut of meat!</p>

					<div class="heading-28">Experience Convenient Meat Delivery to Cheltenham</div>
					<p>With our BBQ Box, you’ll have access to top-notch, ethically sourced meat without ever having to leave your home.</p>
					<p>And if you’re a fan of Angus and Wagyu steaks, BBQ meats, and customisable meat boxes, we have something perfect for any occasion. Our customised meat delivery to Cheltenham is perfect for families seeking convenient meal planning or individuals looking to enjoy premium cuts without the trip to the market.</p>
					<p>Whether it’s a casual weekday dinner or a special BBQ party, our meat delivery in Cheltenham ensures that your culinary needs are met, with fresh, ethically sourced meat arriving right at your doorstep.</p>
				</div>
				<div class="img-block sticky">
					<img src="assets/images/grilled-beef-fillet-steak.jpg" alt="grilled beef fillet steak" title="" width="700" height="444" class="image-radius">
				</div>
			</div>
		</div>
	</section>
	<!--  End CONTENT -->

	<?php block('home/online-shop') ?>

	<?php block('home/build-custom-box') ?>

	<?php block('home/choose-plan') ?>

	<section class="content-sec py-100 ">
		<div class="container">
			<div class="flex-container wrap flex-row-reverse">
				<div class="ctent-block">					
					<div class="heading-30">WHY CHOOSE THE ORIGINAL BBQ BOX FOR MEAT DELIVERY TO CHELTENHAM?</div>
					<p>When it comes to meat delivery in Cheltenham, The Original BBQ Box stands out for several reasons</p>
					<ul>
						<li><strong>Ethical Sourcing</strong>We source our meat from Australian farming families who practise humane animal care.</li>
						<li><strong>Freshness Guaranteed</strong>Each delivery comes with a freshness guarantee, ensuring you always get the best quality.</li>
						<li><strong>Convenient Ordering</strong>With our easy-to-use online ordering system, getting premium meat delivered to Cheltenham has never been simpler.</li>
						<li><strong>Customisable Options</strong>Choose from curated boxes for variety or create a custom meat box with your favourite cuts.</li>
						<li><strong>Environmentally Friendly</strong>Our packaging is biodegradable and environmentally friendly, making disposal easy and sustainable.</li>
						<li><strong>Top Quality</strong>From Angus and Wagyu steaks to succulent BBQ meats, we offer only the finest cuts.</li>
					</ul>

					<div class="para-semibold">Trust The Original BBQ Box for your meat delivery needs, enjoying the convenience and quality that we provide.</div>

					<div class="button-group">
						<a href="#" class="button btn-theme">Shop Now</a>
						<a href="#" class="button btn-outline">Build Your Box</a>
					</div>
				</div>
				<div class="img-block sticky">
					<img src="assets/images/raw-meat-bbq.jpg" alt="beef" title="" width="700" height="444" class="image-radius">
				</div>
			</div>
		</div>
	</section>

	<?php block('home/how-it-work') ?>

	<?php block('home/certification-accredition') ?>


	<!--  START CONTENT -->
	<section class="content-sec py-100">
		<div class="container">
			<div class="flex-container wrap">
				<div class="ctent-block">
					<div class="heading-28">CUSTOMISE YOUR MEAT BOX FOR DELIVERY TO CHELTENHAM</div>
					<p>One of the unique aspects of our meat delivery service to Cheltenham homes is the ability to fully customise your meat box.</p>
					<p>Whether you have a specific preference for certain cuts of meat or you want a variety for a special gathering, our custom boxes allow you to get exactly what you need. Enjoy the flexibility of choosing beef butchery services, lamb cutlets, chicken fillets, sausages, and more.</p>
					<p>Our subscription plans also offer a hassle-free way to ensure you always have your favourite cuts available, with options ranging from monthly to bi-monthly deliveries. The choice is always yours!</p>

					<div class="heading-22">ENJOY EXCELLENT MEAT DELIVERY TO HELTENHAM HOMES</div>
					<p>Bring the best meats to your table with The Original BBQ Box’s meat delivery to Cheltenham. From premium Wagyu steaks to flavourful sausages and ribs, we provide an array of options perfect for any meal or occasion.</p>
					<p>With options for customisable meat boxes, curated selections, and flexible subscriptions, The Original BBQ Box has everything you need for a delicious dining experience. Don’t miss out–buy online now and elevate your mealtime.</p>
				</div>
				<div class="img-block sticky">
					<img src="assets/images/fried-meat.jpg" alt="meat" title="" width="700" height="444" class="image-radius">
				</div>
			</div>
		</div>
	</section>
	<!--  End CONTENT -->

	<?php block('home/customers-say') ?>

	<?php block('cta-wrapper') ?>

	<?php block('home/home-faq') ?>

	<!--  START CONTENT -->
	<section class="content-sec py-100 lightyellow">
		<div class="container">
			<div class="flex-container wrap">
				<div class="ctent-block area-we-serve-content">
					<div class="heading-28">Areas We Serve </div>
					<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.</p>

					<ul class="areas-sec-list">
						<li><a href="#">Meat Delivery Geelong</a></li>
						<li><a href="#">Meat Delivery Cheltenham</a></li>
						<li><a href="#">Meat Delivery Glen-Iris</a></li>
						<li><a href="#">Meat Delivery South-Yarra</a></li>
						<li><a href="#">Meat Delivery Brighton</a></li>
						<li><a href="#">Meat Delivery Doncaster</a></li>
						<li><a href="#">Meat Delivery Ringwood</a></li>
						<li><a href="#">Meat Delivery Richmond</a></li>
						<li><a href="#">Meat Delivery Thornbury</a></li>
						<li><a href="#">Meat Delivery Northcote</a></li>
						<li><a href="#">Meat Delivery Ivanhoe</a></li>
					</ul>

					<div class="button-group">
						<a href="#" class="button btn-theme">Shop Now</a>
						<a href="#" class="button btn-outline">Build Your Box</a>
					</div>
				</div>
				<div class="area-item areas-sec-img img-block sticky">
					<div class="areas-sec-map">
						<iframe
							src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=Beaumaris%20%20Australia+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"
							width="100%" height="432" style="border:0;" allowfullscreen="" loading="lazy"
							referrerpolicy="no-referrer-when-downgrade" data-gtm-yt-inspected-6="true"></iframe>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--  End CONTENT -->

	<!-- instagram Sec Start -->
	<?php block('instagram') ?>
	<!-- instagram Sec End -->

</main>
<?php get_footer();
