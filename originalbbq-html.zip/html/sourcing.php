<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="howitworks-pg page-wrapper page-left-leaf page-raw-meat-width-leaf">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative">
        <img class="banner_bg" src="assets/images/sourcing-banner.jpg" height="350" width="1920" alt="image">
        <div class=" inner_banner_info">
            <div class="heading-40 white">Sourcing</div>
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <a href="#">How It Works</a>
                            <span class="breadcrumb_last" aria-current="page">Sourcing</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->

    <section class="our-prommise-sec top-content py-90 bottom-line lightyellow">
        <div class="container">
            <div class="center-content text-center">
                <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                <p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
            </div>
        </div>
    </section>

    <!--  START CONTENT -->
    <section class="content-sec py-100 lightyellow relative">
        <img src="assets/images/raw-meat-leg.svg" alt="raw-meat-leg" title="" width="" height="" class="shape raw-meat-leg-left">
        <div class="container">
            <div class="flex-container wrap flex-row-reverse">
                <div class="ctent-block">
                    <div class="semi-head">100% Grass-Fed, Grass-Finished Beef</div>
                    <div class="heading-28">BEEF</div>
                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during.</p>
                    <ul>
                        <li>This is dummy text, we use it at Supple during web designing</li>
                        <li>Hence, don't worry about this dummy text.</li>
                        <li>We use this dummy text to give you an idea how text on this page</li>
                        <li>We use it at Supple during web designing in case we don't have</li>
                        <li>Hence, don't worry about this dummy text.</li>
                    </ul>

                    <div class="button-group">
                        <a href="#" class="button btn-theme">Shop Now</a>
                        <a href="#" class="button btn-outline">Build Your Box</a>
                    </div>
                </div>
                <div class="img-block sticky">
                    <img src="assets/images/sourcing-beef.jpg" alt="beef" title="" width="700" height="444" class="image-radius">
                </div>
            </div>

            <div class="flex-container wrap">
                <div class="ctent-block">
                    <div class="semi-head">FREE-RANGE & PASTURE-RAISED CHICKEN</div>
                    <div class="heading-28">CHICKEN</div>
                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                    <ul>
                        <li>This is dummy text, we use it at Supple during web designing</li>
                        <li>Hence, don't worry about this dummy text.</li>
                        <li>We use this dummy text to give you an idea how text on this page</li>
                        <li>We use it at Supple during web designing in case we don't have</li>
                        <li>Hence, don't worry about this dummy text.</li>
                    </ul>

                    <div class="button-group">
                        <a href="#" class="button btn-theme">Shop Now</a>
                        <a href="#" class="button btn-outline">Build Your Box</a>
                    </div>
                </div>
                <div class="img-block sticky">
                    <img src="assets/images/sourcing-chicken.jpg" alt="chicken" title="" width="700" height="444" class="image-radius">
                </div>
            </div>

            <div class="flex-container wrap flex-row-reverse">
                <div class="ctent-block">
                    <div class="semi-head">100% Grass-Fed, Grass-Finished Lamb</div>
                    <div class="heading-28">LAMB</div>
                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                    <ul>
                        <li>This is dummy text, we use it at Supple during web designing</li>
                        <li>Hence, don't worry about this dummy text.</li>
                        <li>We use this dummy text to give you an idea how text on this page</li>
                        <li>We use it at Supple during web designing in case we don't have</li>
                        <li>Hence, don't worry about this dummy text.</li>
                    </ul>

                    <div class="button-group">
                        <a href="#" class="button btn-theme">Shop Now</a>
                        <a href="#" class="button btn-outline">Build Your Box</a>
                    </div>
                </div>
                <div class="img-block sticky">
                    <img src="assets/images/sourcing-lamb.jpg" alt="lamb" title="" width="700" height="444" class="image-radius">
                </div>
            </div>

            <div class="flex-container wrap">
                <div class="ctent-block">
                    <div class="semi-head">FREE-RANGE & PASTURE-RAISED CHICKEN</div>
                    <div class="heading-28">PORK</div>
                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                    <ul>
                        <li>This is dummy text, we use it at Supple during web designing</li>
                        <li>Hence, don't worry about this dummy text.</li>
                        <li>We use this dummy text to give you an idea how text on this page</li>
                        <li>We use it at Supple during web designing in case we don't have</li>
                        <li>Hence, don't worry about this dummy text.</li>
                    </ul>

                    <div class="button-group">
                        <a href="#" class="button btn-theme">Shop Now</a>
                        <a href="#" class="button btn-outline">Build Your Box</a>
                    </div>
                </div>
                <div class="img-block sticky">
                    <img src="assets/images/sourcing-pork.jpg" alt="pork" title="" width="700" height="444" class="image-radius">
                </div>
            </div>
        </div>
    </section>
    <!--  End CONTENT -->

    <!-- START  Accreditation or Partners and certification -->
    <section class="partners-sec my-100">
        <div class="container">
            <div class="flex-container wrap">
                <div class="col6">
                    <div class="heading-16 bold text-center">Accreditation or Partners</div>

                    <ul class="partners-slider partner-list client-js">
                        <li>
                            <div class="partnerbox">
                                <img src="assets/images/pepesaya.png" alt="pepesaya" title="" width="" height="">
                            </div>
                        </li>
                        <li>
                            <div class="partnerbox">
                                <img src="assets/images/the-rub-society.png" alt="The-rub-socirty" title="" width="" height="">
                            </div>
                        </li>
                        <li>
                            <div class="partnerbox">
                                <img src="assets/images/lalonica.png" alt="lalonica" title="" width="" height="">
                            </div>
                        </li>
                    </ul>

                </div>
                <div class="col6">
                    <div class="heading-16 bold text-center">Certifications</div>

                    <ul class="certification-slider partner-list client-js">
                        <li>
                            <div class="partnerbox">
                                <img src="assets/images/hca.png" alt="hca" title="" width="" height="">
                            </div>
                        </li>
                        <li>
                            <div class="partnerbox">
                                <img src="assets/images/rspca.png" alt="rspca" title="" width="" height="">
                            </div>
                        </li>
                        <li>
                            <div class="partnerbox">
                                <img src="assets/images/netnada.png" alt="netnada" title="" width="" height="">
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- End  Accreditation or Partners and certification -->

    <!-- Start Faq -->
    <section class="hm-faq py-100 lightyellow">
        <div class="container">
            <div class="intro text-center">
                <div class="heading-36">Frequently Asked Questions</div>
                <span class="semi-para">About Buying Meat Online to Melbourne</span>
            </div>
            <div class="faq_accordion faq-page column-faq">
                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>What are the benefits of buying meat online to Melbourne through Original BBQ Box?</h3>
                    </div>
                    <div class="acc_content">
                        <p>Buying meat online in Melbourne from Original BBQ Box means you receive premium, fresh, and organic meat directly to your doorstep. We source our meat from ethical and sustainable Australian farming families, which means every piece is free from antibiotics and hormones. By choosing us, you save time and get the highest quality cuts for your meals, whether for a quick dinner or a weekend BBQ.</p>
                    </div>
                </div>
                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>How does Original BBQ Box ensure the freshness of meat delivered to Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>
                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>Can I customise my order when buying meat online in Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>

                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>Do you offer organic meat online to Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>

                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>What areas do you cover for fresh meat delivery to Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Faq -->

    <!-- instagram Sec Start -->
    <?php block('instagram') ?>
    <!-- instagram Sec End -->

</main>
<?php get_footer();
