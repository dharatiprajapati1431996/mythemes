<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="aboutpg page-wrapper page-left-leaf page-right-raw-meat">

	<!-- Inner Banner Section -->
	<section class="inner-banner relative">
		<img class="banner_bg" src="assets/images/about-banner-bg.jpg" height="350" width="1920" alt="image">
		<div class=" inner_banner_info">
			<div class="heading-40 white">about</div>
			<ul class="woo_breadcums">
				<li>
					<span>
						<span>
							<a href="#">Home</a>
							<span class="breadcrumb_last" aria-current="page">about</span>
						</span>
					</span>
				</li>
			</ul>
		</div>
	</section>
	<!-- Inner Banner Section -->


	<section class="top-content py-90 bottom-line lightyellow">
		<div class="container">
			<div class="center-content text-center">
				<div class="heading-28">Supple during web designing in case we don't have content </div>
				<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
				<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
			</div>
		</div>
	</section>

	<!--  START CONTENT -->
	<section class="content-sec py-100 lightyellow">
		<div class="container">
			<div class="flex-container wrap">
				<div class="ctent-block">
					<div class="heading-28">Hence, don't worry about this dummy text. We use this dummy text to give </div>
					<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
					<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
					<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.</p>
					<p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
				</div>
				<div class="img-block sticky">
					<img src="assets/images/about-content-img.jpg" alt="Person" title="" width="700" height="444" class="image-radius">
				</div>
			</div>
		</div>
	</section>
	<!--  End CONTENT -->


	<!-- Why Choose Section -->
	<section class="why-choose-us relatve py-90">
		<div class="container">
			<div class="intro text-center">
				<div class="semi-head">BUY MEAT ONLINE FOR MELBOURNE CUSTOMERS</div>
				<div class="heading-36">WHY CHOOSE THE ORIGINAL BBQ BOX?</div>
				<p>Why should you buy meat online as a Melbourne customer from Original BBQ Box?</p>
			</div>
			<div class="why-choose-wrapper">

				<div class="why-choose-box">
					<div class="why-choose-img"><img src="assets/images/svg/humane-sustainable.svg" alt="humane-sustainable"></div>
					<div class="why-choose-info">
						<div class="why-title">Humane and Sustainable</div>
						<p>Our meat is sourced from farms that follow ethical and sustainable practices, supporting Australian farming families.</p>
					</div>
				</div>

				<div class="why-choose-box">
					<div class="why-choose-img"><img src="assets/images/svg/online-ordering.svg" alt="online-ordering"></div>
					<div class="why-choose-info">
						<div class="why-title">Easy Online Ordering</div>
						<p>Choose, customise, and order your meat boxes with just a few clicks.</p>
					</div>
				</div>

				<div class="why-choose-box">
					<div class="why-choose-img"><img src="assets/images/svg/cutomisable-options.svg" alt="cutomisable-options"></div>
					<div class="why-choose-info">
						<div class="why-title">Customisable Options</div>
						<p>Whether you want a curated selection or from our team or a customised meat box, we have something for every meat lover!</p>
					</div>
				</div>

				<div class="why-choose-box">
					<div class="why-choose-img"><img src="assets/images/svg/free-shipping-order.svg" alt="free-shipping-order"></div>
					<div class="why-choose-info">
						<div class="why-title">Humane and Sustainable</div>
						<p>Free Shipping on all curated box orders</p>
					</div>
				</div>

				<div class="why-choose-box">
					<div class="why-choose-img"><img src="assets/images/svg/freshness-guaranteed.svg" alt="freshness-guaranteed"></div>
					<div class="why-choose-info">
						<div class="why-title">Freshness Guaranteed</div>
						<p>Every piece of meat is as fresh as possible with our careful selection and packing processes.</p>
					</div>
				</div>
			</div>

			<p class="para-semibold text-center">Choose Original BBQ Box for reliable, high-quality meat delivered right to your doorstep.</p>

			<div class="button-group">
				<div class="button btn-theme">Shop Now</div>
				<div class="button btn-outline">Build Your Box</div>
			</div>
		</div>
	</section>
	<!-- Why Choose Section -->


	<!--  START CONTENT -->
	<section class="content-sec py-100 lightyellow relative">
		<img src="assets/images/raw-meat-leaf.png" alt="leaf" title="" width="380" height="320" class="shape leaf-right">
		<div class="container">
			<div class="flex-container wrap flex-row-reverse">
				<div class="ctent-block">
					<div class="heading-28">Hence, don't worry about this dummy text. We use this dummy text to give </div>
					<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
					<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
					<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. </p>
					<p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
				</div>
				<div class="img-block sticky">
					<img src="assets/images/about-food-craving.jpg" alt="about-food-craving" title="" width="700" height="444" class="image-radius">
				</div>
			</div>
		</div>
	</section>
	<!--  End CONTENT -->


	<!-- instagram Sec Start -->
	<?php block('instagram') ?>
	<!-- instagram Sec End -->

</main>
<?php get_footer();
