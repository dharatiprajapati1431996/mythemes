<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML Theme</title>
    <?php wp_head(); ?>
</head>
<body>
<!-- Start Header -->

    <header class="mainheader">

        <a class="togglebtn"><span></span></a>
        <div class="overlay"></div>


        <div class="head-top">
            <div class="container ">
                <div class="flex-container wrap justify-end items-center">
                    <p>Free Shipping for all curated box orders</p>
                   
                   <div class="head-top-call">
                        <a href="tel:0467 826 130" class="head-call"><img src="assets/images/svg/call.svg" alt="call" title="" width="24" height="24">Call us now: 0467 826 130</a>
                   </div>
                </div>
            </div>
        </div>


        <div class="head-bottom">
            <div class="container wrap justify-between items-center">
                <div class="logo-left">
                    <a href="home.php" class="disblock">
                        <img src="assets/images/original-bbq-box-logo.svg" alt="original-bbq-box-logo" title=""
                            width="105" height="109">
                    </a>
                </div>
                <div class="menu_link">
                    <nav>
                        <ul>
                            <li><a href="index.php">Home </a></li>
                            <li class="has-sub">
                                <a href="#"> Curated Boxes</a>
                                <div class="submenu megamenu">
                                    <ul class="sublink">
                                        <li>
                                            <a href="#">
                                                <div class="menu-img">
                                                    <img src="assets/images/beef.jpg" alt="beef" title="" width="265" height="265">
                                                </div>
                                                <div class="label-info">Beef</div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div class="menu-img">
                                                    <img src="assets/images/lamb.jpg" alt="lamb" title="" width="265" height="265">
                                                </div>
                                                <div class="label-info">Lamb</div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div class="menu-img">
                                                    <img src="assets/images/chicken.jpg" alt="chicken" title="" width="265" height="265">
                                                </div>
                                                <div class="label-info">Chicken</div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div class="menu-img">
                                                    <img src="assets/images/pork.jpg" alt="pork" title="" width="265" height="265">
                                                </div>
                                                <div class="label-info">Pork</div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div class="menu-img">
                                                    <img src="assets/images/pantry.jpg" alt="pantry" title="" width="265" height="265">
                                                </div>
                                                <div class="label-info">Pantry</div>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="menu-cta flex-container justify-between">
                                        <div class="heading-30">Shop our high-quality meat</div>
                                        <div class="button-group">
                                            <a href="#" class="button btn-theme">Shop Now</a>
                                            <a href="#" class="button btn-outline">Build Your Box</a>
                                         </div>
                                    </div>
                                </div>
                            </li>
                            <li class="has-sub">
                                <a href="#">Build Your Box</a>
                                <div class="submenu simple-dorpdown">
                                    
                                </div>
                            </li>
                            <li class="has-sub">
                                <a href="about.php">About </a>
                                <div class="submenu simple-dorpdown">
                                    
                                </div>
                            </li>
                            <li class="has-sub">
                                <a href="#">How It Works</a>
                                <div class="submenu simple-dorpdown">
                                   
                                </div>
                            </li>
                            <li><a href="#"> Contact</a></li>

                        </ul>
                    </nav>

                    <!-- START MENU CTA -->
                    <div class="menu-show-cta hidden">
                        <div class="heading-26">Shop our high-quality meat</div>
                            <div class="button-group">
                                <a href="#" class="button btn-theme">Shop Now</a>
                                <a href="#" class="button btn-outline">Build Your Box</a>
                            </div>
                    </div>
                    <!-- END MENU CTA -->

                </div>

                <div class="head-ecommerce">
                    <div class="search-wrap hide-mobile-search">
                        <form class="searchcontrol">
                            <select class="custom_select">
                                <option value="default">All Products</option>
                                <option value=""></option>
                                <option value=""></option>
                                <option value=""></option>
                            </select>

                            <input type="text" class="form-control" placeholder="Search...">
                            <input class="submit" value="" type="submit">
                        </form>

                        <div class="close-form">
                            <img src="assets/images/menu-close.png" alt="close" title="" width="17" height="18">   
                        </div>

                    </div>
                    <ul class="accout-wrap">
                        <li class="accout-blk hidden search-mobile">
                            <a href="#" class="accout-link search-on-link">
                                <div class="img-wrap">
                                    <img src="assets/images/svg/search.svg" alt="search" title="" width="" height="">
                                </div>
                            </a>
                        </li>
                        <li class="accout-blk">
                            <a href="#" class="accout-link">
                                <div class="img-wrap"><img src="assets/images/svg/user.svg" height="17" width="15" title="" alt="user"></div>
                                <div class="info-wrap">
                                    <div class="accout-title">Account</div>
                                </div>
                            </a>
                        </li>
                        <li class="cart-blk">
                            <a href="#" class="cart-link">
                                <div class="img-wrap"><img src="assets/images/svg/cart.svg" height="16" width="21" title="" alt="cart"></div>
                                <div class="info-wrap">
                                    <div class="accout-title">My Cart</div>
                                    <div class="flex-container">
                                        <!-- <div class="cart-item"><span>2</span>Items |</div>
                                        <div class="cart-price">Total:<span>$2000</span></div> -->
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>

                    <div class="search-wrap search-show-mobile hidden">
                        <!-- <a class="close-search">
                            <img src="assets/images/menu-close.png" alt="menu-close" title="" width="" height="">
                        </a> -->

                        <form class="searchcontrol">
                            <select class="custom_select">
                                <option value="default">All Products</option>
                                <option value=""></option>
                                <option value=""></option>
                                <option value=""></option>
                            </select>

                            <input type="text" class="form-control" placeholder="Search...">
                            <input class="submit" value="" type="submit">
                        </form>
                    </div>
                </div>

            </div>
        </div>

    </header>
    <!-- End Header -->



                        