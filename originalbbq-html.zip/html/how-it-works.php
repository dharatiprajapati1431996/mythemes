<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="howitworks-pg page-wrapper page-left-leaf page-raw-meat-width-leaf woocommerce">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative">
        <img class="banner_bg" src="assets/images/how-it-work-banner.jpg" height="350" width="1920" alt="how-it-work-banner">
        <div class=" inner_banner_info">
            <div class="heading-40 white">How It Works</div>
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <span class="breadcrumb_last" aria-current="page">How It Works</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->

    <section class="our-prommise-sec top-content py-90">
        <div class="container">
            <div class="center-content text-center">
                <div class="heading-36">our process</div>
                <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
            </div>

            <div class="how-it-work-sec our-process">
                <div class="step-wrap">
                    <div class="step-box">
                        <div class="step-img">
                            <img src="assets/images/svg/bbq-box.svg" alt="bbq-box" title="" width="98" height="70">
                        </div>
                        <div class="step-info">
                            <label class="step-num">step 1</label>
                            <div class="heading-18">Choose Your BBQ Box</div>
                            <p>Browse our selection of expertly curated BBQ boxes or build your own from scratch. Don’t forget to add extras from our pantry to complete your feast!</p>
                        </div>
                    </div>
                    <div class="step-box">
                        <div class="step-img">
                            <img src="assets/images/svg/place-order.svg" alt="place-order" title="" width="72" height="69">
                        </div>
                        <div class="step-info">
                            <label class="step-num">step 2</label>
                            <div class="heading-18">Place Your Order</div>
                            <p>Easily place your order online through our secure platform. Whether you're at home or on the go, it’s fast, simple, and convenient.</p>
                        </div>
                    </div>
                    <div class="step-box">
                        <div class="step-img">
                            <img src="assets/images/svg/receive-order.svg" alt="receive-order" title="" width="74" height="74">
                        </div>
                        <div class="step-info">
                            <label class="step-num">step 3</label>
                            <div class="heading-18">Receive Your BBQ Box</div>
                            <p>We deliver your BBQ box straight to your doorstep, carefully packed on ice to ensure freshness. Just sit back and get ready to grill!</p>
                        </div>
                    </div>
                    <div class="step-box">
                        <div class="step-img">
                            <img src="assets/images/svg/fire-grill.svg" alt="fire-grill" title="" width="70" height="74">
                        </div>
                        <div class="step-info">
                            <label class="step-num">step 4</label>
                            <div class="heading-18">Fire Up the Grill</div>
                            <p>Unpack your premium BBQ meats & get grilling! Looking for inspiration? Explore new recipes & tips on our [XXX] page for the ultimate BBQ experience.</p>
                        </div>
                    </div>
                </div>

                <div class="button-group">
                    <a href="#" class="button btn-theme">Shop Now</a>
                    <a href="#" class="button btn-outline">Build Your Box</a>
                </div>
            </div>


            <div class="certification-inner-wrap">
                <div class="head-xs uppercase text-center">Certifications</div>

                <ul class="certification-slider partner-list client-js">
                    <li>
                        <div class="partnerbox">
                            <img src="assets/images/hca.png" alt="hca" title="" width="" height="">
                        </div>
                    </li>
                    <li>
                        <div class="partnerbox">
                            <img src="assets/images/rspca.png" alt="rspca" title="" width="" height="">
                        </div>
                    </li>
                    <li>
                        <div class="partnerbox">
                            <img src="assets/images/netnada.png" alt="netnada" title="" width="" height="">
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>


    <section class="explore-product lightyellow py-90">
        <div class="container">
            <div class="premium-product premium-js slick-arrow">
                <ul class="products columns-4">
                    <li class="product type-product  instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <span class="onsale special">Special</span>
                            <div class="prod-img">
                                <img src="assets/images/grass-fed-porterhouse.png" alt="grass-fed-porterhouse" title="" width="273" height="206">
                            </div>
                            <h2 class="woocommerce-loop-product__title">Grass-fed Porterhouse Steak Twin Pack</h2>

                             <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>25.95</bdi></span></del> <span class="screen-reader-text">Original price was: $25.95.</span><ins aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>20.95</bdi></span></ins><span class="screen-reader-text">Current price is: $20.95.</span></span>
                        </a>

                        <a href="?add-to-cart=1593" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1593" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1593" data-product_sku="woo-beanie" aria-label="Add to cart: “Beanie”" rel="nofollow" data-success_message="“Beanie” has been added to your cart">Add to cart</a>   <span id="woocommerce_loop_add_to_cart_link_describedby_1593" class="screen-reader-text"></span>
                    </li>


                    <li class="product type-product instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">

                            <div class="prod-img">
                                <img src="assets/images/chicken-breast-fillet.png" alt="chicken breast fillet" title="" width="" height="">
                            </div>


                            <h2 class="woocommerce-loop-product__title">Free Range Chicken Breast Fillet</h2>
                            <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>15.95</bdi></span></span>
                        </a>

                        <a href="?add-to-cart=1610" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1610" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1610" data-product_sku="Woo-beanie-logo" aria-label="Add to cart: “Beanie with Logo”" rel="nofollow" data-success_message="“Beanie with Logo” has been added to your cart">Add to cart</a>  

                        <span id="woocommerce_loop_add_to_cart_link_describedby_1610" class="screen-reader-text"></span>
                    
                    </li>


                    <li class="product type-product instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <div class="prod-img">
                                <img src="assets/images/smoked-chicken-fillet.png" alt="Smoked Chicken Fillet" title="" width="" height="">
                            </div>
                            <h2 class="woocommerce-loop-product__title">Free Range Smoked Chicken Fillet</h2>

                            <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>30.95</bdi></span></span>
                        </a>

                        <a href="?add-to-cart=1594" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1594" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1594" data-product_sku="woo-belt" aria-label="Add to cart: “Belt”" rel="nofollow" data-success_message="“Belt” has been added to your cart">Add to cart</a> 
                        <span id="woocommerce_loop_add_to_cart_link_describedby_1594" class="screen-reader-text"></span>
                    </li>

                    <li class="product type-product instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <div class="prod-img">
                                <img src="assets/images/pork-ribs-sweet-sticky.png" alt="Pork Ribs Sweet & Sticky" title="" width="" height="">
                            </div>

                            <h2 class="woocommerce-loop-product__title">Free Range Pork Ribs Sweet & Sticky</h2>

                             <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>20.95</bdi></span></span>
                        </a>

                        <a href="?add-to-cart=1595" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1595" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1595" data-product_sku="woo-cap" aria-label="Add to cart: “Cap”" rel="nofollow" data-success_message="“Cap” has been added to your cart">Add to cart</a>    
                        <span id="woocommerce_loop_add_to_cart_link_describedby_1595" class="screen-reader-text"></span>
                    </li>
                </ul>
            </div>
        </div>
    </section>


    <!-- Start Faq  -->
    <section class="hm-faq py-100 bottom-line relative">
        <img src="assets/images/raw-meat-leg.svg" alt="raw-meat-leg" title="" width="" height="" class="shape raw-meat-leg-left">
        <div class="container">
            <div class="intro text-center">
                <div class="heading-36">Frequently Asked Questions</div>
                <span class="semi-para">About Buying Meat Online to Melbourne</span>
            </div>
            <div class="faq_accordion faq-page column-faq">
                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>What are the benefits of buying meat online to Melbourne through Original BBQ Box?</h3>
                    </div>
                    <div class="acc_content">
                        <p>Buying meat online in Melbourne from Original BBQ Box means you receive premium, fresh, and organic meat directly to your doorstep. We source our meat from ethical and sustainable Australian farming families, which means every piece is free from antibiotics and hormones. By choosing us, you save time and get the highest quality cuts for your meals, whether for a quick dinner or a weekend BBQ.</p>
                    </div>
                </div>
                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>How does Original BBQ Box ensure the freshness of meat delivered to Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>
                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>Can I customise my order when buying meat online in Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>

                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>Do you offer organic meat online to Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>

                <div class="accordion_in">
                    <div class="faq-head">
                        <h3>What areas do you cover for fresh meat delivery to Melbourne?</h3>
                    </div>
                    <div class="acc_content">

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Faq  -->


    <!-- instagram Sec Start -->
    <?php block('instagram') ?>
    <!-- instagram Sec End -->

</main>
<?php get_footer();
