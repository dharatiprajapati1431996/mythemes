<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
    <main class="page_wrapper errorpg">

    	<!-- Inner Banner Section -->
		<section class="inner-banner relative">
			<img class="banner_bg" src="assets/images/contact-inner.jpg" height="350" width="1920" alt="image">
			<div class=" inner_banner_info">
				<div class="heading-40 white">404</div>
				<ul class="woo_breadcums">
					<li>
						<span>
							<span>
								<a href="#">Home</a>
								<span class="breadcrumb_last" aria-current="page">404</span>
							</span>
						</span>
					</li>
				</ul>
			</div>
		</section>
		<!-- Inner Banner Section -->


        <section class="inpage py-100 lightyellow">
                <div class="container">
                    
                    <div class="thank_you_content">
                        <img src="assets/images/404.png" alt="404" title="404" width="500" height="500" />				
                        <p>Woops, looks like this page doesn't exist.</p>
                    </div>

                </div>
        </section>



        <!-- Start Keyfactor  -->
		<section class="keyfactor-sec">
		    <div class="container">
		        <?php block('keyfactor'); ?>
		    </div>
		</section>
		<!-- End Keyfactor  -->
		
    </main>
<?php get_footer();
