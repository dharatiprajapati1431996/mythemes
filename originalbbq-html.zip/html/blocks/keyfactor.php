<!-- Start Keyfactor  -->

    <div class="keyfactor-wrapper keyfactor-js">
        <div class="keyfact-box">
            <div class="key-icon">
                <img src="assets/images/svg/easy-online-order.svg" alt="easy-online-order" title="" width="37"
                    height="36">
            </div>
            <div class="key-info">
                <p>Easy online ordering process</p>
            </div>
        </div>

        <div class="keyfact-box">
            <div class="key-icon">
                <img src="assets/images/svg/environment-friendly.svg" alt="Environmentally friendly" title="" width="37"
                    height="32">
            </div>
            <div class="key-info">
                <p>Environmentally friendly</p>
            </div>
        </div>

        <div class="keyfact-box">
            <div class="key-icon">
                <img src="assets/images/svg/certified-humane-care.svg" alt="Certified humane" title="" width="37"
                    height="37">
            </div>
            <div class="key-info">
                <p>Certified humane animal care</p>
            </div>
        </div>

        <div class="keyfact-box">
            <div class="key-icon">
                <img src="assets/images/svg/free-shipping.svg" alt="Free Shipping" title="" width="35"
                    height="24">
            </div>
            <div class="key-info">
                <p>Free Shipping on all curated box orders</p>
            </div>
        </div>
    </div>
<!-- End Keyfactor  -->