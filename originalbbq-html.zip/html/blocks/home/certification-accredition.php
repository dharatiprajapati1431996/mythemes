
<!-- START  Accreditation or Partners and certification -->

<section class="partners-sec py-100 bottom-line">
	<div class="container">
		<div class="flex-container wrap">
			<div class="col6">
				<div class="heading-16 bold text-center">Accreditation or Partners</div>

				<ul class="partners-slider partner-list client-js">
					<li>
						<div class="partnerbox">
							<img src="assets/images/pepesaya.png" alt="pepesaya" title="" width="157" height="36">
						</div>
					</li>
					<li>
						<div class="partnerbox">
							<img src="assets/images/the-rub-society.png" alt="The-rub-socirty" title="" width="99" height="90">
						</div>
					</li>
					<li>
						<div class="partnerbox">
							<img src="assets/images/lalonica.png" alt="lalonica" title="" width="128" height="71">
						</div>
					</li>
				</ul>

			</div>
			<div class="col6">
				<div class="heading-16 bold text-center">Certifications</div>

				<ul class="certification-slider partner-list client-js">
					<li>
						<div class="partnerbox">
							<img src="assets/images/hca.png" alt="hca" title="" width="167" height="66">
						</div>
					</li>
					<li>
						<div class="partnerbox">
							<img src="assets/images/rspca.png" alt="rspca" title="" width="107" height="107">
						</div>
					</li>
					<li>
						<div class="partnerbox">
							<img src="assets/images/netnada.png" alt="netnada" title="" width="181" height="68">
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- End  Accreditation or Partners and certification -->