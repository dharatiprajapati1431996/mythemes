
<!-- Start why choose -->

<section class="pt-120 pb-120 why-choose">
	<div class="container">
		<div class="flex-container wrap items-start">
			<div class="choose-left sticky">
				<div class="image-group">
					<img src="assets/images/food-app.jpg" alt="food-app" title="" width="350" height="548" class="image-radius">
					<img src="assets/images/meat.jpg" alt="meat" title="" width="350" height="548" class="image-radius">
				</div>
			</div>
			<div class="choose-right">
				<div class="intro">
					<div class="semi-head">Buy Meat Online for Melbourne Customers</div>
					<div class="heading-36">Why Choose The Original BBQ Box?</div>
					<p>Why should you buy meat online as a Melbourne customer from Original BBQ Box?</p>
				</div>

				<ul class="why-choose-list">
					<li>
						<div class="chbox">
							<div class="ch-icon">
								<img src="assets/images/svg/online-ordering.svg" alt="easy-online-order" title="" width="52" height="48">
							</div>
							<div class="ch-info">
								<div class="head-xs">Easy Online Ordering</div>
								<p>Choose, customise, and order your meat boxes with just a few clicks. </p>
							</div>
						</div>
					</li>
					<li>
						<div class="chbox">
							<div class="ch-icon">
								<img src="assets/images/svg/freshness-guaranteed.svg" alt="Freshness Guaranteed" title="" width="59" height="54">
							</div>
							<div class="ch-info">
								<div class="head-xs">Freshness Guaranteed</div>
								<p>Every piece of meat is as fresh as possible with our careful selection and packing processes. </p>
							</div>
						</div>
					</li>
					<li>
						<div class="chbox">
							<div class="ch-icon">
								<img src="assets/images/svg/humane-sustainable.svg" alt="Humane and Sustainable" title="" width="55" height="47">
							</div>
							<div class="ch-info">
								<div class="head-xs">Humane and Sustainable</div>
								<p>Our meat is sourced from farms that follow ethical and sustainable practices, supporting Australian farming families. </p>
							</div>
						</div>
					</li>
					<li>
						<div class="chbox">
							<div class="ch-icon">
								<img src="assets/images/svg/cutomisable-options.svg" alt="Customisable Options" title="" width="55" height="53">
							</div>
							<div class="ch-info">
								<div class="head-xs">Customisable Options</div>
								<p>Whether you want a curated selection or from our team or a customised meat box, we have something for every meat lover!</p>
							</div>
						</div>
					</li>
					<li>
						<div class="chbox">
							<div class="ch-icon">
								<img src="assets/images/svg/free-shipping-order.svg" alt="Free Shipping" title="" width="43" height="55">
							</div>
							<div class="ch-info">
								<div class="head-xs">Free Shipping</div>
								<p>Free Shipping on all curated box orders </p>
							</div>
						</div>
					</li>
				</ul>


				<p class="para-semibold">Choose Original BBQ Box for reliable, high-quality meat delivered right to your doorstep.</p>

				<div class="button-group">
					<a href="#" class="button btn-theme">Shop Now</a>
					<a href="#" class="button btn-outline">Build Your Box</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End why choose -->