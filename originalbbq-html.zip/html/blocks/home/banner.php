 <!-- banner section start -->

<section class="banner">
     <div class="js_hmbanner slick-arrow">
         <div class="slidediv slideone">
             <img src="assets/images/banner.jpg" alt="" title="" width="1920" height="700" class="desktop_banner">
             <div class="bannertext">
                 <div class="container hmbo_wrap">
                     <div class="webox">
                         <div class="heading-60">Premium BBQ Meat Delivered to Your Doorstep</div>
                         <p>Free Shipping on all curated box orders</p>

                         <div class="button-group">
                            <a href="#" class="button btn-theme">Shop Now</a>
                            <a href="#" class="button btn-outline-white">Build Your Box</a>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </section>

    

 <!-- banner section end -->