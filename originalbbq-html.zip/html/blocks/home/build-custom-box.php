
<!-- Start BUILD YOUR CUSTOM BOX -->
<section class="custom-box lightyellow py-100 relative">
    <img src="assets/images/raw-meat-leg.svg" alt="raw-meat-leg" title="" width="214" height="328" class="shape raw-meat-leg-left">
    <img src="assets/images/raw-meat-shape-leg.svg" alt="raw meat leg right" title="" width="357" height="383" class="shape raw-meat-leg-right">
	<div class="container">
		<div class="text-center heading-40">Build your custom box</div>


		 <div class="build-custome-box-wrapper">
            <div id="custom-build" class="custom_wrapper">
                <div class="custom-tab-wrap">
                    <ul class="resp-tabs-list">
                        <li data-tab="beef" class="resp-tab-active">
                            <div class="title_xs">
                            	<span>
                            		<img src="assets/images/svg/beef.svg" alt="beef" title="" width="75" height="48"> 

                            		<audio  id="beef">
									  <!-- <source src="assets/images/cow.ogg" type="audio/ogg" preload="auto"> -->
									  <source src="assets/images/cow.mp3" type="audio/mpeg" preload="auto">
									</audio>
                            	</span>
                            	Beef
                            </div>
                        </li>
                        <li data-tab="lamb">
                            <div class="title_xs">
                            	<span>
                            		<img src="assets/images/svg/lamb.svg" alt="lamb" title="" width="53" height="45"> 
                            		<audio id="lamb">
									  <!-- <source src="assets/images/lamb.ogg" type="audio/ogg" preload="auto"> -->
									  <source src="assets/images/lamb.mp3" type="audio/mpeg" preload="auto">
									</audio>
                            	</span>
                            	Lamb
                            </div>
                        </li>
                        <li data-tab="chiken">
                            <div class="title_xs">
                            	<span>
                            		<img src="assets/images/svg/chiken.svg" alt="Chiken" title="" width="44" height="46"> 
                            		<audio id="chiken">
										<!-- <source src="assets/images/chicken.ogg" type="audio/ogg" preload="auto"> -->
										<source src="assets/images/chicken.mp3" type="audio/mpeg" preload="auto">
									</audio>
                            	</span>
                            	Chiken
                            </div>
                        </li>
                        <li data-tab="pork">
                            <div class="title_xs">
                            	<span>
                            		<img src="assets/images/svg/pork.svg" alt="Pork" title="" width="86" height="48"> 
                            		<audio id="pork">
										<!-- <source src="assets/images/pork.ogg" type="audio/ogg" preload="auto"> -->
										<source src="assets/images/pork.mp3" type="audio/mpeg" preload="auto">
									</audio>
                            	</span>
                            	Pork
                        	</div>
                        </li>
                    </ul>
                </div>

                <div class="resp-tabs-container mobile-accordion">
                    <div class="div_tb resp-tab-content-active" id="beef">
                        <div class="tab_content ">
                            <div class="product-slider">
                                <ul class="products columns-4 slick-arrow">
                                    <li class="product type-product  instock">
                                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                            <span class="onsale special">Special</span>
                                            <div class="prod-img">
                                                <img src="assets/images/grass-fed-porterhouse.png" alt="grass-fed-porterhouse" title="" width="273" height="206" class="hover-hide">

                                                <img src="assets/images/grass-fed-porterhouse-steak-twin.jpg" alt="Grass-fed Porterhouse Steak Twin" title="" width="340" height="226" class="hover-show">


                                            </div>
                                            <h2 class="woocommerce-loop-product__title">Grass-fed Porterhouse Steak Twin Pack</h2>

                                             <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                            <span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>25.95</bdi></span></del> <span class="screen-reader-text">Original price was: $25.95.</span><ins aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>20.95</bdi></span></ins><span class="screen-reader-text">Current price is: $20.95.</span></span>
                                        </a>

                                        <a href="?add-to-cart=1593" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1593" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1593" data-product_sku="woo-beanie" aria-label="Add to cart: “Beanie”" rel="nofollow" data-success_message="“Beanie” has been added to your cart">Add to cart</a>   <span id="woocommerce_loop_add_to_cart_link_describedby_1593" class="screen-reader-text"></span>
                                    </li>


                                    <li class="product type-product instock">
                                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">

                                            <div class="prod-img">
                                                <img src="assets/images/chicken-breast-fillet.png" alt="chicken breast fillet" title="" width="272" height="204" class="hover-hide">

                                                <img src="assets/images/grass-fed-porterhouse-steak-twin.jpg" alt="Free Range Chicken Breast Fillet" title="" width="340" height="226" class="hover-show">
                                            </div>


                                            <h2 class="woocommerce-loop-product__title">Free Range Chicken Breast Fillet</h2>
                                            <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>15.95</bdi></span></span>
                                        </a>

                                        <a href="?add-to-cart=1610" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1610" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1610" data-product_sku="Woo-beanie-logo" aria-label="Add to cart: “Beanie with Logo”" rel="nofollow" data-success_message="“Beanie with Logo” has been added to your cart">Add to cart</a>  

                                        <span id="woocommerce_loop_add_to_cart_link_describedby_1610" class="screen-reader-text"></span>
                    
                                    </li>


                                    <li class="product type-product instock">
                                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                            <div class="prod-img">

                                                <img src="assets/images/smoked-chicken-fillet.png" alt="Smoked Chicken Fillet" title="" width="259" height="173" class="hover-hide">

                                                <img src="assets/images/pork-chicken.jpg" alt="pork-chicken" title="" width="340" height="226" class="hover-show">
                                            </div>
                                            <h2 class="woocommerce-loop-product__title">Free Range Smoked Chicken Fillet</h2>

                                            <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>30.95</bdi></span></span>
                                        </a>

                                        <a href="?add-to-cart=1594" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1594" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1594" data-product_sku="woo-belt" aria-label="Add to cart: “Belt”" rel="nofollow" data-success_message="“Belt” has been added to your cart">Add to cart</a> 
                                        <span id="woocommerce_loop_add_to_cart_link_describedby_1594" class="screen-reader-text"></span>

                                    </li>

                                    <li class="product type-product instock">
                                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                            <div class="prod-img">
                                                <img src="assets/images/pork-ribs-sweet-sticky.png" alt="Pork Ribs Sweet & Sticky" title="" width="287" height="191" class="hover-hide">

                                                <img src="assets/images/pork-ribs-sweet.jpg" alt="Free Range Pork Ribs Sweet" title="" width="340" height="226" class="hover-show">
                                            </div>

                                            <h2 class="woocommerce-loop-product__title">Free Range Pork Ribs Sweet & Sticky</h2>

                                             <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>20.95</bdi></span></span>
                                        </a>

                                        <a href="?add-to-cart=1595" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1595" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1595" data-product_sku="woo-cap" aria-label="Add to cart: “Cap”" rel="nofollow" data-success_message="“Cap” has been added to your cart">Add to cart</a>    
                                        <span id="woocommerce_loop_add_to_cart_link_describedby_1595" class="screen-reader-text"></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="div_tb" id="lamb">
                        Lamb
                    </div>
                    <div class="div_tb" id="chiken">
                        chiken
                    </div>
                    <div class="div_tb" id="Pork">
                       Pork
                    </div>

                </div>



		<div class="button-group justify-center">
            <div class="button-group">
				<a href="#" class="button btn-theme">Shop Now</a>
				<a href="#" class="button btn-outline">Build Your Box</a>
			</div>
        </div>
        
	</div>
</section>
<!-- End BUILD YOUR CUSTOM BOX -->
