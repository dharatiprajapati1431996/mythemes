
<!-- Start Your Plan  -->
<section class="choose-plan">
	<div class="container-fluid">
		<div class="flex-container wrap">

			<div class="badge-wrap">
				<img src="assets/images/badge.png" alt="badge" title="" width="174" height="174">
			</div>

			<div class="col6 plan-left white-text">
				<img src="assets/images/wine-background.jpg" alt="wine background" title="" width="960" height="580" class="bgimg">
				<div class="plan-inner">
					<div class="intro">
						<div class="heading-36">Choose your plan</div>
						<span class="semi-para">Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</span>
					</div>

					<div class="plan-wrap">
						<div class="plan-box">
							<div class="head-20">Subscription Options Available</div>
							<ul class="plan-list">
								<li>Weekly</li>
								<li>Fortnightly</li>
								<li>Monthly</li>
							</ul>
						</div>
						<div class="plan-box benefit-wrap">
							<div class="head-20">Benefits</div>
							<ul class="plan-list">
								<li>Flexible Subscriptions</li>
								<li>Pause or Cancel Anytime</li>
							</ul>
						</div>
					</div>


					<a href="#" class="button btn-primary">Build Your Box</a>


				</div>
			</div>
			<div class="col6">
				<img src="assets/images/grilled-pork.jpg" alt="Grilled Pork" title="" width="960" height="580">
			</div>
		</div>
	</div>
</section>

<!-- End Your Plan  -->