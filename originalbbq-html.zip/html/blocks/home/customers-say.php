
<!-- START CUSTOMERS SAY -->
<section class="pt-100 pb-220 customers-say lightyellow">
	<div class="container">
		<div class="intro text-center">
			<div class="heading-36">What Our Customers Say</div>
			<span class="semi-para">We use this dummy text to give you an idea how text on this page</span>
		</div>
	</div>

	<div class="customer-wrapper">
		<div class="customer-say customer-grid slick-arrow">

			<div class="customer-item">
				<div class="cuctomer-inner">

					<div class="cust-img">
						<img src="assets/images/meat-peace.png" alt="meat-peace" title="" width="503" height="503">
					</div>
					<div class="cust-review">
						<div class="name-wrap">
							<div class="name-img">
								<img src="assets/images/lin-hicks.png" alt="" title="" width="56" height="55">
							</div>
							<div class="name">Lin Hicks <span class="date">03-Aug- 2024 </span></div>
						</div>

						<div class="ratting">
							<img src="assets/images/star.png" alt="star" title="" width="87" height="14">
						</div>
						<div class="review-box">
							<p>My husband and l shop there weekly, the quality of the meat is very good and the service is excellent<br>I really hope they stay around for years to come<br>It’s great having a butcher in the mall</p>
						</div>
					</div>

				</div>
			</div>

			<div class="customer-item">
				<div class="cuctomer-inner">
					<div class="cust-img">
							<img src="assets/images/meat-slice-grill.png" alt="meat-slice-grill" title="" width="503" height="503">
						</div>
						<div class="cust-review">
							<div class="name-wrap">
								<div class="name-img">
									<img src="assets/images/lin-hicks.png" alt="" title="" width="56" height="55">
								</div>
								<div class="name">Lin Hicks <span class="date">03-Aug- 2024 </span></div>
							</div>

							<div class="ratting">
								<img src="assets/images/star.png" alt="star" title="" width="87" height="14">
							</div>

							<div class="review-box">
								<p>My husband and l shop there weekly, the quality of the meat is very good and the service is excellent<br>I really hope they stay around for years to come<br>It’s great having a butcher in the mall</p>
							</div>
						</div>
				</div>
			</div>

			<div class="customer-item">
				<div class="cuctomer-inner">
					<div class="cust-img">
						<img src="assets/images/meat-slice.png" alt="meat-slice" title="" width="503" height="503">
					</div>
					<div class="cust-review">
						<div class="name-wrap">
							<div class="name-img">
								<img src="assets/images/lin-hicks.png" alt="" title="" width="56" height="55">
							</div>
							<div class="name">Lin Hicks <span class="date">03-Aug- 2024 </span></div>
						</div>

						<div class="ratting">
							<img src="assets/images/star.png" alt="star" title="" width="87" height="14">
						</div>

						<div class="review-box">
							<p>My husband and l shop there weekly, the quality of the meat is very good and the service is excellent<br>I really hope they stay around for years to come<br>It’s great having a butcher in the mall</p>
						</div>
					</div>
				</div>

			</div>

		</div>
	</div>

</section>
<!-- END CUSTOMERS SAY -->