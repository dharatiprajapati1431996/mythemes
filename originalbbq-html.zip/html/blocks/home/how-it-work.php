
<!-- START CUSTOMERS SAY -->
<section class="py-100 how-it-work-sec lightyellow relative">
	<img src="assets/images/raw-meat-side.png" alt="raw-meat-side" title="" width="256" height="406" class="shape raw-meat-side">

	<img src="assets/images/raw-meat-shape1.svg" alt="raw-meat-side" title="" width="458" height="510" class="shape raw-meat-how-work">

	<div class="container">
		<div class="intro text-center">
			<div class="heading-36">How It Works</div>
			<span class="semi-para">We use this dummy text to give you an idea how text on this page</span>
		</div>

		<div class="step-wrap">
			<div class="step-box">
				<div class="step-img">
					<img src="assets/images/bbq-box.png" alt="bbq-box" title="" width="160" height="160" class="step-bg-img">
					<img src="assets/images/svg/step-icon1.svg" alt="step-icon1" title="" width="97" height="69" class="step-icon">
				</div>
				<div class="step-info">
					<label class="step-num">step 1</label>
					<div class="heading-18">Choose Your BBQ Box</div>
					<p>Browse our selection of expertly curated BBQ boxes or build your own from scratch. Don’t forget to add extras from our pantry to complete your feast!</p>

					<div class="short-line"></div>
				</div>
			</div>
			<div class="step-box">
				<div class="step-img">
					<img src="assets/images/place-order.png" alt="place-order" title="" width="160" height="160" class="step-bg-img">
					<img src="assets/images/svg/step-icon2.svg" alt="step-icon1" title="" width="72" height="69" class="step-icon">
				</div>
				<div class="step-info">
					<label class="step-num">step 2</label>
					<div class="heading-18">Place Your Order</div>
					<p>Easily place your order online through our secure platform. Whether you're at home or on the go, it’s fast, simple, and convenient.</p>
					<div class="short-line"></div>
				</div>
			</div>
			<div class="step-box">
				<div class="step-img">
					<img src="assets/images/receive-order.png" alt="receive-order" title="" width="160" height="160" class="step-bg-img">
					<img src="assets/images/svg/step-icon3.svg" alt="step-icon1" title="" width="73" height="73" class="step-icon">
				</div>
				<div class="step-info">
					<label class="step-num">step 3</label>
					<div class="heading-18">Receive Your BBQ Box</div>
					<p>We deliver your BBQ box straight to your doorstep, carefully packed on ice to ensure freshness. Just sit back and get ready to grill!</p>
					<div class="short-line"></div>
				</div>
			</div>
			<div class="step-box">
				<div class="step-img">
					<img src="assets/images/fire-grill.png" alt="fire-grill" title="" width="160" height="160" class="step-bg-img">
					<img src="assets/images/svg/step-icon4.svg" alt="step-icon1" title="" width="69" height="74" class="step-icon">
				</div>
				<div class="step-info">
					<label class="step-num">step 4</label>
					<div class="heading-18">Fire Up the Grill</div>
					<p>Unpack your premium BBQ meats &  get grilling! Looking for inspiration? Explore new recipes & tips on our [XXX] page for the ultimate BBQ experience.</p>
					<div class="short-line"></div>
				</div>
			</div>
		</div>



		<div class="button-group">
			<a href="#" class="button btn-theme">Shop Now</a>
			<a href="#" class="button btn-outline">Build Your Box</a>
		</div>
	</div>
</section>
<!-- END CUSTOMERS SAY -->