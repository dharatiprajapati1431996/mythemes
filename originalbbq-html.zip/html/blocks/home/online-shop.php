
<!-- START ONLINE SHOP -->
<section class="online-shop py-90 relative">
	<img src="assets/images/leaf.png" alt="leaf" title="" width="383" height="376" class="shape leaf-left">

	<img src="assets/images/raw-meat-leaf.png" alt="leaf" title="" width="380" height="320" class="shape leaf-right">


	<div class="container">
		<div class="heading-36 text-center">Your Online BBQ Shop</div>

		<div class="online-grid">
			<div class="online-item">
				<a href="#" class="item-box">
					<div class="item-img">
						<img src="assets/images/bbq-meat-box.jpg" alt="bbq meat box" title="" width="500" height="610">
					</div>
					<div class="item-overlay">
						<div class="heading-22">Curated Meat Boxes</div>
						<span class="alink">View More <i class="fa fa-angle-right" aria-hidden="true"></i></span>
					</div>
				</a>
			</div>
			<div class="online-item">
				<a href="#" class="item-box">
					<div class="item-img">
						<img src="assets/images/raw-marbled-beef.jpg" alt="raw marbled beef" title="" width="500" height="300">
					</div>
					<div class="item-overlay">
						<div class="heading-22">Custom Boxes</div>
						<span class="alink">View More <i class="fa fa-angle-right" aria-hidden="true"></i></span>
					</div>
				</a>

				<a href="#" class="item-box">
					<div class="item-img">
						<img src="assets/images/butcher-cutting-pork-meat.jpg" alt="butcher cutting pork meat" title="" width="500" height="300">
					</div>
					<div class="item-overlay">
						<div class="heading-22">Individual Cuts</div>
						<span class="alink">View More <i class="fa fa-angle-right" aria-hidden="true"></i></span>
					</div>
				</a>
			</div>
			<div class="online-item">
				<a href="#" class="item-box">
					<div class="item-img">	
						<img src="assets/images/dips-sauces.jpg" alt="dips sauces" title="" width="500" height="300">
					</div>
					<div class="item-overlay">
						<div class="heading-22">BBQ Pantry</div>
						<span class="alink">View More <i class="fa fa-angle-right" aria-hidden="true"></i></span>
					</div>
				</a>

				<a href="#"class="item-box special-box">
					<div class="item-img">
						<img src="assets/images/grilled-meat.jpg" alt="grilled meat" title="" width="500" height="300">
					</div>
					<div class="item-overlay">
						<div class="heading-40">Special Offers</div>
						<p>Limited time only!s</p>
						<span class="alink">Shop Now <i class="fa fa-angle-right" aria-hidden="true"></i></span>
					</div>
				</a>
			</div>
		</div>
	</div>
</section>
<!-- End ONLINE SHOP -->