<section class="inner-banner relative sec-art">
    <img class="banner_bg" src="assets/images/contact-banner-bg.jpg" height="350" width="1920" alt="image">
    <div class=" inner_banner_info">
        <div class="heading-40 white">contact</div>
        <ul class="woo_breadcums">
            <li>
                <span>
                    <span>
                        <a href="#">Home</a>
                        <span class="breadcrumb_last" aria-current="page">Contact</span>
                    </span>
                </span>
            </li>
        </ul>
    </div>
</section>