
<!--  START CTA WRAPPER -->
<section class="cta-sec">
	<div class="container">
		<div class="cta-wrapper relative">
			<img src="assets/images/cta-bg.jpg" alt="cta wrapper" title="" width="1520" height="216" class="bgimg">
			<div class="cta-inner flex-container wrap">
				<div class="cta-left">
					<div class="bbq-box">
						<img src="assets/images/bbq-box-logo.svg" alt="bbq box logo" title="" width="90" height="93">
					</div>

					<div class="heading-34">As Trusted By As Seen on <span class="bold">Events</span></div>

				</div>
				<div class="cta-right">
					<img src="assets/images/meatstock-logo.svg" alt="meatstock" title="" title="" width="311" height="98" class="meatstock-text">

					<img src="assets/images/showing-raw-steak.png" alt="Showing Raw Steak" title="" title="" width="177" height="198" class="raw-steak">

					<img src="assets/images/grilled-ribeye-steak.png" alt="" title="" width="243" height="165" class="grilld-steak">
				</div>


				<img src="assets/images/veg-icon-group.png" alt="veg icon group" title="" width="826" height="193" class="veg-icon-shape">

			</div>
		</div>
	</div>
</section>
<!--  END CTA WRAPPER -->