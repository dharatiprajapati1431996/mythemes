
<!-- Start instagram -->
<section class="instagram-sec relative py-100"> 

	<img src="assets/images/shape.svg" alt="" title="" width="234" height="168" class="meat-outline-shape shape">

	<div class="container">
		<div class="column-container">
			<div class="heading-36 heading-icon"><img src="assets/images/svg/instagram-black.svg" alt="instagram" title="" width="30" height="30"> Follow us on Instagram</div>


			<a href="#" class="btn-outline btn-instagram button"><img src="assets/images/svg/instagram-black.svg" alt="instagram" title="" width="24" height="24"> originalbbqbox</a>
		</div>
		

		<div class="instagram-wrap">
			<img src="assets/images/instagram.png" alt="instagram" title="" width="1516" height="251">
		</div>

		
	</div>
</section>
<!-- End instagram -->