<?php

$GLOBALS['assets'] = [
    'common' => [
        'styles' => [
             'woocommerce-layout',
            ['src' => 'assets/woo/css/woocommerce-smallscreen', 'media' => 'only screen and (max-width: 768px)'],
            'woocommerce',
            'font-awesome.min', 
            'slick', 
            'slick-theme',  
            'reset', 
            'normalize', 
            'utiliti' ,
            'header', 
            'woo-custom',
            'common',
        ],
        'scripts' => ['jquery', 'slick', 'script'],
    ],
    'home' => [
        'styles' => ['home' , 'smk-accordion' , 'easy-responsive-tabs'],
        'scripts' => [ 'home' , 'smk-accordion' , 'faq' , 'easy-responsive-tabs' , 'tab' , 'audio' ],
    ],
    'about' => [
        'styles' => ['about'],
        'scripts' => [],
    ],
    'how-it-works' => [
        'styles' => ['smk-accordion', 'how-it-works'],
        'scripts' => ['smk-accordion', 'faq', 'product' ],
    ],
    'sourcing' => [
        'styles' => ['smk-accordion', 'sourcing'],
        'scripts' => ['smk-accordion', 'faq'],
    ],
    'contact' => [
        'styles' => ['contact'],
        'scripts' => [],
    ],
    'product-listing' => [
        'styles' => ['product-listing' , 'listgridscript'],
        'scripts' => ['product'],
    ],
    'meat-packs' => [
        'styles' => ['product-listing'],
        'scripts' => [],
    ],
    'product-detail' => [
        'styles' => ['product-detail' , 'smk-accordion'],
        'scripts' => ['product-detail' , 'smk-accordion', 'faq'],
    ],
    'bull-cooking-box' => [
        'styles' => ['product-detail', 'smk-accordion' ],
        'scripts' => ['product-detail' , 'smk-accordion', 'faq'],
    ],
    'large-box' => [
        'styles' => ['product-detail', 'smk-accordion' ],
        'scripts' => ['product-detail' , 'smk-accordion', 'faq'],
    ],
    'area-we-serve' => [
        'styles' => ['areas-we-serve'],
        'scripts' => [],
    ],
    'suburb' => [
        'styles' => ['home', 'easy-responsive-tabs', 'areas-we-serve', 'smk-accordion'],
        'scripts' => ['home', 'easy-responsive-tabs', 'smk-accordion', 'faq', 'tab' , 'audio'],
    ],
    'choose-your-box' => [
        'styles' => ['choose-box'],
        'scripts' => [],
    ],
    'custom-box' => [
        'styles' => ['choose-box'],
        'scripts' => [],
    ],
];