<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="product-detailpg page-wrapper woocommerce page-leaf-right">

	<!-- Inner Banner Section -->
	<section class="inner-banner relative no-banner">
		<div class=" inner_banner_info">
			<ul class="woo_breadcums">
				<li>
					<span>
						<span>
							<a href="#">Home</a>
                            <a href="product-listing.php">Meat Packs</a>
							<span class="breadcrumb_last" aria-current="page">Bull's Cooking Box</span>
						</span>
					</span>
				</li>
			</ul>
		</div>
	</section>
	<!-- Inner Banner Section -->


	<section class="content-bottom py-100 lightyellow bottom-line">
		<div class="container">
			<div class="flex-container wrap items-start">
                <div class="prod-left sticky">

                    <div class="summary-mobile-title-wrap hidden">
                        <div class="summary-title">
                            <div class="heading-36">Bull's Cooking Box</div>
                            <div class="sku-wrap">
                                <div class="star-rating" role="img" aria-label="">
                                    <div class="star-rating" role="img" aria-label="Rated 5 out of 5">
                                        <span style="width:100%">Rated<strong class="rating">5</strong> out of 5</span>
                                    </div>(1)
                                </div>  
                                <span class="sku-text">SKU: H1001SP</span>
                            </div>
                        </div>

                        <div class="price-wrap">
                            <span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>120.40</bdi></span></del> <span class="screen-reader-text">Original price was: 120.40</span><ins aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>100.00</bdi></span></ins><span class="screen-reader-text">Current price is: $100.00</span></span>
                        </div>
                    </div>

                    <div class="product-prod-detail">
                        <div class="product-inner">
                        <div class="zoom-icon">
                            <img src="assets/images/zoom-icon.png" alt="zoom-icon" title="" width="37" height="34">
                        </div>

                            <div class="slider slider-for-prod">

                                <div class="slider-banner-image">
                                    <img src="assets/images/bull-cooking-box.png" alt="Bull's Cooking Box" title="" width="760" height="620">
                                </div>

                                <div class="slider-banner-image">
                                    <img src="assets/images/bull-cooking-box.png" alt="Bull's Cooking Box" title="" width="760" height="620">
                                </div>

                           </div>
                        </div>
                    </div>


                    <div class="categories-wrap">
                        <p>Categories: <a href="">Lamb,</a> <a href="#">BBQ / Grill</a> ,  <a href="#">Grass Fed Beef</a></p>

                        <ul class="share-item">
                            <li>Share this:</li>
                            <li>
                                <a href="#"><img src="assets/images/svg/facebook-black.svg" alt="facebook-black" title="" width="" height=""> </a>
                            </li>
                            <li>
                                <a href="#"><img src="assets/images/svg/instagram-black.svg" alt="instagram-black" title="" width="" height=""> </a>
                            </li>
                            <li>
                                <a href="#"><img src="assets/images/svg/share-black.svg" alt="share-black" title="" width="" height=""> </a>
                            </li>
                        </ul>
                    </div>

                </div>
                <div class="prod-right">  
                    <div class="summary entry-summary">
                        <div class="summary-title">
                            <div class="heading-36">Bull's Cooking Box</div>
                            <div class="sku-wrap">
                                <div class="star-rating" role="img" aria-label="">
                                    <div class="star-rating" role="img" aria-label="Rated 5 out of 5">
                                        <span style="width:100%">Rated<strong class="rating">5</strong> out of 5</span>
                                    </div>(1)
                                </div>  
                                <span class="sku-text">SKU: H1001SP</span>
                            </div>
                        </div>

                        <div class="price-wrap">
                            <span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>120.40</bdi></span></del> <span class="screen-reader-text">Original price was: 120.40</span><ins aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>100.00</bdi></span></ins><span class="screen-reader-text">Current price is: $100.00</span></span>
                        </div>

                        <div class="description-wrap">
                            <p class="para-semi">Curated by Bull himself, this box of meat will level up your bbq game. The box includes:</p>
                        </div>

                        <ul>
                            <li>1 tray of cevapcici</li>
                            <li>2 x Cape Grim beef porterhouse steaks</li>
                            <li>dry cured streaky bacon</li>
                            <li>8 point lamb rack</li>
                        </ul>

                        <div class="subscription-wrap">
                            <div class="head-20">Choose a Subscription Plan</div>
                            <form>
                                <input type="radio" id="html" name="fav_language" value="HTML">
                                <label for="html">Purchase one time</label><br>
                                <input type="radio" id="css" name="fav_language" value="CSS">
                                <label for="css">Subscription</label><br>
                            </form>
                        </div>

                        <div class="deliver-wrap">
                            <div class="head-20">Deliver</div>
                            <form>
                                <select name="" id="" form="carform" class="form-control">
                                  <option value="weekly">Weekly</option>
                                  <option value=""></option>
                                  <option value=""></option>
                                  <option value=""></option>
                                </select>
                            </form>
                        </div>

                        <div class="bottom-line"></div>


                        <div class="quantity-button-wrap">
                            <div class="quantitydiv">
                                <div class="qtytitle">Quantity</div>
                                <div class="quantitybox">
                                    <div class="value-button decrease" id="decrease" onclick="decreaseValue($(this))"
                                        value="Decrease Value">
                                        <img src="assets/images/btn-minus.png" alt="Remove" title="">
                                    </div>
                                    <input type="number" value="0">
                                    <div class="value-button increase" id="increase" onclick="increaseValue($(this))"
                                        value="Increase Value">
                                        <img src="assets/images/btn-plus.png" alt="plus" title="">
                                    </div>
                                </div>
                            </div>

                            <button type="submit" name="add-to-cart" class="btn-theme single_add_to_cart_button button alt">
                                <img src="assets/images/cart.png" alt="Cart" title="Cart" width="21" height="17">Add to Carts
                            </button>
                        </div>


                        <div class="keyfactor-item">
                            <ul class="keyfactor-list">
                                <li>
                                    <div class="keybox">
                                        <div class="keyicon">
                                            <img src="assets/images/svg/grass-fed-beef.svg" alt=" Grass-fed Beef" title="" width="" height="">
                                        </div>
                                        <p>
                                            <span>100%</span>
                                            Grass-fed Beef
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="keybox">
                                        <div class="keyicon">
                                            <img src="assets/images/svg/paddock-to-plate.svg" alt="Paddock to Plate" title="" width="" height="">
                                        </div>
                                        <p>
                                            <span>100%</span>
                                           Paddock to Plate
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="keybox">
                                        <div class="keyicon">
                                            <img src="assets/images/svg/australian-framers.svg" alt="Australian Farmers" title="" width="" height="">
                                        </div>
                                        <p>
                                            <span>100%</span>
                                            Australian Farmers
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="keybox">
                                        <div class="keyicon">
                                            <img src="assets/images/svg/traceable-to-farm.svg" alt="Traceable to Farm" title="" width="" height="">
                                        </div>
                                        <p>
                                            <span>100%</span>
                                            Traceable to Farm
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>



                         <div class="faq_accordion description-accordion">
                            <div class="accordion_in">
                                <div class="faq-head"><h3>Description</h3></div>
                                    <div class="acc_content">
                                        <p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                                    </div>
                            </div>
                            <div class="accordion_in">
                                <div class="faq-head"><h3>Additional information</h3></div>
                                    <div class="acc_content">
                                        <p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                                    </div>
                            </div>
                            <div class="accordion_in">
                                <div class="faq-head"><h3>reviews</h3></div>
                                    <div class="acc_content">
                                        <p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                                    </div>
                            </div>

                            <div class="accordion_in">
                                <div class="faq-head"><h3>Ingredients</h3></div>
                                    <div class="acc_content">
                                        <p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                                    </div>
                            </div>

                            <div class="accordion_in">
                                <div class="faq-head"><h3>Cooking Methods</h3></div>
                                    <div class="acc_content">
                                        <p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
                                    </div>
                            </div>
                            
                        </div>



                    </div>
                </div>
            </div>
		</div>
	</section>

    <section class="related-product py-100 lightyellow">
        <div class="container">
            <div class="heading-36 text-center">You may also like</div>
            <div class="related-product-collection related-prod-js slick-arrow">
                <ul class="products columns-4">
                    <li class="product type-product instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <div class="prod-img">
                                <img src="assets/images/backyard-bbq-box.jpg" alt="Backyard BBQ Box" title="" width="340" height="226">
                            </div>

                            <h2 class="woocommerce-loop-product__title">Backyard BBQ Box</h2>

                             <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>80.99</bdi></span></span>
                        </a>

                        <a href="?add-to-cart=1595" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1595" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1595" data-product_sku="woo-cap" aria-label="Add to cart: “Cap”" rel="nofollow" data-success_message="“Cap” has been added to your cart">Add to cart</a>    
                        <span id="woocommerce_loop_add_to_cart_link_describedby_1595" class="screen-reader-text"></span>
                    </li>

                    <li class="product type-product  instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <span class="onsale special">Special</span>
                            <div class="prod-img">
                                <img src="assets/images/all-the-golds.jpg" alt="All The Golds" title="" width="340" height="226">
                            </div>
                            <h2 class="woocommerce-loop-product__title">All The Golds</h2>

                             <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                             <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>69.99</bdi></span></span>
                        </a>

                        <a href="?add-to-cart=1593" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1593" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1593" data-product_sku="woo-beanie" aria-label="Add to cart: “Beanie”" rel="nofollow" data-success_message="“Beanie” has been added to your cart">Add to cart</a>   <span id="woocommerce_loop_add_to_cart_link_describedby_1593" class="screen-reader-text"></span>
                    </li>

                    <li class="product type-product instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <div class="prod-img">
                                <img src="assets/images/wagyu-burger-pack.jpg" alt="Wagyu Burger Pack" title="" width="" height="">
                            </div>

                            <h2 class="woocommerce-loop-product__title">Wagyu Burger Pack</h2>
                            <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>40.00</bdi></span></span>
                        </a>

                        <a href="?add-to-cart=1610" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1610" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1610" data-product_sku="Woo-beanie-logo" aria-label="Add to cart: “Beanie with Logo”" rel="nofollow" data-success_message="“Beanie with Logo” has been added to your cart">Add to cart</a>  
                        <span id="woocommerce_loop_add_to_cart_link_describedby_1610" class="screen-reader-text"></span>
                    </li>

                    <li class="product type-product instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <div class="prod-img">
                                <img src="assets/images/camping-box.jpg" alt="Camping Box" title="" width="" height="">
                            </div>
                            <h2 class="woocommerce-loop-product__title">Camping Box</h2>

                            <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>90.00</bdi></span></span>
                        </a>
                        <a href="?add-to-cart=1594" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1594" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1594" data-product_sku="woo-belt" aria-label="Add to cart: “Belt”" rel="nofollow" data-success_message="“Belt” has been added to your cart">Add to cart</a>
                        <span id="woocommerce_loop_add_to_cart_link_describedby_1594" class="screen-reader-text"></span>
                    </li>

                    <li class="product type-product instock">
                        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                            <div class="prod-img">
                                <img src="assets/images/lunchbox-winners.jpg" alt="Camping Box" title="" width="" height="">
                            </div>
                            <h2 class="woocommerce-loop-product__title">Lunchbox Winners</h2>

                            <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>90.00</bdi></span></span>
                        </a>
                        <a href="?add-to-cart=1594" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1594" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1594" data-product_sku="woo-belt" aria-label="Add to cart: “Belt”" rel="nofollow" data-success_message="“Belt” has been added to your cart">Add to cart</a>
                        <span id="woocommerce_loop_add_to_cart_link_describedby_1594" class="screen-reader-text"></span>
                    </li>
                </ul>
            </div>
        </div>
    </section>


    <?php  block('home/choose-plan'); ?>
    

	<!-- instagram Sec Start -->
	<?php block('instagram') ?>
	<!-- instagram Sec End -->


    <!-- Start Keyfactor  -->
    <section class="keyfactor-sec">
        <div class="container">
            <?php block('keyfactor'); ?>
        </div>
    </section>
    <!-- End Keyfactor  -->

</main>
<?php get_footer();




