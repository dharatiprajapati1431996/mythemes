<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="homepg woocommerce">

    <?php block('home/banner'); ?>



	<!-- START key factor -->
	<section class="keyfactor-top lightyellow">
		<div class="container">
			<?php block('keyfactor'); ?>
		</div>
	</section>
	<!-- End key factor -->

    <section class="top-content py-90 bottom-line">
    	<div class="container">
    		<div class="center-content text-center">
    			<div class="heading-36">Buy Meat Online Melbourne</div>
    			<p>If you're looking to buy meat online as a Melbourne customer, Original BBQ Box is your ultimate destination for premium, fresh, and meat. Skip the crowded markets and supermarkets and let us deliver the highest quality cuts right to your front door!  </p>
    			<p>From juicy steaks and tender chops to mouth-watering sausages and ribs, we bring the best Australian proteins directly to you. Order online today and sign up for our delicious offer! </p>
    		</div>
    	</div>
    </section>



    <?php  block('home/online-shop'); ?>


    <?php block('home/build-custom-box'); ?>

    <?php  block('home/choose-plan'); ?>

    <?php  block('home/how-it-work'); ?>

    <?php  block('home/certification-accredition'); ?>

    <?php  block('home/home-faq'); ?>

    <?php  block('home/customers-say'); ?>

   <?php  block('cta-wrapper'); ?> 

    <?php  block('home/why-choose'); ?>


    <!--  START CONTENT -->
    <section class="content-sec py-100 lightyellow">
    	<div class="container">
    		<div class="flex-container wrap">
    			<div class="ctent-block">
    				<div class="heading-28">Premium Meat Online to Melbourne Customers </div>
    				<p>When you buy fresh meat online as a Melbourne customer through Original BBQ Box, you're investing in the quality and taste of your meals. </p>
    				<p>Our meat is sourced from ethical and sustainable Australian farming families dedicated to raising animals humanely. Whether you're preparing a quick weekday dinner or hosting a weekend BBQ, our premium meat selection will elevate your experience.</p>
    				<p>We offer a variety of high-end cuts such as Angus and Wagyu steaks, perfect for discerning meat lovers. Our steaks are known for their tenderness; choose from our curated meat boxes for a convenient assortment of premium meats or customise your own box.</p>
    				<p>Each order is backed by our freshness guarantee, so every piece of meat will arrive as fresh as the day it was butchered. With Original BBQ Box, you can enjoy the peace of mind that comes from knowing your meat is sourced ethically and handled with the highest standards of care. </p>
    			</div>
    			<div class="img-block sticky">
    				<img src="assets/images/raw-meat.jpg" alt="raw-meat" title="" width="700" height="500" class="image-radius">
    			</div>
    		</div>

    		<div class="flex-container wrap flex-row-reverse">
    			<div class="ctent-block">
    				<div class="heading-28">High quality Meat Online to Melbourne Meat Lovers</div>
    				<p>For those who prioritise health and sustainability, Original BBQ Box offers organic meat online in Melbourne. Our organic selections are sourced from certified farms that practise humane and eco-friendly farming methods. No antibiotics or hormones are used in raising the livestock, offering you a healthier and more natural meat option.</p>
    				<p>Whether you're a long-time organic enthusiast or just starting to explore organic meat options, our customisable boxes provide a convenient way to enjoy delicious and healthy meals at home. </p>

    				<ul>
    					<li>Our fresh meat delivery service ensures that your food is never frozen, retaining its exceptional quality and taste. </li>
    					<li>We use temperature-controlled packaging to maintain freshness, giving you the assurance that your order will arrive in prime condition.</li>
    				</ul>

    				<p>Whether you’re looking to buy meat online as a customer cooking a family dinner or planning a BBQ, the Original BBQ Box delivers the freshest meat right to you.</p>

    				<div class="heading-24">Buy Meat Online to Melbourne Customers: Order Online! </div>
    				<p>If you’re planning a family gathering, a birthday, or a bigger event, our BBQ boxes will excite any meat enthusiast.</p>
    				<p>Ready to elevate your meals with the finest meat Melbourne has to offer? Visit Original BBQ Box today to buy meat online in Melbourne. Place your order today or call <a href="tel:0467 826 130">0467 826 130</a> if you have any subscription questions!</p>
    			</div>
    			<div class="img-block sticky">
    				<img src="assets/images/fried-meat.jpg" alt="fried-meat" title="" width="700" height="500" class="image-radius">
    			</div>
    		</div>
    	</div>
    </section>
    <!--  End CONTENT -->

    <?php block('instagram'); ?>


    <!-- Start Keyfactor  -->
	<section class="keyfactor-sec">
	    <div class="container">
	        <?php block('keyfactor'); ?>
	    </div>
	</section>
	<!-- End Keyfactor  -->

</main>
<?php get_footer();