<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="choose-boxpg page-wrapper page-left-leaf page-right-raw-meat">

	<!-- Inner Banner Section -->
	<section class="inner-banner relative">
		<img class="banner_bg" src="assets/images/custom-inner-banner.jpg" height="350" width="1920" alt="image">
		<div class=" inner_banner_info">
			<ul class="woo_breadcums">
				<li>
					<span>
						<span>
							<a href="#">Home</a>
							<span class="breadcrumb_last" aria-current="page">Custom Box</span>
						</span>
					</span>
				</li>
			</ul>
		</div>
	</section>
	<!-- Inner Banner Section -->



	<section class="py-100 lightyellow choose-box-sec">
		<div class="container">
			<div class="center-intro text-center small-intro-wrapper">
				<div class="heading-40">Custom Box</div>
				<p>Time to choose your box size.</p>
			</div>

			<div class="custom-grid">

				<a href="" class="choose-item">
					<div class="heading-26 ch-title">Small Box</div>
					<div class="custom-img">
						<img src="assets/images/bbq-box-custom.png" alt="bbq-box-custom" title="" width="" height="">
					</div>
					<div class="choose-info">
						<div class="heading-26">From $159.00</div>
						<ul>
							<li>2-3 people</li>
							<li>Up to 6kg of meat</li>
						</ul>
					</div>
				</a>

				<a href="" class="choose-item">
					<div class="heading-26 ch-title">Large Box</div>
					<div class="custom-img">
						<img src="assets/images/bbq-box-custom.png" alt="bbq-box-custom" title="" width="" height="">
					</div>
					<div class="choose-info">
						<div class="heading-26">From $269.00</div>
						<ul>
							<li>4-5 people</li>
							<li>Up to 11kg of meat</li>
						</ul>
					</div>
				</a>

			</div>


		</div>
	</section>



	<?php  block('home/certification-accredition'); ?>



	<!-- instagram Sec Start -->
	<?php block('instagram') ?>
	<!-- instagram Sec End -->

</main>
<?php get_footer();
