$(document).ready(function () {

  $(".js_hmbanner").slick({
    arrows: false,
    dots: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    horizontal: true,
    infinite: true,
    autoplay: true,
    fade: true,
    pauseOnHover: false,
    autoplaySpeed: 5000,
    responsive: [
      {
        breakpoint: 601,
        settings: {
          arrows: false,
          dots: false,
        },
      },
    ],
  });



	$('.product-slider > ul ').slick({
		arrows:true,
		dots: false,
		infinite: true,
		arrows: true,
		speed: 500,
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: false,	
		responsive: [
		  {
			breakpoint: 1440,
			settings: {
			  slidesToShow: 3,
			  slidesToScroll: 1,
			},
		  },
		  {
			breakpoint: 992,
			settings: {
			  slidesToShow: 2,
			  slidesToScroll: 1,
			},
		  },
		  {
			breakpoint: 361,
			settings: {
			  slidesToShow: 1,
			  slidesToScroll: 1,
			},
		  }		 
		],
	});



	 $("#custom-build ul.resp-tabs-list > li").on('click', function () { 		
	      $('.resp-tab-content  ul.products').slick('refresh');   
	    });



	  $('.customer-say').slick({
	  		arrows:true,
		    dots: false,
		    infinite: true,
		    speed: 300,
		    slidesToShow: 1,
		    centerMode: true,
		    autoplay:true,
		    centerPadding: '400px',
		    responsive: [
			  {
				breakpoint: 1851,
				settings: {
				  centerPadding: '280px',
				},
			  },
			  {
				breakpoint: 1601,
				settings: {
				  slidesToShow: 1,
				  slidesToScroll: 1,
	  			  centerPadding: '200px',
				},
			  },
			  {
				breakpoint: 1440,
				settings: {
				  slidesToShow: 1,
				  slidesToScroll: 1,
	  			  centerPadding: '180px',
				},
			  },
			  {
				breakpoint:992,
				settings: {
				  slidesToShow: 1,
				  slidesToScroll: 1,
	  			  centerMode: false,
		    		centerPadding: '0',
				},
			  }
		 
		],
	 });



});
