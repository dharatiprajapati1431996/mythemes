$( document ).ready(function() { 
    
    $("#custom-build li.resp-tab-item .title_xs").on("mouseover", function() {
    console.log("Mouseover triggered");
    var audioElement = $(this).find("audio")[0];
    if (audioElement) {
        audioElement.play();
    }
    }).on("mouseout", function() {
        console.log("Mouseout triggered");
        var audioElement = $(this).find("audio")[0];
        if (audioElement) {
            audioElement.pause();
            audioElement.currentTime = 0;
        }
    });


});