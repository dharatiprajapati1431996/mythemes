$(document).ready(function ($) {


    // PRODUCT detail Slider

       $(".slider-for-prod").slick({
          arrows: false,
          dots:   false,
          slidesToShow: 1,
          slidesToScroll: 1,
          horizontal: true,
          infinite: true,
          autoplay: true,
          fade: true,
          pauseOnHover: false,
          autoplaySpeed: 5000,
          responsive: [
            {
              breakpoint: 601,
              settings: {
                arrows: false,
                dots: false,
              },
            },
          ],
      });



    //  RELATED SLIDER
        $('.related-prod-js > ul ').slick({
          arrows:true,
          dots: false,
          infinite: true,
          arrows: true,
          speed: 500,
          slidesToShow: 4,
          slidesToScroll: 1,
          autoplay: true, 
          responsive: [
            {
              breakpoint: 1440,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 992,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
                centerPadding: '100px',
              },
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
                centerPadding: '60px',
              },
            }
            ,
            {
              breakpoint: 576,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: true,
                centerPadding: '15px',
              },
            }
         
        ],
    });



});





/*Increment input*/
function increaseValue(ele) {
    console.log(ele.parent().find('input[type="number"]').val());
    var value = ele.parent().find('input[type="number"]').val();
    // var value = parseInt(inputele.value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    ele.parent().find('input[type="number"]').val(value);
    if (value == 0) {
        ele.parents('.roomlistbox').removeClass('selectedinput');
        if ($('.quantitybox').length > 0) {
            ele.parents('.quantitybox').parent().prev().parent().removeClass('selectedinput');
        }
    } else {
        ele.parents('.roomlistbox').addClass('selectedinput');
        if ($('.quantitybox').length > 0) {
            ele.parents('.quantitybox').parent().prev().parent().addClass('selectedinput');
        }
    }
}

function decreaseValue(ele) {
    var value = ele.parent().find('input[type="number"]').val();
    //    var value = parseInt(inputele.value, 10);
    value = isNaN(value) ? 0 : value;
    value < 1 ? value = 1 : '';
    value--;
    ele.parent().find('input[type="number"]').val(value);
    if (value == 0) {
        ele.parents('.roomlistbox').removeClass('selectedinput');
        if ($('.quantitybox').length > 0) {
            ele.parents('.quantitybox').parent().prev().parent().removeClass('selectedinput');
        }
    } else {
        ele.parents('.roomlistbox').addClass('selectedinput');
        if ($('.quantitybox').length > 0) {
            ele.parents('.quantitybox').parent().prev().parent().addClass('selectedinput');
        }
    }
}