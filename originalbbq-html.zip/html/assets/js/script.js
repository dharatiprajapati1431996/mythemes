$(document).ready(function () {
  /*Scroll top*/
  var scrollTop = $(".scrollTop");
  $(window).scroll(function () {
    var topPos = $(this).scrollTop();
    if (topPos > 0) {
      $(scrollTop).css("opacity", "1");
    } else {
      $(scrollTop).css("opacity", "0");
    }
  });
  $(scrollTop).click(function () {
    $("html, body").animate(
      {
        scrollTop: 0,
      },
      600
    );
    return false;
  });
  /*Menu dropdown*/
  var ico = $('<i class="fa fa-angle-down menudrop"></i>');
  $(".menu_link li:has(.submenu) > a").append(ico);
  $(".menudrop").on("click", function (e) {
    $(this).parent().parent().addClass("no-hover");

    $(".menu_link ul li")
      .not($(this).parent().parent())
      .find(".submenu")
      .stop(true, true)
      .delay(200)
      .fadeOut(500);
    $(".menu_link ul li").not($(this).parent().parent()).removeClass("open");
    $(".menu_link ul li a .menudrop").not($(this)).removeClass("openedmenu");
    $(".menu_link ul li a .menudrop").not($(this)).addClass("closemenu");

    e.preventDefault();
    if ($(this).hasClass("openedmenu")) {
      $(this)
        .parent()
        .parent()
        .find(".submenu")
        .stop(true, true)
        .delay(200)
        .fadeOut(500);
      $(this).removeClass("openedmenu");
      $(this).addClass("closemenu");
    } else {
      $(this)
        .parent()
        .parent()
        .find(".submenu")
        .stop(true, true)
        .delay(200)
        .fadeIn(500);
      $(this).removeClass("closemenu");
      $(this).addClass("openedmenu");
    }
  });

  if ($(window).width() >= 1120) {
    $(".menu_link nav > ul > li.has-sub").hover(
      function () {
        $("body").addClass("menuoverlay");
        $(window).trigger("resize");
      },
      function () {
        $("body").removeClass("menuoverlay");
      }
    );
  }

  /*-----BURGER MENU-----*/
  $(".togglebtn, .overlay").click(function () {
    $(".togglebtn, .overlay, .menu_link").toggleClass("active");
    if ($(".overlay").hasClass("active")) {
      $(".overlay").fadeIn();
      $("html").addClass("menuhidden");
    } else {
      $(".overlay").fadeOut();
      $("html").removeClass("menuhidden");
    }
  });

  /*-----FIXED HEADER-----*/

  $(window).scroll(function () {
    if ($(window).scrollTop() > 200 && $(window).width() >= 319) {
      $("body").addClass("fixed-header");
    } else {
      $("body").removeClass("fixed-header");
    }
  });



  //  Search Bar

    // $('.search-wrap .searchcontrol').hover(
    //     function() {
    //         // On mouse enter, add the class to the parent
    //         $(this).parent().addClass('hovered');
    //     },
    //     function() {
    //         // On mouse leave, remove the class from the parent
    //         $(this).parent().removeClass('hovered');
    //     }
    // );
    

    // $('.search-wrap .searchcontrol').on('click', function() {
    //     $(this).parent().toggleClass('hovered');
    // });


       // $('.search-wrap .searchcontrol').on('click', function() {
       //      $(this).parent().toggleClass('hovered');
       //  });

    


  // CLIENT REVIEW

  $(".client-js").slick({
    arrows: false,
    dots: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    horizontal: true,
    infinite: true,
    autoplay: true,
    pauseOnHover: false,
    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
          centerMode: true,
          centerPadding: '30px',
        },
      },
      {
        breakpoint: 481,
        settings: {
          slidesToShow: 1,
          centerMode: true,
          centerPadding: '20px',
        },
      }
    ],
  });



    const init = {
      autoplay: true,
      infinite: true,
      cssEase: "linear",
      slidesToShow: 3,
      slidesToScroll: 1,
      true:false,
      dot:false,
      autoplay: true,
      arrows: false,
      autoplaySpeed: 3000,
        responsive: [
         
          {
            breakpoint: 992,
            settings: {
                      slidesToShow: 2,
            }
          },
          {
            breakpoint: 576,
            settings: {
                      slidesToShow: 1,
            }
          }
        ]
      };

      $(() => {
      const win = $(window);
      const slider = $(".keyfactor-js");

      win.on("load resize", () => {
          if (win.width() < 1440) {
              slider.not(".slick-initialized").slick(init);
            } else if (slider.hasClass("slick-initialized")) {
              slider.slick("unslick");
            }
        });
    });


  
});



// +++++++++++++++++++++++++++++++  Search var for desktop 

  $(document).ready(function () {
      // Toggle the 'hovered' class on the parent when the form is clicked
      $('.search-wrap .searchcontrol').on('click', function (e) {
          e.stopPropagation(); // Prevent click from bubbling up
          $(this).parent().toggleClass('hovered');
      });

      // Remove the 'hovered' class when the close button is clicked
      $('.close-form').on('click', function (e) {
          e.stopPropagation(); // Prevent click from bubbling up
          $('.search-wrap').removeClass('hovered');
      });

      // Optional: Close the search-wrap when clicking outside
      $(document).on('click', function () {
          $('.search-wrap').removeClass('hovered');
      });

      // Prevent the click inside the search-wrap from closing it
      $('.search-wrap').on('click', function (e) {
          e.stopPropagation(); // Allow clicks inside the search-wrap
      });




  // Mobile search toggle 
        $('.accout-wrap li a.search-on-link').on('click', function(e) {
           e.preventDefault(); // Prevent default link behavior

            // Toggle visibility of the .search-show-mobile div
            $('.search-show-mobile').toggleClass('hidden');

            // Add or remove the active class on the parent .head-ecommerce div
            $('.head-ecommerce').toggleClass('show-search-bar');
        });
       
  });
