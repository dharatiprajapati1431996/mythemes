$(document).ready(function () {


	// for mobile filter slide -->
    $(document).on('click', 'a.m_filtertrigger, a.closemenu', function (e) {
        //alert("test");
        e.preventDefault();
        $(".mobile-slide").toggleClass("slide");
        $("body").toggleClass("overlayshow");
    });

    /*$('#enq_sortby').popup({
        transition: 'all 0.5s',
        opacity: '0.9'
    });*/

    $(".filterbyprice_container span").click(function () {
        $(".filterbyprice_container .filterpricediv").stop().slideToggle();
    });



	//  SLIDER 

	$('.premium-js > ul ').slick({
		arrows:true,
		dots: false,
		infinite: true,
		arrows: true,
		speed: 500,
		slidesToShow: 4,
		slidesToScroll: 1,
		autoplay: false,	
		responsive: [
		  {
			breakpoint: 1440,
			settings: {
			  slidesToShow: 3,
			  slidesToScroll: 1,
			},
		  },
		  {
			breakpoint: 992,
			settings: {
			  slidesToShow: 2,
			  slidesToScroll: 1,
			},
		  },
		  {
			breakpoint: 361,
			settings: {
			  slidesToShow: 1,
			  slidesToScroll: 1,
			},
		  }		 
		],
	});


});
