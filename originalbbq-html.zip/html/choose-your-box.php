<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="choose-boxpg page-wrapper page-left-leaf page-right-raw-meat">

	<!-- Inner Banner Section -->
	<section class="inner-banner relative">
		<img class="banner_bg" src="assets/images/choose-box-inner-banner.jpg" height="350" width="1920" alt="image">
		<div class=" inner_banner_info">
			<ul class="woo_breadcums">
				<li>
					<span>
						<span>
							<a href="#">Home</a>
							<span class="breadcrumb_last" aria-current="page">Choose your box</span>
						</span>
					</span>
				</li>
			</ul>
		</div>
	</section>
	<!-- Inner Banner Section -->



	<section class="py-100 lightyellow choose-box-sec">
		<div class="container">
			<div class="center-intro text-center small-intro-wrapper">
				<div class="heading-40">Choose your box</div>
				<p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
			</div>

			<div class="custom-grid">

				<a href="" class="choose-item">
					<div class="heading-26 ch-title">Custom Box</div>
					<div class="custom-img">
						<img src="assets/images/bbq-box-custom.png" alt="bbq-box-custom" title="" width="" height="">
					</div>
					<div class="choose-info">
						<div class="heading-18">Build your own</div>
						<span class="alink">Learn more <img src="assets/images/caret-right.png" alt="" title="" width="" height=""></span>
					</div>
				</a>

				<a href="" class="choose-item">
					<div class="heading-26 ch-title">Curated Boxes</div>
					<div class="custom-img">
						<img src="assets/images/bbq-box-custom.png" alt="bbq-box-custom" title="" width="" height="">
					</div>
					<div class="choose-info">
						<div class="heading-18">Curated by us</div>
						<span class="alink">Learn more <img src="assets/images/caret-right.png" alt="" title="" width="" height=""></span>
					</div>
				</a>

			</div>


		</div>
	</section>



	<?php  block('home/certification-accredition'); ?>



	<!-- instagram Sec Start -->
	<?php block('instagram') ?>
	<!-- instagram Sec End -->

</main>
<?php get_footer();
