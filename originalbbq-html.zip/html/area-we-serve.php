<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="area-we-serve-pg page-wrapper">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative">
        <img class="banner_bg" src="assets/images/area-we-serve-banner.jpg" height="350" width="1920" alt="image">
        <div class=" inner_banner_info">
            <div class="heading-40 white">meat delivery near me</div>

            <form class="suburb-search-form" method="post" action="/">
                <input type="search" name="suburb_locations" value="" placeholder="Suburb / Postcode" class="ui-autocomplete-input" autocomplete="off">
                <button type="button"><img src="assets/images/svg/search.svg" alt="search-icon" title="search-icon" width="" height=""></button>
                <ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" unselectable="on" style="display: none;"></ul>
            </form>

        </div>
    </section>
    <!-- Inner Banner Section -->

    <div class="sm-woo_breadcums">
        <div class="container">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>                            
                            <span class="breadcrumb_last" aria-current="page">Areas We Serve </span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </div>

    <!--  START CONTENT -->
    <section class="content-sec py-100">
        <div class="container">
            <div class="flex-container wrap flex-row-reverse">
                <div class="ctent-block">
                    <div class="heading-28">Supple during web designing in case we don't have content</div>
                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new
                        NON SEO pages and it is changed during development of the new site. Hence, don't worry about
                        this dummy text. We use this dummy text to give you an idea how text on this page would look like as
                        a site user.</p>

                    <p>We use it at Supple during web designing in case we don't have content for new NON SEO pages
                        and it is changed during development of the new site. Hence, don't worry about this dummy text.
                        We use this dummy text to give you an idea how text on this page would look like as a site user.</p>

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new
                        NON SEO pages and it is changed during development of the new site. </p>

                    <p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on
                        this page would look like as a site user.</p>

                </div>
                <div class="img-block sticky">
                    <img src="assets/images/area-we-serve-content.jpg" alt="beef" title="" width="700" height="444" class="image-radius">
                </div>
            </div>
        </div>
    </section>
    <!--  End CONTENT -->

    <!--  START CONTENT -->
    <section class="content-sec py-100 lightyellow">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block area-we-serve-content">
                    <div class="heading-28">Areas We Serve </div>
                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.</p>

                    <ul class="areas-sec-list">
                        <li><a href="#">Meat Delivery Geelong</a></li>
                        <li><a href="#">Meat Delivery Cheltenham</a></li>
                        <li><a href="#">Meat Delivery Glen-Iris</a></li>
                        <li><a href="#">Meat Delivery South-Yarra</a></li>
                        <li><a href="#">Meat Delivery Brighton</a></li>
                        <li><a href="#">Meat Delivery Doncaster</a></li>
                        <li><a href="#">Meat Delivery Ringwood</a></li>
                        <li><a href="#">Meat Delivery Richmond</a></li>
                        <li><a href="#">Meat Delivery Thornbury</a></li>
                        <li><a href="#">Meat Delivery Northcote</a></li>
                        <li><a href="#">Meat Delivery Ivanhoe</a></li>
                    </ul>

                    <div class="button-group">
                        <a href="#" class="button btn-theme">Shop Now</a>
                        <a href="#" class="button btn-outline">Build Your Box</a>
                    </div>
                </div>
                <div class="area-item areas-sec-img img-block sticky">
                    <div class="areas-sec-map">
                        <iframe
                            src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=Beaumaris%20%20Australia+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"
                            width="100%" height="432" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade" data-gtm-yt-inspected-6="true"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  End CONTENT -->

    <!-- instagram Sec Start -->
    <?php block('instagram') ?>
    <!-- instagram Sec End -->

</main>
<?php get_footer();
