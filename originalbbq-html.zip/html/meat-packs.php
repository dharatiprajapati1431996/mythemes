<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="product-listingpg page-wrapper woocommerce">

	<!-- Inner Banner Section -->
	<section class="inner-banner relative">
		<img class="banner_bg" src="assets/images/meat-packs-inner.jpg"  height="350" width="1920" alt="Meat Packs" title="">
		<div class=" inner_banner_info">
			<div class="heading-40 white">Meat Packs</div>
			<ul class="woo_breadcums">
				<li>
					<span>
						<span>
							<a href="#">Home</a>
							<span class="breadcrumb_last" aria-current="page">Meat Packs</span>
						</span>
					</span>
				</li>
			</ul>
		</div>
	</section>
	<!-- Inner Banner Section -->


	<section class="content-bottom py-100 lightyellow">
		<div class="container">
			<div class="flex-container wrap">
				<div class="left-panel sticky">

                    <div class="mobile-slide">
                        <a href="#" class="closemenu desk-hide">
                            <img src="assets/images/menu-close.png" alt="close" width="" height="">
                        </a>
                        <div class="categorylistbox">
                            <p>Wordpress plugin Here</p>
                        </div>
                    </div>

					<div class="leftcolfilter">
                        <div class="heading-filter">Product Categories</div>
                        <p>Wordpress plugin Here</p>
                    </div>


					<div class="your-plan-wrap relative">
						<img src="assets/images/grilled-meat-with-sauces.jpg" alt="grilled meat with sauces" title="" width="360" height="455" class="bgimg">  
						<div class="plan-inner">
							<div class="intro">
								<div class="heading-26">Choose your plan</div>
							</div>

							<div class="plan-wrap">
								<div class="plan-box subsription-box">
									<div class="head-20">Subscription Options Available</div>
									<ul class="plan-list">
										<li>Weekly</li>
										<li>Fortnightly</li>
										<li>Monthly</li>
									</ul>
								</div>
								<div class="plan-box benefit-wrap">
									<div class="head-20">Benefits</div>
									<ul class="plan-list">
										<li>Flexible Subscriptions</li>
										<li>Pause or Cancel Anytime</li>
									</ul>
								</div>
							</div>
							<a href="#" class="button btn-primary">Build Your Box</a>
						</div>

					</div>
				</div>
				<div class="right-panel">

                    <div class="mobilefilter_box hide-in-desktop">
                        <a href="javascript:void(0);" class="button btn-theme m_filtertrigger"><span> Filter </span>
                            <i class="fa fa-filter"></i>
                        </a>
                    </div>

					<div class="product-wc-header bottom-line">
                        <p class="woocommerce-result-count">You're viewing 1-26 of 26 products</p>
                        <div class="pro_listfilterdiv_right">
                            <form class="woocommerce-ordering" method="get">
                                <select name="orderby" class="orderby" aria-label="Shop order">
                                    <option value="menu_order" selected="selected">Sort: Best selling</option>
                                    <option value="popularity">Sort by popularity</option>
                                    <option value="rating">Sort by average rating</option>
                                    <option value="date">Sort by latest</option>
                                    <option value="price">Sort by price: low to high</option>
                                    <option value="price-desc">Sort by price: high to low</option>
                                </select>
                                <input type="hidden" name="paged" value="1">
                            </form>
                            <div class="sortcolnumber">
                                <a href="" class="grid-col-3 grid-col">
                                	<img src="assets/images/svg/grid-3.svg" alt="grid-3" title="" width="" height="">
                                </a>
                                <a href="" class="grid-col-1 grid-col active">
                                	<img src="assets/images/svg/grid-1.svg" alt="grid-3" title="" width="" height="">
                                </a>
                            </div>
                            
                        </div>
                    </div>

                    <div class="product-wrapper-collection">
                    	<ul class="products columns-3">
                    		<li class="product type-product instock">
                                <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                    <div class="prod-img">
                                        <img src="assets/images/backyard-bbq-box.jpg" alt="Backyard BBQ Box" title="" width="340" height="226">
                                    </div>

                                    <h2 class="woocommerce-loop-product__title">Backyard BBQ Box</h2>

                                     <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                    <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>80.99</bdi></span></span>
                                </a>

                                <a href="?add-to-cart=1595" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1595" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1595" data-product_sku="woo-cap" aria-label="Add to cart: “Cap”" rel="nofollow" data-success_message="“Cap” has been added to your cart">Add to cart</a>    
                                <span id="woocommerce_loop_add_to_cart_link_describedby_1595" class="screen-reader-text"></span>
                            </li>

                            <li class="product type-product  instock">
                                <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                    <span class="onsale special">Special</span>
                                    <div class="prod-img">
                                        <img src="assets/images/all-the-golds.jpg" alt="All The Golds" title="" width="340" height="226">
                                    </div>
                                    <h2 class="woocommerce-loop-product__title">All The Golds</h2>

                                     <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                     <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>69.99</bdi></span></span>
                                </a>

                                <a href="?add-to-cart=1593" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1593" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1593" data-product_sku="woo-beanie" aria-label="Add to cart: “Beanie”" rel="nofollow" data-success_message="“Beanie” has been added to your cart">Add to cart</a>   <span id="woocommerce_loop_add_to_cart_link_describedby_1593" class="screen-reader-text"></span>
                            </li>

                            <li class="product type-product instock">
                                <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                    <div class="prod-img">
                                        <img src="assets/images/wagyu-burger-pack.jpg" alt="Wagyu Burger Pack" title="" width="" height="">
                                    </div>

                                    <h2 class="woocommerce-loop-product__title">Wagyu Burger Pack</h2>
                                    <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                    <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>40.00</bdi></span></span>
                                </a>

                                <a href="?add-to-cart=1610" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1610" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1610" data-product_sku="Woo-beanie-logo" aria-label="Add to cart: “Beanie with Logo”" rel="nofollow" data-success_message="“Beanie with Logo” has been added to your cart">Add to cart</a>  
                                <span id="woocommerce_loop_add_to_cart_link_describedby_1610" class="screen-reader-text"></span>
                            </li>

                            <li class="product type-product instock">
                                <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                    <div class="prod-img">
                                        <img src="assets/images/camping-box.jpg" alt="Camping Box" title="" width="" height="">
                                    </div>
                                    <h2 class="woocommerce-loop-product__title">Camping Box</h2>

                                    <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                    <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>90.00</bdi></span></span>
                                </a>
                                <a href="?add-to-cart=1594" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1594" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1594" data-product_sku="woo-belt" aria-label="Add to cart: “Belt”" rel="nofollow" data-success_message="“Belt” has been added to your cart">Add to cart</a>
                                <span id="woocommerce_loop_add_to_cart_link_describedby_1594" class="screen-reader-text"></span>
                            </li>

                            <li class="product type-product instock">
                                <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                    <div class="prod-img">
                                        <img src="assets/images/lunchbox-winners.jpg" alt="Camping Box" title="" width="" height="">
                                    </div>
                                    <h2 class="woocommerce-loop-product__title">Lunchbox Winners</h2>

                                    <div class="star-rating" role="img" aria-label="Rated 3.00 out of 5"><span style="width:60%">Rated <strong class="rating">3.00</strong> out of 5</span></div>

                                    <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>90.00</bdi></span></span>
                                </a>
                                <a href="?add-to-cart=1594" aria-describedby="woocommerce_loop_add_to_cart_link_describedby_1594" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="1594" data-product_sku="woo-belt" aria-label="Add to cart: “Belt”" rel="nofollow" data-success_message="“Belt” has been added to your cart">Add to cart</a>
                                <span id="woocommerce_loop_add_to_cart_link_describedby_1594" class="screen-reader-text"></span>
                            </li>
      
                        </ul>
                    </div>


                    <div class="product-bottom-wrap">
                    	<p class="woocommerce-result-count">You're viewing 1-26 of 26 products</p>

                    	<nav class="woocommerce-pagination">
                            <ul class="page-numbers">
                                <li><a class="prev page-numbers" href=""><i class="fa fa-angle-left"></i></a></li>
                                <li><a class="page-numbers" href="">1</a></li>
                                <li><span aria-current="page" class="page-numbers current">2</span></li>
                                <li><a class="page-numbers" href="">3</a></li>
                                <li><a class="next page-numbers" href=""><i class="fa fa-angle-right"></i></a></li>
                            </ul>
                        </nav>
                    </div>



				</div>
			</div>
		</div>
	</section>

	<!-- START key factor -->
	<section class="keyfactor-top inner-keyfactor bottom-line">
		<div class="container">
			<?php block('keyfactor'); ?>
		</div>
	</section>
	<!-- End key factor -->


	<section class="content-sec py-100 bottom-line">
    	<div class="container">
    		<div class="flex-container wrap">
    			<div class="ctent-block">
    				<div class="heading-28">Supple during web designing in case we don't have content </div>

    				<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>

    				<p>We use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site.  Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>

    				<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new NON SEO pages and it is changed during development of the new site. </p>

    				<p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would look like as a site user.</p>
    				
    			</div>
    			<div class="img-block sticky">
    				<img src="assets/images/happy-family.jpg" alt="Happy Family" title="" width="700" height="500" class="image-radius">
    			</div>
    		</div>

    	</div>
    </section>



	<!-- instagram Sec Start -->
	<?php block('instagram') ?>
	<!-- instagram Sec End -->


    <!-- Start Keyfactor  -->
    <section class="keyfactor-sec">
        <div class="container">
            <?php block('keyfactor'); ?>
        </div>
    </section>
    <!-- End Keyfactor  -->

</main>
<?php get_footer();




