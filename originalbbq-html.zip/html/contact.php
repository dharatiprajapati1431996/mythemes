<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="contactpg page-wrapper page-left-leaf page-right-raw-meat">

	<!-- Inner Banner Section -->
	<section class="inner-banner relative">
		<img class="banner_bg" src="assets/images/contact-inner.jpg" height="350" width="1920" alt="image">
		<div class=" inner_banner_info">
			<div class="heading-40 white">Contact</div>
			<ul class="woo_breadcums">
				<li>
					<span>
						<span>
							<a href="#">Home</a>
							<span class="breadcrumb_last" aria-current="page">Contact</span>
						</span>
					</span>
				</li>
			</ul>
		</div>
	</section>
	<!-- Inner Banner Section -->


	<!-- getintouch start -->
	<section class="contactus-form-sec border-bottom">
		<div class="container">
			<div class="contact-wrapper flex-container justify-between wrap items-start">
				<div class="contact-left-block">
					<div class="address-detail-sec">
						<div class="heading-28">General enquiries</div>

						<div class="contact-detail-wraper">
							<div class="address-left-block">
								<ul>
									<li>
										<div class="address-box">
											<span>
												<img src="assets/images/svg/contact-phone.svg" alt="call-icon" width="15" height="15">
											</span>
											<div class="address-detail">
												<label for="">Phone</label>
												<a href="tel:0467 826 130">0467 826 130</a>
											</div>
										</div>
									</li>
									<li>
										<div class="address-box">
											<span>
												<img src="assets/images/svg/email-light.svg" alt="email-icon" width="16" height="13">
											</span>
											<div class="address-detail">
												<label for="">Email</label>
												<a href="mailto:info@originalbbqbox.com.au">info@originalbbqbox.com.au</a>
											</div>
										</div>
									</li>
								</ul>
							</div>
							<div class="social-right-block">
								<ul>
									<p>Follow us now</p>
									<li>
										<div class="address-box socialicon">
											<a href="#!">
												<span>
													<img src="assets/images/svg/facebook-black.svg" alt="facebook" width="28" height="28">
												</span>
											</a>
											<a href="#!">
												<span>
													<img src="assets/images/svg/instagram-black.svg" alt="instagram" width="25" height="25">
												</span>
											</a>
										</div>
									</li>
								</ul>
							</div>
						</div>

						<div class="keyfactor-sec">
							<div class="keyfactor-wrapper wrap">
								<div class="keyfact-box">
									<div class="key-icon">
										<img src="assets/images/svg/easy-online-order.svg" alt="easy-online-order" title="" width="34" height="34">
									</div>
									<div class="key-info">
										<p>Easy online ordering process</p>
									</div>
								</div>

								<div class="keyfact-box">
									<div class="key-icon">
										<img src="assets/images/svg/free-shipping.svg" alt="free-shipping" title="" width="33" height="22">
									</div>
									<div class="key-info">
										<p>Free Shipping on all curated box orders</p>
									</div>
								</div>

								<div class="keyfact-box">
									<div class="key-icon">
										<img src="assets/images/svg/certified-humane-care.svg" alt="certified-humane-care" title="" width="35" height="35">
									</div>
									<div class="key-info">
										<p>Certified humane animal care</p>
									</div>
								</div>

								<div class="keyfact-box">
									<div class="key-icon">
										<img src="assets/images/svg/environment-friendly.svg" alt="environment-friendly" title="" width="35" height="30">
									</div>
									<div class="key-info">
										<p>Environmentally friendly</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="contact-right-block">
					<div class="contact-form-box sec-art">
						<div class="home-address-head">
							<div class="heading-28">Send us a message</div>
							<p>If you have any questions for original BBQ box, we'd love to help.</p>
						</div>

						<form class="form-box">
							<div class="row">
								<div class="form-group width50">
									<input class="form-control" type="text" name="fname" placeholder="First Name">
								</div>
								<div class="form-group width50">
									<input class="form-control" type="text" name="lname" placeholder="Surname">
								</div>
							</div>

							<div class="row">
								<div class="form-group width50">
									<input class="form-control" type="number" name="phone" placeholder="Mobile Number">
								</div>
								<div class="form-group width50">
									<input class="form-control" type="text" name="Email" placeholder="Email Address">
								</div>
							</div>

							<div class="row">
								<div class="form-group width100">
									<textarea placeholder="Message" class="form-control"></textarea>
								</div>
							</div>

							<div class="form-group formsubmit_btn">
								<input type="submit" name="" value="Submit" class="btnsubmit">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- getintouch start -->



	<!-- instagram Sec Start -->
	<?php block('instagram') ?>
	<!-- instagram Sec End -->

</main>
<?php get_footer();
