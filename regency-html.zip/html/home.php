<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="homepg">

    <?php block('home/banner'); ?>

    <?php block('key-feature'); ?>

    <section class="content-wrapper relative py-lg-120">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block">
                    <div class="intro">
                        <div class="semi-head">At Regency Plastics</div>
                        <div class="heading-40">Precision-Engineered Plastic Solutions for Every Industry
                        </div>
                    </div>

                    <p>With decades of experience, Regency Plastics delivers precision-engineered solutions across various industries, specializing in high-quality materials like acrylic, polycarbonate, and HDPE to ensure durability, performance, and exceptional customer service.</p>

                    <ul>
                    	<li>Known for precision-engineered, durable solutions tailored to industry needs.</li>
                    	<li>Specializing in acrylic, polycarbonate, HDPE, and more</li>
                    	<li>Trusted in Melbourne and the surrounding areas for quality and fast service.</li>
                    </ul>

                    <a href="#" class="button button-outline">Learn more about us <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

                </div>
                <div class="img-block sticky trangle-shape">
                    <div class="img-shape">
                        <img src="assets/images/plastic-industry.png" alt="plastic-industry" title="" width="634"
                            height="525">
                    </div>
                </div>
            </div>
        </div>

        <img src="assets/images/melbourne-leader.png" alt="melbourne-leader" title="" width="624" height="259" class="leader-img">
    </section>


    
	<?php block('home/how-it-work'); ?>

	<?php block('home/cta-sec'); ?> 

    <?php block('home/explore-product-services'); ?>

    <?php block('home/why-choose'); ?> 

    <?php block('home/our-workshop-videos'); ?> 

    <?php block('home/cta-sec'); ?> 
   
    <?php block('home/our-work-gallery'); ?>

    <?php block('home/hm-industries'); ?>

    <?php block('home/hm-contact'); ?>

    <?php block('home/hm-faq'); ?>

    <section class="content-wrapper divider-bottom white-bg pt-lg-120">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block">
                    <div class="intro">
                        <div class="semi-head">At Regency Plastics</div>
                        <div class="heading-40">Melbourne’s Leader in Industrial and Engineering Plastic Fabrication
                        </div>
                    </div>

                    <p>With many years of combined experience in the industry, we are your one stop shop for all your
                        plastic needs. With sheets, rods and tubes available, we can meet the requirements of countless
                        different industries by supplying products suitable for a variety of applications. The key to
                        our service is that we can offer a solution that is specifically customised for your
                        circumstances. Whatever your needs may be, we are here to assist you.
                    </p>

                    <p>Our experience in <a href="#">plastic fabrication</a> will allow us to properly help all our
                        clients make the right decisions on what products to buy, ensuring that they are the right fit
                        for their intended purpose. Through our comprehensive expertise and commitment to high
                        standards, we have earned a lot of referrals and retained many repeat customers who know we will
                        get the job done quickly and efficiently. Thanks to our history assisting businesses with all
                        kinds of plastic fabrication, Regency Plastics have become the trusted experts who can deliver
                        accurate fabrication works to suit your needs.</p>

                    <div class="heading-30">The Experts in Plastic Cut to Size</div>

                    <p>Regency Plastics can have engineering and industrial plastic cut to size at our Melbourne
                        workshop at an affordable price with a quick turnaround. We are the team you can turn to when
                        you need unique products, parts or components that are designed especially for your industry and
                        the intended application. From plastic sheets to plastic rods, our team is here to assist you
                        with whatever you need.</p>
                </div>
                <div class="img-block sticky trangle-shape">
                    <div class="img-shape">
                        <img src="assets/images/machine-guards.jpg" alt="machine-guards" title="" width="634"
                            height="457">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php block('footer-instagram'); ?>

</main>
<?php get_footer();