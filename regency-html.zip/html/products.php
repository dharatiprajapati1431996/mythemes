<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper product-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner mb-50">
					 <img src="assets/images/product-banner.jpg" alt="product-banner" width="1920" height="530" class="bgimg">
        <div class="container">
            <div class="inbanner-content">
													   <div class="heading-54">Products</div>
                <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="home.php">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Products</span>
                                </span>
                            </span>
                        </li>
                    </ul>
									   </div>
        </div>

        <div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
			 </section>
    <!-- Inner Banner Section -->
		
	   <!-- key feature -->
			<?php block('key-feature'); ?>
	   
	  <!-- product listing -->
    <section class="sec-product mb-80">
       <div class="container">
								
								 <div class="product-content-wrap">
												<p>Here at Regency Plastics we provide a wide range of different products. We specialise in plastic sheet, rod and tubes carry a broad selection of these products in stock – as well as a range of other products.</p>
								 </div>
								
								 <ul class="product-ul">
									  <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/abs-image.jpg" alt="abs image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">ABS</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about ABS <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/acetal-image.jpg" alt="acetal-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Acetal
																							(Delrin, Ertacetal, Sustarin)</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Acetal <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/acrylic-image.jpg" alt="acrylic-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Acrylic (Perspex)</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>Looking for top-quality acrylic sheet suppliers in Melbourne and the surrounding areas?</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Acrylic<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/bait-boards-image.jpg" alt="bait-boards-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Bait Boards (Seaboard, Uniboard)</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Bait Boards<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/corflute-image.jpg" alt="corflute-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Corflute</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Corflute<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/hdpe-image.jpg" alt="hdpe-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">HDPE</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>When it comes to HDPE products, Regency Plastics has the high-quality solutions you are seeking for your business.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about HDPE<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/hips-image.jpg" alt="hips-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">HIPS</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about HIPS<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/nylon-ertalon-image.jpg" alt="nylon-ertalon-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Nylon (Ertalon)</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Nylon<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/petg-image.jpg" alt="petg-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">P.E.T.G</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about P.E.T.G<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/polycarbonate-image.jpg" alt="polycarbonate-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Polycarbonate (Lexan, Makralon)</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>Rigid polypropylene sheets have a range of advantages and applications for various industries.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Polycarbonate<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/polypropylene-image.jpg" alt="abs image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Polypropylene</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Polypropylene<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/pvc-image.jpg" alt="pvc-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">PVC</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about PVC<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/teflon-image.jpg" alt="teflon-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Teflon (PTFE)</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about ABS <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/uhmwpe-image.jpg" alt="uhmwpe-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">UHMWPE</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about UHMWPE<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/vesconite-image.jpg" alt="vesconite-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Vesconite</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Vesconite<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
								 </ul>
								 
						 </div>
    </section>
	
	  <!-- content section -->
		<section class="content-wrapper white-bg pt-120">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block">
                    <div class="intro">
                        <div class="semi-head">At Regency Plastics</div>
                        <div class="heading-40">Our Other Products
                        </div>
                    </div>
																	  <p>In addition to plastic sheets, rods and tubes, we also manufacture a range of other products – many of which can be customised to suit your individual requirements. We offer high quality wear strips, cutting boards and even display boxes that can be fabricated from a range of different plastics.</p>
																	 <p>For more information on our plastic, sheet, rod and tubes other fabricated products, give us a call on <a href="tel:(03)97614452">(03) 9761 4452</a> or fill out our enquiry form.</p>
														 </div>
                <div class="img-block sticky trangle-shape">
                    <div class="img-shape">
                        <img src="assets/images/machine-guards.jpg" alt="machine-guards" title="" width="634" height="457">
                    </div>
                </div>
            </div>
        </div>
    </section>
 
	 <?php block('home/hm-contact'); ?>
	
	   <?php block('footer-instagram'); ?>

</main>
<?php get_footer();