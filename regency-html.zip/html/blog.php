<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="page-wrapper blog-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner">
		<img src="assets/images/blog-banner-image.jpg" alt="contact-banner" width="1920" height="530" class="bgimg">
        <div class="container">
            <div class="inbanner-content">
				<div class="heading-54">Blog</div>
                <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="home.php">Home</a>
									<span class="breadcrumb_last" aria-current="page">Blog</span>
                                </span>
                            </span>
                        </li>
                    </ul>
			</div>
        </div>
        <div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
	</section>
    <!-- Inner Banner Section -->
			
	   <!-- blog listing -->
	   <section class="sec-blog">
	     <div class="container">
					     <ul class="blog-ul">
												<li>
															<a href="#">
																	<div class="blog-li">
																				<div class="blog-img">
																						<img src="assets/images/blog-image.jpg" alt="blog image" title="" width="440" height="300">
																		  </div>
																		  <div class="blog-bottom">
																						 <div class="blog-label">December 13, 2024</div>
																					  <div class="blog-title">The Beauty and Versatility of Coloured Acrylic Sheets in Various Industries</div>
																		  </div>
																 </div>
													  </a>
											 </li>
											 <li>
															<a href="#">
																	<div class="blog-li">
																				<div class="blog-img">
																						<img src="assets/images/blog-image1.jpg" alt="blog image" title="" width="440" height="300">
																		  </div>
																		  <div class="blog-bottom">
																						 <div class="blog-label">December 18, 2024</div>
																					  <div class="blog-title">This is dummy text, we use it at Supple during web designing in case we don't have content</div>
																		  </div>
																 </div>
													  </a>
											 </li>
											<li>
															<a href="#">
																	<div class="blog-li">
																				<div class="blog-img">
																						<img src="assets/images/blog-image2.jpg" alt="blog image" title="" width="440" height="300">
																		  </div>
																		  <div class="blog-bottom">
																						 <div class="blog-label">December 25, 2024</div>
																					  <div class="blog-title">We use this dummy text to give you an idea how text on this page would look like</div>
																		  </div>
																 </div>
													  </a>
											 </li>
							   </ul>
					 </div>
					 <img src="assets/images/melbourne-leader.png" alt="melbourne-leader" title="" width="624" height="259" class="cnt-obj-img">
	   </section>
	  
	 	<!-- CTA -->
			<section class="cta-sec">
					<div class="container">
						<div class="cta-wrapper  flex-container wrap justify-between">
								<div class="cta-left">
											<div class="logo-icon">
												<img src="assets/images/logo-shape.svg" alt="r-icon" title="" width="111" height="111">
											</div>
											<div class="heading-30">Reach out today and let’s create the perfect solution together!</div>
								</div>
								<div class="button-group">
	            <a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

	            <a href="tel:03 9761 4452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height=""> Call us on: 03 9761 4452</a>
        	</div>
						</div>
			</div>
			</section>
	
	  <?php block('footer-instagram'); ?>

</main>
<?php get_footer();