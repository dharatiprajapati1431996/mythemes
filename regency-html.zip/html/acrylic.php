<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper acrylic-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner-noimg mb-70">
					 <div class="container">
         <ul class="woo_breadcums">
           <li>
             <span>
               <span>
                 <a href="home.php">Home</a>
																 <a href="#">Products</a>
                 <span class="breadcrumb_last" aria-current="page">Acrylic (Perspex)</span>
               </span>
             </span>
           </li>
         </ul>
						</div>
			 </section>
    <!-- Inner Banner Section -->
		
	   
	  <!-- product listing -->
    <section class="sec-category mb-80">
       <div class="container">
								 <div class="category-wrap">
											<div class="panel-left">
												  <!-- search -->
												  <div class="pr-search-wr">
													   <input type="search" class="form-control" placeholder="Search...">
															 <div class="pr-icon button button-theme"><img src="assets/images/svg/search-icon.svg" alt="search-icon" title="" width="21" height="21"></div>
												  </div>
												   
												  <div class="mobile-slide">
                <a href="#" class="closemenu desk-hide">
                   <img src="assets/images/menu-close.png" alt="close" width="17" height="18">
                </a>
                 <div class="categorylistbox">
																		 <div class="category-heading">Products Category</div>
                   <div class="category-body">
																					<p>Plugin Here</p>
																		 </div>
                 </div>
              </div>
										 </div>
										 <div class="panel-right">
														<div class="mobilefilter_box hide-in-desktop">
                <a href="javascript:void(0);" class="button btn-theme m_filtertrigger"><span> Filter </span>
                  <i class="fa fa-filter"></i>
                </a>
              </div>
															<div class="heading-40">Acrylic (Perspex)</div>
															<ul class="product-ul">
									  <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/aquariums-image.jpg" alt="aquariums-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Aquariums</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/backboard-basketball.jpg" alt="backboard-basketball" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Backboards - Basketball</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/boat-windcreen-image.jpg" alt="boat-windcreen-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Boat Windscreens</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>Looking for top-quality acrylic sheet suppliers in Melbourne and the surrounding areas?</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/cake-topper-image.jpg" alt="cake-topper-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Cake Toppers</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/caravan-window-image.jpg" alt="caravan-window-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Caravan Windows</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/table-top-image.jpg" alt="table-top-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Custom Table Tops</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>When it comes to HDPE products, Regency Plastics has the high-quality solutions you are seeking for your business.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/display-case-image.jpg" alt="display-case-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Display Cases/ Boxes</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/glazing-window-image.jpg" alt="glazing-window-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Double Glazing Windows</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/rods-image.jpg" alt="rods-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Rods</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/safety-feature-image.jpg" alt="safety-feature-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Safety Features </div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>Rigid polypropylene sheets have a range of advantages and applications for various industries.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/sheet-image.jpg" alt="sheet-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Sheets</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/signage-image.jpg" alt="signage-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Signage - Numbers,Signs, Displays</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/skylight-image.jpg" alt="skylight-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Skylights</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/sneeze-image.jpg" alt="sneeze-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Sneeze/ Privacy Guards</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/splashback-image.jpg" alt="splashback-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Splashbacks</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
												<li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/tube-image.jpg" alt="tube-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Tube</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
												<li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/lock-box-image.jpg" alt="lock-box-image" title="" width="323" height="415">
																	  <div class="product-overlay">
																				 <div class="pr-title">Wishing Well / Lock Boxes</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">Read More <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
								 </ul>
										  </div>
								 </div>

							</div>
    </section>
 
	 <?php block('home/hm-contact'); ?>
	
	   <?php block('footer-instagram'); ?>

</main>
<?php get_footer();