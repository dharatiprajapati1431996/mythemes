<!-- Start instagram -->
<section class="hm-instagram white-bg py-lg-120 py-40">
    <div class="container">

        <div class="intro-column">
            <div class="instagram-column">
                <div class="logo-icon">
                    <img src="assets/images/r-small-icon.svg" alt="r-small-icon" title="" width="49" height="49">
                </div>
                <div class="logo-info">
                    Our Instagram Handle
                    <span>regencyplastics</span>
                </div>
            </div>

            <p>Regency Plastics is your one stop shop for all your plastic needs, with our laser cutter, CNC router and
                panel saw with cut to size options.</p>
        </div>

        <div class="instagram-wrap mb-50">
            <img src="assets/images/instagram.jpg" alt="instagram" title="" width="1401" height="349">
        </div>

        <div class="text-center">
            <a href="#" class="button button-outline"><img src="assets/images/svg/instagram-black.svg"
                    alt="instagram-black" title="" width="16" height="16"> Follow Us on Instagram</a>
        </div>

    </div>
</section>
<!-- End instagram -->