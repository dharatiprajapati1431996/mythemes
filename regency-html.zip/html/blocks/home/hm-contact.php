
<!-- Start Contact us -->
<section class="hm-contact white-bg pt-lg-120 ">
	<div class="container">
		<div class="contact-wrapper flex-container wrap dark-bg items-start">
			<div class="get-left">
				
				<div class="intro">
					<div class="uppercase head-xs"><span class="circle"></span> Let’s Bring Your Vision to Life!</div>
					<div class="heading-50">Have a Project in Mind? Contact With Us.</div>
					<p>Regency Plastics provides plastic solutions. Contact us today to discuss your needs and get started!<p>
				</div>

				<div class="divider"></div>

				<div class="ft-address">
                <div class="address-block">
                    <div class="heading-24">Regency Plastics</div>
                    <address>Fact 5, 257 Colchester Road,
                        Kilsyth South, Victoria 3137,
                        Australia.</address>


                    <ul class="ft-contact">
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/call-yellow.svg" alt="call-yellow" title="" width="15" height="15">
                                </div>
                                <div class="ft-info">
                                    <a href="tel:03 9761 4452">03 9761 4452</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/mobile-device.svg" alt="mobile-device" title="" width="12" height="17">
                                </div>
                                <div class="ft-info">
                                    <a href="tel:0435 100 453">0435 100 453</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/email.svg" alt="email" title="" width="15" height="15">
                                </div>
                                <div class="ft-info">
                                    <a href="mailto:sales@regencyplastics.com.au">sales@regencyplastics.com.au</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/location.svg" alt="location" title="" width="12" height="14">
                                </div>
                                <div class="ft-info">
                                    <label for="">Our business hours are</label>
                                    <p>Monday to Friday: 8:00 am to 4:30 pm
                                        <span>Saturday: By appointment</span></p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="r-logo">
                    <img src="assets/images/r-icon.svg" alt="r-icon" title="" width="274" height="274">
                </div>
            </div>

			</div>
			<div class="get-right">
				<div class="get-wrap">
					<div class="intro">
						<div class="heading-40">Get in Touch</div>
						<p>Contact Regency Plastics today, and our expert team will assist you with the right products.</p>
					</div>


					<form class="get-touch-form">
						<div class="form-group">
                            <input class="form-control" type="text" name="name" placeholder="Your Name">
                        </div>


                            <div class="row">
                                <div class="form-group width50">
                                    <input class="form-control" type="email" name="name" placeholder="Email Address">
                                </div>
                                <div class="form-group width50">
                                    <input class="form-control" type="number" name="phone" placeholder="Phone">
                                </div>
                            </div>

                            <div class="form-group">
                            	<select name="cars" id="services" class="form-control">
								    <option value="">Select Product or Service</option>
								    <option value=""></option>
								    <option value=""></option>
								    <option value=""></option>
								</select>
                            </div>


							<div class="form-group message_area width100">
                                <textarea class="form-control" placeholder="Project Details/Requirements" name="your-message"></textarea>
                            </div>

                            
                            <div class="form-group">
                                <div class="fileinputs">
                                    <input class="file" name="attachment" placeholder="Upload Image" id="attachment" type="file">
                                    <div class="fakefile">
                                        <span id="filevalue">Upload Files</span>
                                        <div class="fakebtn"><img src="assets/images/svg/upload.svg" alt="upload" title="" width="" height=""> </div>
                                    </div>
                                </div>
                                <label for="name">PDF, DWG, DXF</label>
                            </div>
                            <div class="submit_btn">
                                <input type="submit" name="" value="Get a Free Consultation" class="btnsubmit">
                            </div>
                        </form>

				</div>
			</div>
		</div>
	</div>
</section>
<!-- End Contact us -->