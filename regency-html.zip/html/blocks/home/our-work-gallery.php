
<!-- Start our work gallery -->
<section class="hm-work-gallery py-lg-120 py-40 light-blue-bg">
	<div class="container">
		<div class="intro">
			<p>Our Work Gallery</p>
			<div class="heading-40">See Our Work in Action</div>
		</div>


		<div class="work-gallery-grid work-gallery-js slick-arrow">
			<div class="galery-item">
				<a href="assets/images/gallery-1.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
					<img src="assets/images/gallery-1.jpg" alt="" title="" width="646" height="485">
				</a>
			</div>
			<div class="galery-item">
				<a href="assets/images/gallery-2.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
					<img src="assets/images/gallery-2.jpg" alt="" title="" width="646" height="485">
				</a>
			</div>
			<div class="galery-item">
				<a href="assets/images/gallery-3.jpg" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
					<img src="assets/images/gallery-3.jpg" alt="" title="" width="646" height="485">
				</a>
			</div>
		</div>


		<div class="text-center">
			<a href="#" class="button button-outline btn-top">Explore All<img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>
		</div>
	</div>
</section>
<!-- End our work gallery -->