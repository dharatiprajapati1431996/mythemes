
<!-- Start industries -->
<section class="hm-industries white-bg pt-lg-120">
	<div class="container">
		<div class="intro text-center">
			<div class="semi-head">Industries Served</div>
			<div class="heading-40">Proudly Serving These Industries</div>
		</div>


		<div class="indust-grid">

			<div class="indust-item">
				<div class="indust-box">
					<div class="indust-icon">
						<img src="assets/images/svg/signage.svg" alt="signage" title="" width="46" height="50">
					</div>
					<div class="indust-info">
						<div class="heading-22">Signage</div>
						<p>High-quality, durable plastic solutions for eye-catching, long-lasting signage.</p>
					</div>
				</div>
			</div>

			<div class="indust-item">
				<div class="indust-box">
					<div class="indust-icon">
						<img src="assets/images/svg/hotels.svg" alt="hotels" title="" width="65" height="54">
					</div>
					<div class="indust-info">
						<div class="heading-22">Cafes & Hotels</div>
						<p>Custom plastic designs enhance aesthetics and functionality in hospitality.</p>
					</div>
				</div>
			</div>

			<div class="indust-item">
				<div class="indust-box">
					<div class="indust-icon">
						<img src="assets/images/svg/hospitals.svg" alt="Hospitals" title="" width="51" height="48">
					</div>
					<div class="indust-info">
						<div class="heading-22">Hospitals</div>
						<p>Hygienic, durable plastics for medical applications and hospital environments.</p>
					</div>
				</div>
			</div>

			<div class="indust-item">
				<div class="indust-box">
					<div class="indust-icon">
						<img src="assets/images/svg/retail-spaces.svg" alt="Retail Spaces" title="" width="54" height="43">
					</div>
					<div class="indust-info">
						<div class="heading-22">Retail Spaces</div>
						<p>Sleek, customized plastic solutions to elevate store displays and branding.</p>
					</div>
				</div>
			</div>

			<div class="indust-item">
				<div class="indust-box">
					<div class="indust-icon">
						<img src="assets/images/svg/school.svg" alt="Schools" title="" width="54" height="45">
					</div>
					<div class="indust-info">
						<div class="heading-22">Schools</div>
						<p>Safe, durable, and versatile plastic products for educational spaces.</p>
					</div>
				</div>
			</div>

			<div class="indust-item">
				<div class="indust-box">
					<div class="indust-icon">
						<img src="assets/images/svg/commercial-spaces.svg" alt="Commercial Spaces" title="" width="43" height="51">
					</div>
					<div class="indust-info">
						<div class="heading-22">Commercial Spaces</div>
						<p>Tailored plastic solutions for modern, efficient, and stylish workplaces.</p>
					</div>
				</div>
			</div>

		</div>

	</div>
</section>
<!-- End industries -->