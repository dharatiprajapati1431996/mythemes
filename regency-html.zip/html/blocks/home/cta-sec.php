<!-- Start CTA -->
<section class="cta-sec white-bg pb-lg-120">
	<div class="container">
		<div class="cta-wrapper  flex-container wrap justify-between">

			<div class="cta-left">
				<div class="logo-icon">
					<img src="assets/images/logo-shape.svg" alt="r-icon" title="" width="111" height="111">
				</div>
				<div class="heading-30">Contact us now to bring your project to life!</div>
			</div>

			<div class="button-group">
	            <a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

	            <a href="tel:03 9761 4452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height=""> Call us on: 03 9761 4452</a>
        	</div>
		</div>
	</div>
</section>
<!-- End CTA -->