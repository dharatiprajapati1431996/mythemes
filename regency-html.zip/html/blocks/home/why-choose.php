
<!-- Start why choose -->

<section class="hm-why-choose white-bg divider-bottom pt-lg-120">
	<div class="container">
		<div class="center-intro text-center">
			<p>Everything You Need to Know</p>
			<div class="heading-40">Why Choose Regency Plastics for Your Fabrication Needs?</div>
		</div>

		<div class="flex-container wrap">
			<div class="choose-left">

				<div class="heading-76 heading-line"><span>Trusted.</span> <span>Sustainable.</span> <span>Custom.</span></div>

				<p>With years of experience, we are your one-stop shop for all plastic needs. Offering sheets, rods and tubes, we cater to diverse industries and provide customized solutions tailored to your specific requirements. Whatever your needs, we’re dedicated to delivering quality products and exceptional service.</p>

				<div class="button-group">
		            <a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

		            <a href="tel:03 9761 4452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height=""> Call us on: 03 9761 4452</a>
	        	</div>
			</div>
			<div class="choose-right">
				<ul class="keyfeature-ul choose-grid">
					<li>
						<div class="keyfeature-li">
							<div class="keyfeature-icon"><img src="assets/images/svg/fast-turnaround-icon.svg" alt="fast-turnaround-icon" title="" width="85" height="91"></div>
								<div class="keyfeature-desc">
									<div class="key-title">Fast Turnaround</div>
									<div class="key-info">Same-day cut-to-size service available.</div>
								</div>
						</div>
					</li>
					<li>
						<div class="keyfeature-li">
							<div class="keyfeature-icon"><img src="assets/images/svg/expert-advice-icon.svg" alt="expert-advice-icon" title="" width="81" height="81"></div>
							<div class="keyfeature-desc">
								<div class="key-title">Expert Advice</div>
								<div class="key-info">Over 12 years of industry experience.</div>
							</div>
						</div>
					</li>
					<li>
						<div class="keyfeature-li">
							<div class="keyfeature-icon"><img src="assets/images/svg/custom-solution-icon.svg" alt="custom-solution-icon" title="" width="85" height="75"></div>
							<div class="keyfeature-desc">
								<div class="key-title">Custom Solutions</div>
								<div class="key-info">Products tailored to your specific application.</div>
							</div>
						</div>
					</li>
					<li>
						<div class="keyfeature-li">
							<div class="keyfeature-icon"><img src="assets/images/svg/commitment-quality-icon.svg" alt="commitment-quality-icon" title="" width="87" height="87"></div>
								<div class="keyfeature-desc">
									<div class="key-title">Commitment to Quality</div>
									<div class="key-info">High standards in both products and services.</div>
								</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- End why choose -->