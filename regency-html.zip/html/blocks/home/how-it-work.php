
<!-- Start how it Work -->
<section class="how-it-work white-bg pt-lg-120">
	<div class="container">
		<div class="intro text-center center-intro">
			<p>How It Works</p>
			<div class="heading-40">Get Your Perfect Plastic Solution in 3 Steps</div>
		</div>

		<div class="step-grid">
			<div class="step-item">
				<div class="step-img">
					<img src="assets/images/customer-talk.jpg" alt="customer-talk" title="" width="416" height="270">
				</div>
				<div class="step-detail">
					<div class="num">1</div>
					<div class="stepinfo">
						<div class="heading-22">Tell Us Your Needs</div>
						<p><a href="#">Contact us</a> or browse our products to share your project details.</p>
					</div>
				</div>
			</div>
			
			<div class="step-item">
				<div class="step-img">
					<img src="assets/images/customise-fabricate.jpg" alt="customise-fabricate" title="" width="416" height="270">
				</div>
				<div class="step-detail">
					<div class="num">2</div>
					<div class="stepinfo">
						<div class="heading-22">We Customise & Fabricate</div>
						<p>
							<a href="#">Contact us</a> or browse our products to share your project details.
						</p>
					</div>
				</div>
			</div>

			<div class="step-item">
				<div class="step-img">
					<img src="assets/images/fast-reliable-collection.jpg" alt="fast-reliable-collection" title="" width="416" height="270">
				</div>
				<div class="step-detail">
					<div class="num">3</div>
					<div class="stepinfo">
						<div class="heading-22">Fast & Reliable Collection</div>
						<p>Fast turnaround with collection from our warehouse. 
							<span class="tooltip"><img src="assets/images/svg/tool-tip.svg" alt="tool-tip" title="" width="16" height="16"> 

								<span class="tooltiptext"><img src="assets/images/svg/local-shipping.svg" alt="local-shipping" alt="" title="" width="31" height="22"> Delivery is available at an extra charge.</span> 

							</span> 
						</p>
					</div>
				</div>
			</div>

		</div>
	</div>
</section>
<!-- End how it Work -->