<!-- Start FAQ -->
<section class="hm-faq py-lg-120 py-40 light-blue-bg">
    <div class="container">
        <div class="intro text-center">
            <div class="semi-head">Got Questions? We’ve Got Answers.</div>
            <div class="heading-40">Frequently Asked Questions</div>
        </div>

        <div class="faq-container">
            <div class="faq_accordion">

                <div class="accordion_in">
                    <div class="acc_head">
                        <h3>Do you deliver outside Melbourne?</h3>
                    </div>
                    <div class="acc_content">
                        <p></p>
                    </div>
                </div>

                <div class="accordion_in">
                    <div class="acc_head">
                        <h3>Can you fabricate custom designs?</h3>
                    </div>
                    <div class="acc_content">
                        <p></p>
                    </div>
                </div>

                <div class="accordion_in">
                    <div class="acc_head">
                        <h3>How quickly can I get my order?</h3>
                    </div>
                    <div class="acc_content">
                        <p></p>
                    </div>
                </div>

                <div class="accordion_in">
                    <div class="acc_head">
                        <h3>What types of plastics do you supply?</h3>
                    </div>
                    <div class="acc_content">
                        <p></p>
                    </div>
                </div>
            </div>
        </div>


        <div class="button-group justify-center">
            <a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg"
                    alt="arrow right" title="" width="12" height="12"></a>

            <a href="tel:03 9761 4452" class="button button-outline"><img src="assets/images/svg/call-black.svg"
                    alt="call-black" title="" width="" height=""> Call us on: 03 9761 4452</a>
        </div>
    </div>
</section>
<!-- End FAQ -->