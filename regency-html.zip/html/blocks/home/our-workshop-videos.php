

<!-- START OUR WORKSHOP VIDEOS  -->
<section class="our-workshop white-bg pt-lg-120">
	<div class="container">
		<div class="intro text-center">
			<p>Our Workshop Videos</p>
			<div class="heading-40">Explore How We Work</div>
		</div>

		<div class="workshop-grid workshop-js slick-arrow">
			<div class="work-item">

				<a href="assets/images/sample-video.mp4" class="fancybox work-box" rel="group" data-fancybox="group" tabindex="0">
					<div class="work-img">
						<img src="assets/images/flame-polishing.jpg" alt="flame-polishing" title="" width="440" height="300">

						<span class="play-button"><img src="assets/images/play-icon.png" alt="Play Button" title="" width="26" height="28"> </span>

					</div>
					<div class="work-info">
						<div class="heading-22">Flame Polishing</div>
						<p>Sleek, customized plastic solutions to elevate store displays and branding.</p>
					</div>
				</a>
			</div>
			<div class="work-item">
				<a href="assets/images/sample-video.mp4" class="fancybox work-box" rel="group" data-fancybox="group" tabindex="0">
					<div class="work-img">
						<img src="assets/images/laser-engraving-lettering.jpg" alt="Laser Engraving Lettering" title="" width="440" height="300">

						<span class="play-button"><img src="assets/images/play-icon.png" alt="Play Button" title="" width="26" height="28"> </span>

					</div>
					<div class="work-info">
						<div class="heading-22">Laser Engraving Lettering</div>
						<p>Sleek, customized plastic solutions to elevate store displays and branding.</p>
					</div>
				</a>
			</div>
			<div class="work-item">
				<a href="assets/images/sample-video.mp4" class="fancybox work-box" rel="group" data-fancybox="group" tabindex="0">
					<div class="work-img">
						<img src="assets/images/rod-saw-cutter.jpg" alt="Rod Saw Cutter" title="" width="440" height="300">

						<span class="play-button"><img src="assets/images/play-icon.png" alt="Play Button" title="" width="26" height="28"> </span>
					</div>
					<div class="work-info">
						<div class="heading-22">Rod Saw Cutter</div>
						<p>Sleek, customized plastic solutions to elevate store displays and branding.</p>
					</div>
				</a>

			</div>
		</div>
	</div>
</section>

<!-- END OUR WORKSHOP VIDEOS  -->



