
<!-- Start banner  -->

 <section class="banner mb-50">
     <div class="js_hmbanner slick-arrow">
         <div class="slidediv slideone">
             <img src="assets/images/banner.jpg" alt="" title="" width="1920" height="930" class="desktop_banner">
             <!-- <img src="assets/images/mobile-banner.jpg" alt="" title="" width="768" height="450" class="mobile-banner"> -->
             <div class="bannertext">
                 <div class="container hmbo_wrap">
                     <div class="webox">
                        <div class="semi-heading">Family owned and operated</div>
                         <div class="heading-54">Custom Plastic Fabrication for Every Industry – Delivered Fast!</div>
                         <div class="button-group">
                            <a href="#" class="button button-theme">Get a Free Quote <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

                            <a href="tel:03 9761 4452" class="button button-secondary">Explore Our Products</a>
                        </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>

     <div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
 </section>

 <!-- End banner  -->
