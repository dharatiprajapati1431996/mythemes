
<!-- Start Explore Product Services -->
<section class="explore-product-services py-lg-120">
	<div class="container">
		<div class="heading-40">Explore Our Products & Services</div>

		<hr>


		<div class="explore-wrapper">
			<div class="intro mb-50">
				<div class="heading-18 heading-shape">Popular Materials</div>
				<p>Here at Regency Plastics we provide a wide range of different products. We specialise in plastic sheet, rod and tubes.</p>
			</div>

			<ul class="product-ul explore-js slick-arrow">
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/acrylic-perspex.jpg" alt="Acrylic (Perspex)" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">Acrylic (Perspex)</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>Looking for top-quality acrylic sheet suppliers in Melbourne and the surrounding areas?</p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">More about Acrylic<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/polycarbonate.jpg" alt="polycarbonate" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">Polycarbonate</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>Rigid polypropylene sheets have a range of advantages and applications for various industries.</p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">More about Polycarbonate<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/HDPE.jpg" alt="HDPE" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">HDPE</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>When it comes to HDPE products, Regency Plastics has the high-quality solutions you are seeking for your business.</p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">More about HDPE<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/dk-grey-box.jpg" alt="dk-grey-box" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">Acrylic (Perspex)</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>With decades of combined experience in the plastic fabrication industry.</p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">All Products<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
			</ul>

			<div class="text-center">
				<a href="#" class="button button-outline btn-top">Explore All Products <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>
			</div>

		</div>


		<div class="divider"></div>


		<div class="explore-wrapper">
			<div class="intro mb-50">
				<div class="heading-18 heading-shape">Key Services</div>
				<p>Here at Regency Plastics, we offer a wide range of services, from general plastic fabrication through to a custom design and build service.</p>
			</div>

			<ul class="product-ul explore-js slick-arrow">
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/laser-cutting.jpg" alt="Laser Cutting" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">Laser Cutting</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>When it comes to acrylic cutting, laser cut acrylic provides a superior result. </p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">More about laser cutting<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/CNC-routing.jpg" alt="CNC Routing" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">CNC Routing</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>With decades of combined experience in the plastic fabrication industry.</p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">More about CNC cutting<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/welding.jpg" alt="Welding" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">Welding</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>With decades of combined experience in the plastic fabrication industry.</p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">More about Welding<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
				<li>
					<a href="#">
						<div class="product-li">
							<img src="assets/images/fabrication.jpg" alt="Fabrication" title="" width="416" height="535">
								<div class="product-overlay">
									<div class="pr-title">Fabrication</div>
										<div class="pr-bottom">
											<div class="pr-cnt">
												<p>With decades of combined experience in the plastic fabrication industry.</p>
											</div>
											<div class="pr-link-wr">
													<div class="pr-more">All Products<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
													
													<div class="pr-arrow">
														<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
													</div>
													
											</div>
										</div>
								</div>
						 </div>
					</a>
				</li>
			</ul>


			<div class="text-center">
				<a href="#" class="button button-outline btn-top">Explore All Services <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>
			</div>

		</div>

	</div>
</section>
<!-- End Explore Product Services -->