	   <section class="sec-keyfeature mb-50">
					 <div class="container">
									<ul class="keyfeature-ul">
											<li>
															<div class="keyfeature-li">
																	 <div class="keyfeature-icon"><img src="assets/images/svg/fast-turnaround-icon.svg" alt="fast-turnaround-icon" title="" width="52" height="56"></div>
																  <div class="keyfeature-desc">
																				<div class="key-title">Fast Turnaround</div>
																			 <div class="key-info">Same-day cut-to-size service available.</div>
																  </div>
												   </div>
										 </li>
										<li>
															<div class="keyfeature-li">
																	 <div class="keyfeature-icon"><img src="assets/images/svg/expert-advice-icon.svg" alt="expert-advice-icon" title="" width="49" height="49"></div>
																  <div class="keyfeature-desc">
																				<div class="key-title">Trusted advice</div>
																			 <div class="key-info">Over 12 years of industry experience.</div>
																  </div>
												   </div>
										 </li>
										<li>
															<div class="keyfeature-li">
																	 <div class="keyfeature-icon"><img src="assets/images/svg/custom-solution-icon.svg" alt="custom-solution-icon" title="" width="52" height="47"></div>
																  <div class="keyfeature-desc">
																				<div class="key-title">Custom Solutions</div>
																			 <div class="key-info">Products tailored to your specific application.</div>
																  </div>
												   </div>
										 </li>
										<li>
															<div class="keyfeature-li">
																	 <div class="keyfeature-icon"><img src="assets/images/svg/commitment-quality-icon.svg" alt="commitment-quality-icon" title="" width="53" height="53"></div>
																  <div class="keyfeature-desc">
																				<div class="key-title">Commitment to Quality</div>
																			 <div class="key-info">High standards in both products and services.</div>
																  </div>
												   </div>
										 </li>
							  </ul>
					 </div>
	   </section>