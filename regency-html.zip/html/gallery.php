<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="page-wrapper gallery-pg">


	 <!-- Inner Banner Section -->
    <section class="inner-banner mb-50">
					 <img src="assets/images/gallery-banner.jpg" alt="gallery-banner" width="1920" height="530" class="bgimg">
        <div class="container">
            <div class="inbanner-content">
													   <div class="heading-54">Gallery</div>
                <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="home.php">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Gallery</span>
                                </span>
                            </span>
                        </li>
                    </ul>
									   </div>
        </div>
					<div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
			 </section>
    <!-- Inner Banner Section -->

    <section class="gallery-inpage relative py-lg-120">
    	<div class="container">
								<ul class="gallery-list">
						 			<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image1.jpg" alt="gallery image" width="679" height="509">
														 </div>
														 <div class="g-overlay">
																 <div class="g-client-wr">
																		 <div class="g-client-tp"><img src="assets/images/quote.png" alt="quote icon" title="" width="23" height="18">Client Review</div>
																		 <div class="g-client-md">
																		 		<p>With years of experience, we are your one-stop shop for all plastic needs. Offering sheets</p>
																				 <a href="#">More</a>
																		 </div>
																		 <div class="g-client-btm">
																		 		<div class="g-client">Client: Kim Dowling</div>
																				 <div class="rating"><img src="assets/images/rating.png" alt="rating" title=""></div>
																		 </div>
																 </div>
														 </div>
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image2.jpg" alt="gallery image" width="679" height="509">
														 </div>
												
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image3.jpg" alt="gallery image" width="679" height="509">
														 </div>
														 <div class="g-overlay">
																 <div class="g-client-wr">
																		 <div class="g-client-tp"><img src="assets/images/quote.png" alt="quote icon" title="" width="23" height="18">Client Review</div>
																		 <div class="g-client-md">
																		 		<p>With years of experience, we are your one-stop shop for all plastic needs. Offering sheets</p>
																				 <a href="#">More</a>
																		 </div>
																		 <div class="g-client-btm">
																		 		<div class="g-client">Client: Kim Dowling</div>
																				 <div class="rating"><img src="assets/images/rating.png" alt="rating" title=""></div>
																		 </div>
																 </div>
														 </div>
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image4.jpg" alt="gallery image" width="679" height="509">
														 </div>
														 <div class="g-overlay">
																 <div class="g-client-wr">
																		 <div class="g-client-tp"><img src="assets/images/quote.png" alt="quote icon" title="" width="23" height="18">Client Review</div>
																		 <div class="g-client-md">
																		 		<p>With years of experience, we are your one-stop shop for all plastic needs. Offering sheets</p>
																				 <a href="#">More</a>
																		 </div>
																		 <div class="g-client-btm">
																		 		<div class="g-client">Client: Kim Dowling</div>
																				 <div class="rating"><img src="assets/images/rating.png" alt="rating" title=""></div>
																		 </div>
																 </div>
														 </div>
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image5.jpg" alt="gallery image" width="679" height="509">
														 </div>
													
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image6.jpg" alt="gallery image" width="679" height="509">
														 </div>
														 <div class="g-overlay">
																 <div class="g-client-wr">
																		 <div class="g-client-tp"><img src="assets/images/quote.png" alt="quote icon" title="" width="23" height="18">Client Review</div>
																		 <div class="g-client-md">
																		 		<p>With years of experience, we are your one-stop shop for all plastic needs. Offering sheets</p>
																				 <a href="#">More</a>
																		 </div>
																		 <div class="g-client-btm">
																		 		<div class="g-client">Client: Kim Dowling</div>
																				 <div class="rating"><img src="assets/images/rating.png" alt="rating" title=""></div>
																		 </div>
																 </div>
														 </div>
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image7.jpg" alt="gallery image" width="679" height="509">
														 </div>

											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image8.jpg" alt="gallery image" width="679" height="509">
														 </div>
														
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image9.jpg" alt="gallery image" width="679" height="509">
														 </div>
														
											  </div>
									 </li>
									<li>
												 <div class="gallery-img">
															<div class="g-imgwr">
																<img src="assets/images/gallery-image10.jpg" alt="gallery image" width="679" height="509">
														 </div>
														
											  </div>
									 </li>
						  </ul>
							
						  <div class="center">
									 <a href="#" class="button button-outline">Load More <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>
							 </div>
						
					</div>
					<img src="assets/images/melbourne-leader.png" alt="melbourne-leader" title="" width="624" height="259" class="leader-img">
    </section>
	
	 

	<?php block('home/hm-contact'); ?>
	
	<?php block('footer-instagram'); ?>

</main>
<?php get_footer();