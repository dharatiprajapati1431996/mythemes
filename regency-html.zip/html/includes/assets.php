<?php


$GLOBALS['assets'] = [
    'common' => [
        'styles' => ['font-awesome.min', 'slick', 'slick-theme' , 'reset', 'normalize', 'utiliti' , 'variables' , 'jquery.fancybox' ,'header','common','common-new' ],
        'scripts' => ['jquery', 'slick', 'script' , 'jquery.fancybox.min' ],
    ],
    'home' => [
        'styles' => ['home' , 'smk-accordion' , 'product' ],
        'scripts' => [ 'home' , 'smk-accordion' , 'faq' ],
    ],
    'products' => [
        'styles' => ['product' ],
        'scripts' => [ 'product' ],
    ],
	   'acrylic' => [
        'styles' => ['product' ],
        'scripts' => [ 'product' ],
    ],
	  'acrylic-detail' => [
        'styles' => ['product-detail' ],
        'scripts' => [ 'product-detail' ],
    ],
	  'cake-topper' => [
        'styles' => ['product-detail' ],
        'scripts' => [ 'product-detail' ],
    ],
			'gallery' => [
        'styles' => ['gallery' ],
        'scripts' => [ 'gallery' ],
    ],
	   'services' => [
        'styles' => ['service' ],
        'scripts' => [ 'service' ],
    ],
	   'acrylic-laser-cutting' => [
        'styles' => ['service-detail' ],
        'scripts' => [ 'service' ],
    ],
	   'contact' => [
        'styles' => ['contact' ],
        'scripts' => [ ],
    ],
	   'blog' => [
        'styles' => ['blog' ],
        'scripts' => [ ],
    ],
	   'blog-detail' => [
        'styles' => ['blog' ],
        'scripts' => ['blog' ],
    ],
   'about' => [
        'styles' => ['about' ],
        'scripts' => [],
    ],
    'gallery' => [
        'styles' => ['gallery' ],
        'scripts' => [],
    ],
];