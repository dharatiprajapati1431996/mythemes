$(document).ready(function () {

$(".sec-product-list ul.product-ul").slick({
    autoplay:false,
	   arrows:true,
    slidesToShow: 3,
		  slidesToScroll: 1,
    arrows: true,
    dots:false,
			 responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
        }
      },
				 {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
									 centerMode:true,
									 centerPadding:'80px',
        }
      }
			]
  });

	 $('.slider-for').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false,
          fade: true,
          asNavFor: '.slider-nav'
      });
  $('.slider-nav').slick({
          slidesToShow: 5,
          slidesToScroll: 1,
			 					 arrows:false,
          asNavFor: '.slider-for',
          dots: false,
          focusOnSelect: true,
          infinite:false,
			  					autoplay: true,
 								 autoplaySpeed: 2000,
      });
	
	
});

