$( document ).ready(function() {
	// $('.js_hmbanner').slick({
	// 	arrows: false,
	// 	dots: true,
	// 	slidesToShow: 1,
	// 	slidesToScroll: 1,
	// 	horizontal: true,
	// 	infinite: true,
	// 	autoplay: true,
	// 	fade: true,
	// 	pauseOnHover: false,
	// 	autoplaySpeed: 5000,
	// 	responsive: [
	// 		{
	// 			breakpoint: 601,
	// 			settings: {
	// 				arrows: false,
	// 				dots: false
	// 			}
	// 		}
	// 	]
	// });



	// OUR PRODUCT
		$('.workshop-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 3,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 2,
					}
				},
				{
					breakpoint: 576,
					settings: {
						slidesToShow: 1,
					}
				}
			]
		});



		// OUR PRODUCT
		$('.explore-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 3,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			centerMode: true,
			centerPadding: "70px",
			responsive: [
				{
					breakpoint: 1440,
					settings: {
						centerPadding: "50px",
					}
				},
				{
					breakpoint: 1200,
					settings: {
						slidesToShow: 2,
						centerPadding: "50px",
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 1,
						centerPadding: "30px",
					}
				}
			]
		});
	

});
