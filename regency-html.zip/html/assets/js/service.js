$( document ).ready(function() {
	 $('.content-slider').slick({
	 	arrows: true,
	 	dots: false,
	 	slidesToShow: 1,
	 	slidesToScroll: 1,
	 	horizontal: true,
	 	infinite: true,
	 	autoplay: true,
	 	fade: true,
	 	pauseOnHover: false,
	 	autoplaySpeed: 5000,
	
	 });


});
