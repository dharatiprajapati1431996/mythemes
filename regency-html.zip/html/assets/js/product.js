$(document).on('click', 'a.m_filtertrigger, a.closemenu', function (e){
     e.preventDefault();
     $(".mobile-slide").toggleClass("slide");
     $("body").toggleClass("overlayshow");
});