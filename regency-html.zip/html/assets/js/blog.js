$(document).ready(function () {

$(".blogslider ul.blog-ul").slick({
    autoplay:false,
    slidesToShow: 3,
		  slidesToScroll: 1,
    arrows: true,
    dots:false,
			 responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        }
      }
			]
  });

});

