$(document).ready(function () {

//FAQ
$(".faq_accordion").smk_Accordion({
    closeAble: true,
    activeIndex: false // All closed initially
});



});
    

