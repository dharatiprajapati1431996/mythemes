$(document).ready(function () {
	/*Scroll top*/
	var scrollTop = $(".scrollTop");
	$(window).scroll(function () {
		var topPos = $(this).scrollTop();
		if (topPos > 0) {
			$(scrollTop).css("opacity", "1");
		} else {
			$(scrollTop).css("opacity", "0");
		}
	});
	$(scrollTop).click(function () {
		$('html, body').animate({
			scrollTop: 0
		}, 600);
		return false;
	});
	/*Menu dropdown*/
	$('.menu_link ul li:has(ul)').addClass("haschild");
	var caicon = $('<i class="fa fa-angle-down menudrop" aria-hidden="true"></i>');
	$('.menu_link ul li:has(ul) > a').append(caicon);
	$('.menu_link ul li:has(ul) > a').next().addClass("childmenu");
	$('.menu_link .sublink > li > ul > li').on('mouseenter', function () {
		$(this).siblings().removeClass('menu-item-hover');
		$(this).addClass('menu-item-hover');
		$('.current-menu-parent').removeClass('active');
		$('.current_page_item').removeClass('active')
	});
	$('.menudrop').on('click', function (e) {
		var label = $(this).parent();
		var parent = label.parent('.haschild');
		var list = label.siblings('.childmenu');
		e.preventDefault();
		if (parent.hasClass('isopen')) {
			list.hide();
			parent.removeClass('isopen')
		} else {
			parent.parent().find('li.haschild').removeClass('isopen');
			parent.parent().find('li.haschild .childmenu').hide();
			list.show();
			parent.addClass('isopen')
		}
	});



	if ($(window).width() >= 1120) {
		$(".menu_link nav > ul > li.has-sub").hover(
			function () {
				$('body').addClass("menuoverlay");
				$(window).trigger('resize');
			},
			function () {
				$('body').removeClass("menuoverlay");
			}
		);
	}

	/*-----BURGER MENU-----*/
	$(".togglebtn, .overlay").click(function () {
		$(".togglebtn, .overlay, .menu_link").toggleClass("active");
		if ($(".overlay").hasClass("active")) {
			$(".overlay").fadeIn();
			$('html').addClass('menuhidden');
		} else {
			$(".overlay").fadeOut();
			$('html').removeClass('menuhidden');
		}
	});


	/*-----FIXED HEADER-----*/

	$(window).scroll(function () {
		if (($(window).scrollTop() > 200) && ($(window).width() >= 319)) {
			$('body').addClass('fixed-header');
		} else {
			$('body').removeClass('fixed-header');
		}
	});
	
	 /**/
		if($('main').children().hasClass("inner-banner-noimg")){ 
     $("body").addClass("header-black");
			}

	
    // FANCYBOX

    $("[data-fancybox]").fancybox({
        // Options will go here
        // slideShow  : false,
        // fullScreen : false,
        // thumbs     : true,
        // closeBtn   : true, 
        // slideShow  : true,  
    });  





// Work in Action
		$('.work-gallery-js').slick({
			arrows: true,
			dots: false,
			slidesToShow: 2,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			centerMode: true,
			centerPadding: "70px",
			responsive: [
				{
					breakpoint: 1200,
					settings: {
						centerPadding: "30px",
					}
				},
				{
					breakpoint: 768,
					settings: {
						slidesToShow: 1,
						centerPadding: "50px",
					}
				}
			]
		});


  // keyfeature
		$('.sec-keyfeature .keyfeature-ul').slick({
			arrows: false,
			dots: false,
			slidesToShow:4,
			slidesToScroll: 1,
			horizontal: true,
			infinite: true,
			autoplay: true,
			pauseOnHover: false,
			autoplaySpeed: 3000,
			responsive: [
				{
					breakpoint: 1440,
					settings: {
						slidesToShow: 3,
					}
				},
				
				{
					breakpoint:992,
					settings: {
						slidesToShow: 2,
					}
				},
					{
					breakpoint:576,
					settings: {
						slidesToShow:1,
						centerMode: true,
      centerPadding:'58px',
					}
				}
			]
		});


	 	
	 	 // FOOTER TOGGLE

		    $(".acc-nav .acc-nav-head").click (function(){
		      if ($(window).width() < 992) {
		          let $this = $(this);
		          
		          $this.toggleClass('showhide');

		          let $wrapper = $this.closest('.acc-nav');
		          let $heads = $wrapper.find('.acc-nav-head');

		          $heads.not($this).removeClass('showhide');
		          $heads.not('.showhide').next().stop().slideUp(300);
		          $heads.filter('.showhide').next().stop().slideDown(300);
		      }
		  });



		       /* search box*/
				$(document).click(function(e) {
				        if ($(e.target).closest("#searchdiv").attr("id") != "searchdiv") {
				            $('.search-toggle').removeClass('opened').addClass('closed');
				            $('.search-toggle, .search-container').removeClass('opened')
				        }
				    });
				    $('.search-toggle').addClass('closed');
				    $('.search-toggle .aws-search-btn,.search-icon-mobile').click(function(e) {
				        if ($('.search-toggle').hasClass('closed')) {
				            $('.search-toggle').removeClass('closed').addClass('opened');
				            $('.search-toggle, .search-container').addClass('opened');
				            $('#search-terms').focus();
				            $('body').addClass('search-active');
				            $('.aws-search-result').show()
				        } else {
				            $('.search-toggle').removeClass('opened').addClass('closed');
				            $('.search-toggle, .search-container').removeClass('opened');
				            $('body').removeClass('search-active');
				            $('.aws-search-result').hide()
				        }
				        e.stopPropagation()
				    });




});

