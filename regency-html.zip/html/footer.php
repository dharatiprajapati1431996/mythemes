<footer>
    <div class="container">
        <div class="ft-top flex-container wrap justify-between">
            <div class="ft-logo">
                <a href="home.php">
                    <img src="assets/images/regency-plastics.png" alt="regency-plastics" title="" width="324" height="104">
                </a>
            </div>

            <div class="button-group">
                <a href="#" class="button button-white button-badge"><span class="new-badge">New</span> Acrylic Sheet</a>
                <a href="#" class="button button-theme button-width">Get a Free Quote <img src="assets/images/svg/arrow-right.svg"
                        alt="arrow right" title="" width="12" height="12"></a>
            </div>
        </div>

        <div class="ft-navigation-wrap flex-container wrap justify-between">

            <div class="quick-wrap">
                <div class="hidden ft-head">Quick Links</div>
                <ul class="nav-link">
                    <li><a href="home.php">Home </a></li>
                    <li><a href="about.php">About Us </a></li>
                    <li><a href="products.php">Products </a></li>
                    <li><a href="services.php">Services </a></li>
                    <li><a href="gallery.php">Gallery </a></li>
                    <li><a href="blog.php">Blog </a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>

            <a href="tel:03 9761 4452" class="alink-call"><img src="assets/images/svg/call-white.svg" alt="call-white"
                    title="" width="18" height="19"> <span>Call us now on:</span> 03 9761 4452</a>
        </div>

        <div class="ft-bottom flex-container wrap items-start acc-nav">
            <div class="ft-link">
                <div class="col6 ft-product">
                    <div class="ft-head acc-nav-head">Products</div>
                    <ul class="nav-link half-link">
                        <li><a href="#">ABS</a></li>
                        <li><a href="#">P.E.T.G</a></li>
                        <li><a href="#">Acetal</a></li>
                        <li><a href="#">Polycarbonate</a></li>
                        <li><a href="#">Acrylic</a></li>
                        <li><a href="#">Polypropylene</a></li>
                        <li><a href="#">Bait Boards</a></li>
                        <li><a href="#">PVC</a></li>
                        <li><a href="#">Corflute</a></li>
                        <li><a href="#">Teflon (PTFE)</a></li>
                        <li><a href="#">HDPE</a></li>
                        <li><a href="#">UHMWPE</a></li>
                        <li><a href="#">HIPS</a></li>
                        <li><a href="#">Vesconite</a></li>
                        <li><a href="#">Nylon</a></li>
                    </ul>
                </div>

                <div class="col6 ft-services">
                    <div class="ft-head acc-nav-head">Services</div>
                    <ul class="nav-link">
                        <li><a href="#">Acrylic Laser Cutting</a></li>
                        <li><a href="#">Bending</a></li>
                        <li><a href="#">CNC Routing</a></li>
                        <li><a href="#">Customised Programming / Drawings</a></li>
                        <li><a href="#">Cut to Size</a></li>
                        <li><a href="#">Fabrication</a></li>
                        <li><a href="#">Laser Cutter</a></li>
                        <li><a href="#">Polishing</a></li>
                        <li><a href="#">Welding</a></li>
                    </ul>
                </div>

            </div>
            <div class="ft-address">
                <div class="address-block">
                    <div class="heading-24">Regency Plastics</div>
                    <address>Fact 5, 257 Colchester Road,
                        Kilsyth South, Victoria 3137,
                        Australia.</address>


                    <ul class="ft-contact">
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/call-yellow.svg" alt="call-yellow" title="" width="15"
                                        height="15">
                                </div>
                                <div class="ft-info">
                                    <a href="tel:03 9761 4452">03 9761 4452</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/mobile-device.svg" alt="mobile-device" title=""
                                        width="12" height="17">
                                </div>
                                <div class="ft-info">
                                    <a href="tel:0435 100 453">0435 100 453</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/email.svg" alt="email" title="" width="15" height="15">
                                </div>
                                <div class="ft-info">
                                    <a href="mailto:sales@regencyplastics.com.au">sales@regencyplastics.com.au</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ft-box">
                                <div class="ft-icon">
                                    <img src="assets/images/svg/location.svg" alt="location" title="" width="12"
                                        height="14">
                                </div>
                                <div class="ft-info">
                                    <label for="">Our business hours are</label>
                                    <p>Monday to Friday: 8:00 am to 4:30 pm
                                        <span>Saturday: By appointment</span></p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="r-logo">
                    <img src="assets/images/r-icon.svg" alt="r-icon" title="" width="292" height="292">
                </div>
            </div>
        </div>
    </div>

    <!-- Start Footer social -->
    <div class="ft-social-wrap">
        <div class="container">
            <ul class="social-link">
                <li><a href="#"><img src="assets/images/svg/instagram.svg" alt="instagram" title="" width="20"
                            height="20"></a></li>
                <li><a href="#"><img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="21"
                            height="21"></a></li>
                <li><a href="#"><img src="assets/images/svg/linkedin.svg" alt="linkedin" title="" width="16"
                            height="16"></a></li>
            </ul>
        </div>
    </div>




    <!-- End Footer social -->


    <!-- START COPYRIGHT -->
    <div class="copyright text-center">
        <div class="container">
            <p>Copyrights © 2025 Regency Plastics. <span>All Rights Reserved.</span></p>
        </div>
    </div>
    <!-- END COPYRIGHT -->


</footer>

<button class="scrollTop"><i class="fa fa-angle-up" aria-hidden="true"></i> </button>


<?php wp_footer(); ?>
</body>

</html>