<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="page-wrapper service-detail-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner mb-50">
					 <img src="assets/images/acrylic-laser-cutting-banner.jpg" alt="acrylic-laser-cutting-banner" width="1920" height="530" class="bgimg">
        <div class="container">
            <div class="inbanner-content">
													   <div class="heading-54">Acrylic Laser Cutting</div>
                <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="home.php">Home</a>
									<a href="#"> Services</a>
                                    <span class="breadcrumb_last" aria-current="page"> Acrylic Laser Cutting</span>
                                </span>
                            </span>
                        </li>
                    </ul>
													
													<div class="button-group">
																		<a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

																		<a href="tel:03 9761 4452" class="button button-outline-white">Explore Our Products</a>
														</div>
									   </div>
        </div>


        <div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
        
			 </section>
    <!-- Inner Banner Section -->
		
	   <!-- key feature -->
			<?php block('key-feature'); ?>
	   
			 <!-- content section -->
		  <section class="content-wrapper pt-120">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block">
                   <div class="heading-30">Acrylic Laser Cutting</div>
																	  <p>For our laser cut acrylic panels, we use a 150-WATT CO2 laser cutter. This means whether your sheets are 1.5mm or 25mm thick, we can provide custom laser cut acrylic that will exceed your expectations. Acrylic sheet laser cutting will provide you with a result sure to impress customers and make your sign, display or awards look flawless.</p>
																		<p>We can provide acrylic sheet laser cutting on Acrylic. If you are looking for laser cut clear or frosted acrylic, We offer competitive pricing. We also offer mirrored acrylic laser cutting, ideal for decorative purposes and bringing a pop of colour and life to any space.</p>
																		<p>When you are looking for acrylic laser cutting in Melbourne. Make Regency Plastics your number one choice.</p>
														 </div>
                <div class="img-block sticky trangle-shape">
                    <div class="img-shape">
       														   <ul class="content-slider slick-arrow">
																										<li>
																												<div class="cnt-slide-img">
																														<img src="assets/images/acrylic-laser-cutting-slider-image.jpg" alt="acrylic-laser-cutting-slider-image" title="" width="634" height="529">
																											 </div>
																									 </li>
																									 <li>
																												<div class="cnt-slide-img">
																														<img src="assets/images/acrylic-laser-cutting-slider-image.jpg" alt="acrylic-laser-cutting-slider-image" title="" width="634" height="529">
																											 </div>
																									 </li>
																					   </ul>
                    </div>
                </div>
            </div>
        </div>
	</section>
 	  
	  <!-- CTA -->
			<section class="cta-sec">
					<div class="container">
						<div class="cta-wrapper  flex-container wrap justify-between">

			<div class="cta-left">
				<div class="logo-icon">
					<img src="assets/images/logo-shape.svg" alt="r-icon" title="" width="111" height="111">
				</div>
				<div class="heading-30">Reach out today and let’s create the perfect solution together!</div>
			</div>

			<div class="button-group">
	            <a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

	            <a href="tel:03 9761 4452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height=""> Call us on: 03 9761 4452</a>
        	</div>
		</div>
			</div>
			</section>
	
	
				 <!-- content section -->
		  <section class="content-wrapper py-lg-120">
        <div class="container">
            <div class="flex-container wrap flex-row-reverse">
                <div class="ctent-block">
                   <div class="heading-30">Plastic Laser Cutting Melbourne</div>
																	  <p>Laser cut plastic allows you to utilise a durable and affordable material for 
																						almost any imaginable purpose. By laser cutting plastic sheets, you can 
																						achieve a crisp edge, straight lines and even shapes with very little effort.
																			</p>
																	  <p>Regency Plastics’ laser cut plastic panels have been used for displays, 
																						signage, decor, construction and more. Whatever you choose to use your 
																						custom laser cut plastic for, you can rest assured we have the skills and 
																						experience to provide a perfect result.</p>
																	 <p>For plastic laser cutting in Melbourne, Regency Plastics are the ultimate 
																					choice. Contact us today to find out more about our services and receive a 
																					competitive quote.</p>
														 </div>
                <div class="img-block sticky trangle-shape">
                    <div class="img-shape">
																						<ul class="content-slider slick-arrow">
																										<li>
																												<div class="cnt-slide-img">
																														<img src="assets/images/gear-laser-slider-image.jpg" alt="gear-laser-slider-image" title="" width="634" height="529">
																											 </div>
																									 </li>
																									 <li>
																												<div class="cnt-slide-img">
																													<img src="assets/images/gear-laser-slider-image.jpg" alt="gear-laser-slider-image" title="" width="634" height="529">
																											 </div>
																									 </li>
																					   </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
	
			<?php block('home/why-choose'); ?> 
	  
	  <?php block('home/our-work-gallery'); ?>
	
	   <?php block('home/hm-industries'); ?>
	
			<?php block('home/hm-contact'); ?>
	
	   <?php block('footer-instagram'); ?>

</main>
<?php get_footer();