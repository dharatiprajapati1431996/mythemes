<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper product-detail-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner-noimg mb-80">
		<div class="container">
         <ul class="woo_breadcums">
           <li>
             <span>
               <span>
                 <a href="home.php">Home</a>
				<a href="#">Products</a>
                 <span class="breadcrumb_last" aria-current="page">Acrylic (Perspex)</span>
               </span>
             </span>
           </li>
         </ul>
	</div>
</section>
    <!-- Inner Banner Section -->
	  
	   <!-- product detail -->
	   <section class="sec-pr-detail">
						 <div class="container">
									<div class="pr-detail-wrap">
											<div class="pr-dtl-left sticky">
												  <div class="pr-mob">
																<div class="heading-40">Acrylic Sheet</div>
												 	</div>
												
										 			<div class="slider slider-for">
                   <div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                      <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
															    <div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                      <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
																			<div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                      <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
															    <div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                      <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
															    <div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                      <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
																			<div class="slider-banner-image">
                       <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
                   <div class="slider-banner-image">
                      <img src="assets/images/product-detail-image.jpg" alt="product-detail-image" title="" width="700" height="600">
                   </div>
               </div>
              <div class="slider slider-nav thumb-image">
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img1.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img2.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
																   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img3.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
																   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img4.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
																			<div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img1.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
																		 <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img1.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img2.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
																   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img3.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
																   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img4.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
																			<div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/product-thumbnail-img1.jpg" alt="product-thumbnail-img" title="" width="116" height="100">
                       </div>
                   </div>
               </div>
										 </div>
										 <div class="pr-dtl-right">
												
												 <div class="pr-mob">
										 	 	<div class="heading-40">Acrylic Sheet</div>
													</div>	
												
												 <p>Used in a range of applications across various industries, acrylic is one of the oldest and most versatile plastics available. Australian businesses can rely on acrylic for displays, signage, fish tanks, medical purposes, and much more.</p>
												 <p>Regency Plastics are the acrylic sheet suppliers in Melbourne. Based in Melbourne and serving a range of industries, we can produce cut-to-size and made-to-measure solutions for your needs.</p>
												 <p>Generally speaking, acrylic is useful for a wide range of purposes. It is malleable, transparent, and lightweight but still strong. Best of all, our acrylic sheet in Melbourne is low-maintenance, meaning it can be used to create everything from machine guards to furniture.</p>
												 <p>Not sure what you need from your acrylic plastic in Melbourne? We can recommend solutions for your industry and your application.</p>
												
												<div class="heading-30">Acrylic Sheet Suppliers in Melbourne.</div>
												<p>Are you looking for acrylic sheet suppliers in Melbourne. For acrylic sheets in Melbourne and across the country, contact our team today.</p>
												<p>While we’re based in Melbourne, Regency Plastics can meet your plastic</p>
												
												<div class="button-group">
		            <a href="#" class="button button-theme">Get a Free Quote <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="13" height="12"></a>

		            <a href="tel:0397614452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="19" height="19"> Call us on: 03 9761 4452</a>
	        	</div>
												
										 </div>
								 </div>
					  </div>
	   </section>
	
	 <!-- product listing slider -->
	  <section class="sec-product-list category-wrap mb-100">
		   <div class="container">
						 <div class="divider"></div>
							<div class="heading-40">Our Products</div>
						 
						 	<ul class="product-ul slick-arrow">
									  <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/acrylic-image.jpg" alt="acrylic-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Aquariums</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Aquariums<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/backboards-basketball-image.jpg" alt="backboard-basketball" title="" width="438" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Backboards - Basketball</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Backboards - Basketball<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/boat-windscreen-image.jpg" alt="boat-windcreen-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Boat Windscreens</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>Looking for top-quality acrylic sheet suppliers in Melbourne and the surrounding areas?</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Boat Windscreens<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
									  <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/acrylic-image.jpg" alt="acrylic-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Aquariums</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Aquariums<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
								 </ul>
						
				 </div>
	  </section>

	  <?php block('home/hm-contact'); ?>
	
	  <?php block('footer-instagram'); ?>

</main>
<?php get_footer();