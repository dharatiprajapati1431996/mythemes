<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML Theme</title>
    <?php wp_head(); ?>
</head>
<body>
<!-- Start Header -->
 <!-- Start Header -->
    <header class="mainheader">

        <a class="togglebtn"><span></span></a>
        <div class="overlay"></div>

        <div class="container">
            <div class="head-top flex-conatiner wrap items-center justify-between">
                <div class="logo-left">
                    <a href="home.php" class="disblock">
                        <img src="assets/images/regency-plastics-logo.svg" alt="Regency Plastics" title=""
                            width="302" height="96">
                    </a>
                </div>


                <div class="head-right">
                	<div class="search-wrapper">
			            <div class="aws-container">
			              <form class="aws-search-form aws-show-clear">
			                <div class="aws-wrapper">
			                  <input type="search" name="s" id="6560217296fcb" value="" class="aws-search-field" placeholder="Search Product or Services" autocomplete="off">
			                  <div class="aws-search-clear">
			                    <span>×</span>
			                  </div>
			                  <div class="aws-loader"></div>
			                </div>
			                <div class="aws-search-btn aws-form-btn">
			                  <span class="aws-search-btn_icon">
			                    <svg xmlns="http://www.w3.org/2000/svg" width="17.425" height="17.414" viewBox="0 0 17.425 17.414">
			                      <g id="Group_2815" data-name="Group 2815" transform="translate(1 1)">
			                        <g id="Group_2813" data-name="Group 2813">
			                          <path id="Path_16" data-name="Path 16" d="M17.371,10.936A6.436,6.436,0,1,1,10.936,4.5,6.436,6.436,0,0,1,17.371,10.936Z" transform="translate(-4.5 -4.5)" fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
			                          <path id="Path_17" data-name="Path 17" d="M29.005,28.994l-4.03-4.019" transform="translate(-13.994 -13.994)" fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
			                        </g>
			                      </g>
			                    </svg>
			                  </span>
			                </div>
			              </form>
			            </div>
	                </div>

	                <div class="search-icon-mobile hidden">
	                	<img src="assets/images/svg/search-icon.svg" alt="search-icon" title="" width=""  height="">
	                </div>

	                <div class="head-button">
	                    <div class="button-group">
	                        <a href="#" class="button button-white button-badge"><span class="new-badge">New</span> Acrylic Sheet</a>
	                        <a href="#" class="button button-theme button-width">Get a Free Quote <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>
	                    </div>
	                </div>
                </div>



            </div>
            <div class="head-bottom navigation-wrapper flex-conatiner wrap justity-between items-center">
                <div class="menu_link">
                    <nav>
                        <ul>
                            <li><a href="home.php">Home</a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li class="has-sub">
                                <a href="products.php">Products</a>
                                <div class="submenu megamenu">
                                    <div class="menu-prodcut">
                                        <ul class="sublink menu-level1">
                                        <li class="menu-item-hover">
                                            <a href="#">ABS</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">ABS</div>

                                                <ul class="sublink">
                                                    <li><a href="#">Sheet</a></li>
                                                </ul>

                                            </div>
                                        </li>

                                        <li>
                                            <a href="#">Acetal</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Acetal</div>
                                                <ul class="sublink">
                                                   <li><a href="#">Machine Parts</a></li>
                                                   <li><a href="#">Rod</a></li>
                                                   <li><a href="#">Sheet</a></li>
                                                </ul>
                                            </div>
                                        </li>

                                        <li>
                                            <a href="#">Acrylic</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Acrylic (Perspex)</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Aquariums</a></li>
                                                    <li><a href="#">Backboards - Basketball</a></li>
                                                    <li><a href="#">Boat Windscreens</a></li>
                                                    <li><a href="#">Cake Toppers</a></li>
                                                    <li><a href="#">Caravan Windows</a></li>
                                                    <li><a href="#">Custom Table Tops</a></li>
                                                    <li><a href="#">Display Cases/ Boxes</a></li>
                                                    <li><a href="#">Double Glazing Windows</a></li>
                                                    <li><a href="#">Rods</a></li>
                                                    <li><a href="#">Safety Features</a></li>
                                                    <li><a href="#">Sheets</a></li>
                                                    <li><a href="#">Signage - Numbers, Signs, Displays</a></li>
                                                    <li><a href="#">Skylights</a></li>
                                                    <li><a href="#">Sneeze/ Privacy Guards</a></li>
                                                    <li><a href="#">Splashbacks</a></li>
                                                    <li><a href="#">Tube</a></li>
                                                    <li><a href="#">Wishing Well / Lock Boxes</a></li>
                                                </ul>
                                            </div>
                                        </li>

                                        <li>
                                            <a href="#">Bait Boards</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Bait Boards</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Medical Equipment</a></li>
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">Corflute</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Corflute</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">HDPE</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">HDPE</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Bait Boards</a></li>
                                                    <li><a href="#">Cutting/ Chopping Boards</a></li>
                                                    <li><a href="#">Machine Parts</a></li>
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Sheet </a></li>
                                                    <li><a href="#">Wear Plates</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">HIPS</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">HIPS</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">Nylon</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Nylon</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Machine Parts </a></li>
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">P.E.T.G</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">P.E.T.G</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Sheet</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">Polycarbonate</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Polycarbonate</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Ar (Abrasian Resistant) Sheets</a></li>
                                                    <li><a href="#">Backboards - Basketball</a></li>
                                                    <li><a href="#">Machine Guards</a></li>
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Screen Protectors</a></li>
                                                    <li><a href="#">Security Guard Panels - Machines, Forklifts, Excavtor</a></li>
                                                    <li><a href="#">Sheet</a></li>
                                                    <li><a href="#">Tube</a></li>
                                                    <li><a href="#">Windows - Vehicles</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">Polypropylene</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Polypropylene</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Polystone</a></li>
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">PVC</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">PVC</div>
                                                <ul class="sublink">
                                                    <li><a href="#"></a>Chemical Tanks</li>
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">Teflon (PTFE)</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Teflon (PTFE)</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Draw Runners</a></li>
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>

                                        <li>
                                            <a href="#">UHMWPE</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">UHMWPE</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Draw Runners</a></li>
                                                    <li><a href="#">Machine Parts</a></li>
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Sheet</a></li>
                                                    <li><a href="#">Wear Plates</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">Vesconite</a>

                                            <div class="submenu menu-level2">
                                                <div class="heading-24">Vesconite</div>
                                                <ul class="sublink">
                                                    <li><a href="#">Rod</a></li>
                                                    <li><a href="#">Sheet </a></li>
                                                </ul>
                                            </div>
                                        </li>

                                    </ul>
                                    </div>


                                    <div class="menu-dropdown-cta">
                                        <div class="menu-img">
                                            <img src="assets/images/acrylic-sheet.jpg" alt="acrylic-sheet" title="" width="232" height="217">
                                        </div>
                                        <div class="menu-cta-inner">
                                            <p>Looking for top-quality acrylic sheet suppliers in Melbourne and across the country? <a href="#">contact our team today</a></p>

                                            <a href="tel:03 9761 4452" class="button button-gray"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height="">03 9761 4452</a>
                                        </div>
                                    </div>

                                </div>
                            </li>
                            <li class="has-sub">
                                <a href="services.php">Services</a>
                               <div class="submenu service-dropdown">
                                    <div class="menu-left">
                                        <div class="heading-24">Key Services</div>

                                        <ul class="sublink">
                                            <li><a href="#">Acrylic Laser Cutting</a></li>
                                            <li><a href="#">Bending</a></li>
                                            <li><a href="#">CNC Routing</a></li>
                                            <li><a href="#">Customised Programming / Drawings</a></li>
                                            <li><a href="#">Cut to Size</a></li>
                                            <li><a href="#">Fabrication</a></li>
                                            <li><a href="#">Laser Cutter</a></li>
                                            <li><a href="#">Polishing</a></li>
                                            <li><a href="#">Welding</a></li>
                                        </ul>
                                    </div>

                                    <div class="menu-dropdown-cta">
                                        <div class="menu-img">
                                            <img src="assets/images/regency-plastics-office.jpg" alt="regency-plastics-office" title="" height="">
                                        </div>
                                        <div class="menu-cta-inner">
                                            <p>Looking for top-quality acrylic sheet suppliers in Melbourne and across the country?  <a href="#">contact our team today</a></p>

                                            <a href="tel:03 9761 4452" class="button button-gray"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height="">03 9761 4452</a>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li><a href="gallery.php">Gallery </a></li>
                            <li><a href="blog.php">Blog </a></li>

                            <!-- <li class="has-sub areas-dropdown">
                                        <a href="areas-we-serve.php">Areas</a>
                                        <div class="submenu megamenu">
                                            <ul class="sublink menu-level1">
                                                <div class="heading-18">Areas we serve</div>

                                                <li class="menu-item-hover">
                                                    <a href="#">
                                                        <span class="label-cion">
                                                            <img src="assets/images/svg/barn.svg" alt="year-trusted"
                                                                title="" width="" height="">
                                                        </span>
                                                        <div class="label-info">Barn <span>This is dummy text,
                                                                we use
                                                                it at Supple during web designing</span></div>
                                                    </a>

                                                    <div class="submenu menu-level2">
                                                        <div class="menu-info">This is dummy text, we use it at Supple
                                                            during
                                                            web designing in case we don't have
                                                            content for new NON SEO pages and it is changed during
                                                            development
                                                            of the new site. </div>
                                                        <ul class="sublink">
                                                            <li><a href="#">list</a></li>
                                                            <li><a href="#">list</a></li>
                                                            <li><a href="#">list</a></li>
                                                        </ul>

                                                    </div>
                                                </li>

                                                <li>
                                                    <a href="#">
                                                        <span class="label-cion">
                                                            <img src="assets/images/svg/carports.svg" alt="year-trusted"
                                                                title="" width="" height="">
                                                        </span>
                                                        <div class="label-info">Carports <span>This is dummy text, we
                                                                use it at Supple during web designing</span></div>
                                                    </a>

                                                    <div class="submenu menu-level2">
                                                        <div class="menu-info">This is dummy text, we use it at Supple
                                                            during web designing in case we don't have content for new
                                                            NON SEO pages and it is changed during development of the
                                                            new site. </div>
                                                        <ul class="sublink">
                                                            <li><a href="#">list</a></li>
                                                            <li><a href="#">list</a></li>
                                                            <li><a href="#">list</a></li>
                                                        </ul>
                                                    </div>
                                                </li>

                                                <li>
                                                    <a href="#">
                                                        <span class="label-cion">
                                                            <img src="assets/images/svg/garages.svg" alt="year-trusted"
                                                                title="" width="" height="">
                                                        </span>
                                                        <div class="label-info">Garages<span>This is dummy text, we use
                                                                it at Supple during web designing</span> </div>
                                                    </a>

                                                    <div class="submenu menu-level2">
                                                        <div class="menu-info">This is dummy text, we use it at Supple
                                                            during
                                                            web designing in case we don't have
                                                            content for new NON SEO pages and it is changed during
                                                            development
                                                            of the new site.</div>
                                                        <ul class="sublink">
                                                            <li><a href="#">list</a></li>
                                                            <li><a href="#">list</a></li>
                                                            <li><a href="#">list</a></li>
                                                        </ul>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                            </li>  -->

                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav>

                    <!-- Start menu cta  -->
                    <div class="menu-cta hidden">
                    	<div class="heading-30">Contact us now to bring your project to life!</div>
                    	<div class="button-group">
				            <a href="#" class="button button-black">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

				            <a href="tel:03 9761 4452" class="button button-white"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="18" height="19"> 03 9761 4452</a>
			        	</div>
                    </div>
                    <!-- End menu cta  -->



                </div>


                <a href="tel:03 9761 4452" class="head-call">
                    <div class="head-icon">
                        <img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="19" height="19">
                    </div>
                    <div class="head-info">
                        Call us Now on
                        <span>03 9761 4452</span>
                    </div>
                </a>

            </div>
        </div>



        <!-- search -->
      <div class="search-container" id="searchdiv">
        <div class="search__content">
          <div class="aws-container" role="search">
            <form>
              <div class="aws-wrapper">
                <input type="search" name="s" id="6560217297512" value="" class="aws-search-field" placeholder="Search Product or Services" autocomplete="off">
                <div class="aws-search-clear">
                  <span>×</span>
                </div>
                <div class="aws-loader"></div>
              </div>
              <div class="aws-search-btn aws-form-btn">
                <span class="aws-search-btn_icon">
                  <svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24px">
                    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
                  </svg>
                </span>
              </div>
            </form>
          </div>
          <div class="btnsearch search-toggle closed">
            <div class="aws-search-btn aws-form-btn">
              <span class="aws-search-btn_icon">
                <img src="assets/images/menu-close.png" alt="close-search" class="close-search-icon" width="12" height="12">
              </span>
            </div>
          </div>
        </div>
      </div>

    </header>
<!-- End Header -->