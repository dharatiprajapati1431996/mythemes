<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper service-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner mb-50">
					 <img src="assets/images/service-banner.jpg" alt="product-banner" width="1920" height="530" class="bgimg">
        <div class="container">
            <div class="inbanner-content">
													   <div class="heading-54">Services</div>
                <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="home.php">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Services</span>
                                </span>
                            </span>
                        </li>
                    </ul>
									   </div>
        </div>

        <div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
			 </section>
    <!-- Inner Banner Section -->
		
	   <!-- key feature -->
			<?php block('key-feature'); ?>
	   
	  <!-- product listing -->
    <section class="sec-product mb-80">
       <div class="container">
								
								 <div class="service-content-wrap">
												<p>Here at Regency Plastics, we offer a wide range of services.</p>
								 </div>
								
								 <ul class="product-ul">
									  <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/acryliclaser-cutting-image.jpg" alt="acryliclaser-cutting-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Acrylic Laser Cutting</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>When it comes to acrylic cutting, laser cut acrylic provides a superior result. </p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about laser cutting <img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/bending-image.jpg" alt="bending-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Bending</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>With decades of combined experience in the plastic fabrication industry.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Bending<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/cnc-routing-image.jpg" alt="cnc-routing-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">CNC Routing</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>With decades of combined experience in the plastic fabrication industry.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about CNC Routing<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/customised-image.jpg" alt="customised-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Customised Programming / Drawings</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>When it comes to acrylic cutting, laser cut acrylic provides a superior result. </p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Customised Programming<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/cut-size-image.jpg" alt="cut-size-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Cut to Size</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>With decades of combined experience in the plastic fabrication industry.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Cut to Size<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/fabrication-image.jpg" alt="fabrication-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Fabrication</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>With decades of combined experience in the plastic fabrication industry.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Fabrication<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/laser-cutter-image.jpg" alt="laser-cutter-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Laser Cutter</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>When it comes to acrylic cutting, laser cut acrylic provides a superior result. </p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Laser Cutter<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/polishing-image.jpg" alt="polishing-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Polishing</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>With decades of combined experience in the plastic fabrication industry.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Polishing<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/welding-image.jpg" alt="welding-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Welding</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>With decades of combined experience in the plastic fabrication industry.</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Welding<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
									</ul>
								 
						 </div>
    </section>
			
	   <!-- cta -->
				<section class="cta-sec white-bg">
						<div class="container">
							<div class="cta-wrapper  flex-container wrap justify-between">

								<div class="cta-left">
									<div class="logo-icon">
										<img src="assets/images/logo-shape.svg" alt="r-icon" title="" width="111" height="111">
									</div>
									<div class="heading-30">Reach out today and let’s create the perfect solution together!</div>
								</div>

								<div class="button-group">
																		<a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

																		<a href="tel:03 9761 4452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height=""> Call us on: 03 9761 4452</a>
														</div>
							</div>
						</div>
			</section>
	
	   <?php block('footer-instagram'); ?>

</main>
<?php get_footer();