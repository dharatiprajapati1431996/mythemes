<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper about-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner mb-50">
		<img src="assets/images/about-banner.jpg" alt="about-banner" width="1920" height="530" class="bgimg">
        <div class="container">
            <div class="inbanner-content">
				<div class="heading-54">About Us</div>
                <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="home.php">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">About Us</span>
                                </span>
                            </span>
                        </li>
                    </ul>
			</div>
        </div>

        <div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
	</section>
    <!-- Inner Banner Section -->
		
	   <!-- key feature -->
			<?php block('key-feature'); ?>
	
	   <section class="content-wrapper py-lg-120 relative">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block">
                   <div class="heading-30">Who We Are</div>
																	  <p>Regency Plastics is a family-owned and run business with many years of experience in the plastics manufacturing industry. We’re a great choice for businesses that need high-quality plastic products and reliable service.</p>
																	 <p>We specialise in supplying plastic sheets, rods, and tubes for a wide range of applications, and we keep a broad selection of materials in stock for your convenience. We manufacture to clients’ measurements and specifications, including wear strips, display boxes, cutting boards, and custom designs.</p>
																	 <p>Our services include plastic fabrication, plastic welding, custom drawings, and designs built to purpose for businesses that require something tailored and unique.</p>
																	<p>Located in Kilsyth South, we’re open Monday to Friday, from 8.00 am to 4.30 pm. For more information, feel free to email us at <a href="mailto:sales@regencyplastics.com.au">sales@regencyplastics.com.au</a>.</p>
														 </div>
                <div class="img-block sticky trangle-shape">
                    <div class="img-shape">
       														  <img src="assets/images/regencyplastics-office.jpg" alt="about-image" title="" width="634" height="529">
                    </div>
                </div>
            </div>
        </div>
				   <img src="assets/images/melbourne-leader.png" alt="melbourne-leader" title="" width="624" height="259" class="leader-img">
	</section>		
	
		  <?php block('home/how-it-work'); ?>
		
	   <!-- start CTA -->
				<section class="cta-sec pb-lg-120 white-bg">
					<div class="container">
						<div class="cta-wrapper  flex-container wrap justify-between">
								<div class="cta-left">
											<div class="logo-icon">
												<img src="assets/images/logo-shape.svg" alt="r-icon" title="" width="111" height="111">
											</div>
											<div class="heading-30">Reach out today and let’s create the perfect solution together!</div>
								</div>
								<div class="button-group">
	            <a href="#" class="button button-theme">Get Started <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="12" height="12"></a>

	            <a href="tel:03 9761 4452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="" height=""> Call us on: 03 9761 4452</a>
        	</div>
						</div>
			</div>
			</section>




	    
	   <section class="content-wrapper white-bg">
        <div class="container">
            <div class="flex-container wrap">
                <div class="ctent-block">
                   <div class="heading-30">Why Choose Us</div>
																	  <ul>
																						<li>We offer same day cut to size service</li>
																				  <li>We offer a range of plastic products. When you buy through us, you will always be able to find the right material for the job at hand.</li>
																				  <li>We have a number of different products in stock. Our main products are plastic rods, sheets and tubes – and these come in a wide range of different styles and sizes to suit various applications.</li>
																				  <li>We provide you with the right advice. With plenty of industry experience, we will always be able to give you the advice you need – ensuring you get the right plastic product for the job.</li>
																	  </ul>
														 </div>
                <div class="img-block sticky trangle-shape">
                    <div class="img-shape">
       														  <img src="assets/images/machine-guard-image.jpg" alt="machine-guard-image" title="" width="634" height="457">
                    </div>
                </div>
            </div>
									
									  <div class="divider"></div>
        </div>
	</section>		
	   
	  <?php block('home/why-choose'); ?> 
	
	  <?php block('home/hm-contact'); ?>
	
	   <?php block('footer-instagram'); ?>

</main>
<?php get_footer();