<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page-wrapper product-detail-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner-noimg mb-80">
					 <div class="container">
         <ul class="woo_breadcums">
           <li>
             <span>
               <span>
                 <a href="home.php">Home</a>
																 <a href="#">Products</a>
                 <span class="breadcrumb_last" aria-current="page">Cake Toppers</span>
               </span>
             </span>
           </li>
         </ul>
						</div>
			 </section>
    <!-- Inner Banner Section -->
	  
	   <!-- product detail -->
	   <section class="sec-pr-detail">
						 <div class="container">
									<div class="pr-detail-wrap">
											<div class="pr-dtl-left">
												 <div class="pr-mob">
										 	 	<div class="heading-40">Cake Toppers</div>
													</div>	
												
										 			<div class="slider slider-for">
                   <div class="slider-banner-image">
                       <img src="assets/images/cake-topper-banner.jpg" alt="cake-topper-banner" title="" width="700" height="600">
                   </div>
                   
               </div>
               <div class="slider slider-nav thumb-image">
                   <div class="thumbnail-image">
                       <div class="thumbImg">
                           <img src="assets/images/cake-topper-thumbnail.jpg" alt="cake-topper-thumbnail" title="" width="116" height="100">
                       </div>
                   </div>
               </div>
										 </div>
										 <div class="pr-dtl-right">
										 	 
												 <div class="pr-mob">
										 	 	<div class="heading-40">Cake Toppers</div>
													</div>	
												
												 <p>Regency Plastics also supplies high-quality plastic acrylic cake toppers, 
																perfect for adding a personalized touch to any celebration. Whether 
																you’re looking for a unique design to match a special theme or a classic 
																style to top off a beautifully decorated cake, our acrylic cake toppers are 
																crafted with precision and attention to detail. Made from durable 
																materials, they are not only visually appealing but also safe and easy to 
																use. Our team can work with you to create a custom design that reflects 
																your vision, ensuring your cake stands out at any event.</p>
												
												<div class="button-group">
		            <a href="#" class="button button-theme">Get a Free Quote <img src="assets/images/svg/arrow-right.svg" alt="arrow right" title="" width="13" height="12"></a>

		            <a href="tel:0397614452" class="button button-outline"><img src="assets/images/svg/call-black.svg" alt="call-black" title="" width="19" height="19"> Call us on: 03 9761 4452</a>
	        	</div>
												
										 </div>
								 </div>
					  </div>
	   </section>
	
	 <!-- product listing slider -->
	  <section class="sec-product-list category-wrap mb-100">
		   <div class="container">
						 <div class="divider"></div>
							<div class="heading-40">Related Products</div>
						 
						 	<ul class="product-ul slick-arrow">
									  <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/acrylic-image.jpg" alt="acrylic-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Aquariums</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Aquariums<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/backboards-basketball-image.jpg" alt="backboard-basketball" title="" width="438" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Backboards - Basketball</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Backboards - Basketball<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
										 <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/boat-windscreen-image.jpg" alt="boat-windcreen-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Boat Windscreens</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>Looking for top-quality acrylic sheet suppliers in Melbourne and the surrounding areas?</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Boat Windscreens<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
									  <li>
														<a href="#">
												    <div class="product-li">
																		 <img src="assets/images/acrylic-image.jpg" alt="acrylic-image" title="" width="439" height="564">
																	  <div class="product-overlay">
																				 <div class="pr-title">Aquariums</div>
																				 <div class="pr-bottom">
																							<div class="pr-cnt">
																						 		<p>This is dummy text, we use it at Supple during web designing in case we don't have content for</p>
																						 </div>
																						 <div class="pr-link-wr">
																									<div class="pr-more">More about Aquariums<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13"></div>
																								
																								 <div class="pr-arrow">
																											<img src="assets/images/arrow-right.png" alt="arrow right" title="" width="13" height="13">
																								 </div>
																								
																						 </div>
																				 </div>
																	  </div>
															 </div>
												  </a>
										 </li>
								 </ul>
						
				 </div>
	  </section>

	  <?php block('home/hm-contact'); ?>
	
	  <?php block('footer-instagram'); ?>

</main>
<?php get_footer();