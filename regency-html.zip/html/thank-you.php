<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper thank_youpg ">

 <!-- Inner Banner Section -->
    <section class="inner-banner mb-50">
        <img src="assets/images/about-banner.jpg" alt="about-banner" width="1920" height="530" class="bgimg">
        <div class="container">
            <div class="inbanner-content">
                <div class="heading-54">Thank You</div>
                <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="home.php">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Thank You</span>
                                </span>
                            </span>
                        </li>
                    </ul>
            </div>
        </div>
        <div class="arrow-down"><img src="assets/images/arrow-down.png" alt="" title="" width="13" height="14">   </div>
    </section>
    <!-- Inner Banner Section -->

    <!-- key feature -->
    <?php block('key-feature'); ?>


    <section class="inpage pb-lg-120">
        <div class="container">

            <div class="flex-container thank_you_content wrap">
                <div class="error-left">
                    <div class="heading-36">We’ve Received Your Inquiry!</div>
                    <p>We're excited to help you build your perfect space.</p>
                    <p>Thank you for reaching out to Superior Granny Flats! One of our team members will get back to you
                        shortly to discuss your project and answer any questions you may have.</p>
                    <p>In the meantime, feel free to explore more about what we offer:</p>

                    <ul>
                        <li><a href="#">Browse our latest projects</a></li>
                        <li><a href="#">Learn more about our process</a></li>
                        <li><a href="#">Read testimonials from our happy clients</a></li>
                    </ul>

                    <p>Have an urgent inquiry? Give us a call at <a href="tel:03 9761 4452">03 9761 4452</a> for
                        immediate assistance.</p>
                </div>

                <div class="error-right">
                    <img src="assets/images/thankyou.png" alt="404" title="404" width="500" height="500">
                </div>
            </div>

        </div>
    </section>

</main>
<?php get_footer();