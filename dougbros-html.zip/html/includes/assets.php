<?php

$GLOBALS['assets'] = [

    'common' => [
        'styles' => [
            'font-awesome.min',  
            'slick.min', 
            'slick-theme.min', 
            'variables', 
            'reset',
            'normalize',
            'utiliti',
            'assets/shopify/css/base',  
            'assets/shopify/css/component-price', 
            'assets/shopify/css/component-predictive-search' ,  
            'assets/shopify/css/quick-add' , 
            'assets/shopify/css/component-card' , 
            'assets/shopify/css/component-facets' , 
            'assets/shopify/css/section-main-product' , 
            'assets/shopify/css/component-search' , 
            'assets/shopify/css/component-predictive-search' , 
            'assets/shopify/css/component-pagination' , 
            
            'jquery.fancybox.min', 
            'header', 
            'style'],
        'scripts' => ['jquery-3.7.1.min', 'slick.min', 'jquery.fancybox.min' , 'script'],
    ],


    'home' => [
        'styles' => ['smk-accordion','faq','testimonial','home'],
        'scripts' => [ 'smk-accordion','home','faq'],
    ],
    'about' => [
        'styles' => [''],
        'scripts' => [ ''],
    ],
    'product-listing' => [
        'styles' => ['product'],
        'scripts' => [ ''],
    ],
    'product-detail' => [
        'styles' => ['product-detail'],
        'scripts' => [ 'product-detail'],
    ],

    'contact' => [
        'styles' => ['contact'],
        'scripts' => [ ],
    ],
    'pizza-ovens' => [
        'styles' => [],
        'scripts' => [ ],
    ],
	   'gas-pizza-oven-sale' => [
        'styles' => ['smk-accordion','faq','pizza-oven'],
        'scripts' => ['smk-accordion','faq','pizza-oven'],
    ],
	   'testimonials' => [
        'styles' => ['testimonial'],
        'scripts' => [ ],
    ], 
	   'faqs' => [
        'styles' => ['smk-accordion','faq'],
        'scripts' => ['smk-accordion','faq'],
    ],
	   'recipes' => [
        'styles' => [],
        'scripts' => [ ],
    ],
	   'guides' => [
        'styles' => ['smk-accordion','guide'],
        'scripts' => ['smk-accordion','guide'],
    ],
      'how-to-make-pizza-dough' => [
        'styles' => ['smk-accordion','guide'],
        'scripts' => ['smk-accordion','guide'],
    ],
];