<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper make-recipes-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner no-banner-image relative mb-100">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <a href="#">Resources</a>
                            <a href="#">Recipes</a>
                            <span class="breadcrumb_last" aria-current="page">How to make Pizza Dough</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->

	<!-- content -->
    <section class="content-wrapper relative mb-100">

    	<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">


    	<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right-bottom">

		<div class="page-width">

            <div class="make-pizza-wrapper flex-container wrap mb-100 align-items-center">
                <div class="col6 column-block">
                    <div class="making-dough-inner">
                        <div class="heading-50">How to make Pizza Dough</div>
                        <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. </p>


                        <ul class="making-dough-list">
                            <li>
                                <div class="make-box">
                                    <div class="heading-20"><img src="assets/images/svg/difficulty-icon.svg" alt="difficulty" title="" width="" height=""> Difficulty</div>
                                    <img src="assets/images/circle-icon.png" alt="circle-icon" title="" width="" height="">
                                </div>
                            </li>
                            <li>
                                <div class="make-box">
                                    <div class="heading-20"><img src="assets/images/svg/serving-icon.svg" alt="serving" title="" width="" height=""> Servings</div>
                                    <p>This is dummy text, we use it at Supple during web designing in</p>
                                </div>
                            </li>
                            <li>
                                <div class="make-box">
                                    <div class="heading-20"><img src="assets/images/svg/prep-time-icon.svg" alt="Prep Time" title="" width="" height=""> Prep Time</div>
                                    <p>3 to 6 hours for same day pizza</p>
                                </div>
                            </li>
                            <li>
                                <div class="make-box">
                                    <div class="heading-20"><img src="assets/images/svg/fire-icon.svg" alt="Cook Time" title="" width="" height=""> Cook Time</div>
                                    <p>1 to 2 minutes</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col6 img-left">
                    <img src="assets/images/dough-making.jpg" alt="dough-making" title="" width="800" height="600">  
                </div>
            </div>


            <div class="common-block-wr">
                <div class="block-left">
                    <div class="heading-50">We use it at Supple during web designing in case we don't have content for new</div>

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>

                    <div class="video-block">
                        <img src="assets/images/pizza-video.jpg" alt="video image block" title="" width="1000" height="550">
                        <div class="video-icon">
                            <img src="assets/images/svg/play-icon.svg" alt="play icon" title="" width="62" height="62">
                        </div>
                    </div> 

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>

                    <div class="heading-22">1. We use it at Supple during web designing in case we don't have content for new.</div>

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>

                    <div class="heading-22">2. Supple during web designing in case we don't have content for new.</div>

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>

                    <div class="heading-22">3. We use it at Supple during web designing in case we.</div>

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>

                    <div class="heading-22">4. It is changed during development of the new site.</div>

                    <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>       
                </div>
                <div class="block-right sticky">
                    <div class="guide_accordion"> 
                        <!-- Section 1 -->
                        <div class="accordion_in">
                            <div class="acc_head">Equipment</div>
                            <div class="acc_content">
                                <ul class="acc-ul acc-alink">
                                        <li>
                                            <div class="acc-li">
                                                <div class="acc-icon">
                                                    <img src="assets/images/solid-fuel-image.jpg" alt="solid fuel image" title="" width="70" height="70">
                                                </div>
                                                <div class="acc-desc">
                                                    <div class="acc-title">Turning peel</div>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="acc-li">
                                                <div class="acc-icon">
                                                    <img src="assets/images/gas-image.jpg" alt="gas-image" title="" width="70" height="70">
                                                </div>
                                                    <div class="acc-desc">
                                                        <div class="acc-title">Bro Scraper</div>
                                                    </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="acc-li">
                                                <div class="acc-icon">
                                                    <img src="assets/images/pizza-peel-image.jpg" alt="pizza-peel-image" title="" width="70" height="70">
                                                </div>
                                                <div class="acc-desc">
                                                    <div class="acc-title">Bro Board</div>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="acc-li">
                                                <div class="acc-icon">
                                                    <img src="assets/images/infrared-thermometer-image.jpg" alt="infrared-thermometer-image" title="" width="70" height="70">
                                                </div>
                                                <div class="acc-desc">
                                                    <div class="acc-title">Bro Cutter</div>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="acc-li">
                                                <div class="acc-icon">
                                                    <img src="assets/images/bro-peel.jpg" alt="infrared-thermometer-image" title="" width="70" height="70">
                                                </div>
                                                <div class="acc-desc">
                                                    <div class="acc-title">Bro Peel</div>
                                                </div>
                                            </div>
                                        </li>
                                </ul>
                            </div>
                        </div>
                                                
                        <!-- Section 2 -->
                        <div class="accordion_in">
                            <div class="acc_head">Ingredients</div>
                                <div class="acc_content">
                                    <ul class="acc-ul">
                                            <li>
                                                
                                                <div class="acc-li">
                                                    <div class="acc-icon">
                                                        <img src="assets/images/solid-fuel-image.jpg" alt="solid fuel image" title="" width="70" height="70">
                                                    </div>
                                                    <div class="acc-desc">
                                                        <div class="acc-title">Solid Fuel</div>
                                                
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="acc-li">
                                                    <div class="acc-icon">
                                                        <img src="assets/images/gas-image.jpg" alt="gas-image" title="" width="70" height="70">
                                                    </div>
                                                    <div class="acc-desc">
                                                        <div class="acc-title">Gas</div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="acc-li">
                                                    <div class="acc-icon">
                                                       <img src="assets/images/pizza-peel-image.jpg" alt="pizza-peel-image" title="" width="70" height="70">
                                                    </div>
                                                    <div class="acc-desc">
                                                        <div class="acc-title">Pizza Peel</div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="acc-li">
                                                    <div class="acc-icon">
                                                        <img src="assets/images/infrared-thermometer-image.jpg" alt="infrared-thermometer-image" title="" width="70" height="70">
                                                    </div>
                                                    <div class="acc-desc">
                                                        <div class="acc-title">Infrared Thermometer</div>
                                                    </div>
                                                </div>
                                            </li>
                                    </ul>
                                </div>
                        </div>
                    </div>            
                </div>
            </div>      
        </div>


        <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
	</section>
	

	
	  

</main>
<?php get_footer();