<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper contact-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative mb-100">
        <img class="bgimg" src="assets/images/contact-inner.jpg" height="400" width="1920" alt="contact-inner">
       
            <div class="page-width">
                <div class="heading-50 ">Contact Us</div>
            </div>
            
            <div class="breacurmb-wrapper">
                <div class="page-width">
                    <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="#">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Contact Us</span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100 relative">

        <img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">

        <div class="page-width">

           <div class="contact-wrapper flex-container wrap">
               <div class="col6 get-form-block">
                   <div class="get-in-touch">
                       <div class="intro">
                           <div class="heading-50">Get In Touch</div>
                            <p>Have questions or ready to bring authentic wood fire cooking to your space? Our team is here to help with expert advice and custom solutions. Contact us today!</p>
                       </div>

                        <form>
                            <div class="row">
                                <div class="form-group width50">
                                    <label>Your Name</label>
                                    <input type="text" class="form-control" placeholder="Enter your name">
                                </div>
                                <div class="form-group width50">
                                         <label>Enter Phone</label>
                                         <input type="text" class="form-control" placeholder="0000 000 000">
                                </div>
                            </div>
                            <div class="form-group">
                                     <label>Enter Email</label>
                                     <input type="email" class="form-control" placeholder="Example@gmail.com.au">
                            </div>
                             
                            <div class="form-group">
                                     <label>Comment</label>
                                     <textarea class="form-control"></textarea>
                            </div>
                            <div class="sub-btnblk">
                                   <div class="submit-button">
                                        <input type="submit" value="Submit">
                                   </div>
                            </div>
                        </form>


                        <ul class="follow-list">
                            <li>Connect With Us:</li>
                            <li>
                                <a href="#">
                                    <img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="10" height="19">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="assets/images/svg/twitter.svg" alt="twitter" title="" width="19" height="18">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="assets/images/svg/instagram.svg" alt="instagram" title="" width="17" height="17">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="assets/images/svg/youtube.svg" alt="youtube" title="" width="19" height="13">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="assets/images/svg/tiktok.svg" alt="tiktok" title="" width="16" height="18">
                                </a>
                            </li>
                        </ul>

                   </div>
               </div>
               <div class="col6 ctact-img">
                   <img src="assets/images/douch-bros-pizza-oven.jpg" alt="douch-bros-pizza-oven" title="" width="" height="">
               </div>
           </div>
        </div>

        <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
    </section>


</main>
<?php get_footer();