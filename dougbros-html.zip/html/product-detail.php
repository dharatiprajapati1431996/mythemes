<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper product-detail-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner no-banner-image relative mb-100">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <a href="#">Pizza Ovens</a>
                            <span class="breadcrumb_last" aria-current="page">Nevo Pizza Oven</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100 relative">
        <img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">

        <div class="page-width">

            <div class="product-wrapper mb-100">
                <div class="flex-container wrap items-start mrgb80">
                <div class="prod-left sticky">

                    <div class="summary-mobile-title-wrap">
                        <div class="sum_column">
                            <div class="intro">
                                <div class="semi-head">Dough Bros Pizza Ovens</div>
                                <div class="heading-50">Nevo Pizza Oven</div>
                            </div>

                            <span class="badge badge--bottom-left sold-out">Sold out</span>
                        </div>

                        <div class="flex_wrap price_box">
                            <div class="price price--large price--show-badge">
                                <div class="price__container">
                                    <div class="price__regular">
                                        <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                        <span class="price-item price-item--regular">
                                            $79.00
                                        </span>
                                    </div>
                                    <div class="price__sale">
                                        <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                        <span><s class="price-item price-item--regular"></s></span>
                                        <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                        <span class="price-item price-item--sale price-item--last">$79.00 </span>
                                    </div>
                                    <small class="unit-price caption hidden">
                                        <span class="visually-hidden">Unit price</span>
                                        <span class="price-item price-item--last">
                                            <span></span>
                                            <span aria-hidden="true">/</span>
                                            <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                            <span>
                                            </span>
                                        </span>
                                    </small>
                                </div>
                                <span class="badge price__badge-sale color-accent-2">Sale</span>
                                <span class="stock_info in-stock">In Stock</span>
                            </div>
                        </div>
                    </div>


                    <div class="product-prod-detail">
                        <div class="product-inner">
                        <div class="zoom-icon">
                            <img src="assets/images/svg/search-icon.svg" alt="zoom-icon" title="" width="17" height="17">
                        </div>


                            
                           <div class="slider-wrapper">

                                <div class="slider slider-product">
                                    <div class="slider-banner-image">
                                        <img src="assets/images/nevo-pizza-oven-big.jpg" alt="nevo pizza oven" title="" width="820" height="580">
                                    </div>
                                    <div class="slider-banner-image">
                                        <img src="assets/images/nevo-pizza-oven-big.jpg" alt="nevo pizza oven" title="" width="820" height="580">
                                    </div>
                                </div>

                                <div class="slider slider-thumb slick-arrow">
                                    <div class="thumnail-img">
                                        <img src="assets/images/thumnail-01.png" alt="thumnail-01" title="" width="255" height="180">
                                    </div>
                                    <div class="thumnail-img">
                                        <img src="assets/images/thumnail-02.png" alt="thumnail-02" title="" width="255" height="180">
                                    </div>
                                    <div class="thumnail-img">
                                        <img src="assets/images/thumnail-03.png" alt="thumnail-03" title="" width="255" height="180">
                                    </div>
                                    <div class="thumnail-img">
                                        <img src="assets/images/thumnail-04.png" alt="thumnail-04" title="" width="255" height="180">
                                    </div>
                                    <div class="thumnail-img">
                                        <img src="assets/images/thumnail-05.png" alt="thumnail-05" title="" width="255" height="180">
                                    </div>
                                </div>
                           </div>

                        </div>
                    </div>

                </div>
                <div class="prod-right">  
                    <div class="summary entry-summary">
                       <div class="sum_column">
                            <div class="intro">
                                <div class="semi-head">Dough Bros Pizza Ovens</div>
                                <div class="heading-50">Nevo Pizza Oven</div>
                            </div>

                            
                        </div>

                        <div class="price_box">
                            <span class="badge badge--bottom-left sold-out">Sold out</span>
                            <div id="price-template" role="status">
                                <div class="price price--large price--show-badge">
                                    <div class="price__container">
                                        <div class="price__regular">
                                            <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                            <span class="price-item price-item--regular">$595.00 AUD</span>
                                        </div>
                                        <div class="price__sale">
                                            <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                            <span><s class="price-item price-item--regular"></s></span>
                                            <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                            <span class="price-item price-item--sale price-item--last">$595.00 AUD</span>
                                        </div>
                                        <small class="unit-price caption hidden">
                                                <span class="visually-hidden">Unit price</span>
                                                <span class="price-item price-item--last">
                                                <span></span>
                                                <span aria-hidden="true">/</span>
                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                <span></span>
                                              </span>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="color-wrap">
                            <div class="label-head">Color: <span>Black</span></div>
                        </div>


                        <div class="product-form__input product-form__quantity">
                            <label class="quantity__label form__label" for="">Quantity:</label>
                            <quantity-input class="quantity">
                                <button class="quantity__button no-js-hidden" onclick="decreaseValue($(this))"
                                    value="Decrease Value" id="decrease" name="minus" type="button">
                                    <img src="assets/images/minus.png" alt="Remove" title="" width="14" height="14">
                                </button>

                                <input class="quantity__input" type="number" name="quantity"
                                    id="Quantity-template--14238873944153__main" min="1" value="1"
                                    form="product-form-template--14238873944153__main">

                                <button class="quantity__button no-js-hidden" id="increase"
                                    onclick="increaseValue($(this))" value="Increase Value" name="plus" type="button">
                                    <img src="assets/images/plus.png" alt="plus" title="" width="14" height="14">
                                </button>
                            </quantity-input>
                        </div>


                        <div class="free-shipping">
                           <span class="shipping-icons"><img src="assets/images/svg/shipping-van.svg" alt="shipping-van" title="" width="" height=""> </span>  <p>Free Australia Wide Shipping On All Ovens</p>
                        </div>


                        <div class="product-add-cart-wrap">
                            <button type="submit" name="add"
                                class="product-form__submit button button--full-width button--secondary">
                                <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
                                <span>Add to cart</span>

                                <div class="loading__spinner hidden">
                                    <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30">
                                        </circle>
                                    </svg>
                                </div>
                            </button>
                            

                            <button class="paypal-btn">
                                <img src="assets/images/pay-pal.png" alt="pay-pal" title="" width="610" height="52">
                            </button>

                            <a href="#" class="payment-link">More payment options</a>
                        </div> 


                        <hr>


                        <p><strong>FAST</strong> - Heats to 500°C & cooks pizza in 1 to 2 minutes. <strong>EASY</strong> - No assembly, built-in gas ignition & adjustable heat control dial for temperature control.</p>

                        <p><strong>PORTABLE</strong> - Retractable legs, makes it easy to transport and set up - just click the switch and start cooking.</p>

                        <p>The oven is ready to go straight out of the box with no, bolts or tools required for assembly. Complete with dial control and non battery gas igniter included as standard.</p>

                    </div>
                </div>
            </div>
            </div>

			
			<div class="content-wrapper gray-bg mb-100">
				<div class="flex-container wrap flex-row-reverse ctent-block-wr"> 
					<div class="ctent-block">
						<div class="heading-50">Choose Your Topping</div>
						<p>Give your pizza oven some personality with our Shells because every great pizza deserves the perfect topping! Start by choosing from our first six delicious colors (we call them “toppings”) to make your oven uniquely yours. Whether you’re into bold, spicy reds or classic, cheesy whites, we’ve got a topping to suit your taste.</p>
						
						<p>And just like adding extra toppings to your favorite pizza, we’re always cooking up new colors to keep your options fresh! Stay tuned as we drop more irresistible choices to make your oven stand out.</p>

                        <p>Why settle for plain when you can dress up your oven with a little flavor? Pick your topping and show off your style!</p>
								
					</div>
					<div class="ctent-img">
						<img src="assets/images/pizza-oven.jpg" alt="Pizza Oven" title="" width="780" height="550">
					</div>
				</div>
			</div>


            <div class="related-product-wrapper">
                <div class="heading-50 text-center">You May Also Like</div>

                <div class="related-product related-js slick-arrow">
                    <ul id="product-grid" class="grid product-grid grid--4-col-desktop">

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                            <div class="card__inner color-background-2 ratio">
                                                <div class="card__media">
                                                    <div class="media media--transparent">
                                                        <img src="assets/images/nevo-pizza-oven-product.png" alt="Nevo Pizza Oven" class="motion-reduce" width="285" height="184">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card__content">
                                                <div class="card__information">
                                                    <div class="semi-head">Dough Bros Pizza Ovens</div>
                                                    <h3 class="card__heading h5">
                                                        <a href="#" id="" class="full-unstyled-link">Nevo Pizza Oven</a>
                                                    </h3>
                                                    <div class="card-information">
                                                        <span class="caption-large light"></span>
                                                        <div class="price ">
                                                            <div class="price__container">
                                                                <div class="price__regular">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span class="price-item price-item--regular">$595.00 AUD</span>
                                                                </div>
                                                                <div class="price__sale">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span><s class="price-item price-item--regular"></s></span>
                                                                    <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                                                    <span class="price-item price-item--sale price-item--last">$595.00 AUD</span>
                                                                </div>
                                                                <small class="unit-price caption hidden">
                                                                    <span class="visually-hidden">Unit price</span>
                                                                    <span class="price-item price-item--last">
                                                                        <span></span>
                                                                        <span aria-hidden="true">/</span>
                                                                        <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                        <span></span>
                                                                    </span>
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card__badge bottom left"></div>
                                            </div>

                                            <button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
                                                <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
                                                <span> Add To Cart </span>
                                            </button>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 gradient ratio">
                                            <div class="card__badge bottom left"><span class="badge badge--bottom-left sold-out">Sold out</span></div>
                                            <div class="card__media">
                                                <div class="media media--transparent">
                                                    <img src="assets/images/bro-scraper.png" alt="Bro Scraper" class="motion-reduce" loading="lazy" width="229" height="229">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <div class="semi-head">Dough Bros Pizza Ovens</div>
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">Bro Scraper</a>
                                                </h3>
                                                <div class="card-information">
                                                    <span class="caption-large light"></span>
                                                    <div class="price  price--on-sale">
                                                        <div class="price__container">
                                                                <div class="price__regular">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span class="price-item price-item--regular">$00.00 AUD</span>
                                                                </div>
                                                                <div class="price__sale">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span><s class="price-item price-item--regular"></s></span>
                                                                    <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                                                    <span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
                                                                </div>
                                                                <small class="unit-price caption hidden">
                                                                    <span class="visually-hidden">Unit price</span>
                                                                    <span class="price-item price-item--last">
                                                                        <span></span>
                                                                        <span aria-hidden="true">/</span>
                                                                        <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                        <span></span>
                                                                    </span>
                                                                </small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card__badge bottom left">
                                                <span class="badge badge--bottom-left color-accent-2">Sale</span>
                                            </div>
                                        </div>
                                        <button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
                                            <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
                                            <span> Add To Cart </span>
                                        </button>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                                <div class="card__badge bottom left"><span class="badge badge--bottom-left">News</span></div>
                                                <div class="card__media">
                                                    <div class="media media--transparent">
                                                        <img src="assets/images/bro-board.png" alt="Bro Board" class="motion-reduce" width="" height="">
                                                    </div>
                                                </div>
                                        </div>

                                        <div class="card__content">
                                                <div class="card__information">
                                                    <div class="semi-head">Dough Bros Pizza Ovens</div>
                                                    <h3 class="card__heading h5">
                                                        <a href="#" id="" class="full-unstyled-link">Bro Board</a>
                                                    </h3>
                                                    <div class="card-information">
                                                        <span class="caption-large light"></span>
                                                        <div class="price ">
                                                            <div class="price__container">
                                                                <div class="price__regular">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span class="price-item price-item--regular">$00.00 AUD</span>
                                                                </div>
                                                                <div class="price__sale">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span><s class="price-item price-item--regular"></s></span>
                                                                    <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                                                    <span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
                                                                </div>
                                                                <small class="unit-price caption hidden">
                                                                    <span class="visually-hidden">Unit price</span>
                                                                    <span class="price-item price-item--last">
                                                                        <span></span>
                                                                        <span aria-hidden="true">/</span>
                                                                        <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                        <span></span>
                                                                    </span>
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card__badge bottom left"></div>
                                        </div>

                                        <button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
                                            <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
                                            <span> Add To Cart </span>
                                        </button>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__media">
                                                <div class="media media--transparent">
                                                    <img src="assets/images/bro-cutter.png" alt="Bro Cutter" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="card__content">
                                                <div class="card__information">
                                                    <div class="semi-head">Dough Bros Pizza Ovens</div>
                                                    <h3 class="card__heading h5">
                                                        <a href="#" id="" class="full-unstyled-link">Bro Cutter</a>
                                                    </h3>
                                                    <div class="card-information">
                                                        <span class="caption-large light"></span>
                                                        <div class="price ">
                                                            <div class="price__container">
                                                                <div class="price__regular">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span class="price-item price-item--regular">$00.00 AUD</span>
                                                                </div>
                                                                <div class="price__sale">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span><s class="price-item price-item--regular"></s></span>
                                                                    <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                                                    <span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
                                                                </div>
                                                                <small class="unit-price caption hidden">
                                                                    <span class="visually-hidden">Unit price</span>
                                                                    <span class="price-item price-item--last">
                                                                        <span></span>
                                                                        <span aria-hidden="true">/</span>
                                                                        <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                        <span></span>
                                                                    </span>
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card__badge bottom left"></div>
                                        </div>

                                        <button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
                                            <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
                                            <span> Add To Cart </span>
                                        </button>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                            <div class="card__inner color-background-2 ratio">
                                                <div class="card__media">
                                                    <div class="media media--transparent">
                                                        <img src="assets/images/turning-peel.png" alt="Turning peel" class="motion-reduce" width="248" height="231">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card__content">
                                                <div class="card__information">
                                                    <div class="semi-head">Dough Bros Pizza Ovens</div>
                                                    <h3 class="card__heading h5">
                                                        <a href="#" id="" class="full-unstyled-link">Turning peel</a>
                                                    </h3>
                                                    <div class="card-information">
                                                        <span class="caption-large light"></span>
                                                        <div class="price ">
                                                            <div class="price__container">
                                                                <div class="price__regular">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span class="price-item price-item--regular">$00.00 AUD</span>
                                                                </div>
                                                                <div class="price__sale">
                                                                    <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                                                    <span><s class="price-item price-item--regular"></s></span>
                                                                    <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                                                    <span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
                                                                </div>
                                                                <small class="unit-price caption hidden">
                                                                    <span class="visually-hidden">Unit price</span>
                                                                    <span class="price-item price-item--last">
                                                                        <span></span>
                                                                        <span aria-hidden="true">/</span>
                                                                        <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                        <span></span>
                                                                    </span>
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card__badge bottom left"></div>
                                            </div>

                                            <button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
                                                <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
                                                <span> Add To Cart </span>
                                            </button>
                                    </div>
                                </div>
                            </li>

                        </ul>
                </div>
            </div>
        </div>

        <img src="assets/images/gradient-center-top.png" alt="gradient-center-top" title="" width="1920" height="380" class="gradient-img gradient-center">

        <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
    </section>





</main>
<?php get_footer();