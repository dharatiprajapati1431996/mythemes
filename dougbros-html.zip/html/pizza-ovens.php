<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper pizza-oven-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative mb-100">
        <img class="bgimg" src="assets/images/pizza-oven-banner.jpg" height="400" width="1920" alt="pizza-oven-banner">
       
            <div class="page-width">
                <div class="heading-50">Pizza Ovens</div>
            </div>
            
            <div class="breacurmb-wrapper">
                <div class="page-width">
                    <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="#">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Pizza Ovens</span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100 relative">
					 <img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					 <div class="page-width">
								<div class="two-column-ul">
										 <div class="two-column-li">
												 <a href="#">
														<div class="two-column-box">
															 <div class="column-img">
																		<img src="assets/images/nevo-pizza-oven-image.jpg" alt="nevo-pizza-oven-image" title="" width="780" height="450">
														   </div>
														  <div class="column-bottom">
																		<div class="cbtm-left">
																				<div class="cbtm-title">Nevo Pizza Oven</div>
																			 <div class="cbtm-price">$595.00 AUD</div>
																		</div>
																	 <div class="cbtm-right">
																				<div class="button button-black">Shop Now</div>
																	 </div>
														  </div>
												 </div>	
												 </a>	
										 </div>
										 <div class="two-column-li">
												 <a href="#">
														<div class="two-column-box">
															 <div class="column-img">
																		<img src="assets/images/nevo-digital-pizza-oven-image.jpg" alt="nevo-digital-pizza-oven-image" title="" width="780" height="450">
														   </div>
														  <div class="column-bottom bg-blue">
																		<div class="cbtm-left">
																				<div class="cbtm-title">Nevo+ Digital Pizza Oven</div>
																			 <div class="cbtm-price">$695.00 AUD</div>
																		</div>
																	 <div class="cbtm-right">
																				<div class="button button-black">Shop Now</div>
																	 </div>
														  </div>
												 </div>	
												 </a>	
										 </div>
							  </div>
							</div>
					 <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
    </section>


</main>
<?php get_footer();