<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper testimonial-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative mb-100">
        <img class="bgimg" src="assets/images/testimonial-banner.jpg" height="400" width="1920" alt="testimonial-banner">
       
            <div class="page-width">
                <div class="heading-50">Testimonials</div>
            </div>
            
            <div class="breacurmb-wrapper">
                <div class="page-width">
                    <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="#">Home</a>
																																	   <a href="#">Resources</a>
                                    <span class="breadcrumb_last" aria-current="page">Testimonials</span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        
    </section>
    <!-- Inner Banner Section -->


    <section class="inpage mb-100 relative">
					 <img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					 <div class="page-width">
								
							<ul class="testimonial-ul test-three-block">
													 <li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Hunter Made It Easy"
																	 </div>
																	 <div class="t-content">
																					<p>I wanted a small pizza oven for my backyard, and Hunter was great to deal with. He explained everything, and the oven has been perfect.Simple to use, quick to heat up, and the pizzas come out great every time...</p>
																	 </div>
																	 <div class="t-name">Jessica T.</div>
															 </div>
													 </li>
													 <li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Great for Backyard Pizza Nights"
																	 </div>
																	 <div class="t-content">
																					<p>Picked up a pizza oven from Clyde, and it’s been awesome. He helped me choose the right one, and it’s super easy to use. Heats up fast and makes amazing pizzas. Perfect for weekends with the family!</p>
																	 </div>
																	 <div class="t-name">Cameron L.</div>
															 </div>
													 </li>
													<li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Lincoln Knows His Stuff"
																	 </div>
																	 <div class="t-content">
																					<p>Lincoln helped me find the right pizza oven, and I love it. Feels just like using a BBQ fast, fun, and great results. Definitely recommend if you love homemade pizza!...</p>
																	 </div>
																	 <div class="t-name">Mark R.</div>
															 </div>
													 </li>
													 <li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"This is dummy text"
																	 </div>
																	 <div class="t-content">
																					<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site.  Hence, don't worry about this dummy text...</p>
																	 </div>
																	 <div class="t-name">James K.</div>
															 </div>
													 </li>
														<li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"we use it at Supple during"
																	 </div>
																	 <div class="t-content">
																					<p>We use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site...</p>
																	 </div>
																	 <div class="t-name">John D.</div>
															 </div>
													 </li>
														<li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Supple during web designing"
																	 </div>
																	 <div class="t-content">
																					<p>Supple during web designing in case we don't have content for new pages and it is changed during development of the new site hence don't worry about this dummy...</p>
																	 </div>
																	 <div class="t-name">Carlos T.</div>
															 </div>
													 </li>
													 <li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"This is dummy text"
																	 </div>
																	 <div class="t-content">
																					<p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site.  Hence, don't worry about this dummy text..</p>
																	 </div>
																	 <div class="t-name">James K.</div>
															 </div>
													 </li>
													<li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"we use it at Supple during"
																	 </div>
																	 <div class="t-content">
																					<p>We use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site...</p>
																	 </div>
																	 <div class="t-name">John D.</div>
															 </div>
													 </li>
														<li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Supple during web designing"
																	 </div>
																	 <div class="t-content">
																					<p>Supple during web designing in case we don't have content for new pages and it is changed during development of the new site hence don't worry about this dummy...</p>
																	 </div>
																	 <div class="t-name">Carlos T.</div>
															 </div>
													 </li>
											 </ul>
								
							   <div class="link-center"><a href="#" class="link">Load more Testimonials</a></div>
							
							</div>
					 <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
    </section>


</main>
<?php get_footer();