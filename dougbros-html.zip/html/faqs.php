<?php require_once __DIR__ . '/includes/includes.php'; ?> 
<?php get_header(); ?> 
<main class="page_wrapper faq-page">
	
  <!-- Inner Banner Section -->
  <section class="inner-banner relative mb-100">
    <img class="bgimg" src="assets/images/faq-banner-image.jpg" height="400" width="1920" alt="faq-banner-image">
    <div class="page-width">
      <div class="heading-50">FAQs</div>
    </div>
    <div class="breacurmb-wrapper">
      <div class="page-width">
        <ul class="woo_breadcums">
          <li>
            <span>
              <span>
                <a href="#">Home</a>
                <a href="#">Resources</a>
                <span class="breadcrumb_last" aria-current="page">FAQs</span>
              </span>
            </span>
          </li>
        </ul>
      </div>
    </div>
  </section>
	
  <!-- Inner Banner Section -->
  <section class="inpage mb-100 relative">
			 <img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
    <div class="page-width">
      <div class="flex-container wrap">
							
        <div class="panel-left sticky">
          <div class="panel-cta relative">
            <img src="assets/images/oven-pizza-bg.jpg" alt="oven-pizza-bg" title="" width="370px" height="530px" class="bgimg">
            <div class="cta-inner-wrapper video-wrap">
              <a href="assets/images/sample-video.mp4" class="fancybox" rel="group" data-fancybox="group" tabindex="0">
                <div class="video-icon">
                  <img src="assets/images/svg/play-icon.svg" alt="play icon" title="" width="62" height="62">
                </div>
                <div class="heading-34">Watch the Magic Behind Every Perfect Pizza</div>
                <div class="video-content">See how our pizza ovens bring the perfect pizza to life, with every detail crafted for delicious results.</div>
                <div class="button">Watch Now</div>
              </a>
            </div>
          </div>
        </div>
        
							 <div class="panel-right">
										<div class="faq_accordion"> 
													<!-- Section 1 -->
													<div class="accordion_in">
															<div class="acc_head">Is a gas oven better for pizza?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
													<!-- Section 2 -->
													<div class="accordion_in">
															<div class="acc_head">Are gas-fired pizza ovens any good?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											  <!-- Section 3 -->
												 <div class="accordion_in">
															<div class="acc_head">What are the main benefits of owning a pizza oven compared to a conventional oven?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											  <!-- Section 4 -->
													<div class="accordion_in">
															<div class="acc_head">What should I consider when choosing the right pizza oven for my needs?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											  <!-- Section 5 -->
													<div class="accordion_in">
															<div class="acc_head">We use it at Supple during web designing in case we don't have content for new?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											  <!-- Section 6 -->
													<div class="accordion_in">
															<div class="acc_head">This is dummy text we use it at supple during web designing in?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
												 <!-- Section 7 -->
													<div class="accordion_in">
															<div class="acc_head">Supple during web designing in case we don't have content for new pages and it is?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											  <!-- Section 8 -->
													<div class="accordion_in">
															<div class="acc_head">It is changed during development of the new site?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											  <!-- Section 9 -->
													<div class="accordion_in">
															<div class="acc_head">Hence don't worry about this dummy text we use this dummy text to give you?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											  <!-- Section 10 -->
													<div class="accordion_in">
															<div class="acc_head">We use it at Supple during web designing in case we don't have content for new?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											</div>
							 </div>
							
      </div>
    </div>
			 <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
  </section>
	
</main> 

<?php get_footer();