<?php require_once __DIR__ . '/includes/includes.php'; ?> 
<?php get_header(); ?> 
<main class="page_wrapper recipe-page">
	
  <!-- Inner Banner Section -->
  <section class="inner-banner relative mb-100">
    <img class="bgimg" src="assets/images/recipes-banner-image.jpg" height="400" width="1920" alt="recipes-banner-image">
    <div class="page-width">
      <div class="heading-50">Recipes</div>
    </div>
    <div class="breacurmb-wrapper">
      <div class="page-width">
        <ul class="woo_breadcums">
          <li>
            <span>
              <span>
                <a href="#">Home</a>
                <a href="#">Resources</a>
                <span class="breadcrumb_last" aria-current="page">Recipes</span>
              </span>
            </span>
          </li>
        </ul>
      </div>
    </div>
  </section>
	
  <!-- Inner Banner Section -->
  <section class="inpage mb-100 relative">
			 <img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
			
    <div class="page-width">
      <ul class="recipes-ul">
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/pizza-dough.jpg" alt="pizza-dough-image" title="" width="360" height="450">
															 </div>
															 <div class="recipes-bottom bg-babypink">
																		<div class="recipes-title">How to make Pizza Dough</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/detroit-style-pizza.jpg" alt="detroit-pizza-image" title="" width="360" height="450">
															 </div>
															 <div class="recipes-bottom bg-blue">
																		<div class="recipes-title">Australian Detroit Style Pizza</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/french-half-pizza.jpg" alt="french-pizza-image" title="" width="360" height="450">
															 </div>
															 <div class="recipes-bottom bg-yellow">
																		<div class="recipes-title">French Half and Half Pizza </div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/bachett-pizza.jpg" alt="attilio-pizza" title="" width="360" height="450">
															 </div>
															 <div class="recipes-bottom bg-greenish-cyan">
																		<div class="recipes-title">Attilio Bachetti’s Pizza Diavola</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/cheddar-pizza.jpg" alt="cheddar-pizza" title="" width="360" height="450">
															 </div>
															 <div class="recipes-bottom bg-greenish-cyan">
																		<div class="recipes-title">Haggis, Potato & Cheddar Pizza</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/pepperoni-pizza.jpg" alt="pepperoni-pizza" title="" width="360" height="450">
															 </div>
															 <div class="recipes-bottom bg-yellow">
																		<div class="recipes-title">Pepperoni Pizza</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/margherita-pizza.jpg" alt="margherita-pizza" title="" width="360" height="450">
															 </div>
															 <div class="recipes-bottom bg-babypink">
																		<div class="recipes-title">Margherita Pizza</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
							  </ul>
    </div>
			
			 <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
  </section>
	
</main> 

<?php get_footer();