<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML Theme</title>
    <?php wp_head(); ?>
</head>

<body class="have-notification-open">
    <!-- Start Header -->

    <header class="mainheader" id="shopify-section-header">

        <a class="togglebtn"><span></span></a>
        <div class="overlay"></div>


        <div class="notificaton-head header-notice-bar">
            <p>Free Australia wide shipping this month!</p>

            <a href="#" class="close">
                <img src="assets/images/svg/close.svg" alt="close" title="" width="" height="">
            </a>
        </div>



        <div class="navbar-wrapper">
            <div class="page-width">
                <div class="flex-container wrap">
                    <div class="logo-left"> <a href="home.php" class="disblock"><img src="assets/images/dough-bros-pizza-ovens.svg" alt="dough-bros-pizza-ovens" title="" width="295" height="58"></a> </div>

                    <div class="menu_link">
                        <div class="menulogo"> 
                            <a href="home.php" class="disblock">
                                <img src="assets/images/dough-bros-pizza-ovens.svg" alt="dough-bros-pizza-ovens" title="" width="295" height="58">
                            </a> 
                        </div>
                        <nav>
                            <ul>
                                <li><a href="home.php">Home</a> </li>
                                <li class="has-sub">
                                    <a href="pizza-ovens.php">Pizza Ovens</a>
                                    <div class="submenu">
                                       <ul class="sublink">
                                            <li>
                                                <a href="gas-pizza-oven-sale.php">
                                                    <div class="menu-img">
                                                        <img src="assets/images/gas-pizza-oven-menu.jpg" alt="gas-pizza-oven-menu" title="" width="" height="">
                                                    </div>
                                                    Gas Pizza Oven
                                                </a>
                                            </li>
                                            <li>
                                                <a href="">
                                                    <div class="menu-img">
                                                        <img src="assets/images/outdoor-gas.jpg" alt="Outdoor Gas Pizza Ovens" title="" width="" height="">
                                                    </div>
                                                    Outdoor Gas Pizza Ovens
                                                </a>
                                            </li>
                                            <li>
                                                <a href="">
                                                    <div class="menu-img">
                                                        <img src="assets/images/portable-gas.jpg" alt="Portable Gas Pizza Oven" title="" width="" height="">
                                                    </div>
                                                    Portable Gas Pizza Oven
                                                </a>
                                            </li>
                                       </ul>
                                    </div>
                                </li>
                                <li> <a href="#">Bundles</a></li>
                                <li class="blankli"></li>
                                <li><a href="product-listing.php">Accessories  </a></li>
                                <li class="has-sub">
                                    <a href="#">Resources</a>
                                    <div class="submenu simple-dropdown">
                                       <ul class="sublink">
                                            <li>
                                                <a href="faqs.php">
                                                    <div class="menu-img">
                                                        <img src="assets/images/svg/faq-icon.svg" alt="faq" title="" width="" height="">
                                                    </div>
                                                    FAQs
                                                </a>
                                            </li>
                                            <li>
                                                <a href="guides.php">
                                                    <div class="menu-img">
                                                        <img src="assets/images/svg/guides-icon.svg" alt="guides" title="" width="" height="">
                                                    </div>
                                                    Guides
                                                </a>
                                            </li>
                                            <li>
                                                <a href="recipes.php">
                                                    <div class="menu-img">
                                                        <img src="assets/images/svg/recipes-icon.svg" alt="recipes" title="" width="" height="">
                                                    </div>
                                                    Recipes
                                                </a>
                                            </li>
                                            <li>
                                                <a href="testimonials.php">
                                                    <div class="menu-img">
                                                        <img src="assets/images/svg/testimonials-icon.svg" alt="testimonials" title="" width="" height="">
                                                    </div>
                                                    Testimonials
                                                </a>
                                            </li>
                                       </ul>
                                    </div>
                                </li>
                                <li><a href="contact.php" class="btn_blk">Contact </a> </li>
                            </ul>
                        </nav>
                    </div>

                    <div class="header__icons">
                        <div class="desktop-localization-wrapper"></div>
                            <details-modal class="header__search">
                                <details>
                                    <summary class="header__icon header__icon--search header__icon--summary link focus-inset modal__toggle" aria-haspopup="dialog" aria-label="Search" role="button">
                                        <span>
                                            <img src="assets/images/svg/search.svg" alt="search" title="" width="" height="">
                                        </span>
                                    </summary>

                                    <div class="search-modal modal__content gradient" role="dialog" aria-modal="true" aria-label="Search">
                                        <div class="modal-overlay"></div>
                                        <div class="search-modal__content search-modal__content-bottom" tabindex="-1">
                                            <predictive-search class="search-modal__form" data-loading-text="Loading...">
                                                <form action="/search" method="get" role="search" class="search search-modal__form">
                                                    <div class="field">
                                                        <input class="search__input field__input" id="Search-In-Modal" type="search" name="q" value="" placeholder="Search" role="combobox" aria-expanded="false" aria-owns="predictive-search-results" aria-controls="predictive-search-results" aria-haspopup="listbox" aria-autocomplete="list" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false">
                                                        <label class="field__label" for="Search-In-Modal">Search</label>
                                                        <input type="hidden" name="options[prefix]" value="last">
                                                        <button type="reset" class="reset__button field__button hidden" aria-label="Clear search term">
                                                          <svg class="icon icon-close" aria-hidden="true" focusable="false">
                                                            <use xlink:href="#icon-reset">
                                                          </use></svg>
                                                        </button>
                                                        <button class="search__button field__button" aria-label="Search">
                                                          <svg class="icon icon-search" aria-hidden="true" focusable="false">
                                                            <use href="#icon-search">
                                                          </use></svg>
                                                        </button>
                                                    </div>

                                                    <div class="predictive-search predictive-search--header" tabindex="-1" data-predictive-search="">
                                                        <div class="predictive-search__loading-state">
                                                            <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </div>

                                                    <span class="predictive-search-status visually-hidden" role="status" aria-hidden="true"></span>
                                                </form>
                                            </predictive-search>

                                            <button type="button" class="search-modal__close-button modal__close-button link link--text focus-inset" aria-label="Close">
                                                <svg class="icon icon-close" aria-hidden="true" focusable="false"><use href="#icon-close"></use></svg>
                                            </button>
                                        </div>
                                    </div>
                                </details>
                            </details-modal>

                            <a href="#" class="header__icon header__icon--account link focus-inset">
                                <account-icon>
                                    <img src="assets/images/svg/user.svg" alt="user" title="" width="" height="">

                                </account-icon>
                                <span class="visually-hidden">Log in</span>
                            </a>

                            <a href="#" class="header__icon header__icon--cart link focus-inset" id="cart-icon-bubble">
                                <img src="assets/images/svg/cart-white.svg" alt="cart" title="" width="" height="">
                                <span class="visually-hidden">Cart</span>
                            </a>
                    </div>
                </div>

            </div>
        </div>
       
    </header> 
    <!-- End Header -->