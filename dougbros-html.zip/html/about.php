<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper about-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative mb-100">
        <img class="bgimg" src="assets/images/about-inner.jpg" height="400" width="1920" alt="image">
       
            <div class="page-width">
                <div class="heading-50 ">About Us</div>
            </div>
            
            <div class="breacurmb-wrapper">
                <div class="page-width">
                    <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="#">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">About Us</span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        
    </section>
    <!-- Inner Banner Section -->

		  <!-- content -->
    <section class="content-wrapper relative mb-100">
					<div class="page-width">
							
						<!-- 1 -->
						<div class="flex-container wrap flex-row-reverse ctent-block-wr"> 
									<div class="ctent-block">
										 <div class="semi-head">Our Story</div>
										 <div class="heading-50">The Dough Bros Story</div>
										 <p>At Dough Bros, we’re a father and two sons from Melbourne who love good food and even better company. We started this business to bring high-quality, gas powered pizza ovens to homes across Australia. Nothing beats a crispy base and that authentic smoky flavour, and we believe everyone should be able to make restaurant-quality pizza in their own backyard.</p>
										 <p>Designed in Australia, our ovens are built for durability, efficiency, and ease of use. Whether you're cooking for family, friends, or just yourself, they make it simple to create incredible pizza, every time.</p>
										 <p>From our family to yours.... fire it up and enjoy.</p>
								 </div>
								 <div class="ctent-img">
										  <img src="assets/images/dough-bros-story-image.jpg" alt="dough-bros-story-image" title="" width="780" height="550">
								 </div>
						 </div>
							
				
						
					</div>
						<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
	   </section>
	
			 <?php block('video-section'); ?>
	
	   <!-- start content section -->
	   <section class="content-wrapper relative">
					<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					<div class="page-width">
							
						<!-- 1 -->
						<div class="flex-container wrap flex-row-reverse ctent-block-wr"> 
									<div class="ctent-block">
										 <img src="assets/images/dough-bros-pizza-ovens.svg" alt="dough-bros-pizza-ovens" title="" width="271" height="52" class="logo-content">
										 <div class="heading-50">Crafted to Perform, Designed for Perfection</div>
										 <p>Our pizza ovens are designed for convenience, speed, and performance. With fast heat-up times, even cooking, and durable construction, they make creating restaurant-quality pizzas at home easy. Whether you're a beginner or a pizza pro, our ovens offer the perfect balance of quality and ease of use.</p>
										 
										 <a href="#" class="button">Find your pizza oven</a>
										
								 </div>
								 <div class="ctent-img">
										  <img src="assets/images/pizza-oven.png" alt="pizza-oven" title="" width="679" height="618">
								 </div>
						 </div>
					 
						<hr>
						
					</div>
	   </section>
	
	    	   <!-- why choose -->
	   <section class="whychoose-sec mb-100 relative">
	     <div class="page-width">
								 <div class="content-width">
											 <div class="heading-50">Why Choose a Gas Fired Pizza Oven for Your Melbourne Home?</div>
										  <p>Gas-fired pizza ovens are an excellent choice for residents who want to appreciate authentic, wood-fired style pizzas without the hassle of managing a wood-burning oven. Here are some reasons why a gas fired pizza oven is a must-have for your Melbourne home:</p>
							  </div>
								 
							  <div class="whychs-wrap">
										<div class="whychs-li">
											 	<div class="whychs-box bg-babypink">
													   <img src="assets/images/svg/heat-distribution-icon.svg" alt="heat-distribution-icon" title="" width="62" height="52">
														  <div class="whychs-info">
																		 <div class="whychs-title">Consistent Heat Distribution</div>
																	  <p>Our gas pizza ovens are engineered to provide even heat distribution so that your pizza cooks uniformly without any cold spots.</p>
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-yellow">
													   <img src="assets/images/svg/cooking-time-icon.svg" alt="cooking-time-icon" title="" width="54" height="56">
														  <div class="whychs-info">
																		 <div class="whychs-title">Quick Cooking Times</div>
																	  <p>With a gas-fired pizza oven, you can have a delicious, piping-hot pizza ready in just minutes. Say goodbye to long waiting times and hello to fast, satisfying meals.</p>
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-greenish-cyan">
													   <img src="assets/images/svg/cooking-option-icon.svg" alt="cooking-option-icon" title="" width="48" height="56">
														  <div class="whychs-info">
																		 <div class="whychs-title">Versatile Cooking Options</div>
																	  <p>While our ovens excel at making pizzas, they are also perfect for cooking a diverse range of other dishes, such as roasted vegetables, grilled meats, and even desserts like sweet calzones.</p>
														  </div>
											  </div>
										</div>
							  </div>
							
				  </div>
					<img src="assets/images/gradient-center-top.png" alt="gradient-center-top" title="" width="1920" height="380" class="gradient-img gradient-center">
	   </section>
	
	  

</main>
<?php get_footer();