<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper gas-pizza-oven-sale-page">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative">
        <img class="bgimg" src="assets/images/gas-pizza-oven-sale-banner.jpg" height="400" width="1920" alt="gas-pizza-oven-sale-banner">
       
            <div class="page-width">
                <div class="heading-50">Gas Pizza Oven for Sale</div>
            </div>
            
            <div class="breacurmb-wrapper">
                <div class="page-width">
                    <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="#">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Gas Pizza Oven for Sale</span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        
    </section>
    <!-- Inner Banner Section -->
	  
	  	<?php block('key-feature'); ?>

		 	<!-- start content section -->
	   <section class="content-wrapper relative">
				 	<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					 <div class="page-width">
							 <!-- 1 -->
								<div class="flex-container wrap flex-row-reverse ctent-block-wr "> 
									<div class="ctent-block">
										 <p>If you're looking to buy a gas pizza oven for sale, you've come to the right place. At Dough Bros, we offer premium gas-fired pizza ovens that deliver restaurant-quality results in the comfort of your own home. </p> 
										 <p>Whether you're a passionate home cook or a professional chef, our ovens are designed to help you create delicious pizzas with ease. With Dough Bros, you're in great hands for all your pizza-making needs in Melbourne!</p>
										 <a href="#" class="button">Find your pizza oven</a>
									</div>
								 <div class="ctent-img">
										  <img src="assets/images/gas-pizza-oven.jpg" alt="gas-pizza-oven" title="" width="780" height="550">
								 </div>
						</div>
							 <hr>
						</div>
				</section>
			
	   <!-- Gas pizza oven section -->
	   <section class="pizza-oven-sec relative">
					 <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left gradient-topleft">
			   <div class="page-width">
							  <div class="content-width">
											<div class="semi-head">Make the perfect pizza</div>
							  		<div class="heading-50">Gas Pizza Oven Melbourne</div>
							  		<p>Are you searching for the ideal gas pizza oven in Melbourne to take your homemade pizzas to new heights? You're in great hands with Dough Bros! We provide premium gas-fired pizza ovens designed to help you create delicious, restaurant-quality pizzas right in your own backyard.</p>
									</div>	
								
							  <div class="two-column-ul">
										 <div class="two-column-li">
												 <a href="#">
														<div class="two-column-box">
															 <div class="column-img">
																		<img src="assets/images/nevo-pizza-oven-image.jpg" alt="nevo-pizza-oven-image" title="" width="780" height="450">
														   </div>
														  <div class="column-bottom">
																		<div class="cbtm-left">
																				<div class="cbtm-title">Nevo Pizza Oven</div>
																			 <div class="cbtm-price">$595.00 AUD</div>
																		</div>
																	 <div class="cbtm-right">
																				<div class="button button-black">Shop Now</div>
																	 </div>
														  </div>
												 </div>	
												 </a>	
										 </div>
										 <div class="two-column-li">
												 <a href="#">
														<div class="two-column-box">
															 <div class="column-img">
																		<img src="assets/images/nevo-digital-pizza-oven-image.jpg" alt="nevo-digital-pizza-oven-image" title="" width="780" height="450">
														   </div>
														  <div class="column-bottom bg-blue">
																		<div class="cbtm-left">
																				<div class="cbtm-title">Nevo+ Digital Pizza Oven</div>
																			 <div class="cbtm-price">$695.00 AUD</div>
																		</div>
																	 <div class="cbtm-right">
																				<div class="button button-black">Shop Now</div>
																	 </div>
														  </div>
												 </div>	
												 </a>	
										 </div>
							  </div>
							
								 <div class="link-center mb-100"> <a href="#">view all Pizza Ovens</a> </div>
							
					 </div>
				</section>
			
	  <!-- video -->
	  <?php block('video-section'); ?>
	
	  <!-- why Buy a Gas Pizza Oven -->
	  <section class="gas-pizzaoven-sec slick-arrow">
					<div class="page-width">
									<div class="content-width">
											 <div class="heading-50">Why Buy a Gas Pizza Oven?</div>
										  <p>Choosing to buy a gas pizza oven from Dough Bros is a fantastic investment for any pizza lover. Here's why:</p>
						   </div>
									
						   <div class="whychs-wrap block-slider">
										
										<div class="whychs-li">
											 	<div class="whychs-box bg-babypink">
													   <img src="assets/images/svg/cooking-time-icon.svg" alt="cooking-time-icon" title="" width="54" height="56">
														  <div class="whychs-info">
																		 <div class="whychs-title">Quick Cooking Times</div>
																	  <p>Our ovens, thanks to their high heat retention, can cook a pizza in under 90 seconds.</p>
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-yellow">
													   <img src="assets/images/svg/heat-distribution-icon.svg" alt="heat-distribution-icon" title="" width="62" height="52">
														  <div class="whychs-info">
																		 <div class="whychs-title">Consistent Heat Distribution</div>
																	  <p>Say goodbye to cold spots or unevenly cooked pizzas. Our ovens give you perfect pizza results every time!</p>
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-greenish-cyan">
													   <img src="assets/images/svg/cooking-option-icon.svg" alt="cooking-option-icon" title="" width="48" height="56">
														  <div class="whychs-info">
																		 <div class="whychs-title">Versatility</div>
																	  <p>While they excel at pizza, gas ovens can also cook a variety of other dishes, from roasted veggies to BBQ ribs.</p>
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-greenish-cyan">
													   <img src="assets/images/svg/cooking-option-icon.svg" alt="cooking-option-icon" title="" width="48" height="56">
														  <div class="whychs-info">
																		 <div class="whychs-title">Versatility</div>
																	  <p>While they excel at pizza, gas ovens can also cook a variety of other dishes, from roasted veggies to BBQ ribs.</p>
														  </div>
											  </div>
										</div> 
							  </div>
						
						   <div class="content-width">
											 <p>Choosing to buy a gas fired pizza oven from Dough Bros means you'll benefit from all these advantages and more. Our ovens are built to help you achieve pizza perfection every single time.</p>
						   </div>
						   
						    <hr>
						
				 </div>
	  </section>
	
	  	<!-- start content section -->
	   <section class="content-wrapper relative mb-100">
				 	<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					
					 <div class="page-width">
								
							 <div class="content-width">
										<div class="heading-50">Explore Benchtop Gas Pizza Ovens in Melbourne</div>
									 <p>At Dough Bros, we provide a variety of benchtop gas pizza ovens in Melbourne to suit every need and budget:</p>
							 </div>
							
							 <!-- 1 -->
								<div class="flex-container wrap flex-row-reverse ctent-block-wr "> 
									<div class="ctent-block">
										 <div class="heading-50">Benchtop Gas Pizza Ovens</div>
										 <p>Our base benchtop model is ideal for smaller spaces or outdoor kitchens. Compact and portable, it still packs a punch when it comes to performance. These ovens are perfect for anyone looking to enjoy authentic pizza without sacrificing valuable space.</p>
										 <a href="#" class="button">Find your pizza oven</a>
									</div>
								 <div class="ctent-img">
										  <img src="assets/images/benchtop-gas-pizza-oven.jpg" alt="benchtop-gas-pizza-oven" title="" width="780" height="550">
								 </div>
						  </div>
							 
							 <!-- 2 -->
								<div class="flex-container wrap ctent-block-wr "> 
									<div class="ctent-block">
										 <div class="heading-50">Rotating Gas Pizza Ovens</div>
										 <p>Take your pizza game to the next level with a rotating oven. The rotating internal stone will make sure your pizza is baked evenly, without the need for manual turning. This innovative design feature guarantees consistently cooked pizzas with minimal effort on your part.</p>
										 <a href="#" class="button">Find your pizza oven</a>
									</div>
								 <div class="ctent-img">
										  <img src="assets/images/rotating-gas-pizza.jpg" alt="rotating-gas-pizza" title="" width="780" height="550">
								 </div>
						  </div>
							 
						</div>
					
					<img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
				</section>
			 
	   <!-- Pizza oven shells -->
				<?php block('pizza-oven-shells-block'); ?>
	
			 <!-- start content section -->
	   <section class="content-wrapper">
					
					<div class="page-width">
						<!-- 1 -->
						<div class="flex-container wrap flex-row-reverse ctent-block-wr"> 
									<div class="ctent-block">
										 <img src="assets/images/dough-bros-pizza-ovens.svg" alt="dough-bros-pizza-ovens" title="" width="271" height="52" class="logo-content">
										 <div class="heading-50">Customisable Gas Pizza Oven Shells</div>
										 <p>Make your oven uniquely yours with our customisable colour options. Choose from a range of vibrant "toppings"! Whether you want a classic look or something bold and eye-catching, we've got you covered.</p>
										 <p>With Dough Bros, you have the freedom to choose the perfect gas pizza oven that aligns with your specific needs and preferences. Our ovens are for every pizza enthusiast.</p>
										 <a href="#" class="button">Find your pizza oven</a>
										
								 </div>
								 <div class="ctent-img">
										  <img src="assets/images/pizza-oven.png" alt="pizza-oven" title="" width="679" height="618">
								 </div>
						 </div>
						<hr>
					</div>
	   </section>
	   
	   <!-- why Buy a Gas Pizza Oven -->
	   <section class="gas-pizzaoven-sec slick-arrow mb-50">
					<div class="page-width">
									<div class="content-width">
											 <div class="heading-50">Need a Rotating Gas Pizza Oven in Melbourne? Experience the Dough Bros Difference</div>
										  <p>Whether you buy a standard or rotating gas pizza oven in Melbourne from Dough Bros, you're not just getting a high-performance product. You're also getting:</p>
						   </div>
									
						   <div class="whychs-wrap block-slider">
										
										<div class="whychs-li">
											 	<div class="whychs-box bg-lightorange">
													   <img src="assets/images/svg/australian-warranty-icon.svg" alt="australian-warranty-icon" title="" width="47" height="60">
														  <div class="whychs-info">
																		 <div class="whychs-title">Australian-based support and warranty for peace of mind</div>
																</div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-lightpink">
													   <img src="assets/images/svg/fast-delivery-icon.svg" alt="fast-delivery-icon" title="" width="84" height="63">
														  <div class="whychs-info">
																		 <div class="whychs-title">Faster delivery times, so you can start cooking sooner</div>
																	 
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-lightblue">
													   <img src="assets/images/svg/quality-icon.svg" alt="quality-icon" title="" width="63" height="64">
														  <div class="whychs-info">
																		 <div class="whychs-title">Affordable pricing without compromising on quality or performance</div>
																	 
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-lightblue">
													   <img src="assets/images/svg/quality-icon.svg" alt="quality-icon" title="" width="63" height="64">
														  <div class="whychs-info">
																		 <div class="whychs-title">Affordable pricing without compromising on quality or performance</div>
																	 
														  </div>
											  </div>
										</div> 
							  </div>
						
						   <div class="content-width">
											 <p>Choosing to buy a gas fired pizza oven from Dough Bros means you'll benefit from all these advantages and more. Our ovens are built to help you achieve pizza perfection every single time.</p>
						   </div>
						   
					</div>
	  </section>
	
	  <?php block('faq-block'); ?>
	 
	  	  	<!-- start content section -->
	   <section class="content-wrapper relative mb-100">
				 	<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					
					 <div class="page-width">
								 <!-- 1 -->
								<div class="flex-container wrap flex-row-reverse ctent-block-wr "> 
									<div class="ctent-block">
										 <div class="heading-50">Elevate Your Pizza Game with a Gas Pizza Oven For Sale from Dough Bros</div>
										 <p>Ready to experience the joy of authentic, delicious pizza at home? Browse our gas pizza ovens for sale. With Dough Bros, you'll be crafting pizza masterpieces in no time. Explore now, and let's get cooking!</p>
										 <a href="#" class="button">Find your pizza oven</a>
									</div>
								 <div class="ctent-img">
										  <img src="assets/images/content-image.jpg" alt="content-image" title="" width="780" height="550">
								 </div>
						  </div>
						</div>
				</section>
	
</main>
<?php get_footer();