<?php require_once __DIR__ . '/includes/includes.php'; ?> 
<?php get_header(); ?> 
<main class="page_wrapper guide-page">
	
  <!-- Inner Banner Section -->
  <section class="inner-banner relative mb-100">
    <img class="bgimg" src="assets/images/guides-banner-image.jpg" height="400" width="1920" alt="guides-banner-image">
    <div class="page-width">
      <div class="heading-50">Guides</div>
    </div>
    <div class="breacurmb-wrapper">
      <div class="page-width">
        <ul class="woo_breadcums">
          <li>
            <span>
              <span>
                <a href="#">Home</a>
                <a href="#">Resources</a>
                <span class="breadcrumb_last" aria-current="page">Guides</span>
              </span>
            </span>
          </li>
        </ul>
      </div>
    </div>
  </section>
	
  <!-- Inner Banner Section --> 
  <section class="inpage mb-100 relative">
			 <img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
			
    <div class="page-width">
						<div class="common-block-wr">
								 <div class="block-left">
											<div class="block-title">Prepare</div>
										 <div class="heading-50">We use it at Supple during web designing in case we don't have content for new</div>
										 <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
											
										 <div class="video-block">
													<img src="assets/images/video-image-block.jpg" alt="video image block" title="" width="1000" height="550">
													<div class="video-icon">
														<img src="assets/images/svg/play-icon.svg" alt="play icon" title="" width="62" height="62">
													</div>
										 </div>
											
										 <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
										
										 <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
										
										 <div class="heading-22">We use it at Supple during web designing in case we don't have content for new.</div>
										 <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site.</p>
										
										 <ul>
														<li>Supple during web designing in case we don't have content</li>
												  <li>We use it at Supple during web designing in case we don't have content</li>
												  <li>It at Supple during web designing in case we don't have content.</li>
												  <li>It is changed during development of the new site hence don't worry about.</li>
												  <li>Hence don't worry about this dummy text we use this dummy text to give you.</li>
												  <li>This is dummy text we use it at Supple during web designing in case.</li>
										 </ul>
										
										 <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text on this page would. This is dummy text, we use it at Supple during web designing in case we don't have content for new pages and it is changed during development of the new site. Hence, don't worry about this dummy text.</p>
										
							  </div>
							  <div class="block-right">
											<div class="guide_accordion"> 
													<!-- Section 1 -->
													<div class="accordion_in">
															<div class="acc_head">Tools</div>
															<div class="acc_content">
																 <ul class="acc-ul">
																			<li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/solid-fuel-image.jpg" alt="solid fuel image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Solid Fuel</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																		 <li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/gas-image.jpg" alt="gas-image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Gas</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																		 <li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/pizza-peel-image.jpg" alt="pizza-peel-image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Pizza Peel</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																		 <li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/infrared-thermometer-image.jpg" alt="infrared-thermometer-image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Infrared Thermometer</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																 </ul>
															</div>
													</div>
												
												 	<!-- Section 2 -->
													<div class="accordion_in">
															<div class="acc_head">Ingredients</div>
															<div class="acc_content">
															  <ul class="acc-ul">
																			<li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/solid-fuel-image.jpg" alt="solid fuel image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Solid Fuel</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																		 <li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/gas-image.jpg" alt="gas-image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Gas</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																		 <li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/pizza-peel-image.jpg" alt="pizza-peel-image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Pizza Peel</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																		 <li>
																					<div class="acc-li">
																						  <div class="acc-icon">
																									 	<img src="assets/images/infrared-thermometer-image.jpg" alt="infrared-thermometer-image" title="" width="70" height="70">
																						  </div>
																						  <div class="acc-desc">
																										<div class="acc-title">Infrared Thermometer</div>
																									 <p>We use it at Supple during web designing in case we don't have content for new</p>
																						 </div>
																				 </div>
																		 </li>
																 </ul>
															</div>
													</div>
										 </div>
							  </div>
					 </div>
    </div>
			
			 <img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
  </section>
	
</main> 

<?php get_footer();