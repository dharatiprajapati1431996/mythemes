<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="homepg">

    <?php block('home/banner'); ?>
			
	   <!-- Key Features -->
	   <?php block('key-feature'); ?>
	
	   <!-- Gas pizza oven section -->
	   <section class="pizza-oven-sec relative">
			   <div class="page-width">
							  <div class="content-width">
											<div class="semi-head">Make the perfect pizza</div>
							  		<div class="heading-50">Gas Pizza Oven Melbourne</div>
							  		<p>Are you searching for the ideal gas pizza oven in Melbourne to take your homemade pizzas to new heights? You're in great hands with Dough Bros! We provide premium gas-fired pizza ovens designed to help you create delicious, restaurant-quality pizzas right in your own backyard.</p>
									</div>	
								
							  <div class="two-column-ul">
										 <div class="two-column-li">
												 <a href="#">
														<div class="two-column-box">
															 <div class="column-img">
																		<img src="assets/images/nevo-pizza-oven-image.jpg" alt="nevo-pizza-oven-image" title="" width="780" height="450">
														   </div>
														  <div class="column-bottom">
																		<div class="cbtm-left">
																				<div class="cbtm-title">Nevo Pizza Oven</div>
																			 <div class="cbtm-price">$595.00 AUD</div>
																		</div>
																	 <div class="cbtm-right">
																				<div class="button button-black">Shop Now</div>
																	 </div>
														  </div>
												 </div>	
												 </a>	
										 </div>
										 <div class="two-column-li">
												 <a href="#">
														<div class="two-column-box">
															 <div class="column-img">
																		<img src="assets/images/nevo-digital-pizza-oven-image.jpg" alt="nevo-digital-pizza-oven-image" title="" width="780" height="450">
														   </div>
														  <div class="column-bottom bg-blue">
																		<div class="cbtm-left">
																				<div class="cbtm-title">Nevo+ Digital Pizza Oven</div>
																			 <div class="cbtm-price">$695.00 AUD</div>
																		</div>
																	 <div class="cbtm-right">
																				<div class="button button-black">Shop Now</div>
																	 </div>
														  </div>
												 </div>	
												 </a>	
										 </div>
							  </div>
							
								 <div class="link-center mb-100"> <a href="#">view all Pizza Ovens</a> </div>
							
							   <hr>
							  
					 </div>
					 <img src="assets/images/gradient-center.png" alt="gradient-center" title="" width="1920" height="762" class="gradient-img gradient-center">
	   </section>
		


	   	 <?php block('home/accessories'); ?>



			 <!-- watch video section -->
			 <?php block('video-section'); ?>
			 
			 <!-- start content section -->
	   <section class="content-wrapper mb-100 relative">
					<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					<div class="page-width">
							
						<!-- 1 -->
						<div class="flex-container wrap flex-row-reverse ctent-block-wr "> 
									<div class="ctent-block">
										 <div class="semi-head">Pizza Perfection Starts Here</div>
										 <div class="heading-50">Accessories</div>
										 <p>Great pizza starts with the right tools. From peels to cutters, our accessories are designed to make your pizza-making experience easier and more enjoyable, helping you create perfect pizzas every time.</p>
										 
										 <a href="#" class="button">shop Accessories</a>
										
								 </div>
								 <div class="ctent-img">
										  <img src="assets/images/accessories-image.jpg" alt="accessories-image" title="" width="780" height="550">
								 </div>
							  
						 </div>
						
						<!-- 2 -->
						<div class="flex-container wrap ctent-block-wr"> 
									<div class="ctent-block">
										 <div class="semi-head">The Ultimate Pizza Cooking Bundles</div>
										 <div class="heading-50">Bundles</div>
										 <p>Get everything you need in one go with our pizza oven bundles! Complete with essential accessories, these bundles are designed to make pizza-making effortless and delicious from start to finish.</p>
										 <a href="#" class="button">shop Bundles</a>
									</div>
								 <div class="ctent-img">
										  <img src="assets/images/bundles-image.jpg" alt="bundles-image" title="" width="780" height="550">
								 </div>
						 </div>
					</div>
					
					<img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
	   </section>
	 	
				<!-- Pizza oven shells -->
				 <?php block('pizza-oven-shells-block'); ?>
				
	   <!-- Discover Our Recipes -->
			 <section class="recipes-sec mb-100">
					 <div class="container-fluid"> 
							  <div class="content-width">
								 			<div class="heading-50">Discover Our Recipes</div>
							  			<p>Ready to get creative? Explore our delicious pizza recipes, from timeless classics to exciting new flavours. Whether you're cooking for family or friends, there's something for everyone to enjoy.</p>
									</div>	
							  
									<ul class="recipes-ul">
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/pizza-dough-image.jpg" alt="pizza-dough-image" title="" width="420" height="550">
															 </div>
															 <div class="recipes-bottom bg-babypink">
																		<div class="recipes-title">How to make Pizza Dough</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/detroit-pizza-image.jpg" alt="detroit-pizza-image" title="" width="420" height="550">
															 </div>
															 <div class="recipes-bottom bg-blue">
																		<div class="recipes-title">Australian Detroit Style Pizza</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/french-pizza.jpg" alt="french-pizza-image" title="" width="420" height="550">
															 </div>
															 <div class="recipes-bottom bg-yellow">
																		<div class="recipes-title">French Half and Half Pizza </div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
										<li>
											 <a href="#">
													 <div class="recipes-li">
																<div class="recipes-img">
																		<img src="assets/images/attilio-pizza.jpg" alt="attilio-pizza" title="" width="420" height="550">
															 </div>
															 <div class="recipes-bottom bg-greenish-cyan">
																		<div class="recipes-title">Attilio Bachetti’s Pizza Diavola</div>
																	 <div class="r-arrow"><img src="assets/images/svg/long-arrow.svg" alt="long-arrow" title="" width="28" height="18"></div> 
															 </div>
													 </div>
											 </a>
										</li>
							  </ul>
							  
							  <div class="button-border">
											<a href="#" class="button">explore More Recipes</a>
							  </div>
							  
					 </div>
	   </section>
	  
	  			 <!-- start content section -->
	   <section class="content-wrapper mb-100 relative">
					<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
					<div class="page-width">
							
						<!-- 1 -->
						<div class="flex-container wrap flex-row-reverse ctent-block-wr"> 
									<div class="ctent-block">
										 <img src="assets/images/dough-bros-pizza-ovens.svg" alt="dough-bros-pizza-ovens" title="" width="271" height="52" class="logo-content">
										 <div class="heading-50">Crafted to Perform, Designed for Perfection</div>
										 <p>Our pizza ovens are designed for convenience, speed, and performance. With fast heat-up times, even cooking, and durable construction, they make creating restaurant-quality pizzas at home easy. Whether you're a beginner or a pizza pro, our ovens offer the perfect balance of quality and ease of use.</p>
										 
										 <a href="#" class="button">Find your pizza oven</a>
										
								 </div>
								 <div class="ctent-img">
										  <img src="assets/images/pizza-oven.png" alt="pizza-oven" title="" width="679" height="618">
								 </div>
						 </div>
					
					</div>
	   </section>
	
	
	   <!-- testimonial -->
	   <section class="testimonial-sec mb-100">
				 <div class="page-width">
								<div class="testimonial-box">
										<div class="testimonial-left">
											 <div class="heading-80">Happy Pizza Makers</div>
											 <div class="t-subtitle">what our clients say about us</div>
											 
											 <div class="test-review">
													<div class="g-logo"><img src="assets/images/g-logo.png" alt="google logo" title="" width="28" height="29"></div>
													<div class="g-title">
														 <img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
														 Client Reviews
													</div>
											 </div>
											 
									 </div>
									 <div class="testimonial-right slick-arrow">
												<ul class="testimonial-ul">
													 <li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Hunter Made It Easy"
																	 </div>
																	 <div class="t-content">
																					<p>I wanted a small pizza oven for my backyard, and Hunter was great to deal with. He explained everything, and the oven has been perfect.Simple to use, quick to heat up, and the pizzas come out great every time...</p>
																	 </div>
																	 <div class="t-name">Jessica T.</div>
															 </div>
													 </li>
													 <li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Great for Backyard Pizza Nights"
																	 </div>
																	 <div class="t-content">
																					<p>Picked up a pizza oven from Clyde, and it’s been awesome. He helped me choose the right one, and it’s super easy to use. Heats up fast and makes amazing pizzas. Perfect for weekends with the family!</p>
																	 </div>
																	 <div class="t-name">Cameron L.</div>
															 </div>
													 </li>
													<li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Hunter Made It Easy"
																	 </div>
																	 <div class="t-content">
																					<p>I wanted a small pizza oven for my backyard, and Hunter was great to deal with. He explained everything, and the oven has been perfect.Simple to use, quick to heat up, and the pizzas come out great every time...</p>
																	 </div>
																	 <div class="t-name">Jessica T.</div>
															 </div>
													 </li>
													 <li>
															 <div class="testimonial-li">
																	 <div class="t-top">
																	 	<img src="assets/images/rating-image.png" alt="rating image" title="" width="105" height="17">
																			"Great for Backyard Pizza Nights"
																	 </div>
																	 <div class="t-content">
																					<p>Picked up a pizza oven from Clyde, and it’s been awesome. He helped me choose the right one, and it’s super easy to use. Heats up fast and makes amazing pizzas. Perfect for weekends with the family!</p>
																	 </div>
																	 <div class="t-name">Cameron L.</div>
															 </div>
													 </li>
											 </ul>
											 
											  <a href="#" class="v-link">View All Testimonials</a>
											
									 </div>
						  </div>
				 </div>
	  </section>
		
	   <!-- why choose -->
	   <section class="whychoose-sec mb-100 relative">
	     <div class="page-width">
								 <div class="content-width">
											 <div class="heading-50">Why Choose a Gas Fired Pizza Oven for Your Melbourne Home?</div>
										  <p>Gas-fired pizza ovens are an excellent choice for residents who want to appreciate authentic, wood-fired style pizzas without the hassle of managing a wood-burning oven. Here are some reasons why a gas fired pizza oven is a must-have for your Melbourne home:</p>
							  </div>
								 
							  <div class="whychs-wrap">
										<div class="whychs-li">
											 	<div class="whychs-box bg-babypink">
													   <img src="assets/images/svg/heat-distribution-icon.svg" alt="heat-distribution-icon" title="" width="62" height="52">
														  <div class="whychs-info">
																		 <div class="whychs-title">Consistent Heat Distribution</div>
																	  <p>Our gas pizza ovens are engineered to provide even heat distribution so that your pizza cooks uniformly without any cold spots.</p>
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-yellow">
													   <img src="assets/images/svg/cooking-time-icon.svg" alt="cooking-time-icon" title="" width="54" height="56">
														  <div class="whychs-info">
																		 <div class="whychs-title">Quick Cooking Times</div>
																	  <p>With a gas-fired pizza oven, you can have a delicious, piping-hot pizza ready in just minutes. Say goodbye to long waiting times and hello to fast, satisfying meals.</p>
														  </div>
											  </div>
										</div>
										<div class="whychs-li">
											 	<div class="whychs-box bg-greenish-cyan">
													   <img src="assets/images/svg/cooking-option-icon.svg" alt="cooking-option-icon" title="" width="48" height="56">
														  <div class="whychs-info">
																		 <div class="whychs-title">Versatile Cooking Options</div>
																	  <p>While our ovens excel at making pizzas, they are also perfect for cooking a diverse range of other dishes, such as roasted vegetables, grilled meats, and even desserts like sweet calzones.</p>
														  </div>
											  </div>
										</div>
							  </div>
							
				  </div>
					<img src="assets/images/gradient-center-top.png" alt="gradient-center-top" title="" width="1920" height="380" class="gradient-img gradient-center">
	   </section>
	
	   <!-- Frequently Asked Questions -->
				<?php block('faq-block'); ?>
	  
	
			 <!-- start content section -->
	   <section class="content-wrapper relative">
					<div class="page-width">
							
						<!-- 1 -->
						<div class="flex-container wrap flex-row-reverse ctent-block-wr"> 
									<div class="ctent-block">
										 <div class="semi-head">About us</div>
										 <div class="heading-50">The Dough Bros Story</div>
										 <p>At Dough Bros, we’re a father and two sons from Melbourne who love good food and even better company. We started this business to bring high-quality, gas powered pizza ovens to homes across Australia. Nothing beats a crispy base and that authentic smoky flavour, and we believe everyone should be able to make restaurant-quality pizza in their own backyard.</p>
										 <p>Designed in Australia, our ovens are built for durability, efficiency, and ease of use. Whether you're cooking for family, friends, or just yourself, they make it simple to create incredible pizza, every time.</p>
										 <p>From our family to yours.... fire it up and enjoy.</p>
										 <a href="#" class="button">Find out more</a>
										
								 </div>
								 <div class="ctent-img">
										  <img src="assets/images/dough-bros-story-image.jpg" alt="dough-bros-story-image" title="" width="780" height="550">
								 </div>
						 </div>
							
						 <hr>
						
					</div>
						<img src="assets/images/gradient-right.png" alt="gradient-right" title="" width="960" height="762" class="gradient-img gradient-right">
	   </section>
	
	   <!-- want a Gas pizza oven -->
	   <section class="gas-pizza-sec">
				  <div class="page-width">
					    <div class="content-width">
											 <div class="heading-50">Want a Gas Pizza Oven For Your Home? Trust Dough Bros!</div>
										  <p>When it comes to finding the perfect gas pizza oven, Dough Bros is your best bet. Here's why:</p>
							  </div>
								 
							  <div class="three-block-wrap">
											<div class="th-block"> 
													<div class="three-box bg-lightorange">
													 <div class="t-icon"><img src="assets/images/svg/australian-warranty-icon.svg" alt="australian-warranty-icon" title="" width="47" height="60"></div>
												  <div class="t-content">
														  <div class="heading-24">Australian-Based Support & Warranty</div>
															 <p>We provide local service and easy warranty claims so that you have a stress-free experience with your new oven.</p>
												  </div>
										   </div>
										 </div>
										 <div class="th-block"> 
													<div class="three-box bg-lightpink">
													 <div class="t-icon"><img src="assets/images/svg/fast-delivery-icon.svg" alt="fast-delivery-icon" title="" width="84" height="63"></div>
												  <div class="t-content">
														  <div class="heading-24">Fast Delivery Times</div>
															 <p>We understand that once you've decided on your ideal oven, you want to start cooking as soon as possible. That's why we offer quick shipping throughout Melbourne and beyond.</p>
												  </div>
										 </div>
										 </div>
										 <div class="th-block"> 
													<div class="three-box bg-lightblue">
													 <div class="t-icon"><img src="assets/images/svg/quality-icon.svg" alt="quality-icon" title="" width="63" height="64"></div>
												  <div class="t-content">
														  <div class="heading-24">Affordable Pricing without Compromising Quality</div>
															 <p>At Dough Bros, we believe that everyone should have access to high-quality pizza ovens. We offer competitive pricing without sacrificing the performance or durability of our products.</p>
												  </div>
										 </div>
										 </div>
							  </div>
								
							 <div class="content-width">
									<p>Join the growing community of satisfied Dough Bros customers and experience the joy of creating perfect pizzas in your own backyard. With our gas pizza ovens, you'll be the envy of your friends and family, hosting unforgettable pizza parties and impressing everyone with your culinary skills.</p>
									<p>Don't settle for mediocre homemade pizzas any longer. Invest in a Dough Bros gas pizza oven today and unleash your inner pizza chef. Shop our collection now and get ready to savour the best pizzas you've ever tasted, right in the comfort of your own home!</p>
							</div>
							
							<hr>
							
					 </div>
	   </section>
	
	   <!-- start content section -->
	   <section class="content-wrapper relative">
						<img src="assets/images/gradient-left.png" alt="gradient-left" title="" width="960" height="762" class="gradient-img gradient-left">
					<div class="page-width">
						<div class="flex-container wrap ctent-block-wr"> 
									<div class="ctent-block">
										 <p>Our gas pizza ovens are crafted with cutting-edge features and high-quality materials for even heat distribution and quick cooking times. Whether you're a passionate home cook or just love the taste of homemade pizza, our ovens will help you achieve the perfect crispy crust and bubbly toppings every single time.</p>
										 <div class="heading-27">Explore the Dough Bros Difference With a Residential Gas Pizza Oven</div>
										 <p>At Dough Bros, we are passionate about helping pizza lovers create the best possible pizzas at home. We stand out from the competition by offering:</p>
										
										<ul>
													<li>One-of-a-kind residential gas pizza ovens to match your kitchen</li>
											  <li>Premium materials and advanced design features, like rotating pizza stones and a stainless steel internal design.</li>
											 <li>Energy-efficient burners that minimise fuel consumption and heat loss</li>
											 <li>Portable and compact designs are perfect for home use, outdoor kitchens, and even food trucks</li>
										</ul>
										
									</div>
								 <div class="ctent-img">
										  <img src="assets/images/residential-gas-pizza-oven.jpg" alt="residential-gas-pizza-oven" title="" width="780" height="550">
								 </div>
						 </div>
						
						<hr>
						
					</div>
	   </section>

    <?php block('instagram'); ?>
	
</main>
<?php get_footer();