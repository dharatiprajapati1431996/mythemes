$(document).ready(function () {
  /*Scroll top*/
  var scrollTop = $(".scrollTop");
  $(window).scroll(function () {
    var topPos = $(this).scrollTop();
    if (topPos > 0) {
      $(scrollTop).css("opacity", "1");
    } else {
      $(scrollTop).css("opacity", "0");
    }
  });
  $(scrollTop).click(function () {
    $("html, body").animate(
      {
        scrollTop: 0,
      },
      600
    );
    return false;
  });
  /*Menu dropdown*/
  var ico = $('<i class="fa fa-angle-down menudrop"></i>');
  $(".menu_link li:has(.submenu) > a").append(ico);
  $(".menudrop").on("click", function (e) {
    $(this).parent().parent().addClass("no-hover");

    $(".menu_link ul li")
      .not($(this).parent().parent())
      .find(".submenu")
      .stop(true, true)
      .delay(200)
      .fadeOut(500);
    $(".menu_link ul li").not($(this).parent().parent()).removeClass("open");
    $(".menu_link ul li a .menudrop").not($(this)).removeClass("openedmenu");
    $(".menu_link ul li a .menudrop").not($(this)).addClass("closemenu");

    e.preventDefault();
    if ($(this).hasClass("openedmenu")) {
      $(this)
        .parent()
        .parent()
        .find(".submenu")
        .stop(true, true)
        .delay(200)
        .fadeOut(500);
      $(this).removeClass("openedmenu");
      $(this).addClass("closemenu");
    } else {
      $(this)
        .parent()
        .parent()
        .find(".submenu")
        .stop(true, true)
        .delay(200)
        .fadeIn(500);
      $(this).removeClass("closemenu");
      $(this).addClass("openedmenu");
    }
  });

  if ($(window).width() >= 1120) {
    $(".menu_link nav > ul > li.has-sub").hover(
      function () {
        $("body").addClass("menuoverlay");
        $(window).trigger("resize");
      },
      function () {
        $("body").removeClass("menuoverlay");
      }
    );
  }

  /*-----BURGER MENU-----*/
  $(".togglebtn, .overlay").click(function () {
    $(".togglebtn, .overlay, .menu_link").toggleClass("active");
    if ($(".overlay").hasClass("active")) {
      $(".overlay").fadeIn();
      $("html").addClass("menuhidden");
    } else {
      $(".overlay").fadeOut();
      $("html").removeClass("menuhidden");
    }
  });

  /*-----FIXED HEADER-----*/

  $(window).scroll(function () {
    if ($(window).scrollTop() > 200 && $(window).width() >= 319) {
      $("body").addClass("fixed-header");
    } else {
      $("body").removeClass("fixed-header");
    }
  });

 	/* Breadcurmb NO banner images */
  	
		if($('main').children().hasClass("no-banner-image")){ 
     			$("body").addClass("header-black");
		}


	 $(".keyfeature-ul").slick({
     arrows: false,
     dots: false,
     slidesToShow: 4,
     slidesToScroll: 1,
     horizontal: true,
     infinite: true,
     autoplay: true,
     pauseOnHover: false,
     autoplaySpeed: 3000,
     responsive: [
       {
         breakpoint:1200,
         settings: {
           slidesToShow:3,
           
         },
       },
						 {
         breakpoint:992,
         settings: {
           slidesToShow:2,
         },
       },
						 {
         breakpoint:576,
         settings: {
           slidesToShow:1,
										 centerMode:true,
										 centerPadding:'100px',
         },
       },
						{
         breakpoint:421,
         settings: {
           slidesToShow:1,
										 centerMode:true,
										 centerPadding:'70px',
         },
       },
						 {
         breakpoint:376,
         settings: {
           slidesToShow:1,
										 centerMode:true,
										 centerPadding:'40px',
         },
       }
     ],
   });



       // FOOTER TOGGLE

    $(".acc-nav .acc-nav-head").click (function(){
      if ($(window).width() < 992) {
          let $this = $(this);
          
          $this.toggleClass('showhide');

          let $wrapper = $this.closest('.acc-nav');
          let $heads = $wrapper.find('.acc-nav-head');

          $heads.not($this).removeClass('showhide');
          $heads.not('.showhide').next().stop().slideUp(300);
          $heads.filter('.showhide').next().stop().slideDown(300);
      }
  });


    // Header Notification

  $(".close").click(function() {
        $(".header-notice-bar").hide();
        $('body').removeClass('have-notification-open');
    });

  
});


//  select box

$(document).ready(function () {

 const select = document.getElementById("country-head");
  const flagImg = document.getElementById("flag-icon");

  function updateFlag() {
    const selectedOption = select.options[select.selectedIndex];
    const iconUrl = selectedOption.getAttribute("data-iconurl");
    flagImg.src = iconUrl;
  }

  // Initialize on page load
  updateFlag();

  // Update on change
  select.addEventListener("change", updateFlag);

  });

