$(document).ready(function () {

//FAQ
$(".guide_accordion").smk_Accordion({
    closeAble: true, //boolean
    //closeOther: false, //boolean
    activeIndex: 1 //second section open
});


});
    

