$(document).ready(function () {
  $(".whychs-wrap.block-slider").slick({
     arrows:true,
     dots: false,
     slidesToShow: 3,
     slidesToScroll: 1,
     autoplay: true,
     pauseOnHover: false,
     autoplaySpeed: 3000,
     responsive: [
       {
         breakpoint:992,
         settings: {
           slidesToShow: 2,
           
         },
       },
						{
         breakpoint:576,
         settings: {
           slidesToShow: 1,
           
         },
       }
     ],
   });
});
