$(document).ready(function () {

   $(".js-hmbanner").slick({
     arrows: false,
     dots: true,
     slidesToShow: 1,
     slidesToScroll: 1,
     horizontal: true,
     infinite: true,
     autoplay: true,
     fade: true,
     pauseOnHover: false,
     autoplaySpeed: 5000,
    
   });

		 $(".recipes-sec .recipes-ul").slick({
     arrows: false,
     dots: false,
     slidesToShow: 4,
     slidesToScroll: 1,
     horizontal: true,
     infinite: true,
     autoplay: true,
     pauseOnHover: false,
     autoplaySpeed: 3000,
     responsive: [
       {
         breakpoint:1200,
         settings: {
           slidesToShow:3,
         },
       },
						 {
         breakpoint:992,
         settings: {
           slidesToShow:3,
         },
       },
						{
         breakpoint:768,
         settings: {
           slidesToShow:2,
         },
       },
						{
         breakpoint:576,
         settings: {
           slidesToShow:1,
										 centerMode:true,
										 centerPadding:'50px',
         },
       }
     ],
   });

  /* testimonial */
		 $(".testimonial-box .testimonial-ul").slick({
     arrows:true,
     dots: false,
     slidesToShow: 2,
     slidesToScroll: 1,
     horizontal: true,
     infinite: true,
     autoplay: true,
     pauseOnHover: false,
     autoplaySpeed: 3000,
     responsive: [
       {
         breakpoint:992,
         settings: {
           slidesToShow: 1,
           
         },
       }
     ],
   });




		 $(".accessories-slider > ul").slick({
			     dots: false,
	            infinite: true,
	            arrows: true,
	            slidesToShow: 4,
	            slidesToScroll: 1,
	            autoplay: true,
	            autoplaySpeed: 5000,        
	            responsive: [
	                {
	                    breakpoint: 1440,
	                    settings: {
	                        slidesToShow: 3,
	                        slidesToScroll: 1,
	                    },
	                },        
	                {
	                    breakpoint: 992,
	                    settings: {
	                        slidesToShow: 2,
	                        slidesToScroll: 1,
	                    },
	                },        
	                {
	                    breakpoint: 481,
	                    settings: {
	                        slidesToShow: 1,
	                        slidesToScroll: 1,
	                        centerMode: true,
	                        centerPadding: '20px',
	                    },
	                }
	            ],
   			});


});
