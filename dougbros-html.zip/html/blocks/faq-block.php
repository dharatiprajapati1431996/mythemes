	   <section class="faq-sec mb-100">
				<img src="assets/images/faq-image.jpg" alt="faq image" title="" width="1920" height="600" class="bgimg">
	    <div class="page-width">
							<div class="faq-wrap">
								 <div class="f-left">
											<img src="assets/images/svg/faq-icon.svg" alt="faq icon" title="" width="80" height="85">
										 <div class="heading-50">Frequently Asked Questions</div>
										 <p>Our FAQs cover everything from oven usage to maintenance, ensuring you get the most out of your pizza-making experience. Find the answers here!</p>
										 
										 <a href="#" class="button">Find your pizza oven</a>
										
								 </div>
								 <div class="f-right">
										
											<div class="faq_accordion"> 
													<!-- Section 1 -->
													<div class="accordion_in">
															<div class="acc_head">Is a gas oven better for pizza?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
													<!-- Section 2 -->
													<div class="accordion_in">
															<div class="acc_head">Are gas-fired pizza ovens any good?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
												 <div class="accordion_in">
															<div class="acc_head">What are the main benefits of owning a pizza oven compared to a conventional oven?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
													<div class="accordion_in">
															<div class="acc_head">What should I consider when choosing the right pizza oven for my needs?</div>
															<div class="acc_content">
															<p>Yes! Gas-fired pizza ovens are a fantastic option for home cooks and professionals alike. They offer the convenience and control of gas heat while still delivering the authentic taste and texture of wood-fired pizzas.</p>
															</div>
													</div>
											</div>
										
								 </div>
						 </div>
				 </div>
	  </section>