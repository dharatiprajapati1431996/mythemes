<!-- Start Keyfeature -->
<section class="keyfeature-sec mb-125">
  <div class="page-width">
  		 <ul class="keyfeature-ul">
						 <li>
										<div class="keyfeature-wrap">
													<div class="keyfeature-icon"><img src="assets/images/svg/free-shipping-icon.svg" alt="free-shipping-icon" title="" width="" height=""></div>
											  <div class="keyfeature-detail">
															<span>Free Shipping</span>
														 Fast, Free Shipping Across Australia
											  </div> 
								  </div>
						 </li>
						<li>
										<div class="keyfeature-wrap">
													<div class="keyfeature-icon"><img src="assets/images/svg/secure-checkout-icon.svg" alt="secure-checkout-icon" title="" width="" height=""></div>
											  <div class="keyfeature-detail">
															<span>Secure Checkout</span>
														 Shop with Confidence & Secure Payments
											  </div> 
								  </div>
						 </li>
						<li>
										<div class="keyfeature-wrap">
													<div class="keyfeature-icon"><img src="assets/images/svg/family-run-icon.svg" alt="family-run-icon" title="" width="" height=""></div>
											  <div class="keyfeature-detail">
															<span>Family Run</span>
														 Father and Two Sons
											  </div> 
								  </div>
						 </li>
						<li>
										<div class="keyfeature-wrap">
													<div class="keyfeature-icon"><img src="assets/images/svg/warranty-icon.svg" alt="warranty-icon" title="" width="" height=""></div>
											  <div class="keyfeature-detail">
															<span>5 Year Warranty</span>
														 For Peace of Mind
											  </div> 
								  </div>
						 </li>
			  </ul>      
  </div>
</section>
<!-- End instagram -->