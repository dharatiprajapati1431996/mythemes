<!-- Start instagram -->
<section class="instagram-sec mb-125">
    <div class="page-width">
        <div class="flex-container wrap">
            <div class="intro-wr mb-50">
													  <div class="intro-left">
                <div class="semi-head">#doughbrospizzaovens</div>
                <div class="heading-50">Get a Taste on Insta</div>
													 	</div>
													   <div class="intro-right">
																		<div class="intro-shape">
																	 		<div class="intro-box">
																						<img src="assets/images/svg/award-icon.svg" alt="award icon" title="" width="38" height="41">
																						<div class="i-title">Get a chance to win by uploading your video</div>
																				</div>	
																	 </div>
																	 <a href="#" class="button"><i class="fa fa-instagram" aria-hidden="true"></i>follow us</a>
													   </div>
													 
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="instagram-wrap">
            <img src="assets/images/instagram.png" alt="instagram" title="" width="" height="">
        </div>
    </div>
</section>
<!-- End instagram -->