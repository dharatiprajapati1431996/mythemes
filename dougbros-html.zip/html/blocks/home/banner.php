 <!-- banner section start -->

<!-- banner section start -->
<section class="sec-hmbanner">
  <ul class="js-hmbanner">
    <li>
      <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-desk" width="1920" height="810">
      <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-mob" width="1920" height="810">
      <div class="ol-hmbanner">
        <div class="page-width">
          <div class="olhmban-wrap">
            <div class="olhmban-title">Premium Pizza Ovens for Effortless, Authentic Flavour Every Time</div>
											 <div class="olhmban-label">Cook Like a Pro with High-Performance Ovens and Key Accessories</div>
            <a href="#" class="button">Find your pizza oven</a>
          </div>
        </div>
      </div>
    </li>
    <li>
      <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-desk" width="1920" height="810">
      <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-mob" width="1920" height="810">
      <div class="ol-hmbanner">
        <div class="page-width">
          <div class="olhmban-wrap">
            <div class="olhmban-title">Premium Pizza Ovens for Effortless, Authentic Flavour Every Time</div>
											 <div class="olhmban-label">Cook Like a Pro with High-Performance Ovens and Key Accessories</div>
            <a href="#" class="button">Find your pizza oven</a>
          </div>
        </div>
      </div>
    </li>
			<li>
      <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-desk" width="1920" height="810">
      <img src="assets/images/banner-image.jpg" alt="banner-image" class="ban-mob" width="1920" height="810">
      <div class="ol-hmbanner">
        <div class="page-width">
          <div class="olhmban-wrap">
            <div class="olhmban-title">Premium Pizza Ovens for Effortless, Authentic Flavour Every Time</div>
											 <div class="olhmban-label">Cook Like a Pro with High-Performance Ovens and Key Accessories</div>
            <a href="#" class="button">Find your pizza oven</a>
          </div>
        </div>
      </div>
    </li>
  </ul>
</section>
<!-- banner section end -->

    

 <!-- banner section end -->