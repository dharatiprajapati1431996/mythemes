
<!-- Start Accessories  -->
<section class="hm-accessories mb-100">
	<div class="page-width">

		<div class="intro-column mb-50">
			<div class="intro">
				<div class="semi-head">Must Have Accessories</div>
				<div class="heading-50">Accessories</div>
			</div>
			<p>The secret to perfect pizza lies in the right tools. From pizza cutters to peels, our accessories give you the precision & control needed to elevate your pizza-making skills with ease, confidence, and restaurant-quality results every time.</p>
		</div>
		
		<div class="collection accessories-slider slick-arrow">
			<ul id="product-grid" class="grid product-grid grid--4-col-desktop">
		              		<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
		    						<div class="card card--standard card--media">
									      	<div class="card__inner color-background-2 ratio">
										      	<div class="card__media">
										            <div class="media media--transparent">
			              								<img src="assets/images/turning-peel.png" alt="Turning peel" class="motion-reduce" width="248" height="231">
			              							</div>
			          							</div>
		      								</div>

										    <div class="card__content">
										        <div class="card__information">
										        	<div class="semi-head">Dough Bros Pizza Ovens</div>
											        <h3 class="card__heading h5">
											            <a href="#" id="" class="full-unstyled-link">Turning peel</a>
											        </h3>
										          	<div class="card-information">
										          		<span class="caption-large light"></span>
														<div class="price ">
														  	<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														  	</div>
														</div>
													</div>
										        </div>
										        <div class="card__badge bottom left"></div>
										    </div>

										    <button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										        <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										        <span> Add To Cart </span>
										    </button>
		    						</div>
								</div>
		                	</li>

							<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
								    <div class="card card--standard card--media">
								      	<div class="card__inner color-background-2 gradient ratio">
								      		<div class="card__badge bottom left"><span class="badge badge--bottom-left sold-out">Sold out</span></div>
								      		<div class="card__media">
		            							<div class="media media--transparent">
		              								<img src="assets/images/bro-scraper.png" alt="Bro Scraper" class="motion-reduce" loading="lazy" width="229" height="229">
												</div>
		          							</div>
		      							</div>
		      							<div class="card__content">
		        							<div class="card__information">
		        								<div class="semi-head">Dough Bros Pizza Ovens</div>
										        <h3 class="card__heading h5">
										           	<a href="#" class="full-unstyled-link">Bro Scraper</a>
										        </h3>
		          								<div class="card-information">
		          									<span class="caption-large light"></span>
													<div class="price  price--on-sale">
		  												<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														</div>
													</div>
												</div>
		        							</div>
		        							<div class="card__badge bottom left">
		        								<span class="badge badge--bottom-left color-accent-2">Sale</span>
		        							</div>
		      							</div>
		      							<button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										    <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										    <span> Add To Cart </span>
										</button>
		    						</div>
		  						</div>
		                	</li>

		                	<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
		    						<div class="card card--standard card--media">
									    <div class="card__inner color-background-2 ratio">
									      		<div class="card__badge bottom left"><span class="badge badge--bottom-left">News</span></div>
										      	<div class="card__media">
										            <div class="media media--transparent">
			              								<img src="assets/images/bro-board.png" alt="Bro Board" class="motion-reduce" width="" height="">
			              							</div>
			          							</div>
		      							</div>

										<div class="card__content">
										        <div class="card__information">
										        	<div class="semi-head">Dough Bros Pizza Ovens</div>
											        <h3 class="card__heading h5">
											            <a href="#" id="" class="full-unstyled-link">Bro Board</a>
											        </h3>
										          	<div class="card-information">
										          		<span class="caption-large light"></span>
														<div class="price ">
														  	<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														  	</div>
														</div>
													</div>
										        </div>
										        <div class="card__badge bottom left"></div>
										</div>

										<button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										    <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										    <span> Add To Cart </span>
										</button>
		    						</div>
		  						</div>
		                	</li>

		                	<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
		    						<div class="card card--standard card--media">
									    <div class="card__inner color-background-2 ratio">
										  	<div class="card__media">
										        <div class="media media--transparent">
			              							<img src="assets/images/bro-cutter.png" alt="Bro Cutter" class="motion-reduce" width="" height="">
			              						</div>
			          						</div>
		      							</div>

										<div class="card__content">
										        <div class="card__information">
										        	<div class="semi-head">Dough Bros Pizza Ovens</div>
											        <h3 class="card__heading h5">
											            <a href="#" id="" class="full-unstyled-link">Bro Cutter</a>
											        </h3>
										          	<div class="card-information">
										          		<span class="caption-large light"></span>
														<div class="price ">
														  	<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														  	</div>
														</div>
													</div>
										        </div>
										        <div class="card__badge bottom left"></div>
										</div>

										<button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										    <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										    <span> Add To Cart </span>
										</button>
		    						</div>
		  						</div>
		                	</li>

		                	<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
		    						<div class="card card--standard card--media">
									    <div class="card__inner color-background-2 ratio">
									      		<div class="card__badge bottom left"><span class="badge badge--bottom-left">News</span></div>
										      	<div class="card__media">
										            <div class="media media--transparent">
			              								<img src="assets/images/bro-board.png" alt="Bro Board" class="motion-reduce" width="" height="">
			              							</div>
			          							</div>
		      							</div>

										<div class="card__content">
										        <div class="card__information">
										        	<div class="semi-head">Dough Bros Pizza Ovens</div>
											        <h3 class="card__heading h5">
											            <a href="#" id="" class="full-unstyled-link">Bro Board</a>
											        </h3>
										          	<div class="card-information">
										          		<span class="caption-large light"></span>
														<div class="price ">
														  	<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														  	</div>
														</div>
													</div>
										        </div>
										        <div class="card__badge bottom left"></div>
										</div>

										<button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										    <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										    <span> Add To Cart </span>
										</button>
		    						</div>
		  						</div>
		                	</li>

		                	<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
		    						<div class="card card--standard card--media">
									    <div class="card__inner color-background-2 ratio">
										  	<div class="card__media">
										        <div class="media media--transparent">
			              							<img src="assets/images/bro-cutter.png" alt="Bro Cutter" class="motion-reduce" width="" height="">
			              						</div>
			          						</div>
		      							</div>

										<div class="card__content">
										        <div class="card__information">
										        	<div class="semi-head">Dough Bros Pizza Ovens</div>
											        <h3 class="card__heading h5">
											            <a href="#" id="" class="full-unstyled-link">Bro Cutter</a>
											        </h3>
										          	<div class="card-information">
										          		<span class="caption-large light"></span>
														<div class="price ">
														  	<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														  	</div>
														</div>
													</div>
										        </div>
										        <div class="card__badge bottom left"></div>
										</div>

										<button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										    <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										    <span> Add To Cart </span>
										</button>
		    						</div>
		  						</div>
		                	</li>

		                	<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
		    						<div class="card card--standard card--media">
									    <div class="card__inner color-background-2 ratio">
										  	<div class="card__media">
										        <div class="media media--transparent">
			              							<img src="assets/images/turning-peel.png" alt="Turning peel" class="motion-reduce" width="248" height="231">
			              						</div>
			          						</div>
		      							</div>

										<div class="card__content">
										        <div class="card__information">
										        	<div class="semi-head">Dough Bros Pizza Ovens</div>
											        <h3 class="card__heading h5">
											            <a href="#" id="" class="full-unstyled-link">Turning peel</a>
											        </h3>
										          	<div class="card-information">
										          		<span class="caption-large light"></span>
														<div class="price ">
														  	<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														  	</div>
														</div>
													</div>
										        </div>
										        <div class="card__badge bottom left"></div>
										</div>

										<button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										    <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										    <span> Add To Cart </span>
										</button>
		    						</div>
		  						</div>
		                	</li>
                
		                	<li class="grid__item scroll-trigger animate--slide-in">
								<div class="card-wrapper product-card-wrapper">
								    <div class="card card--standard card--media">
								      	<div class="card__inner color-background-2 gradient ratio">
								      		<div class="card__badge bottom left"><span class="badge badge--bottom-left sold-out">Sold out</span></div>
								      		<div class="card__media">
		            							<div class="media media--transparent">
		              								<img src="assets/images/bro-scraper.png" alt="Bro Scraper" class="motion-reduce" loading="lazy" width="229" height="229">
												</div>
		          							</div>
		      							</div>
		      							<div class="card__content">
		        							<div class="card__information">
		        								<div class="semi-head">Dough Bros Pizza Ovens</div>
										        <h3 class="card__heading h5">
										           	<a href="#" class="full-unstyled-link">Bro Scraper</a>
										        </h3>
		          								<div class="card-information">
		          									<span class="caption-large light"></span>
													<div class="price  price--on-sale">
		  												<div class="price__container">
														  		<div class="price__regular">
														  			<span class="visually-hidden visually-hidden--inline">Regular price</span>
																	<span class="price-item price-item--regular">$00.00 AUD</span>
														    	</div>
															    <div class="price__sale">
															        <span class="visually-hidden visually-hidden--inline">Regular price</span>
															        <span><s class="price-item price-item--regular"></s></span>
															        <span class="visually-hidden visually-hidden--inline">Sale price</span>
															      	<span class="price-item price-item--sale price-item--last">$00.00 AUD</span>
															    </div>
															    <small class="unit-price caption hidden">
															      	<span class="visually-hidden">Unit price</span>
															      	<span class="price-item price-item--last">
															        	<span></span>
															        	<span aria-hidden="true">/</span>
															        	<span class="visually-hidden">&nbsp;per&nbsp;</span>
															        	<span></span>
															      	</span>
															    </small>
														</div>
													</div>
												</div>
		        							</div>
		        							<div class="card__badge bottom left">
		        								<span class="badge badge--bottom-left color-accent-2">Sale</span>
		        							</div>
		      							</div>

		      							<button class="add_to-cart btn_qickadd product-card-quickview quick-add__submit" tabindex="0">
										    <img src="assets/images/svg/cart.svg" width="20" height="16" alt="Cart" class="">
										    <span> Add To Cart </span>
										</button>
		    						</div>
		  						</div>
		                	</li>
            			</ul>
		</div>
	</div>
</section>
<!-- End Accessories  -->