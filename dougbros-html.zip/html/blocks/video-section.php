			 <section class="video-sec mb-100">
					<img src="assets/images/video-image.jpg" alt="video image" title="" width="1920" height="700" class="bgimg">
					<div class="page-width">
					  <div class="video-wrap">
								 <div class="video-icon"><img src="assets/images/svg/play-icon.svg" alt="play icon" title="" width="62" height="62"></div>
						   <div class="heading-50">Watch the Magic Behind Every Perfect Pizza</div>
								 <div class="video-content">See how our pizza ovens bring the perfect pizza to life, with every detail crafted for delicious results.</div>
								 <a class="button" href="#">Watch Now</a>
						 </div>
					</div>
	   </section>