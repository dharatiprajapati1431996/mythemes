<footer>
    <div class="page-width">
        <div class="footer-top flex-container wrap">
            <a href="home.php" class="ft-logo">
                <img src="assets/images/dough-bros-pizza-ovens.svg" alt="dough-bros-pizza-ovens" title="" width="271"
                    height="52">
            </a>
            <ul class="quick-link navigation-wrap">
                <li><a href="home.php">Home</a></li>
                <li><a href="#">Pizza Ovens</a></li>
                <li><a href="#">Bundles</a></li>
                <li class="ft-center"></li>
                <li><a href="#">Accessories</a></li>
                <li><a href="#">About us</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
        <div class="footer-bottom flex-container wrap justify-between">
            <div class="ft-left">
                <div class="newsletterleft">
                    <div class="newslettertxt heading-24">Join Our Newsletter</div>
                    <div class="newsletterform">
                        <form action="" class="form-fields">
                            <input type="email" class="form-control" name="Email" placeholder="Enter your email"
                                required="">
                            <input type="submit" class="btn-subscribe" value="Submit">
                        </form>
                    </div>
                </div>

                <div class="payments-wrap">
                    <div class="ft-head">Payment Method</div>
                    <ul class="payment-list">
                        <li>
                            <div class="paybox">
                                <img src="assets/images/american-express.png" alt="american-express" title="" width="40"
                                    height="26">
                            </div>
                        </li>
                        <li>
                            <div class="paybox">
                                <img src="assets/images/apple-pay.png" alt="apple-pay" title="" width="30" height="13">
                            </div>
                        </li>
                        <li>
                            <div class="paybox">
                                <img src="assets/images/google-pay.png" alt="google-pay" title="" width="31"
                                    height="12">
                            </div>
                        </li>
                        <li>
                            <div class="paybox">
                                <img src="assets/images/mastercard.png" alt="mastercard" title="" width="25"
                                    height="20">
                            </div>
                        </li>
                        <li>
                            <div class="paybox">
                                <img src="assets/images/paypal.png" alt="paypal" title="" width="32" height="9">
                            </div>
                        </li>
                        <li>
                            <div class="paybox">
                                <img src="assets/images/shop-pay.png" alt="shop-pay" title="" width="27" height="12">
                            </div>
                        </li>
                        <li>
                            <div class="paybox">
                                <img src="assets/images/visa.png" alt="visa" title="" width="33" height="10">
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="center-block">
                <img src="assets/images/dough-bros-logo-icon.svg" alt="dough-bros-logo-icon" title="" width=""
                    height="">
            </div>

            <div class="ft-right acc-nav">
                <div class="column-block">
                    <div class="ft-head acc-nav-head">Support</div>
                    <ul class="quick-link">
                        <li><a href="#">Shipping Policy</a></li>
                        <li><a href="#">Returns & Warranty Policy</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Warranty</a></li>
                        <li><a href="#">Free Shipping</a></li>
                    </ul>
                </div>
                <div class="column-block">
                    <div class="ft-head acc-nav-head">Resources</div>
                    <ul class="quick-link">
                        <li><a href="#">FAQs</a></li>
                        <li><a href="#">Guides</a></li>
                        <li><a href="#">Recipes</a></li>
                        <li><a href="#">Testimonials</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="copyright">
        <div class="page-width">
            <div class="flex-container wrap justify-between">
                <p>© 2025, Dough Bros Pizza Ovens. All rights reserved.</p>


                <div class="select-lang-wrap">
                    <div class="selectors-form__item">
                        <div class="country-select-wrapper">
                          <img id="flag-icon" src="assets/images/australia-flag.png" alt="Flag" />
                            <select class="country" name="wcpbc-manual-country" id="country-head">
                                <option value="AU" data-iconurl="assets/images/australia-flag.png">Australia | $ AUD</option>
                                <option value="IN" data-iconurl="assets/images/india-flag.png">India | ₹ INR</option>
                            </select>
                        </div>
                    </div>
                </div>


                <ul class="follow-list">
                    <li>Connect With Us:</li>
                    <li>
                        <a href="#">
                            <img src="assets/images/svg/facebook.svg" alt="facebook" title="" width="" height="">
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <img src="assets/images/svg/twitter.svg" alt="twitter" title="" width="" height="">
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <img src="assets/images/svg/instagram.svg" alt="instagram" title="" width="" height="">
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <img src="assets/images/svg/youtube.svg" alt="youtube" title="" width="" height="">
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <img src="assets/images/svg/tiktok.svg" alt="tiktok" title="" width="" height="">
                        </a>
                    </li>
                </ul>
            </div>
        </div>

</footer>



<button class="scrollTop"><i class="fa fa-angle-up" aria-hidden="true"></i> </button>


<?php wp_footer(); ?>
</body>

</html>