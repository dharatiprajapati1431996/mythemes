<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="page_wrapper thank_youpg">

    <!-- Inner Banner Section -->
    <section class="inner-banner relative mb-100">
        <img class="bgimg" src="assets/images/contact-inner.jpg" height="400" width="1920" alt="contact-inner">
       
            <div class="page-width">
                <div class="heading-50 ">Thank You</div>
            </div>
            
            <div class="breacurmb-wrapper">
                <div class="page-width">
                    <ul class="woo_breadcums">
                        <li>
                            <span>
                                <span>
                                    <a href="#">Home</a>
                                    <span class="breadcrumb_last" aria-current="page">Thank You</span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        
    </section>
    <!-- Inner Banner Section -->

    <section class="inpage mb-100">
        <div class="page-width">

            <div class="flex-container thank_you_content wrap">
                <div class="error-left">
                    <div class="heading-36">We’ve Received Your Inquiry!</div>
                    <p>We're excited to help you build your perfect space.</p>
                    <p>Thank you for reaching out to Superior Granny Flats! One of our team members will get back to you
                        shortly to discuss your project and answer any questions you may have.</p>
                    <p>In the meantime, feel free to explore more about what we offer:</p>

                    <ul>
                        <li><a href="#">Browse our latest projects</a></li>
                        <li><a href="#">Learn more about our process</a></li>
                        <li><a href="#">Read testimonials from our happy clients</a></li>
                    </ul>

                    <p>Have an urgent inquiry? Give us a call at <a href="tel:0421 519 084">0421 519 084</a> for
                        immediate assistance.</p>
                </div>

                <div class="error-right">
                    <img src="assets/images/thankyou.png" alt="404" title="404" width="500" height="500">
                </div>
            </div>

        </div>
    </section>

</main>
<?php get_footer();