$(document).ready(function () {
  $(".featured-cate-slider").slick({
    arrows: true,
    dots: false,
    slidesToShow: 5,
    slidesToScroll: 1,
    horizontal: true,
    infinite: false,
    autoplay: true,
    // vertical: true,
    // verticalSwiping: true,
    pauseOnHover: false,
    autoplaySpeed: 5000,
    // adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 1600,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 4,
          slidesToScroll: 1,
          fade: false,
        },
      },
      {
        breakpoint: 992,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 3,
          slidesToScroll: 1,
          fade: false,
        },
      },
      {
        breakpoint: 768,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 2,
          slidesToScroll: 1,
          fade: false,
        },
      },
      {
        breakpoint: 576,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 1,
          slidesToScroll: 1,
          fade: false,
          centerMode: true,
          centerPadding: "80px",
        },
      },
      {
        breakpoint: 374,
        settings: {
          slidesToShow: 1,
          centerMode: true,
          centerPadding: "30px",
        },
      },
    ],
  });

  $(".testimonials-slider").slick({
    arrows: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 1,
    horizontal: true,
    infinite: false,
    autoplay: true,
    // vertical: true,
    // verticalSwiping: true,
    pauseOnHover: false,
    autoplaySpeed: 5000,
    // adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 2,
          slidesToScroll: 1,
          fade: false,
        },
      },
      {
        breakpoint: 576,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 1,
          slidesToScroll: 1,
          fade: false,
        },
      },
    ],
  });
  $(".arts-slider").slick({
    arrows: true,
    dots: false,
    slidesToShow: 6,
    slidesToScroll: 1,
    horizontal: true,
    infinite: false,
    autoplay: true,
    // vertical: true,
    // verticalSwiping: true,
    pauseOnHover: false,
    autoplaySpeed: 5000,
    // adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 1600,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 5,
          slidesToScroll: 1,
          fade: false,
        },
      },
      {
        breakpoint: 1200,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 4,
          slidesToScroll: 1,
          fade: false,
        },
      },
      {
        breakpoint: 768,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 3,
          slidesToScroll: 1,
          fade: false,
        },
      },
      {
        breakpoint: 576,
        settings: {
          infinite: true,
          autoplaySpeed: 3000,
          slidesToShow: 2,
          slidesToScroll: 1,
          fade: false,
        },
      },
    ],
  });
  /*----------Scroll top -------------*/
  var scrollTop = $(".scrollTop");
  $(window).scroll(function () {
    var topPos = $(this).scrollTop();
    if (topPos > 0) {
      $(scrollTop).css("opacity", "1");
    } else {
      $(scrollTop).css("opacity", "0");
    }
  });
  $(scrollTop).click(function () {
    $("html, body").animate(
      {
        scrollTop: 0,
      },
      600
    );
    return false;
  });

  /*-------- Menu dropdown --------------*/
  /*-----MENU DROPDOWN-----*/

  var ico = $('<i class="fa fa-angle-down menudrop"></i>');
  $(
    ".main-menu > li:has(.submenu) > a,.nav-menu-wrapper ul li:has(.submenu) > a"
  ).append(ico);
  $(".main-menu  li:has(ul)").addClass("haschild");
  $(".main-menu li:has(ul) > a").next().addClass("childmenu");
  $(".main-menu .submenu.megamenu  .sublink  li")
    .on("mouseenter", function () {
      $(this).siblings().removeClass("menu-item-hover");
      $(this).addClass("menu-item-hover");
    })
    .first()
    .trigger("mouseenter");

  if ($(window).width() < 992) {
    $(".menudrop").on("click", function (e) {
      var label = $(this).parent();
      var parent = label.parent(".haschild");
      var list = label.siblings(".childmenu");
      e.preventDefault();
      if (parent.hasClass("isopen")) {
        list.slideUp("fast");
        parent.removeClass("isopen");
      } else {
        parent.parent().find("li.haschild").removeClass("isopen");
        parent.parent().find("li.haschild .childmenu").slideUp(350);
        list.slideDown("fast");
        parent.addClass("isopen");
      }
    });
  }

  /*-----BURGER MENU-----*/
  $(".togglebtn, .overlay").click(function () {
    $(".togglebtn, .overlay, .main-menu").toggleClass("active");
    if ($(".overlay").hasClass("active")) {
      $(".overlay").fadeIn();
      $("html").addClass("menuhidden");
    } else {
      $(".overlay").fadeOut();
      $("html").removeClass("menuhidden");
    }
  });

  /*-----FIXED HEADER-----*/

  $(window).scroll(function () {
    if ($(window).scrollTop() > 200 && $(window).width() >= 319) {
      $("body").addClass("fixed-header");
    } else {
      $("body").removeClass("fixed-header");
    }
  });

  // FOOTER

  $(".acc-nav-item .acc-nav-head").click(function () {
    if ($(window).width() < 992) {
      let $this = $(this);

      $this.toggleClass("showhide");

      let $wrapper = $this.closest(".acc-nav-item");
      let $heads = $wrapper.find(".acc-nav-head");

      $heads.not($this).removeClass("showhide");
      $heads.not(".showhide").next().stop().slideUp(300);
      $heads.filter(".showhide").next().stop().slideDown(300);
    }
  });

  $('[class*="ft-col-"]').addClass("showhide").next().show();
  $(
    ".ft-col-0 .ft-title,.ft-col-1 .ft-title, .ft-col-2 .ft-title,.ft-col-3 .ft-title,.ft-col-4 .ft-title"
  ).click(function () {
    if ($(window).width() < 575) {
      $(
        ".toggle_title, .ft-col-0 .ft-title,.ft-col-1 .ft-title, .ft-col-2 .ft-title,.ft-col-3 .ft-title,.ft-col-4 .ft-title"
      )
        .removeClass("showhide")
        .next()
        .hide();

      $(this).toggleClass("showhide");
      $(this).next().slideDown("");
    }
  });
});
