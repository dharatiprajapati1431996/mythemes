$(document).ready(function () {
  //FAQ
  // $(".faq_accordion").smk_Accordion({
  //     closeAble: true, //boolean
  //     //closeOther: false, //boolean
  //     activeIndex: 1 //second section open
  // });

  $(".faqs").smk_Accordion({
    // activeIndex: false,
    showIcon: true, //boolean
    animation: true, //boolean
    closeAble: true, //boolean
    slideSpeed: 200, //integer, miliseconds
  });
});
