jQuery(document).ready(function($) {
    // for mobile filter slide -->
    $(document).on("click", "a.m_filtertrigger, a.closemenu", function(e) {
        //alert("test");
        e.preventDefault();
        $(".mobile-slide").toggleClass("slide");
        $("body").toggleClass("overlayshow");
    });

    /*$('#enq_sortby').popup({
        transition: 'all 0.5s',
        opacity: '0.9'
    });*/

    $(".filterbyprice_container span").click(function() {
        $(".filterbyprice_container .filterpricediv").stop().slideToggle();
    });

    $(".slider-for-product").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: ".slider-nav-product",
    });

    $(".slider-nav-product").slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        arrows: true,
        vertical: false,
        asNavFor: ".slider-for-product",
        dots: false,
        focusOnSelect: true,
        verticalSwiping: false,
        responsive: [{
                breakpoint: 992,
                settings: {},
            },
            {
                breakpoint: 768,
                settings: {
                    adaptiveheight: true,
                    vertical: false,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                },
            },
            {
                breakpoint: 575,
                settings: {
                    vertical: false,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                },
            },
        ],
    });
});