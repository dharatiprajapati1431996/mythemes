$(document).ready(function () {
  $(".products-slider").slick({
    dots: false,
    infinite: true,
    arrows: true,
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    responsive: [
      {
        breakpoint: 1440,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 374,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  });

  // // for feature product tabs
  // $(".tab-nav span").on("click", function () {
  //   $([$(this).parent()[0], $($(this).data("href"))[0]])
  //     .addClass("active")
  //     .siblings(".active")
  //     .removeClass("active");
  //   $(".tab ul.products").slick("refresh");
  // });
});
