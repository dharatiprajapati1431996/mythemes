<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="homepg page-wrapper woocommerce">
  <?php block('home/banner'); ?>

  <?php block('quality-list'); ?>

  <section class="products-slider-sec">
    <div class="md-container">
      <div class="heading-50 bg-shap">Nick’s Picks</div>
      <?php block('products-slider'); ?>
    </div>
  </section>

  <?php block('featured-cate-sec'); ?>

  <?php block('having-stall-sec'); ?>

  <?php block('shop-collections-sec'); ?>

  <?php block('shop-by-trader-sec'); ?>

  <?php block('established-details-sec'); ?>

  <section class="testimonials-sec">
    <div class="md-container">
      <div class="heading-50 bg-shap">What Our Customers Are Saying</div>
      <ul class="testimonials-slider slick-arrow">
        <li>
          <div class="testimonial_box">
            <div class="heading-testimonial">Great variety of items...</div>
            <p class="content-wrap">Great variety of items here from music, to books, to gaming. I loved how they were
              all neatly laid out in themed rooms and so much of it!</p>
            <div class="detail-wrap">
              <div class="author-rate_wrap">

                <div class="author-nm">Frank 708</div>
                <div class="star-list">
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                </div>
              </div>
              <div class="img-wrap"><img src="assets/images/google-logo.svg" title="" height="39" width="39"
                  alt="google_logo"></div>
            </div>
          </div>
        </li>
        <li>
          <div class="testimonial_box">
            <div class="heading-testimonial">Nick was very helpful...</div>

            <p class="content-wrap">Sold a big lot to this business. It was daunting just looking at it. Nick was very
              helpful. The workers were polite and efficient and I was surprised how smoothly the whole process...<a
                href="#">more</a></p>

            <div class="detail-wrap">
              <div class="author-rate_wrap">

                <div class="author-nm">Carmen Sant</div>
                <div class="star-list">
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                </div>
              </div>
              <div class="img-wrap"><img src="assets/images/google-logo.svg" title="" height="39" width="39"
                  alt="google_logo"></div>
            </div>
          </div>
        </li>
        <li>
          <div class="testimonial_box">
            <div class="heading-testimonial">I loved the wide range of...</div>

            <p class="content-wrap">Way bigger inside then you expect it to be. Heaps to look at and definitely
              something for everyone. I loved the wide range of vintage clothes they had here. Will be back</p>


            <div class="detail-wrap">
              <div class="author-rate_wrap">

                <div class="author-nm">Bianca Wacker</div>
                <div class="star-list">
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                </div>
              </div>
              <div class="img-wrap"><img src="assets/images/google-logo.svg" title="" height="39" width="39"
                  alt="google_logo"></div>
            </div>
        </li>
        <li>
          <div class="testimonial_box">
            <div class="heading-testimonial">Great variety of items...</div>
            <p class="content-wrap">Great variety of items here from music, to books, to gaming. I loved how they were
              all neatly laid out in themed rooms and so much of it!</p>
            <div class="detail-wrap">
              <div class="author-rate_wrap">

                <div class="author-nm">Frank 708</div>
                <div class="star-list">
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                  <div><img src="assets/images/star.svg" height="12" width="13" title="" alt="rate"></div>
                </div>
              </div>
              <div class="img-wrap"><img src="assets/images/google-logo.svg" title="" height="39" width="39"
                  alt="google_logo"></div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </section>

  <section class="divider-sec">
    <div class="md-container relative">
      <div class="img-wrap"><img src="assets/images/divider-img.svg" height="55" width="55" title="" alt="divider">
      </div>
    </div>
  </section>

  <section class="latest-news-sec mb-100">
    <div class="md-container">
      <div class="latest-news-wrap">
        <div class="latest-news-head bg-shap">
          <div class="heading-50">Latest News</div>
        </div>

        <div class="latest-news-blog-body">
          <ul class="latest-news-blog slick-arrow">
            <li>
              <a href="#!" class="blog-box">
                <div class="blogbox-img">
                  <img src="assets/images/blog-img1.jpg" alt="books" width="400" height="365">
                </div>
                <div class="blogbox-detail">
                  <div class="title">25 Dec 2023</div>
                  <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                    opportunity.</div>
                  <div href="#!" class="btn-white">Read More</div>
                </div>
              </a>
            </li>
            <li>
              <a href="#!" class="blog-box">
                <div class="blogbox-img">
                  <img src="assets/images/blog-img2.jpg" alt="books" width="400" height="365" title="">
                </div>
                <div class="blogbox-detail">
                  <div class="title">25 Dec 2023</div>
                  <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                    opportunity.</div>
                  <div href="#!" class="btn-white">Read More</div>
                </div>
              </a>
            </li>
            <li>
              <a href="#!" class="blog-box">
                <div class="blogbox-img">
                  <img src="assets/images/blog-img3.jpg" alt="books" width="400" height="365" title="">
                </div>
                <div class="blogbox-detail">
                  <div class="title">25 Dec 2023</div>
                  <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                    opportunity.</div>
                  <div href="#!" class="btn-white">Read More</div>
                </div>
              </a>
            </li>
            <li>
              <a href="#!" class="blog-box">
                <div class="blogbox-img">
                  <img src="assets/images/blog-img4.jpg" alt="books" width="400" height="365" title="">
                </div>
                <div class="blogbox-detail">
                  <div class="title">25 Dec 2023</div>
                  <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                    opportunity.</div>
                  <div href="#!" class="btn-white">Read More</div>
                </div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA Section start -->
  <section class="cta-sec mb-100">
    <div class="md-container">
      <div class="cta_wrap">
        <img src="assets/images/cta-sec-spry.png" class="cta-wrap-sprey" alt="sprey" width="229" height="315">
        <div class="heading-32">Can't Find What You're Looking For?</div>
        <a href="tel:0418 993 633" class="btn-white"><span><img src="assets/images/f-call.svg" alt="phone" width="15"
              height="15"></span>Call us now: 0418 993 633</a>
        <img src="assets/images/cta-sec-spry.png" class="cta-wrap-sprey-bottom" alt="sprey" width="229" height="315">
      </div>
    </div>
  </section>
  <!-- CTA Section end -->

  <section class="our_vendors_sec">
    <div class="md-container">
      <div class="heading-50 bg-shap">Our Vendors</div>
      <ul class="vendors_list">
        <li>
          <div class="img-wrap">
            <img src="assets/images/royal.png" height="113" width="96" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/vendor.png" height="109" width="114" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/palace.png" height="97" width="111" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/magic.png" height="113" width="113" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/royal.png" height="113" width="96" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/palace.png" height="97" width="111" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/magic.png" height="113" width="113" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/vendor-1.png" height="88" width="95" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/vendor-2.png" height="71" width="207" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/bridge-premium.png" height="94" width="134" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/athena.png" height="94" width="121" title="" alt="our vendor">
          </div>
        </li>
        <li>
          <div class="img-wrap">
            <img src="assets/images/vendor-2.png" height="71" width="207" title="" alt="our vendor">
          </div>
        </li>
      </ul>
    </div>
  </section>

 
  <?php block('instagram'); ?>

</main>
<?php get_footer();
