<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<section class="inner-banner relative mb-150">
    <img class=" banner_bg" src="assets/images/about-banner.jpg"  width="1920" height="300" alt="antique iteams" title="">
    <div class="container inner_banner_info">
        <div class="ark-shap">
            <img src="assets/images/title-ark.svg" alt="title-ark" width="47"  height="26" title="">
        </div>
        <div class="heading-48 white">About Us</div>
        <ul class="woo_breadcums">
            <li>
                <span>
                    <span>
                        <a href="#">Home</a>
                        <span class="breadcrumb_last" aria-current="page">About Us</span>
                    </span>
                </span>
            </li>
        </ul>
    </div>
</section>

<main class="about page-wrapper inpg">

    <?php block('quality-list'); ?>

    <section class="top-content mb-100">
        <div class="container">
            <div class="top-content-wrap">
                <div class="content-left sticky">
                    <div class="img-wrap">
                        <img src="assets/images/music-instrument.png" alt="music-instrument" title="" width="622" height="511">
                    </div>
                </div>
                <div class="content-right">
                    <div class="heading-32 bg-shap">
                        Pickers Retro Haven
                    </div>
                    <p>Established in October 2019, Pickers Retro Haven is the culmination of a dream, and an
                        opportunity for the owners to indulge their passion for collectibles and objects that carry a
                        sense of history.
                    </p>
                    <p>The aim of Pickers Retro Haven, a family-owned an operated business. We have done this by finding
                        the perfect location where we can bring together sellers of antiques and collectibles, creating
                        a destination for customers where they can always find something new and fascinating.
                    </p>
                    <p>The aim of Pickers Retro Haven, a family-owned an operated business. We have done this by finding
                        the perfect location where we can bring together sellers of antiques and collectibles, creating
                        a destination for customers where they can always find something new and fascinating.
                    </p>
                    <p>Currently, we have more 70 individual stallholders and are growing all the time. These local
                        small businesses and start-ups each have their own unique offering, so you can always count on
                        finding something special when you visit us.
                    </p>
                    <p>We love to support Victorian Businesses</p>
                </div>
            </div>
        </div>
    </section>

    <?php block('having-stall-sec'); ?>
    <?php block('instagram'); ?>
</main>
<?php get_footer();

