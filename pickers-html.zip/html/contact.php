<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<section class="inner-banner relative mb-150">
    <img class="banner_bg" src="assets/images/contact-banner.jpg" height="450" width="1920" alt="pickers-history" title="">
    <div class="container inner_banner_info">
        <div class="ark-shap">
            <img src="assets/images/title-ark.svg" alt="ark" width="47" height="26" title="">
        </div>
        <div class="heading-48 white">Contact Us</div>
        <ul class="woo_breadcums">
            <li>
                <span>
                    <span>
                        <a href="#">Home</a>
                        <span class="breadcrumb_last" aria-current="page">Contact Us</span>
                    </span>
                </span>
            </li>
        </ul>
    </div>
</section>

<main class="contact-page">

    <?php block('quality-list'); ?>

    <section class="contact_us_section mb-100">
        <div class="container">
            <div class="home-address-wrap">
                <div class="home-address-left">
                    <div class="home-address-head">
                        <div class="heading-32 bg-shap">Indoor Market Stalls Selling Antiques in Beaconsfield</div>
                        <p>Pickers Retro Heaven is a collection of exciting indoor market stalls in Beaconsfield selling
                            handpicked antiques and unique collectibles. Visit us today to browse the range of quality
                            items that have been carefully curated by over 70 traders who have years of experience in
                            the business. Or, get in touch with us today to apply for a stall of your own.</p>
                    </div>


                    <div class="home-address-body">
                        <div class="heading-24">Contact Details</div>
                        <ul class="address-wrap">
                            <li>
                                <div class="address-box">
                                    <span>
                                        <img src="assets/images/location.svg" alt="address" width="10" height="14" title="">
                                    </span>
                                    <div class="address-detail">
                                        <label for="">Pickers Retro Haven</label>
                                        <address>122 Old Princes HWY Beaconsfield VIC Australia 3807 </address>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="address-box">
                                    <span>
                                        <img src="assets/images/clock.svg" alt="clock" width="12" height="12" title="">
                                    </span>
                                    <div class="address-detail">
                                        <label for="">Opening Hours</label>
                                        <address>Mon – Fri 10:00 am – 5:00 pm</address>
                                        <address>Sat- Sun 10:00 am – 4:00 pm</address>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="address-box">
                                    <span>
                                        <img src="assets/images/call.svg" alt="phone" width="13" height="13" title="">
                                    </span>
                                    <div class="address-detail">
                                        <label for="">Phone</label>
                                        <a href="tel:0418 993 633">0418 993 633</a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="address-box">
                                    <span>
                                        <img src="assets/images/email.svg" alt="email address" width="12" height="10" title="">
                                    </span>
                                    <div class="address-detail">
                                        <label for="">Email</label>
                                        <a href="mailto:enquiries@pickersretrohaven.com.au">enquiries@pickersretrohaven.com.au</a>
                                    </div>
                                </div>
                            </li>
                        </ul>

                        <div class="social_icon">
                            <p>Follow Us On : </p>
                            <ul class="social-icon-box">
                                <li>
                                    <a href="#!">
                                        <span>
                                            <img src="assets/images/facebook.svg" alt="facebook" width="8" height="15" title="">
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#!">
                                        <span>
                                            <img src="assets/images/instagram.svg" alt="instagram" width="14" height="14" title="">
                                        </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="home-address-right">
                    <div class="contact-form-box">
                        <p>Get In Touch</p>
                        <form class="form-box">
                            <div class="row">
                                <div class="form-group width100">
                                    <input class="form-control" type="text" name="Name*" placeholder="First Name*">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group width100">
                                    <input class="form-control" type="text" name="Name*" placeholder="Last Name*">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group width100">
                                    <input class="form-control" type="text" name="Email*" placeholder="example@gmail.com">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group width100">
                                    <input class="form-control" type="text" name="Phone" placeholder="Phone*">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group width100">
                                    <textarea placeholder="Messege" class="form-control"></textarea>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group width100 bnt-sub">
                                    <input type="submit" name="" value="Submit" class="btnsubmit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="map-sec mb-100">
        <div class="container">
            <div class="map">
                <iframe src="https://www.google.com/maps/d/u/0/embed?mid=1zID0J42xntc7d5ZlTsWwqc22ZEemfSY&amp;ehbc=2E312F&amp;noprof=1" width="100%" height="509" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" data-gtm-yt-inspected-9="true" data-gtm-yt-inspected-12="true">
                </iframe>
            </div>
        </div>
    </section>

    <section class="bluepinkcolor mb-80"></section>

</main>
<?php get_footer();
