<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<section class="inner-banner relative mb-100">
    <img class=" banner_bg" src="assets/images/news-banner.jpg" height="450" width="1920" alt="pickers news" title="">
    <div class="container inner_banner_info">
        <div class="ark-shap">
            <img src="assets/images/title-ark.svg" alt="title-ark" width="" height="">
        </div>
        <div class="heading-48 white">News</div>
        <ul class="woo_breadcums">
            <li>
                <span>
                    <span>
                        <a href="#">Home</a>
                        <span class="breadcrumb_last" aria-current="page">News</span>
                    </span>
                </span>
            </li>
        </ul>
    </div>
</section>

<main class="news-detail page-wrapper   inpg">
    <!-- blog content start -->
    <section class="blog_content_sec mb-100">
        <div class="container">
            <div class="blog_detail_wrap">
                <div class="blog_content_box">
                    <div class="blog_content_left">
                        <div class="heading-40 bg-shap">
                            Pickers Retro Haven is the culmination of a dream, and an opportunity.
                        </div>

                        <div class="main_blog_img">
                            <img src="assets/images/news-detail-img.jpg" alt="old teliphone" title="" width="919"
                                height="840">
                        </div>

                        <p>This is dummy text, we use it at Supple during web designing in case we don't have content
                            for new NON SEO pages and it is changed during development of the new site. Hence, don't
                            worry about this dummy text. We use this dummy text to give you an idea how text on this
                            page would look like as a site user. This is dummy text, we use it at Supple during web
                            designing in case we don't have content for new NON SEO pages and it is changed during
                            development of the new site.
                        </p>

                        <p>Hence, don't worry about this dummy text. We use this dummy text to give you an idea how text
                            on this page would look like as a site user. This is dummy text, we use it at Supple during
                            web designing in case we don't have content for new NON SEO pages and it is changed during
                            development of the new site. Hence, don't worry about this dummy text. We use this dummy
                            text to give you an idea how text on this page would look like as a site user.
                        </p>

                        <p>During this article, we'll cover everything that makes Caloundra special, as well as do a
                            deep dive into the local property market.</p>

                        <div class="heading-26">We use this dummy text to give you an idea how text on this page would
                            look like as a site user
                        </div>

                        <p>This is dummy text, we use it at Supple during web designing in case we don't have content
                            for new NON SEO pages and it is changed during development of the new site. Hence, don't
                            worry about this dummy text. We use this dummy text to give you an idea how text on this
                            page would look like as a site user. This is dummy text, we use it at
                        </p>

                        <p> Supple during web designing in case we don't have content for new NON SEO pages and it is
                            changed during development of the new site. Hence, don't worry about this dummy text. We use
                            this dummy text to give you an idea how text on this page would look like as a site user.
                            This is dummy text, we use it at Supple during web designing in case we don't have content
                            for new NON SEO pages and it is changed during development of the new site. Hence, don't
                            worry about this dummy text. We use this dummy text to give you an idea how text on this
                            page would look like as a site user.</p>

                        <ul class="dlist">
                            <li>This is dummy text, we use it at Supple during web designing in case we don't have
                                content for new NON SEO pages and it is changed during development of the new site.

                            </li>
                            <li>This is dummy text, we use it at Supple during web designing in case we don't have
                                content for new NON SEO pages and it is changed during development of the new site.
                            </li>
                            <li>
                                This is dummy text, we use it at Supple during web designing in case we don't have
                                content for new NON SEO pages and it is changed during development of the new site.
                            </li>
                        </ul>

                        <p>This is dummy text, we use it at Supple during web designing in case we don't have content
                            for new NON SEO pages and it is changed during development of the new site. Hence, don't
                            worry about this dummy text. We use this dummy text to give you an idea how text on this
                            page would look like as a site user. This is dummy text, we use it at Supple during web
                            designing in case we don't have content for new NON SEO pages and it is changed during
                            development of the new site. Hence, don't worry about this dummy text.</p>

                        <div class="heading-26">This is dummy text, we use it at Supple during web designing.</div>
                        <p>This is dummy text, we use it at Supple during web designing in case we don't have content
                            for new NON SEO pages and it is changed during development of the new site. Hence, don't
                            worry about this dummy text. We use this dummy text to give you an idea how text on this
                            page would look like as a site user. This is dummy text, we use it at Supple during web
                            designing in case we don't have content for new NON SEO pages and it is changed during
                            development of the new site.</p>

                        <div class="blogpost_sliderbtn">
                            <a href="#!" class="pre-btn">Previous</a>
                            <a href="#!" class="next-btn">Next </a>
                        </div>
                    </div>
                    <div class="blog_content_right sticky">
                        <div class="search_box">
                            <form action="">
                                <input type="text" placeholder="Search blog">
                                <button href="#" class=""><img src="assets/images/search-icon.svg" alt="search-icon"
                                        width="18" height="18">
                                </button>
                            </form>
                        </div>

                        <div class="artical_box">
                            <div class="heading-24">Recent Posts</div>
                            <div class="article_list">
                                <ul class="articales">
                                    <li>
                                        <a href="#!" class="artical_list_box">
                                            <img src="assets/images/news-search-blog.jpg" alt="pickers-home" width="145"
                                                height="130">
                                            <div class="artical_description">
                                                <p>Pickers Retro Haven is the culmination of a dream, and an
                                                    opportunity.
                                                </p>
                                                <div> <img src="assets/images/arrow-right.svg" alt="right" width="11"
                                                        height="9"></div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#!" class="artical_list_box">
                                            <img src="assets/images/news-search-blog2.jpg" alt="news-search-bar"
                                                width="145" height="130">
                                            <div class="artical_description">
                                                <p>Pickers Retro Haven is the culmination of a dream, and an
                                                    opportunity.
                                                </p>
                                                <div> <img src="assets/images/arrow-right.svg" alt="right" width="11"
                                                        height="9"></div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#!" class="artical_list_box">
                                            <img src="assets/images/news-search-blog3.jpg" alt="news-search-dine"
                                                width="145" height="130">
                                            <div class="artical_description">
                                                <p>Pickers Retro Haven is the culmination of a dream, and an
                                                    opportunity.
                                                </p>
                                                <div> <img src="assets/images/arrow-right.svg" alt="right" width="11"
                                                        height="9"></div>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="contact-form">
                                <div class="blog-form-contact flex-container wrap justify-content-between">
                                    <div class="form-group width50 ">
                                        <input class="form-control" type="text" name="Name*" placeholder="First Name*">
                                    </div>
                                    <div class="form-group width50 ">
                                        <input class="form-control" type="text" name="Name*" placeholder="Last Name*">
                                    </div>
                                    <div class="form-group width50">
                                        <input class="form-control" type="email" placeholder="Your Email*">
                                    </div>
                                    <div class="form-group width50">
                                        <input class="form-control" type="text" name="Phone" placeholder="Phone*">
                                    </div>
                                    <div class="form-group width100">
                                        <textarea class="form-control" placeholder="Message"></textarea>
                                    </div>
                                    <div class="form-group width100 bnt-sub">
                                        <input type="submit" name="" value="Submit" class="btnsubmit">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- blog content end -->

    <?php block('instagram'); ?>

</main>
<?php get_footer();

