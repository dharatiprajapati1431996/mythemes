<?php

$GLOBALS['assets'] = [
    'common' => [
        'styles' => ['font-awesome.min',  'slick.min', 'slick-theme.min', 'common-critical','common', 'footer'],
        'scripts' => ['jquery-3.6.1', 'slick.min', 'script', 'latest-news'],
    ],
    'home' => [
        'styles' => ['smk-accordion', 'woocommerce', 'woocommerce-layout', 'woocommerce-smallscreen', 'woo-custome', 'easy-responsive-tabs', 'home', 'jquery.fancybox.min'],
        'scripts' => ['smk-accordion', 'company-quality', 'products-slider', 'shop-collections-slider', 'easy-responsive-tabs', 'home', 'faq', 'jquery.fancybox.min'],
    ],
    'contact' => [
        'styles' => ['contact'],
        'scripts' => ['company-quality'],
    ],
    'about' => [
        'styles' => ['about'],
        'scripts' => ['company-quality'],
    ],
    'news' => [
        'styles' => ['news-detail'],
        'scripts' => ['company-quality'],
    ],
    'news-detail' => [
        'styles' => ['news-detail'],
        'scripts' => ['company-quality'],
    ],
    'products' => [
        'styles' => ['woocommerce', 'woocommerce-layout', 'woocommerce-smallscreen', 'woo-custome', 'products'],
        'scripts' => ['products_list'],
    ],
    'product-details' => [
        'styles' => ['woocommerce', 'woocommerce-layout', 'woocommerce-smallscreen', 'woo-custome', 'smk-accordion', 'faq', 'products', 'jquery.fancybox.min'],
        'scripts' => ['faq', 'smk-accordion', 'products-slider', 'products_list', 'jquery.fancybox.min'],
    ],
];
