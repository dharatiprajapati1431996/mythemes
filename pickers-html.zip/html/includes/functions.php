<?php

function wp_head()
{
    foreach ($GLOBALS['assets'] as $page => $asset) {
        if ($page === 'common' || str_ends_with($_SERVER['PHP_SELF'], "/$page.php")) {
            if (isset($asset['styles']) && is_array($asset['styles'])) {
                foreach ($asset['styles'] as $style) {
                    $src = $style;
                    $media = 'all';
                    if (is_array($style)) extract($style);
                    echo "<link rel='stylesheet' href='" . (str_contains($src, 'assets/') ? $src : "assets/css/$src") . ".css' media='$media'/>" . PHP_EOL;
                }
            }
        }
    }
}

function wp_footer()
{
    foreach ($GLOBALS['assets'] as $page => $asset) {
        if ($page === 'common' || str_ends_with($_SERVER['PHP_SELF'], "/$page.php")) {
            if (isset($asset['scripts']) && is_array($asset['scripts'])) {
                foreach ($asset['scripts'] as $script) {
                    echo "<script src='assets/js/$script.js'></script>" . PHP_EOL;
                }
            }
        }
    }
}

function get_header()
{
    include __DIR__ . '/../header.php';
}

function get_footer()
{
    include __DIR__ . '/../footer.php';
}

function block($path)
{
    if (file_exists($path = normalize_path(__DIR__ . '/../blocks/' . $path . '.php'))) {
        include $path;
    }
    else {
        echo "<div style='color:red;'><strong>Path Not Found:</strong> $path</div>";
    }
}

function get_os()
{
    $OS_WIN = 1;
    $OS_OSX = 2;
    $OS_LINUX = 3;
    $OS_UNKNOWN = 4;

    switch (true) {
        case stristr(PHP_OS, 'WIN'):
            return $OS_WIN;
        case stristr(PHP_OS, 'DAR'):
            return $OS_OSX;
        case stristr(PHP_OS, 'LINUX'):
            return $OS_LINUX;
        default:
            return $OS_UNKNOWN;
    }
}

function normalize_path($path)
{
    $path = preg_replace('/[\/\\\]/', '/', $path);
    $path = explode('/', $path);
    $result = '';

    foreach ($path as $idx => $item) {
        if (!$idx) {
            $result = $item;
        }
        elseif ($item === '.') {
            continue;
        }
        elseif ($item === '..') {
            $result = dirname($result);
        }
        else {
            $result .= '/' . $item;
        }
    }

    return $result;
}

if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool
    {
        $needle_len = strlen($needle);
        return ($needle_len === 0 || 0 === substr_compare($haystack, $needle, -$needle_len));
    }
}

if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool
    {
        return '' === $needle || false !== strpos($haystack, $needle);
    }
}
