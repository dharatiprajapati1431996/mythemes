<footer class="footer footer-bg">
    <div class="footer-mdl">
        <div class="md-container">
            <div class="footer-mdl-wrap">
                <div class="footer-mdl-left sticky">
                    <div class="footer-logo">
                        <a href="#!">
                            <img src="assets/images/footer-logo.jpg" alt="pickersretrohaven" width="155" height="193" title="">
                        </a>
                    </div>

                    <div class="social_icon">
                        <address>
                            122 Old Princes HWY
                            Beaconfield
                            VIC Australia 3807
                        </address>
                        <ul class="social-icon-box">
                            <li>
                                <a href="#!">
                                    <span>
                                        <img src="assets/images/facebook.svg" alt="facebook" width="9" height="15" title="">
                                    </span>
                                </a>
                            </li>

                            <li>
                                <a href="#!">
                                    <span>
                                        <img src="assets/images/instagram.svg" alt="instagram" width="15" height="15" title="">
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="footer-mdl-right">
                    <div class="footer-top">
                        <div class="md-container">
                            <div class="contact-deail">
                                <a href="mailto:enquiries@pickersretrohaven.com.au"><span><img src="assets/images/f-email.svg" alt="f-email"></span>enquiries@pickersretrohaven.com.au</a>
                                <p><span><img src="assets/images/f-call.svg" alt="f-call"></span>Call us now: <a href="tel: 0418 993 633">
                                        0418 993 633</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="footer-mdl-right-wrap">
                        <div class="footer-mdl-right-left">
                            <div class="ft-col-1 showhide">
                                <div class="ft-title">Quick Links</div>
                                <ul class="ft-links">
                                    <li><a href="home.php">Home</a></li>
                                    <li><a href="about.php">About Us</a></li>
                                    <li><a href="#">Vendors</a></li>
                                    <li><a href="#">Resources</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </div>
                            <div class="ft-col-2 showhide">
                                <div class="ft-title">My Account</div>
                                <ul class="ft-links">
                                    <li><a href="#">Sign In</a></li>
                                    <li><a href="#">Register </a></li>
                                    <li><a href="#">My Wishlist</a></li>
                                    <li><a href="#">My Orders</a></li>
                                </ul>
                            </div>
                            <div class="ft-col-3 showhide">
                                <div class="ft-title">Categories</div>
                                <ul class="ft-links">
                                    <li><a href="#">Arts</a></li>
                                    <li><a href="#">Collectibles </a></li>
                                    <li><a href="#">Music</a></li>
                                    <li><a href="#">Vintage</a></li>
                                    <li><a href="#">Jewelry</a></li>
                                    <li><a href="#">Bric and Brac</a></li>
                                </ul>
                            </div>
                            <div class="ft-col-4 showhide">
                                <div class="ft-title">Customer Service</div>
                                <ul class="ft-links">
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Terms and Conditions</a></li>
                                    <li><a href="#">Returns Policy</a></li>
                                    <li><a href="#">Disclaimer</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="footer-mdl-right-right footer-sec">
                            <div class="ft-col-5 showhide">
                                <div class="ft-title">Newsletter Subscription</div>
                                <p>Subscribe to receive the latest updates, announcements, and event details</p>
                                <form class="footer_search_form __web-inspector-hide-shortcut__">
                                    <div class="footer_search_wrapper">
                                        <input type="search" name="" value="" class="aws-search-field form-control" placeholder="Email Address" autocomplete="off">
                                    </div>
                                    <div class="footer_search_btn">
                                        <span class="footer_search_icon">
                                            <img src="assets/images/footer-email-send-icon.svg" height="25" width="25" title="" alt="send">
                                        </span>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="md-container">
        <div class="footer-btm">
            <p>© 2024 Pickers Retro Haven. All Rights Reserved.</p>
            <div class="social_icon">
                <span>Shop Securely </span>
                <div class="payment-option">
                    <img src="assets/images/payment-options.jpg" alt="payment-service" width="268" height="30" title="">
                </div>
            </div>
        </div>
    </div>
    <div class="quick_tap_list">
        <a href="tel:0418 993 633" class="quick_tap_box">
            <div class="img-wrap"><img src="assets/images/call-w.svg" height="19" width="19" alt="call"></div>
            <div class="quick_tap_title">Call</div>
        </a>
        <a href="" class="quick_tap_box">
            <div class="img-wrap"><img src="assets/images/wishlist.svg" height="20" width="23" alt="wishlist"></div>
            <div class="quick_tap_title">Wishlist</div>
        </a>
        <a href="" class="quick_tap_box">
            <div class="img-wrap"><img src="assets/images/accout.svg" height="19" width="19" alt="accout"></div>
            <div class="quick_tap_title">Account</div>
        </a>
        <a href="" class="quick_tap_box">
            <div class="img-wrap"><img src="assets/images/shopping-cart.svg" height="19" width="21" alt="shop cart"></div>
            <div class="quick_tap_title">Cart</div>
        </a>
    </div>
</footer>
<?php wp_footer(); ?>
</body>

</html>