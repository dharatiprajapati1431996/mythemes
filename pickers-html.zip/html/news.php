<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<section class="inner-banner relative mb-120">
    <img class="banner_bg" src="assets/images/news-banner.jpg" height="450" width="1920" alt="pickers-books" title="">
    <div class="container inner_banner_info">
        <div class="ark-shap">
            <img src="assets/images/title-ark.svg" alt="title-ark" width="" height="">
        </div>
        <div class="heading-48 white">News</div>
        <ul class="woo_breadcums">
            <li>
                <span>
                    <span>
                        <a href="#">Home</a>
                        <span class="breadcrumb_last" aria-current="page">News</span>
                    </span>
                </span>
            </li>
        </ul>
    </div>
</section>

<main class="news page-wrapper inpg">

    <!-- blog section start -->
    <section class="blog-sec mb-100">
        <div class="container">
            <div class="blog-wrap">
                <ul class="blog-list">
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img1.jpg" alt="books" width="336" height="307" title="">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">20 OCT 2023</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img2.jpg" alt="books" width="336" height="307" title="">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">25 DEC 2023</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img3.jpg" alt="gold-chain" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">30 JAN 2024</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img4.jpg" alt="teliphone" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">30 JAN 2024</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img5.jpg" alt="dining table" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">20 OCT 2023</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img6.jpg" alt="glass" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">25 DEC 2023</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img7.jpg" alt="cup-boards" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">30 JAN 2024</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img8.jpg" alt="camera lens" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">20 OCT 2023</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img9.jpg" alt="musical instruments" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">25 DEC 2023</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img10.jpg" alt="pickers rooms" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">30 JAN 2024</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img11.jpg" alt="brass clock" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">30 JAN 2024</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#!" class="blog-box">
                            <div class="blogbox-img">
                                <img src="assets/images/blog-img12.jpg" alt="old teliphone" title="" width="336" height="307">
                            </div>
                            <div class="blogbox-detail">
                                <div class="title">30 JAN 2024</div>
                                <div class="heading-20">Pickers Retro Haven is the culmination of a dream, and an
                                    opportunity.</div>
                                <div href="#!" class="btn-white">Read More</div>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <!-- blog section end -->

    <?php block('instagram'); ?>
</main>
<?php get_footer();

