<!-- instagram section start -->
<section class="instagram-sec mb-100">
    <div class="md-container">
        <div class="insta-head-wrap">
            <div class="insta-head-left">
                <div class="insta-logo-heading-wrap">
                    <div class="insta-logo">
                        <img src="assets/images/ickersretrohaven.jpg" alt="pickersretrohaen" width="42" height="52" title="">
                    </div>
                    <div class="insta-logo-detail">
                        <div class="heading-28">
                            pickersretrohaven
                        </div>
                        <p>An eclectic mix of antiques new used upcycled recycled repurposed retro vintage goods &
                            more
                        </p>
                    </div>
                </div>
            </div>
            <div class="insta-head-right">
                <div class="insta-btn">
                    <a href="#!" class="btn-black">Follow us<img src="assets/images/instagram.svg" alt="instagram" width="26" height="26" title=""></a>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="insta-gellary">
            <img src="assets/images/insta-imgs.jpg" alt="instagram-gallery" width="1920" height="641" title="">
        </div>
    </div>

</section> 
<!-- instagram section end -->