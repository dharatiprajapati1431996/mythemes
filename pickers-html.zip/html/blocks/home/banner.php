 <!-- banner section start -->
 <section class="sec_hmbanner">
    <ul class="js_hmbanner slick-arrow">
       <li>
          <div class="bannerimgvid">
             <div class="img-wrap"><img src="assets/images/home-banner.jpg" height="657" width="1920" alt="Antiques Vintage Collectables"></div>
          </div>
          <div class="ol_hmbanner">
             <div class="container md-container">
                <div class="olhmban_wrap">
                   <div class="left-side">
                      <div class="img-wrap">
                         <img src="assets/images/title-ark.svg" height="26" width="47" title="" alt="having-stall-img">
                      </div>
                      <div class="hmban_title">Antiques, Vintage, Collectables & Fine Art For Sale</div>
                      <div class="hmban_content">Over 15000 Antique Listings </div>
                      <div class="btnlist">
                         <a href="#" class="btn-theme">SHOP NOW <img src="assets/images/arrow-d.svg" height="10" width="6" alt="button"></a>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       </li>
       <li>
          <div class="bannerimgvid">
             <div class="img-wrap"><img src="assets/images/home-banner.jpg" height="657" width="1920" alt="Antiques Vintage Collectables"></div>
          </div>
          <div class="ol_hmbanner">
             <div class="container md-container">
                <div class="olhmban_wrap">
                   <div class="left-side">
                      <div class="img-wrap">
                         <img src="assets/images/title-ark.svg" height="26" width="47" title="" alt="having-stall-img">
                      </div>
                      <div class="hmban_title">Antiques, Vintage, Collectables & Fine Art For Sale</div>
                      <div class="hmban_content">Over 15000 Antique Listings</div>
                      <div class="btnlist">
                         <a href="#" class="btn-theme">SHOP NOW <img src="assets/images/arrow-d.svg" height="10" width="6" alt="button"></a>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       </li>
    </ul>
 </section>

 <!-- banner section end -->