<!-- companies-qualities start -->
<section class="qualities-sec mb-100 border-bottom">
    <div class="container">
        <div class="qualities_box">
            <ul class="qualities_box-list">
                <li>
                    <div class="quality_card-box">
                        <span><img src="assets/images/quality-img1.png" alt="australiya map" title="" width="47" height="33"></span>
                        <div class="qualities-des">
                            <strong>Australia Wide Shipping
                            </strong>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="quality_card-box">
                        <span><img src="assets/images/quality-img2.png" alt="correct" title="" width="47" height="33"></span>
                        <div class="qualities-des">
                            <strong>100% secure checkout
                            </strong>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="quality_card-box">
                        <span><img src="assets/images/quality-img3.png" alt="delivery vehical" title="" width="47" height="33"></span>
                        <div class="qualities-des">
                            <strong>Same Day Dispatch</strong>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="quality_card-box">
                        <span><img src="assets/images/quality-img4.png" alt="bag" title="" width="47" height="33"></span>
                        <div class="qualities-des">
                            <strong>Click & Collect Available</strong>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</section>
<!-- companies-qualities end -->