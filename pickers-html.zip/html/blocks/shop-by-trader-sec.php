<section class="shop-by-trader-sec">
    <div class="md-container">
        <div class="heading-50 bg-shap">Shop By Trader</div>
        <ul class="shop_by_traders_list">
            <li>
                <a href="#" class="shop_box">
                    <div class="img-wrap">
                        <img src="assets/images/georges-braque.png" title="" height="310" width="310" alt="georges-braque">
                    </div>
                    <div class="heading-shop_box">
                        Georges Braque
                    </div>
                    <div class="btn-border">Explore Products</div>
                </a>
            </li>
            <li>
                <a href="#" class="shop_box">
                    <div class="img-wrap">
                        <img src="assets/images/chris-baker.png" title="" height="310" width="310" alt="chris baker">
                    </div>
                    <div class="heading-shop_box">
                        Chris Baker
                    </div>
                    <div class="btn-border">Explore Products</div>
                </a>
            </li>
            <li>
                <a href="#" class="shop_box">
                    <div class="img-wrap">
                        <img src="assets/images/salvador-dali.png" title="" height="310" width="310" alt="salvador dali">
                    </div>
                    <div class="heading-shop_box">
                        Salvador Dali
                    </div>
                    <div class="btn-border">Explore Products</div>
                </a>
            </li>
            <li>
                <a href="#" class="shop_box">
                    <div class="img-wrap">
                        <img src="assets/images/leonor_fini.png" title="" height="310" width="310" alt="leonor fini">
                    </div>
                    <div class="heading-shop_box">
                        Leonor Fini
                    </div>
                    <div class="btn-border">Explore Products</div>
                </a>
            </li>
        </ul>
    </div>
</section>