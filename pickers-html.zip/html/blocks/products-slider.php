<ul class="products products-slider slick-arrow">
    <li class="product type-product">
        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
            <img src="assets/images/steely-dan-aja-boxed.jpg" height="319" width="320" alt="steely-dan-aja-boxed">
        </a>
        <div class="product-by-title">by JJs Vinyl</div>
        <h2 class="woocommerce-loop-product__title">STEELY DAN - AJA Boxed Set Vinyl</h2>
        <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
        <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
    </li>

    <li class="product type-product">
        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
            <img src="assets/images/medium-antique-copper-teapot.jpg" height="319" width="320" alt="medium-antique-copper-teapot">
        </a>
        <div class="product-by-title">by The House Of Herbert</div>
        <h2 class="woocommerce-loop-product__title">Medium Antique Copper teapot</h2>
        <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>65.00</bdi></span></span>
        <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
    </li>
    <li class="product type-product">
        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
            <img src="assets/images/the-lady-of-the-rivers-by-philippa-gregory.jpg" height="319" width="320" alt="the-lady-of-the-rivers-by-philippa-gregory">
        </a>
        <div class="product-by-title">by Rumble</div>
        <h2 class="woocommerce-loop-product__title">The Lady of the Rivers by Philippa Gregory</h2>
        <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
        <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
    </li>
    <li class="product type-product">
        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
            <img src="assets/images/handmade-lepidolite-bracelet-with-gold.jpg" height="319" width="320" alt="handmade-lepidolite-bracelet-with-gold">
        </a>
        <div class="product-by-title">by Anay Crystals</div>
        <h2 class="woocommerce-loop-product__title">Handmade Lepidolite Bracelet with Gold</h2>
        <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>36.95</bdi></span></span>
        <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
    </li>
    <li class="product type-product">
        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
            <img src="assets/images/cup.jpg" height="319" width="320" alt="cup">
        </a>
        <div class="product-by-title">by Anay Crystals</div>
        <h2 class="woocommerce-loop-product__title">Handmade Lepidolite Bracelet with Gold</h2>
        <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>36.95</bdi></span></span>
        <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
    </li>
    <li class="product type-product">
        <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
            <img src="assets/images/steely-dan-aja-boxed.jpg" height="319" width="320" alt="steely-dan-aja-boxed">
        </a>
        <div class="product-by-title">by JJs Vinyl</div>
        <h2 class="woocommerce-loop-product__title">STEELY DAN - AJA Boxed Set Vinyl</h2>
        <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
        <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
    </li>
</ul>