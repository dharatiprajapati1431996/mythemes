<section class="featured-cate-sec">
    <div class="md-container">
        <div class="heading-50 bg-shap">Featured Categories</div>
        <p>We carry a wide array of quality antique and vintage items.</p>
        <ul class="featured-cate-slider slick-arrow">
            <li>
                <a href="#" class="feature-cate-box type-1">
                    <div class="img-wrap">
                        <img src="assets/images/arts.png" height="507" width="323" title="" alt="arts">
                        <div class="feature-cate-badge">
                            Arts
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" class="feature-cate-box type-2">
                    <div class="img-wrap">
                        <img src="assets/images/bric-brac.png" height="457" width="332" title="" alt="bric-brac">
                        <div class="feature-cate-badge">
                            Bric a Brac
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" class="feature-cate-box type-3">
                    <div class="img-wrap">
                        <img src="assets/images/collectables.png" height="507" width="333" title="" alt="collectables">
                        <div class="feature-cate-badge">
                            Collectables
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" class="feature-cate-box type-4">
                    <div class="img-wrap">
                        <img src="assets/images/jewellery.png" height="507" width="322" title="" alt="jewellery">
                        <div class="feature-cate-badge">
                            Jewellery
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" class="feature-cate-box type-5">
                    <div class="img-wrap">
                        <img src="assets/images/Vintage.png" height="507" width="309" title="" alt="arts">
                        <div class="feature-cate-badge">
                            Vintage
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" class="feature-cate-box type-2">
                    <div class="img-wrap">
                        <img src="assets/images/bric-brac.png" height="457" width="332" title="" alt="bric-brac">
                        <div class="feature-cate-badge">
                            Bric a Brac
                        </div>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" class="feature-cate-box type-3">
                    <div class="img-wrap">
                        <img src="assets/images/collectables.png" height="507" width="333" title="" alt="collectables">
                        <div class="feature-cate-badge">
                            Collectables
                        </div>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</section>