<section class="having-stall-sec">
    <div class="container">
        <div class="half-section">
            <div class="left-side">
                <div class="img-wrap">
                    <img src="assets/images/title-ark.svg" height="26" width="47" title="" alt="ark">
                </div>
                <div class="small-title">we have more 70 individual stallholders</div>
                <div class="heading-38">Interested in Having a Stall?</div>
                <p>Pickers Retro Haven is the culmination of a dream, and an opportunity for the owners to indulge their passion for collectibles and objects that carry a sense of history.</p>
                <a href="#" class="btn-theme">Browse Stall Holders</a>
            </div>
            <div class="right-side">
                <div class="img-wrap">
                    <img src="assets/images/having-stall-img.png" title="" height="458" width="756" alt="stall product">
                </div>
            </div>
        </div>
    </div>
</section>