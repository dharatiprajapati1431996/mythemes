<section class="established-details-sec">
    <div class="half-section">
        <div class="left-side">
            <div class="img-wrap">
                <img src="assets/images/established-pickers-retro.jpg" height="669" width="622" title="" alt="established-pickers-retro">
            </div>
        </div>
        <div class="middle-side">

            <div class="img-wrap">
                <img src="assets/images/title-ark.svg" height="26" width="47" title="" alt="having-stall-img">
            </div>
            <div class="heading-32">Established in October 2019</div>
            <p>Pickers Retro Haven is the culmination of a dream, and an opportunity for the owners to indulge their passion for collectibles and objects that carry a sense of history.</p>
            <div class="img-wrap section-ark">
                <img src="assets/images/section-ark.png" height="6" width="154" title="" alt="having-stall-img">
            </div>
            <div class="heading-26">Family-owned an operated business</div>
            <p>The aim of Pickers Retro Haven, a family-owned an operated business. We have done this by finding the perfect location where we can bring together sellers of antiques and collectibles, creating a destination for customers where they can always find something new and fascinating.</p>
            <a href="#" class="btn-theme">Explore More</a>
        </div>
        <div class="right-side">
            <div class="img-wrap">
                <img src="assets/images/established-pickers-retro1.jpg" height="669" width="622" title="" alt="established-pickers-retro">
            </div>
        </div>
    </div>
</section>