<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<section class="inner-banner inner-banner-sm dark-bg relative">
    <div class="container md-container inner_banner_info">
        <ul class="woo_breadcums">
            <li>
                <span>
                    <span>
                        <a href="#">Home</a>
                        <a href="#">Arts</a>
                        <span class="breadcrumb_last" aria-current="page">Medium Antique Copper teapot</span>
                    </span>
                </span>
            </li>
        </ul>
    </div>
</section>

<main class="products-details-pg page-wrapper woocommerce inpg">

    <section class="product-details-sec">
        <div class="md-container">
            <div class="half-section">
                <div class="left-side">
                    <div class="slider-wraper">
                        <div class="slick-arrow slider-for-product">
                            <div class="slider-banner-image">
                                <a href="assets/images/antique-copper-teapot.jpg" data-fancybox="gallery" class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot.jpg" alt="" title=" " width="800" height="800">
                                </a>
                            </div>
                            <div class="slider-banner-image">
                                <a href="assets/images/antique-copper-teapot.jpg" data-fancybox="gallery" class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot.jpg" alt="" title=" " width="800" height="800">
                                </a>
                            </div>
                            <div class="slider-banner-image">
                                <a href="assets/images/antique-copper-teapot.jpg" data-fancybox="gallery" class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot.jpg" alt="" title=" " width="800" height="800">
                                </a>
                            </div>
                            <div class="slider-banner-image">
                                <a href="assets/images/antique-copper-teapot.jpg" data-fancybox="gallery" class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot.jpg" alt="" title=" " width="800" height="800">
                                </a>
                            </div>
                            <div class="slider-banner-image">
                                <a href="assets/images/antique-copper-teapot.jpg" data-fancybox="gallery" class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot.jpg" alt="" title=" " width="800" height="800">
                                </a>
                            </div>
                        </div>
                        <div class="slick-arrow slider-nav-product thumb-image">
                            <div class="thumbnail-image">
                                <div class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot-thumb.jpg" alt="" title="" width="126" height="126">
                                </div>
                            </div>
                            <div class="thumbnail-image">
                                <div class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot-thumb.jpg" alt="" title="" width="126" height="126">
                                </div>
                            </div>
                            <div class="thumbnail-image">
                                <div class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot-thumb.jpg" alt="" title="" width="126" height="126">
                                </div>
                            </div>
                            <div class="thumbnail-image">
                                <div class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot-thumb.jpg" alt="" title="" width="126" height="126">
                                </div>
                            </div>
                            <div class="thumbnail-image">
                                <div class="img-wrap">
                                    <img src="assets/images/antique-copper-teapot-thumb.jpg" alt="" title="" width="126" height="126">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="right-side">
                    <div class="product">
                        <div class="product_availability_wrap">
                            <div class="product-store-nm">by The House Of Herbert</div>
                            <div class="in-stock"><img src="assets/images/check_mrk.svg" height="10" width="11" alt="">In Stock</div>
                        </div>
                        <h3 class="product_title entry-title">Medium Antique Copper teapot</h3>
                        <div class="price-detaile-wrap">
                            <p class="price">
                                <span class="woocommerce-Price-amount amount">
                                    <bdi>
                                        <span class="woocommerce-Price-currencySymbol">$</span>
                                        65.00
                                    </bdi>
                                </span>
                                <span class="tax_include">Tax included</span>
                            </p>

                            <div class="woocommerce-product-rating">
                                <a href="#reviews" class="woocommerce-review-link" rel="nofollow">Write a review</a>
                            </div>
                        </div>
                        <div class="woocommerce-product-details__short-description">
                            <p>This is dummy text, we use it at Supple during web designing in case we don’t have content for new NON SEO pages and it is changed during development of the new site. </p>
                        </div>
                        <form class="cart" action="#">
                            <button type="submit" class="single_add_to_cart_button button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to Cart</button>
                            <button type="submit" class="add_to_wishlist_button button"><img src="assets/images/wishlist.svg" height="16" width="19" title="" alt="wishlist"> Add to Wishlist</button>
                        </form>


                        <div class="faqs specificationaccordion">
                            <!-- Section 1 -->
                            <div class="accordion_in">
                                <div class="acc_head">Description</div>

                                <div class="acc_content">
                                    <p>This is dummy text, we use it at Supple during web designing in case
                                        we don’t have content for new NON SEO pages and it is changed during development of the new site.
                                        Hence, don’t worry about this dummy text. We use this dummy text to give you an idea
                                        how text on this page would look like as a site user.
                                    </p>
                                </div>
                            </div>
                            <!-- Section 2 -->

                            <div class="accordion_in">
                                <div class="acc_head">
                                    Specification
                                </div>
                                <div class="acc_content">
                                    <p>This is dummy text, we use it at Supple during web designing in case
                                        we don’t have content for new NON SEO pages and it is changed during development of the new site.
                                        Hence, don’t worry about this dummy text. We use this dummy text to give you an idea
                                        how text on this page would look like as a site user.
                                    </p>
                                </div>
                            </div>
                            <!-- Section 3 -->
                            <div class="accordion_in">
                                <div class="acc_head">
                                    Reviews <span>(1)</span>
                                </div>
                                <div class="acc_content">
                                    <p>This is dummy text, we use it at Supple during web designing in case
                                        we don’t have content for new NON SEO pages and it is changed during development of the new site.
                                        Hence, don’t worry about this dummy text. We use this dummy text to give you an idea
                                        how text on this page would look like as a site user.
                                    </p>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="products-slider-sec">
        <div class="md-container">
            <div class="heading-50 bg-shap">Realted Products</div>
            <?php block('products-slider'); ?>
        </div>
    </section>

    <?php block('instagram'); ?>
</main>
<?php get_footer();
