<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<section class="inner-banner inner-banner-sm relative">
    <div class="container md-container inner_banner_info">
        <ul class="woo_breadcums">
            <li>
                <span>
                    <span>
                        <a href="#">Home</a>
                        <span class="breadcrumb_last" aria-current="page">About Us</span>
                    </span>
                </span>
            </li>
        </ul>
    </div>
</section>

<main class="products-list-pg page-wrapper woocommerce inpg">

    <section class="arts-sec">
        <div class="md-container">
            <div class="heading-50 bg-shap">Art</div>
            <ul class="arts-slider slick-arrow">
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/oil-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Oil
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/watercolour-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Watercolour
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/canvas-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Canvas
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/Print-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Print
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/photo-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Photo
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/limited-edition-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Limited Edition
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/canvas-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Canvas
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" class="arts-box">
                        <div class="img-wrap">
                            <img src="assets/images/Print-art.jpg" height="150" width="250" title="" alt="arts">
                            <div class="arts-badge">
                                Print
                            </div>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </section>
    <section class="prodlistingsec">
        <div class="md-container container product_wrap">
            <div class="half-section">
                <div class="left-side product_sidebar mobile-slide">
                    <div class="mobile-wrap">
                        <a href="#" class="closemenu desk-hide"><img src="assets/images/menu-close.png" alt="close" width="" height=""></a>
                        <div class="categorylistbox">
                        </div>
                    </div>

                    <div class="leftcolfilter">
                        <div class="heading-filter">Shop by Categories</div>
                        <p>Wordpress plugin Here</p>
                    </div>
                </div>
                <div class="right-side product_listing_wrapper">
                    <div class="mobilefilter_box hide-in-desktop">
                        <a href="javascript:void(0);" class="btn-border m_filtertrigger"><span> Filter </span>
                            <i class="fa fa-filter"></i>
                        </a>
                    </div>
                    <div class="product-wc-header">
                        <p class="woocommerce-result-count">
                            Showing 1–16 of 17 results
                        </p>
                        <div class="pro_listfilterdiv_right">
                            <form class="woocommerce-ordering" method="get">
                                <select name="orderby" class="orderby" aria-label="Shop order">
                                    <option value="menu_order" selected="selected">Sort By</option>
                                    <option value="popularity">Sort by popularity</option>
                                    <option value="rating">Sort by average rating</option>
                                    <option value="date">Sort by latest</option>
                                    <option value="price">Sort by price: low to high</option>
                                    <option value="price-desc">Sort by price: high to low</option>
                                </select>
                                <input type="hidden" name="paged" value="1">
                            </form>
                            <div class="sortcolnumber">
                                <a href="" class="sortcol3"></a>
                                <a href="" class="sortcol4 active"></a>
                            </div>
                            <nav class="woocommerce-pagination">
                                <ul class="page-numbers">
                                    <li><a href="#" class="previous page-numbers"><i class="fa fa-angle-left"></i></a></li>
                                    <li><a class="next page-numbers" href="#"><i class="fa fa-angle-right"></i></a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <ul class="products columns-3">
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/medium-antique-copper-teapot.jpg" height="319" width="320" alt="medium-antique-copper-teapot">
                            </a>
                            <div class="product-by-title">by The House Of Herbert</div>
                            <h2 class="woocommerce-loop-product__title">Medium Antique Copper teapot</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>65.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/the-lady-of-the-rivers-by-philippa-gregory.jpg" height="319" width="320" alt="the-lady-of-the-rivers-by-philippa-gregory">
                            </a>
                            <div class="product-by-title">by Rumble</div>
                            <h2 class="woocommerce-loop-product__title">The Lady of the Rivers by Philippa Gregory</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/handmade-lepidolite-bracelet-with-gold.jpg" height="319" width="320" alt="handmade-lepidolite-bracelet-with-gold">
                            </a>
                            <div class="product-by-title">by Anay Crystals</div>
                            <h2 class="woocommerce-loop-product__title">Handmade Lepidolite Bracelet with Gold</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>36.95</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/cup.jpg" height="319" width="320" alt="cup">
                            </a>
                            <div class="product-by-title">by Anay Crystals</div>
                            <h2 class="woocommerce-loop-product__title">Handmade Lepidolite Bracelet with Gold</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>36.95</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>

                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/bottle.jpg" height="310" width="311" alt="bottle">
                            </a>
                            <div class="product-by-title">by JJs Vinyl</div>
                            <h2 class="woocommerce-loop-product__title">STEELY DAN - AJA Boxed Set Vinyl</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>

                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/mug.jpg" height="310" width="311" alt="mug">
                            </a>
                            <div class="product-by-title">by The House Of Herbert</div>
                            <h2 class="woocommerce-loop-product__title">Medium Antique Copper teapot</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>65.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/picture_art.jpg" height="310" width="311" alt="picture_art">
                            </a>
                            <div class="product-by-title">by Rumble</div>
                            <h2 class="woocommerce-loop-product__title">The Lady of the Rivers by Philippa Gregory</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/antique-piece.jpg" height="310" width="311" alt="antique-piece">
                            </a>
                            <div class="product-by-title">by Anay Crystals</div>
                            <h2 class="woocommerce-loop-product__title">Handmade Lepidolite Bracelet with Gold</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>36.95</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/toy_car.jpg" height="310" width="311" alt="toy_car">
                            </a>
                            <div class="product-by-title">by Anay Crystals</div>
                            <h2 class="woocommerce-loop-product__title">Handmade Lepidolite Bracelet with Gold</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>36.95</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>

                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/antique-bottle.jpg" height="310" width="311" alt="antique-bottle">
                            </a>
                            <div class="product-by-title">by The House Of Herbert</div>
                            <h2 class="woocommerce-loop-product__title">Medium Antique Copper teapot</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>65.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/crown.jpg" height="310" width="311" alt="crown">
                            </a>
                            <div class="product-by-title">by JJs Vinyl</div>
                            <h2 class="woocommerce-loop-product__title">STEELY DAN - AJA Boxed Set Vinyl</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>
                        <li class="product type-product">
                            <a href="#" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
                                <img src="assets/images/steely-dan-aja-boxed.jpg" height="319" width="320" alt="steely-dan-aja-boxed">
                            </a>
                            <div class="product-by-title">by JJs Vinyl</div>
                            <h2 class="woocommerce-loop-product__title">STEELY DAN - AJA Boxed Set Vinyl</h2>
                            <span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>340.00</bdi></span></span>
                            <a href="#" class="button add_to_cart_button"><img src="assets/images/shopping-cart.svg" height="17" width="19" alt="shopping-cart"> Add to cart</a>
                        </li>

                    </ul>
                    <div class="half-section product-content">
                        <div class="left-side sticky">
                            <div class="img-wrap">
                                <img src="assets/images/gramophone.jpg" title="" width="538" height="512" alt="gramophone">
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="heading-32 bg-shap">Vintage Art Melbourne</div>
                            <p>Have you been searching for a spectacular range of vintage art? Each piece in our collection tells a unique story.</p>
                            <p>Whether you want to change up your home or search for that perfect, conversation-starting artwork, our range of vintage art in Melbourne will enchant you. You never know what you will find! Contact us for more information, or set up your own stall today.</p>
                            <div class="heading-26">Vintage Wallpaper in Melbourne</div>
                            <p>From Victorian landscapes to mid-century modern abstracts, each artwork is selected for its quality and historical significance. If you’re passionate about artwork in all its forms, browse our eclectic collection and discover pieces that resonate with you!</p>
                            <p>Melbourne art lovers will appreciate the depth and variety of our vintage art collection. Each piece offers a glimpse into the creative minds of artists from different eras.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <?php block('instagram'); ?>
</main>
<?php get_footer();
