<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="thnak_you-page">
    <div class="overlay" style=""></div>

   <section class="inner-banner">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Thank You</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>


    <section class="inpg">
        <div class="page-width">
            <div class="flex-container thank_you_content wrap">
                    <div class="error-left">  <!-- wp:html -->
                        <div class="heading-48">We’ve Received Your Inquiry!</div>

                        <p>We're excited to help you build your perfect space.</p>
                        <p>Thank you for reaching out to Superior Granny Flats! One of our team members will get back to you shortly to discuss your project and answer any questions you may have.</p>

                        <p>In the meantime, feel free to explore more about what we offer:</p>

                        <ul>
                            <li><a href="">Browse our latest projects</a></li>
                            <li><a href="">Learn more about our process</a></li>
                            <li><a href="">Read testimonials from our happy clients</a></li>
                        </ul>
                        <p>Have an urgent inquiry? Give us a call at <a href="tel:0424 667 322">0424 667 322</a> for immediate assistance.</p>
                    </div>

                    <div class="error-right">
                        <img src="assets/images/thankyou.png" alt="thank you" width="500" height="500">
                    </div>
                </div>

        </div>
    </section>
</main>
<?php get_footer();