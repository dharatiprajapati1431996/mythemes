<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>

<main class="thnak_you-page">
    <div class="overlay" style=""></div>

    <section class="inner-banner">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <span class="breadcrumb_last" aria-current="page">404</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>



    <section class="inpg">
        <div class="page-width">
            <div class="flex-container thank_you_content wrap">
                    <div class="error-left"> 
                        <div class="heading-48">Oops! Page Not Found.</div>
                            <p>It looks like the page you're looking for doesn't exist.</p>
                            <p>But don't worry, we're here to help you find your way!</p>
                            <p>You can:</p>
                            <ul>
                                <li><a href="#">Return to the homepage</a> and explore from there.</li>
                                <li><a href="#">Check out our latest projects</a> for inspiration.</li>
                                <li><a href="#">Contact us</a> if you need assistance.</li>
                            </ul>
                    </div>
                    <div class="error-right">  
                        <img src="assets/images/404.png" alt="thank-you" width="500" height="500">
                    </div>
                </div>

        </div>
    </section>


    <?php block('proudlystocking-sec'); ?>  
    <?php block('newsletter'); ?>
</main>


<?php get_footer();