<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="home-page">
    <div class="overlay" style=""></div>
    <?php block('home/slider'); ?>

    <section class="waveeffect_sec mrgb80" style="">
        <div class="wavecontainer" dir="rtl" style="">
            <div class="wave_sliderreverse regular slider">
                <div class=""><img src="assets/images/wave-effect.svg" alt="" width="2480" height="9" title=""></div>
                <div class=""><img src="assets/images/wave-effect.svg" alt="" width="2480" height="9" title=""></div>
                <div class=""><img src="assets/images/wave-effect.svg" alt="" width="2480" height="9" title=""></div>
            </div>
        </div>
    </section>

    <!-- common content section  -->
    <section class="common-content-sec">
        <div class="page-width">
            <div class="flex-container wrap row-reverse mrgb80">
                <div class="hm-content">
                    <div class="smalltitle">Our Story</div>
                    <div class="heading-48">Gelato Suppliers Australia <img src="assets/images/pinklines-invert.svg"
                            alt="" width="54" height="54" class="heartbeat onright"></div>
                    <p>Have you always dreamed of opening your own gelato store? As premium gelato suppliers in
                        Australia, we have everything you need to get your business up and running.</p>
                    <p>Whether you’re running a small artisanal gelato shop or managing a larger operation, GelCo
                        provides commercial-grade gelato production equipment and ingredients to support your
                        success in
                        the gelato industry. We also have short courses if you're interested in finer details of
                        ice-cream making!</p>
                    <p>With our comprehensive range of products and expertise, we help you create the freshest and
                        most
                        delicious gelato that your customers will love. Start your journey with us today and
                        experience
                        the difference GelCo can make to your future in delicious treats.</p>
                    <div class="button-group">
                        <a href="" class="button button-outline">Talk to an Expert</a>
                    </div>
                </div>

                <div class="hm-item sticky">
                    <img src="assets/images/gelato-supplier-australia.jpg" alt="gelato supplier australia" width="720"
                        height="600">
                </div>
            </div>
        </div>
    </section>

    <!-- shop by category section start -->
    <section class="shopcategory_sec mrgb80">
        <img src="assets/images/small-icecream-cup.png" alt="" width="82" height="102" class="smallicecreamcup">
        <div class="heading-48">Shop by Category</div>
        <div class="categorycontainer">
            <a href="" class="categorybx"><img src="assets/images/gelato-ingredients.jpg" alt="Gelato Ingredients"
                    width="440" height="600">
                <span>Gelato Ingredients</span>
            </a>
            <a href="" class="categorybx"><img src="assets/images/gelato-equipments.jpg" alt="Gelato Equipment"
                    width="440" height="600">
                <span>Gelato Equipment</span>
            </a>
            <a href="" class="categorybx"><img src="assets/images/soft-serve-machine.jpg" alt="Soft Serve Machines"
                    width="440" height="600">
                <span>Soft Serve Machines</span>
            </a>
            <a href="" class="categorybx"><img src="assets/images/gelato-showcases.jpg" alt="Gelato Showcases"
                    width="440" height="600">
                <span>Gelato Showcases</span>
            </a>
        </div>

    </section>
    <!-- shop by category section end -->

    <!-- scrolling text section start -->
    <section class="scrollingtxt mrgb80">
        <div class="txtslide"><img src="assets/images/second-text.svg" alt="" width="960" height="165" title=""></div>
        <div class="txtslide"><img src="assets/images/first-text.svg" alt="" width="1358" height="175" title=""></div>
    </section>
    <!-- scrolling text section end -->

    <!-- featured products tab slider start -->
    <section class="hm_featureprod mrgb80">
        <div class="page-width">
            <div class="heading-48">Featured Products</div>












            <div class="tabs">
                <div class="tab-nav">
                    <ul>
                        <li class="active"><span data-href="#tab-1">bestsellers</span></li>
                        <li><span data-href="#tab-2">new arrivals</span></li>
                        <li><span data-href="#tab-3">popular products</span>
                        </li>
                    </ul>
                </div>
                <div class="tab active" id="tab-1">






                    <ul class="grid product-grid grid--2-col-tablet-down grid--4-col-desktop related-js">
                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/ananas-pineapple.png" alt="Ananas (Pineapple)"
                                                    class="motion-reduce" width="297" height="297">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Ananas (Pineapple)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">
                                                <!--  <div class="head-xs">Aromitalia</div> -->
                                            </div>

                                            <div class="card-information">
                                                <span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $79.00 - $155.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular">



                                                                </s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $79.00 - $155.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>

                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class=" card card--standard card--media ">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__badge bottom left">
                                            <span class="badge badge--top-left">exclusive</span>
                                        </div>

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/watermelon.png" alt="watermelon"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>

                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5"
                                                id="title-template--15968257671257__product-grid-6920733229145">
                                                <a href="#"
                                                    id="CardLink-template--15968257671257__product-grid-6920733229145"
                                                    class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>

                                                    <span class="prod-heading">Anguria (Watermelon)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>


                                            <div class="card-information">
                                                <span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $79.00 - 155.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $79.00 - 155.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>
                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>

                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>
                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper lightgray-gradient">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__badge bottom left">
                                            <span class="badge badge--top-left onsale">New</span>
                                        </div>
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">

                                                <img src="assets/images/orange.png" sizes="" alt="Arancia (Orange)"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5"
                                                id="title-template--15968257671257__product-grid-6920734441561">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Arancia (Orange)</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $79.00 - $155.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                From $79.00 - $155.00</span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper light-red-gradient">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">

                                                <img src="assets/images/banana.png" sizes="" alt="Banana"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Banana</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $77.00 - $150.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular">



                                                                </s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $77.00 - $150.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper yellow-gradient">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__badge bottom left">
                                            <span class="badge badge--top-left onsale">New</span>
                                        </div>
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/vegan-base.png" sizes=""
                                                    alt="Base Vegan F (Vegan Base)" class="motion-reduce" width="290"
                                                    height="296">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>

                                                    <span class="prod-heading">Base Vegan F (Vegan Base)</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $44.00 - $500.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $44.00 - $500.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/bubblegum-blue.png" sizes=""
                                                    alt="Bubblegum Blue" class="motion-reduce" width="281" height="297">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Bubblegum Blue</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $92.00 - 190.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $92.00 - 190.00</span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>

                </div>
                <div class="tab" id="tab-2">
                    <ul class="grid product-grid grid--2-col-tablet-down grid--4-col-desktop related-js">

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper lightgray-gradient">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__badge bottom left">
                                            <span class="badge badge--top-left onsale">New</span>
                                        </div>
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">

                                                <img src="assets/images/orange.png" sizes="" alt="Arancia (Orange)"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5"
                                                id="title-template--15968257671257__product-grid-6920734441561">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Arancia (Orange)</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $79.00 - $155.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                From $79.00 - $155.00</span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper light-red-gradient">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">

                                                <img src="assets/images/banana.png" sizes="" alt="Banana"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Banana</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $77.00 - $150.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular">



                                                                </s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $77.00 - $150.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper yellow-gradient">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__badge bottom left">
                                            <span class="badge badge--top-left onsale">New</span>
                                        </div>
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/vegan-base.png" sizes=""
                                                    alt="Base Vegan F (Vegan Base)" class="motion-reduce" width="290"
                                                    height="296">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>

                                                    <span class="prod-heading">Base Vegan F (Vegan Base)</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $44.00 - $500.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $44.00 - $500.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/bubblegum-blue.png" sizes=""
                                                    alt="Bubblegum Blue" class="motion-reduce" width="281" height="297">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Bubblegum Blue</span>
                                                </a>
                                            </h3>


                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $92.00 - 190.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $92.00 - 190.00</span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>


                                        <div class="card__badge bottom left"></div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">
                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/coffee.png" sizes="" alt="CAFFÈ (COFFEE)"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Caffè (Coffee)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">
                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $145.00 - $285.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $145.00 - $285.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/caramel.png" sizes="" alt="Caramel"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Caramel</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $78.00 - $150.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $78.00 - $150.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="tab" id="tab-3">
                    <ul class="grid product-grid grid--2-col-tablet-down grid--4-col-desktop related-js">

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/coconut.png" sizes="" alt="Cocco (Coconut)"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Cocco (Coconut)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $77.00 - $150.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $255.00 - $500.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/fruit-base-50.png" sizes=""
                                                    alt="Dbf Master 50 Classic Tuttovegetale (Fruit Base 50)"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>

                                                    <span class="prod-heading">Dbf Master 50 Classic Tuttovegetale
                                                        (Fruit
                                                        Base 50)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $62.00 - $475.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $62.00 - $475.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/milk-base-50.png" sizes="" alt="Milk Base 50"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Milk Base 50</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $58.00 - $455.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $58.00 - $455.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/milk-base-100.png" sizes=""
                                                    alt="Dpo Super 100 C Classic Neutra Sgi # (Milk Base (100)"
                                                    class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>

                                                    <span class="prod-heading">Dpo Super 100 C Classic Neutra Sgi #
                                                        (Milk
                                                        Base (100)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $60.00 - $465.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $60.00 - $465.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/strawberry.png" sizes=""
                                                    alt="Fragola (Strawberry)" class="motion-reduce" width="" height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>
                                                    <span class="prod-heading">Fragola (Strawberry)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $84.00 - $165.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $84.00 - $165.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="grid__item scroll-trigger animate--slide-in">
                            <div class="card-wrapper product-card-wrapper">
                                <div class="card card--standard card--media">
                                    <div class="card__inner color-background-2 ratio">

                                        <div class="card__media">
                                            <div class="media media--transparent media--hover-effect">
                                                <img src="assets/images/with-seeds.png" sizes=""
                                                    alt="French Vanilla (With Seeds)" class="motion-reduce" width=""
                                                    height="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card__content">
                                        <div class="card__information">
                                            <h3 class="card__heading h5">
                                                <a href="#" class="full-unstyled-link">
                                                    <span class="category-heading">Aromitalia</span>

                                                    <span class="prod-heading">French Vanilla (With Seeds)</span>
                                                </a>
                                            </h3>

                                            <div class="card-info">

                                            </div>

                                            <div class="card-information"><span class="caption-large light"></span>
                                                <div class="price ">
                                                    <div class="price__container">
                                                        <div class="price__regular"><span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span class="price-item price-item--regular">
                                                                From $90.00 - $175.00
                                                            </span>
                                                        </div>
                                                        <div class="price__sale">
                                                            <span
                                                                class="visually-hidden visually-hidden--inline">Regular
                                                                price</span>
                                                            <span>
                                                                <s class="price-item price-item--regular"></s>
                                                            </span><span
                                                                class="visually-hidden visually-hidden--inline">Sale
                                                                price</span>
                                                            <span class="price-item price-item--sale price-item--last">
                                                                From
                                                                $90.00 - $175.00 </span>
                                                        </div>
                                                        <small class="unit-price caption hidden">
                                                            <span class="visually-hidden">Unit price</span>
                                                            <span class="price-item price-item--last">
                                                                <span></span>
                                                                <span aria-hidden="true">/</span>
                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                <span>
                                                                </span>
                                                            </span>
                                                        </small>
                                                    </div>
                                                </div>

                                                <button type="submit"
                                                    class="product-form__submit button button--full-width button--secondary">
                                                    <img src="assets/images/white-cart.svg" alt="cart" title=""
                                                        width="19" height="15">
                                                    <span>Add to cart</span>
                                                    <div class="loading__spinner hidden">
                                                        <svg aria-hidden="true" focusable="false" class="spinner"
                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                cy="33" r="30"></circle>
                                                        </svg>
                                                    </div>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>



















        </div>
    </section>
    <!-- featured products tab slider end -->

    <!-- product cta section start -->
    <section class="productcta_sec mrgb80">
        <div class="page-width">
            <a href="" class="ctabx peachcta">
                <div class="ctatag">Sale</div>
                <div class="ctainfo">
                    <div class="ctasmalltxt">Staf59</div>
                    <div class="ctaname">RHT4/20 A | 3.7L Benchtop Density Controlled Combined Machine
                        with auto extraction</div>
                    <div class="btnbar">
                        <span class="button">Shop Now</span>
                    </div>
                </div>
                <div class="ctaimg"><img src="assets/images/RHT4-20A-benchtop.png" alt="" width="290" height="290">
                </div>
            </a>
            <a href="" class="ctabx bluecta">
                <div class="ctatag">Sale</div>
                <div class="ctainfo">
                    <div class="ctasmalltxt">MondialFramec</div>
                    <div class="ctaname">MIRABELLA H6G | Gelato Showcase with Square Glass - 6 Pan
                    </div>
                    <div class="btnbar">
                        <span class="button">Shop Now</span>
                    </div>
                </div>
                <div class="ctaimg"><img src="assets/images/mirabella-H6G.png" alt="" width="290" height="290"></div>
            </a>
        </div>
    </section>
    <!-- product cta section end -->

    <!-- why choose section start -->
    <section class="whychoose_sec">
        <div class="page-width">
            <div class="heading-48">Why Choose Us?</div>
            <div class="whychoose_container">
                <div class="whychoose_bx">
                    <div class="whychoose_icon"><img src="assets/images/commercial-grade-equipment.svg" alt=""
                            width="85" height="80"></div>
                    <div class="whychoose_name">Commercial-Grade Equipment</div>
                    <p>Reliable, high-performance machines built to maximize your production quality and efficiency.</p>
                </div>
                <div class="whychoose_bx">
                    <div class="whychoose_icon"><img src="assets/images/expert-guidance-support.svg"
                            alt="Expert Guidance & Support" width="85" height="80"></div>
                    <div class="whychoose_name">Expert Guidance & Support</div>
                    <p>Trust our team for professional advice and ongoing assistance tailored to your needs.</p>
                </div>
                <div class="whychoose_bx">
                    <div class="whychoose_icon"><img src="assets/images/premium-ingredients.svg"
                            alt="Premium Ingredients" width="85" height="80"></div>
                    <div class="whychoose_name">Premium Ingredients</div>
                    <p>Elevate your creations with high-quality bases and flavors for the ultimate gelato experience.
                    </p>
                </div>
                <div class="whychoose_bx">
                    <div class="whychoose_icon"><img src="assets/images/industry-experience-trainnig.svg"
                            alt="Industry Experience & Training" width="85" height="80"></div>
                    <div class="whychoose_name">Industry Experience & Training</div>
                    <p>Benefit from years of expertise and specialized training designed to boost your success.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- why choose section end -->

    <!-- quality ingradients section start -->
    <section class="qualityingradient_sec mrgb80">
        <div class="page-width">
            <div class="fullwidthcta">
                <div class="ctatxt">Quality Ingredients & Equipment</div>
                <img src="assets/images/icecream-cup.png" class="icecreamcup" width="145" height="225"
                    alt="ice-cream cup">
                <div class="button-group">
                    <a href="" class="button">Shop Now</a>
                    <a href="" class="button buttonpink">Get a Free Consultation</a>
                </div>
            </div>
        </div>
    </section>
    <!-- quality ingradients section end -->

    <!-- common content section  -->
    <section class="common-content-sec">
        <div class="page-width">
            <div class="flex-container wrap mrgb80">
                <div class="hm-content">
                    <div class="heading-48">Commercial-Grade Gelato Suppliers in Australia</div>
                    <p>Are you ready to elevate your gelato business in Australia? From benchtop timer-controlled
                        freezers with auto extraction to multi-function machines with advanced digital controls, our
                        range of gelato equipment is designed for efficiency and performance. Take, for example, our
                        MOVISWITCH 30 (6L), which boasts a built-in converter, cooling system, self-adjusting
                        scrappers,
                        a horizontal tank for churning, and more. With GelCo, your business will be ready to serve
                        up
                        the best flavours and delight your customers.</p>
                    <p>Whether you're looking for gelato suppliers in Melbourne, Sydney, or Brisbane, are a seasoned
                        professional or new to the industry, our training gets you the most out of your equipment,
                        mastering the art of gelato-making with confidence.</p>
                    <div class="heading-24">Gelato Suppliers in Australia: Delicious Flavours</div>
                    <p>Looking to spice up your menu with a variety of irresistible gelato flavours? As leading
                        gelato
                        suppliers in Melbourne, GelCo offers an extensive selection of flavours that will keep your
                        customers coming back for more.</p>
                    <p>Bulk-order your favourites from options like watermelon, coconut, strawberry, mango,
                        chocolate
                        hazelnut, pineapple, banana, orange, coffee, and more. With our premium ingredients, there's
                        no
                        shortage of choices to spoil your customers.</p>
                </div>

                <div class="hm-item sticky">
                    <img src="assets/images/steel-icecream-machine.jpg" alt="steel icecream machine" width="720"
                        height="600">
                </div>
            </div>
        </div>
    </section>

    <?php block('pickupdeliverysupport'); ?>

    <!-- FAQ section start -->
    <section class="common-content-sec">
        <div class="page-width">

            <div class="flex-container wrap row-reverse mrgb80">
                <div class="hm-content">
                    <div class="heading-48">Frequently Asked Questions – Gelato Suppliers in Australia</div>


                    <div class="accordion_example1">

                        <div class="accordion_in acc_active">
                            <div class="acc_head">What sets GelCo apart from other gelato suppliers in Australia?
                            </div>
                            <div class="acc_content">
                                <p>GelCo stands out due to its commitment to providing high-quality commercial-grade
                                    gelato production equipment and premium ingredients. We offer comprehensive
                                    training
                                    for your team, expert maintenance services, and customisable solutions to meet
                                    the
                                    specific needs of your gelato business. Our objective is to ensure your success
                                    in
                                    producing delicious gelato that will delight your customers.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Do you provide support and training for new gelato businesses in
                                Melbourne?</div>
                            <div class="acc_content">
                                <p>Yes, as leading gelato suppliers in Melbourne, GelCo offers comprehensive
                                    training to
                                    ensure you and your team can master the art of gelato making. We provide
                                    guidance on
                                    using our advanced gelato equipment and creating unique flavours using our
                                    premium
                                    ingredients. Our training is designed to help your Melbourne-based gelato
                                    business
                                    thrive.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Can GelCo supply the equipment and ingredients needed for a
                                successful
                                gelato business in Sydney?</div>
                            <div class="acc_content">
                                <p>Absolutely. GelCo is your go-to gelato supplier in Sydney, offering a wide range
                                    of
                                    state-of-the-art gelato equipment and top-quality ingredients. Our
                                    commercial-grade
                                    machines, including batch freezers and soft serve machines, simplify the
                                    production
                                    process, while our premium bases and pastes allow you to create irresistible
                                    gelato
                                    flavours. We're dedicated to supporting your business's success in Sydney.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">How can GelCo help my gelato business in Brisbane achieve better
                                productivity?</div>
                            <div class="acc_content">
                                <p>As leading gelato suppliers in Brisbane, GelCo provides advanced gelato equipment
                                    designed for efficiency and consistent quality. Our batch freezers and other
                                    machines come with features like digital controls and self-adjusting scrapers to
                                    streamline production. Additionally, we offer expert maintenance services to
                                    ensure
                                    your equipment remains in peak condition, minimising downtime and boosting
                                    productivity.</p>
                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">What types of gelato bases and pastes are available from GelCo in
                                Australia?</div>
                            <div class="acc_content">
                                <p>GelCo offers a diverse selection of premium ingredients, including milk bases,
                                    fruit
                                    bases, yogurt bases, milk paste, fruit paste, and powdered options. These
                                    high-quality ingredients allow you to create a wide variety of flavours,
                                    ensuring
                                    your gelato is always fresh and exciting for your customers. By choosing GelCo
                                    as
                                    your gelato supplier in Australia, you gain access to the best ingredients to
                                    elevate your gelato creations.</p>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="hm-item sticky">
                    <img src="assets/images/different-icecreams.jpg" alt="" width="720" height="600">
                </div>
            </div>
        </div>
    </section>


    <?php block('proudlystocking-sec'); ?>
    <?php block('newsletter'); ?>

</main>
<?php get_footer();