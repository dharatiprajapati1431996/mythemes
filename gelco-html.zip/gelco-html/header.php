<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="assets/images/favicon.jpg" type="image/x-icon">

    <title>Gelato Suppliers Australia | Gelato Ingredients &amp; Equipment | GelCo</title>

    <?php wp_head(); ?>
</head>

<body>

    <!-- mobilecontrols div start -->
    <div class="mobilecontrols">
        <div class="button-group toprightbtndiv">
            <a href="" class="button">Contact Us</a>
            <a href="" class="button buttonpink">Request a Sample</a>
        </div>
    </div>
    <!-- shop slide div - move right left -->

    <!-- HEADER -->
    <header>

        <a class="togglebtn"><span></span></a>

        <div class="tophead_slide">
            <div class="desktopmsg">
                <p>Offering the highest quality gelato production equipment and ingredients <img
                        src="assets/images/tag-icon.svg" alt="" width="16" height="15"> 10% off your first order!”</p>
            </div>
            <marquee behavior="" direction="">
                <p>Offering the highest quality gelato production equipment and ingredients <img
                        src="assets/images/tag-icon.svg" alt="" width="16" height="15"> 10% off your first order!”</p>
            </marquee>
        </div>
        <div class="primeheader">
            <div class="page-width">

                <div class="search_box">
                    <div class="headsearch search-container section-header search_box" id="search_pop"
                        style="border:0px solid orange">
                        <predictive-search data-loading-text="Loading...">
                            <main-search>
                                <form action="/search" method="get" role="search" class="search"
                                    data-hs-cf-bound="true">
                                    <input type="hidden" name="type" value="product">
                                    <div class="field">
                                        <input class="search__input field__input" id="Search-In-Template" type="search"
                                            name="q" value="" placeholder="Search Products" role="combobox"
                                            aria-expanded="false" aria-owns="predictive-search-results"
                                            aria-controls="predictive-search-results" aria-haspopup="listbox"
                                            aria-autocomplete="list" autocorrect="off" autocomplete="off"
                                            autocapitalize="off" spellcheck="false" aria-activedescendant="">
                                        <label class="field__label" for="Search-In-Template">Search for
                                            products...</label>
                                        <input name="options[prefix]" type="hidden" value="last">
                                        <div class="predictive-search predictive-search--search-template" tabindex="-1"
                                            data-predictive-search="">
                                            <div class="predictive-search__loading-state">
                                                <svg aria-hidden="true" focusable="false" class="spinner"
                                                    viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                    <circle class="path" fill="none" stroke-width="6" cx="33" cy="33"
                                                        r="30"></circle>
                                                </svg>
                                            </div>
                                        </div>
                                        <span class="predictive-search-status visually-hidden" role="status"
                                            aria-hidden="true"></span><button type="reset"
                                            class="reset__button field__button hidden" aria-label="Clear search term">
                                            <svg class="icon icon-close" aria-hidden="true" focusable="false">
                                                <use xlink:href="#icon-reset"></use>
                                            </svg>
                                        </button>
                                        <button type="submit" class="search__button field__button" aria-label="Search">
                                            <img src="assets/images/search-icon.svg" alt="" width="17" height="17">
                                        </button>
                                    </div>
                                </form>
                            </main-search>
                        </predictive-search>
                    </div>
                    <!-- <a href="" class="user_icon icon_box hidden"> <img src="assets/images/svg/user.svg"
                                    width="17" height="20"> </a> -->
                    <div class="hidden head-search-show" style="border:0px solid blue">
                        <div class="mobile_e_commerce ">
                            <div class="search_box">
                                <details-modal class="header__search">
                                    <details>
                                        <summary
                                            class="header__icon header__icon--search header__icon--summary link focus-inset modal__toggle"
                                            aria-haspopup="dialog" aria-label="Search" role="button">
                                            <span>
                                                <img src="assets/images/icon/search-icon.svg" alt="" width="17"
                                                    height="17">
                                                <svg class="modal__toggle-close icon icon-close" aria-hidden="true"
                                                    focusable="false">
                                                    <use href="#icon-close"></use>
                                                </svg>
                                            </span>
                                        </summary>

                                        <div class="search-modal modal__content gradient" role="dialog"
                                            aria-modal="true" aria-label="Search">
                                            <div class="modal-overlay"></div>
                                            <div class="search-modal__content search-modal__content-bottom"
                                                tabindex="-1">
                                                <predictive-search class="search-modal__form"
                                                    data-loading-text="Loading...">
                                                    <form action="/search" method="get" role="search"
                                                        class="search search-modal__form">
                                                        <div class="field">
                                                            <input class="search__input field__input"
                                                                id="Search-In-Modal" type="search" name="q" value=""
                                                                placeholder="Search" role="combobox"
                                                                aria-expanded="false"
                                                                aria-owns="predictive-search-results"
                                                                aria-controls="predictive-search-results"
                                                                aria-haspopup="listbox" aria-autocomplete="list"
                                                                autocorrect="off" autocomplete="off"
                                                                autocapitalize="off" spellcheck="false"
                                                                aria-activedescendant="">
                                                            <label class="field__label"
                                                                for="Search-In-Modal">Search</label>
                                                            <input type="hidden" name="options[prefix]" value="last">
                                                            <button type="reset"
                                                                class="reset__button field__button hidden"
                                                                aria-label="Clear search term">
                                                                <svg class="icon icon-close" aria-hidden="true"
                                                                    focusable="false">
                                                                    <use xlink:href="#icon-reset">
                                                                    </use>
                                                                </svg>
                                                            </button>
                                                            <button class="search__button field__button"
                                                                aria-label="Search">
                                                                <img src="assets/images/icon/search-icon.svg"
                                                                    alt="search" title="search" width="17" height="17">

                                                                <svg class="icon icon-search" aria-hidden="true"
                                                                    focusable="false">
                                                                    <use href="#icon-search"></use>
                                                                </svg>
                                                            </button>
                                                        </div>

                                                        <div class="predictive-search predictive-search--header"
                                                            tabindex="-1" data-predictive-search="">
                                                            <div class="predictive-search__loading-state">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    class="spinner" viewBox="0 0 66 66"
                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                    <circle class="path" fill="none" stroke-width="6"
                                                                        cx="33" cy="33" r="30">
                                                                    </circle>
                                                                </svg>
                                                            </div>
                                                        </div>
                                                        <span class="predictive-search-status visually-hidden"
                                                            role="status" aria-hidden="true"></span>
                                                    </form>
                                                </predictive-search>

                                                <button type="button"
                                                    class="search-modal__close-button modal__close-button link link--text focus-inset"
                                                    aria-label="Close">
                                                    <img src="assets/images/icon/menu-close.png" class="icon icon-close"
                                                        alt="close" width="17" height="18">
                                                </button>
                                            </div>
                                        </div>
                                    </details>
                                </details-modal>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="head_logodiv">
                    <a href="home.php"><img src="assets/images/logo.svg" alt="Gelco" width="146" height="68"></a>
                </div>

                <div class="headerright">
                    <!-- shopify header links start -->
                    <div class="header__icons">

                        <a href="/account/login"
                            class="header__icon header__icon--account link focus-inset small-hide"><account-icon>
                                <img src="assets/images/head-user-icon.svg" alt="My account" title="" width="22"
                                    height="20">
                            </account-icon><span class="visually-hidden">Log in</span>
                        </a>
                        <a href="/cart" class="header__icon header__icon--cart link focus-inset" id="cart-icon-bubble">
                            <img src="assets/images/head-cart-icon.svg" alt="cart" title="cart" width="22" height="20">
                            <span class="visually-hidden">Cart</span></a>
                    </div>

                    <div class="button-group toprightbtndiv">
                        <a href="contact.php" class="button">Contact Us</a>
                        <a href="" class="button buttonpink">Request a Sample</a>
                    </div>
                </div>
            </div>
        </div>

        <nav>
            <div class="page-width">
                <div class="navheader">
                    <ul class="main-menu">
                        <li class="mobilehomelink mobilemenulogo">
                            <a href="home.php"><img src="assets/images/logo.svg" alt="Gelco" width="146"
                                    height="68"></a>
                        </li>
                        <li class="active"><a href="home.php">Home</a></li>
                        <li class=""><a href="#">Gelato Ingredients</a>
                            <div class="submenu shopmenu ingredientmenu">
                                <div class="menulinkbx">
                                    <ul class="nav-link">
                                        <li class="submenufirst"><a href="" class="">Powdered Bases</a></li>
                                        <li class=""><a href="" class="">Powdered Bases</a></li>
                                        <li class=""><a href="" class="">Milk Base</a></li>
                                        <li class=""><a href="" class="">Fruit Base</a></li>
                                        <li class=""><a href="" class="">Ready Powders</a></li>
                                        <li class=""><a href="" class="">Yogurt Base</a></li>
                                        <li class=""><a href="" class="">Soft Serve Base</a></li>
                                    </ul>
                                </div>
                                <div class="menulinkbx">
                                    <ul class="nav-link">
                                        <li class="submenufirst"><a href="" class="">Flavour Paste</a></li>
                                        <li class=""><a href="" class="">Flavour Paste</a></li>
                                        <li class=""><a href="" class="">Milk Paste</a></li>
                                        <li class=""><a href="" class="">Fruit Paste</a></li>
                                    </ul>
                                </div>
                                <div class="menuctabx">
                                    <img src="assets/images/menu-cta-bg.jpg" alt="Quality Ingredients & Equipment"
                                        width="372" height="270">
                                    <div class="ctasmalltxt">Quality Ingredients & Equipment</div>
                                    <div class="heading-28 ctatxt">Start Your Gelato Business with Australia’s Leading
                                        Suppliers
                                    </div>
                                    <div class="button-group">
                                        <a href="" class="button buttonpink">Shop Now</a>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class=""><a href="#">Equipment</a>
                            <div class="submenu shopmenu Equipmentmenu">
                                <div class="menulinkbx">
                                    <ul class="nav-link">
                                        <li class="submenufirst"><a href="" class="">Batch Freezers/Chruners</a></li>
                                        <li class=""><a href="" class="">Mechanical Controls</a></li>
                                        <li class=""><a href="" class="">Digital Controls</a></li>
                                    </ul>
                                </div>
                                <div class="menulinkbx">
                                    <ul class="nav-link">
                                        <li class="submenufirst"><a href="" class="">Combined Machines</a></li>
                                        <li class=""><a href="" class="">Digital Controls</a></li>
                                    </ul>
                                </div>
                                <div class="menulinkbx">
                                    <ul class="nav-link">
                                        <li class=""><a href="" class="">Pasteurisers</a></li>
                                        <li class=""><a href="" class="">Soft Serve Machines</a></li>
                                    </ul>
                                </div>

                            </div>
                        </li>

                        <li class=""><a href="#">Gelato Showcases</a>
                            <div class="submenu shopmenu showcasemenu">
                                <div class="menulinkbx">
                                    <ul class="nav-link">
                                        <li class=""><a href="" class="">Compact</a></li>
                                        <li class=""><a href="" class="">Traditional</a></li>
                                        <li class=""><a href="" class="">Pozzetti</a></li>
                                        <li class=""><a href="" class="">Storage Freezers/Display</a></li>
                                        <li class=""><a href="" class="">Blast Freezers</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>

                        <li><a href="">Clearance</a></li>
                        <li class=""><a href="courses.php">Cources</a></li>
                        <li class="mobileshow"><a href="contact.php">Contact</a></li>
                        <li class="mobileshow"><a href="">Terms of Services</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- /HEADER -->