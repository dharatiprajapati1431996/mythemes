<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>


<main class="courses-page">
    <div class="overlay" style=""></div>

    <section class="inner-banner">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Courses</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>

    <!-- content section start -->
    <section class="common-content-sec inpg">
        <div class="page-width">

            <div class="flex-container wrap mrgb80">
                <div class="flex-container wrap row-reverse mrgb80">
                    <div class="hm-content">
                        <div class="heading-48">Traditional Italian Gelato <img src="assets/images/pinklines-invert.svg"
                                alt="" width="54" height="54" class="heartbeat onright"></div>
                        <div class="heading-30">Courses in collaboration with White Art Culinary School</div>
                        <p>The Traditional Gelato course is designed for aspiring Gelato/Ice cream makers, for those who
                            aspire to a new profession or for those who want to enter the world of Gelato as an
                            entrepreneur.</p>
                        <p>Also, we offer TARGETED COURSES FOR PROFESSIONALS like: Experimental Gelato which consists of
                            customized solutions on completely natural base Gelato and Sorbets.</p>
                        <p>By participating in ours courses, you will assimilate the notions for producing your own
                            Artisanal Italian Gelato. Specific course for Premium Artisanal Ice cream can be offered.
                        </p>
                        <p>You will learn the organization of the laboratory to the choice of raw materials. We will
                            teach you how to use your vision of taste and your imagination for Gelato and Sorbet.</p>

                    </div>

                    <div class="hm-item sticky white-img">
                        <img src="assets/images/white-art-school.jpg" alt="white Art School" width="720" height="600">
                    </div>
                </div>
                <div class="hm-content">
                    <div class="heading-30">Introducing Luigi De Luca</div>
                    <p>The Course Professional.</p>

                    <p>The De Luca family has a broad background in the culinary industry – especially Gelato. Salvatore
                        De Luca passionately travelled the Messina streets in a 3-wheeled Ape in the 1940’s – serving
                        joy to the locals in the form of Gelato.</p>

                    <p>Son, Luigi soon followed in his footsteps, starting a Gelateria in Sardinia. The quality of the
                        Gelateria sparked interest for consultation with Gelato brands in Australia. This led to the De
                        Luca family leaving in 1994, bringing the passion and knowledge for Quality Gelato to Australia.
                    </p>

                    <p>Luigi has since been a part of many Artisanal Gelaterie, with his own store La Cremeria
                        (Leichardt). He later assisted his children Sal and Virginia in opening and running Cremerie De
                        Luca (Five dock) as well as providing professional advice and consulting for many other
                        successful Gelateria’s.</p>
                    <p>Luigi’s extensive knowledge and experience will guide you in creating exceptional gelato and
                        sorbet whilst keeping to the traditional use of natural ingredients and methods yet exploring
                        them with a contemporary approach.</p>

                </div>

                <div class="hm-item sticky">
                    <img src="assets/images/professional-course.jpg" alt="Professional Course " width="720"
                        height="600">
                </div>
            </div>

        </div>
    </section>


    <section class="courses-plan-sec py-80">
        <div class="page-width">
            <div class="flex-container wrap items-center">
                <div class="plan-left">
                    <div class="heading-30">What's the plan? <img src="assets/images/pinklines-invert.svg" alt=""
                            width="54" height="54" class="heartbeat onright"></div>
                    <p class="semibold">Simple! Choose between the two options below: Training</p>

                    <p>This fully interactive course is aimed at those who want to undertaking a qualified craft work
                        and learning the different between Gelato, Vegan Gelato, Ice cream and Sorbets ingredients and
                        techniques.</p>
                    <p>The training aims to convey the essential notions.</p>
                    <p class="uppercase">Full Assistance Online Or One-to-one To Our Students After The Course (Fee
                        Apply)</p>
                </div>
                <div class="plan-right">
                    <div class="courses-box">
                        <p class="semibold">The course program is structured as follows:</p>
                        <ul class="ul-line">
                            <li>What is Traditional Artisan Italian Gelato</li>
                            <li>What are the ingredients to make an excellent Gelato</li>
                            <li>How to choose the raw materials and ingredients to produce health and fresh Italian
                                Gelato</li>
                            <li>How to build a recipe.</li>
                            <li>Milk based Gelato</li>
                            <li>Alternative milk-based (Vegan Gelato)</li>
                            <li>Fruit-based Sorbets;</li>
                            <li>Study of sugars (3 of the kind)</li>
                            <li>Low grams use (natural stabilizers)</li>
                            <li>Selection, operation and use of equipment</li>
                            <li>Production management</li>
                            <li>Hygiene</li>
                            <li>Cleaning and sanitising of tools.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="common-content-sec inpg checked-ul semibold-ul">
        <div class="page-width">

            <div class="flex-container wrap row-reverse">
                <div class="hm-content">
                    <div class="accordion_example1">
                        <div class="accordion_in acc_active">
                            <div class="acc_head">Training option 1</div>
                            <div class="acc_content">
                                <p>Full interaction of <span class="semibold">12 hours</span> of Laboratory in <span
                                        class="semibold">2 days</span> from <span class="semibold">10am to 4pm</span>
                                </p>

                                <div class="heading-20">Production techniques:</div>
                                <ul>
                                    <li>Mixing/measuring</li>
                                    <li>Pasteurization (with and without the pasteurizer)</li>
                                    <li>Homogenization (with the pasteurizer)</li>
                                    <li>Cooling down, maturation</li>
                                    <li>Freezing/batch freezing</li>
                                    <li>Forming/presentation on tray or "pozzetto"</li>
                                    <li>Hardening/storage</li>
                                </ul>

                                <div class="heading-20">Price: $ 1320,00</div>

                                <p class="italic">(we also suggest to bring your selected ingredients (fruit, nuts,
                                    citrus, herbs, vegetable, spices to build your own taste)</p>

                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Training option 2</div>
                            <div class="acc_content">
                                <p>Full interaction of <span class="semibold">6 hours</span> of Laboratory in <span
                                        class="semibold">1 day</span> from <span class="semibold">10am to 4pm</span></p>

                                <div class="heading-20">Production techniques:</div>
                                <ul>
                                    <li>Mixing/measuring</li>
                                    <li>Pasteurization (without the pasteurizer),</li>
                                    <li>Homogenization (only with a hand blender),</li>
                                    <li>Cooling down, maturation,</li>
                                    <li>Freezing/batch freezing</li>
                                    <li>Forming/presentation on tray</li>
                                    <li>Hardening/storage</li>
                                </ul>

                                <div class="heading-20">Price: $ 720,00</div>

                                <p class="italic">(we also suggest to bring your selected ingredients (fruit, nuts,
                                    citrus, herbs, vegetable, spices to build your own taste)</p>

                            </div>
                        </div>

                        <div class="accordion_in">
                            <div class="acc_head">Important Information</div>
                            <div class="acc_content">
                                <div class="heading-20">Very important notes for participants:</div>

                                <p>For this specific basic/professional course (fully interactive – hands on), we
                                    suggest you take note of the recipes we will create with your favourite ingredients
                                    and production methods. This will help you create your own personalized booklet with
                                    all your secrets and production steps. This method, which Luigi De Luca introduced
                                    in Italy several years ago, has given to his students greater confidence and today
                                    they are professionals without limits.</p>

                                <div class="heading-20">Certificate of Attendance</div>

                                <p>At the end of the course a certificate of attendance will be issued certifying
                                    participation in an intensive training on the “Traditional Italian Gelato”. The
                                    certificate is private and does not authorize the use of the WHITE ART trademark.
                                </p>

                                <p>Participants: Min 4 - Max 8</p>
                                <p>Uniform supplied: White Art uniform set</p>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="hm-item sticky">
                    <img src="assets/images/laboratory-training.jpg" alt="laboratory training" width="720" height="600">
                </div>
            </div>
        </div>
    </section>


    <section class="join-class-sec inpg">
        <div class="page-width">
            <div class="center-inro text-center">
                <div class="heading-30">Ready to Join a class?</div>
                <p>Select the class that suits you best</p>
            </div>

            <div class="course-plan-wrap">
                <a href="" class="course-item course-day-1">
                    <div class="item-img">
                        <img src="assets/images/day2.png" alt="day2" width="" height="">
                    </div>
                    <div class="course-info">
                        <div class="semi-head">GelCo</div>
                        <div class="heading-16">Traditional Italian Gelato Course - 2 Days</div>
                        <div class="price">$1,320.00</div>
                    </div>
                </a>
                <a href="" class="course-item course-day-2">
                    <div class="item-img">
                        <img src="assets/images/day1.png" alt="day1" width="" height="">
                    </div>
                    <div class="course-info">
                        <div class="semi-head">GelCo</div>
                        <div class="heading-16">Traditional Italian Gelato Course - 1 Day</div>
                        <div class="price">$720.00</div>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <?php block('newsletter'); ?>

</main>
<?php get_footer();