$(document).ready(function () {
  $(".slider").slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    speed: 500,
    autoplaySpeed: 5000,
    infinite: true,
    autoplay: true,
    centerMode: true,
    arrows: true,
    centerPadding: "200px",
    prevArrow:
      '<button class="slide-arrow prev-arrow slick-prev"><img src="assets/images/icon/arrow-prev.svg" alt="btn-arrow" width="14" height="11"></button>',
    nextArrow:
      '<button class="slide-arrow next-arrow slick-next"><img src="assets/images/icon/arrow-next.svg" alt="btn-arrow" width="14" height="11"></button>',
    responsive: [
      {
        breakpoint:1440,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
           centerPadding: "100px",
        },
      },
      {
        breakpoint:1200,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
            centerPadding: "50px",
        },
      },
     {
        breakpoint:769,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
            centerPadding: "50px",
        },
      },  
        {
        breakpoint:577,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
            centerPadding: "40px",
        },
      },
         {
        breakpoint:421,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
            centerPadding: "20px",
        },
      },
    ],
  });
});
