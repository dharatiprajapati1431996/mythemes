jQuery(document).ready(function ($) {

    /* home page banner slider*/
    $(".homebannerslider").slick({
        dots: true,
        infinite: true,
        arrows: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
    });


// Our partner slider
$('.logoslider').slick({
    dots: false,
    infinite: true,
    arrows: false,
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,		
    responsive: [
        {
            breakpoint: 1440,
            settings: {
                slidesToShow: 5,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 992,
            settings: {
                rows: 1,
                slidesToShow: 4,
                slidesToScroll: 1,
            }
        },
        {
            breakpoint: 768,
            settings: {
                rows: 1,
                slidesToShow: 3,
                slidesToScroll: 1,
            }
        },
        {
            breakpoint: 576,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                rows: 1,
            }
        },
        {
            breakpoint: 360,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                rows: 1,
                centerMode: true,
                centerPadding: '20px',
            }
        }
    ]
});


 //feature product slider 
 $(".related-js").slick({
    dots: false,
    infinite: true,
    arrows: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 5000,        
    responsive: [
        {
            breakpoint: 1440,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
            },
        },        
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
            },
        }
    ],
});

  // for feature product tabs
  $(".tab-nav span").on("click", function () {
    $([$(this).parent()[0], $($(this).data("href"))[0]])
      .addClass("active")
      .siblings(".active")
      .removeClass("active");
    $(".tab .related-js").slick("refresh");
  });


});