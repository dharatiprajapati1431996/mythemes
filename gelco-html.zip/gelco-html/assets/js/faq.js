// content faq script
$(".accordion_example1").smk_Accordion({
    showIcon: true, //boolean
    animation: true, //boolean
    closeAble: false, //boolean
    slideSpeed: 200 //integer, miliseconds
});
