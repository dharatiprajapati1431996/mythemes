$(document).ready(function () {
  /*Scroll top*/
  var scrollTop = $(".scrollTop");
  $(window).scroll(function () {
    var topPos = $(this).scrollTop();
    if (topPos > 0) {
      $(scrollTop).css("opacity", "1", "transform", "scale(1)");
      $(".scrollTop").addClass("vis");
    } else {
      $(scrollTop).css("opacity", "0", "transform", "scale(0)");
      $(".scrollTop").removeClass("vis");
    }
  });
  $(scrollTop).click(function () {
    $("html, body").animate(
      {
        scrollTop: 0,
      },
      600
    );
    return false;
  });

  /*Menu dropdown*/
  var ico = $('<i class="fa fa-angle-down menudrop"></i>');
  $(
    ".main-menu > li:has(.submenu) > a,.nav-menu-wrapper ul li:has(.submenu) > a"
  ).append(ico);
  $(".menudrop").on("click", function (e) {
    $(this).parent().parent().addClass("no-hover");

    $(".main-menu li,.nav-menu-wrapper ul li")
      .not($(this).parent().parent())
      .find(".submenu")
      .stop(true, true)
      .delay(200)
      .fadeOut(500);
    $(".main-menu li,.nav-menu-wrapper ul li")
      .not($(this).parent().parent())
      .removeClass("open");
    $(".main-menu li a .menudrop,.nav-menu-wrapper ul li a .menudrop")
      .not($(this))
      .removeClass("openedmenu");
    $(".main-menu li a .menudrop,.nav-menu-wrapper ul li a .menudrop")
      .not($(this))
      .addClass("closemenu");

    e.preventDefault();
    if ($(this).hasClass("openedmenu")) {
      $(this)
        .parent()
        .parent()
        .find(".submenu")
        .stop(true, true)
        .delay(200)
        .fadeOut(500);
      $(this).removeClass("openedmenu");
      $(this).addClass("closemenu");
    } else {
      $(this)
        .parent()
        .parent()
        .find(".submenu")
        .stop(true, true)
        .delay(200)
        .fadeIn(500);
      $(this).removeClass("closemenu");
      $(this).addClass("openedmenu");
    }
  });

  $(".togglebtn, .overlay").click(function () {
    $(".togglebtn, .overlay, .main-menu").toggleClass("active");
    if ($(".overlay").hasClass("active")) {
      $(".overlay").fadeIn();
      $("html").addClass("menuhidden");
    } else {
      $(".overlay").fadeOut();
      $("html").removeClass("menuhidden");
    }
  });
  if ($(window).width() >= 1120) {
    $(".nav-menu-links li.has-sub").hover(
      function () {
        $("body").addClass("menuoverlay");
        $(window).trigger("resize");
      },
      function () {
        $("body").removeClass("menuoverlay");
      }
    );
  }
  $(window).scroll(function () {
    if ($(window).scrollTop() > 130 && $(window).width() >= 300) {
      $("body").addClass("fixed-header");
    } else {
      $("body").removeClass("fixed-header");
    }
  });


// /*mobile slider */
// $('.headslider').slick({
//       slidesToShow: 6,
//       slidesToScroll: 1,
//       arrows: false,
//     autoplay: true,
//     autoplaySpeed: 0,
//     speed: 8000,
//     pauseOnHover: true,
//     cssEase: 'linear',
//     variableWidth: true
// });


 //scrolling text slider 
 $('.scrollingtxt').slick({
  arrow: false,
  dots: false,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 0,
  speed: 80000,
  variableWidth: true,
  pauseOnHover: false,
  cssEase: 'linear',
  responsive: [
      {
          breakpoint: 1440,
          settings: {
              // slidesToShow: 1,
              // slidesToScroll: 1,
              speed: 100000,
          }
      },
      {
          breakpoint: 768,
          settings: {
              // slidesToShow: 1,
              // slidesToScroll: 1
              speed: 100000,
          }
      }
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
  ]
});


// shop menu button and slide menu
// jQuery("button.shop_slide_toggle").click(function(){
//   jQuery('body').toggleClass('shopslide');
// });

// jQuery(".shopslidebox a.closemenu, .menuoverlay").click(function(){
//   jQuery('body').removeClass('shopslide');
// });

  /*-----MOBILE FOOTER LINKS-----*/
  $(".fttitle").click(function () {
    if ($(window).width() < 576) {
      $(this).toggleClass("linkopen");
      $(this).next('ul').stop().slideToggle();
      $(this).next('.divshowhide').stop().slideToggle();
    }
  });


});