jQuery(document).ready(function ($) {
	$('.wave_sliderreverse').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		autoplay: true,
		arrows: false,
		autoplaySpeed: 0,
		speed: 60000,
		pauseOnHover: false,
		cssEase: 'linear',
		rtl:true,
		responsive: [			
			{
			  breakpoint: 575,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				speed: 30000,
			  }
			},
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	});
   
});