$(document).ready(function () {

     // PRODUCT detail Slider

       $('.slider-product').slick({
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: false,
          fade: false,
          infinite: false,
          speed: 1000,
          asNavFor: '.slider-thumb',
        });
        $('.slider-thumb').slick({
          slidesToShow: 5,
          slidesToScroll: 1,
          asNavFor: '.slider-product',
          dots: false,
          arrows: true,
          centerMode: false,
          infinite: false,
          focusOnSelect: true,
          responsive: [
              {
                breakpoint: 1440,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1,
                },
              },
              {
                breakpoint: 1200,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1,
                },
              },
              {
                breakpoint: 481,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1,
                },
              }
            ],


        });

        //related product slider 
        $(".related-js").slick({
            dots: false,
            infinite: true,
            arrows: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            autoplay: false,
            autoplaySpeed: 5000,        
            responsive: [
                {
                    breakpoint: 1440,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                    },
                },        
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    },
                }
            ],
      });


    });

    /*Increment input*/
    function increaseValue(ele) {
        console.log(ele.parent().find('input[type="number"]').val());
        var value = ele.parent().find('input[type="number"]').val();
        // var value = parseInt(inputele.value, 10);
        value = isNaN(value) ? 0 : value;
        value++;
        ele.parent().find('input[type="number"]').val(value);
        if (value == 0) {
            ele.parents('.roomlistbox').removeClass('selectedinput');
            if ($('.quantity').length > 0) {
                ele.parents('.quantity').parent().prev().parent().removeClass('selectedinput');
            }
        } else {
            ele.parents('.roomlistbox').addClass('selectedinput');
            if ($('.quantity').length > 0) {
                ele.parents('.quantity').parent().prev().parent().addClass('selectedinput');
            }
        }
    }

    function decreaseValue(ele) {
        var value = ele.parent().find('input[type="number"]').val();
        //    var value = parseInt(inputele.value, 10);
        value = isNaN(value) ? 0 : value;
        value < 1 ? value = 1 : '';
        value--;
        ele.parent().find('input[type="number"]').val(value);
        if (value == 0) {
            ele.parents('.roomlistbox').removeClass('selectedinput');
            if ($('.quantity').length > 0) {
                ele.parents('.quantity').parent().prev().parent().removeClass('selectedinput');
            }
        } else {
            ele.parents('.roomlistbox').addClass('selectedinput');
            if ($('.quantity').length > 0) {
                ele.parents('.quantity').parent().prev().parent().addClass('selectedinput');
            }
        }
    }

    