<?php

$GLOBALS['assets'] = [

    'common' => [
        'styles' => [

            'assets/shopify/css/variable',
            'reset',
            'normalize',
            'utility',
            'font-awesome.min',
            'slick.min',
            'slick-theme.min',
            //'jquery.selectBoxIt',

            'assets/shopify/css/base',
            'assets/shopify/css/component-card',
            'assets/shopify/css/component-cart',
            'assets/shopify/css/component-cart-items',
            'assets/shopify/css/component-facets',
            'assets/shopify/css/component-pagination',
            'assets/shopify/css/component-predictive-search',
            'assets/shopify/css/component-price',
            'assets/shopify/css/component-rating',
            'assets/shopify/css/component-search',
            'assets/shopify/css/customer',
            'assets/shopify/css/quick-add',
            'assets/shopify/css/section-main-product',
            'assets/shopify/css/template-collection',

            'header',
            'common',
        ],
        'scripts' => ['jquery-3.7.1.min', 'slick.min', 'script' , 'wave-effect'],
    ],

    'home' => [
        'styles' => ['smk-accordion', 'jquery.fancybox', 'client-review', 'home'],
        'scripts' => ['smk-accordion', 'jquery.fancybox.min', 'client-review', 'faq', 'home'],
    ],
    'about' => [
        'styles' => ['about', 'client-review'],
        'scripts' => ['client-review'],
    ],
    'courses' => [
        'styles' => ['courses', 'smk-accordion'],
        'scripts' => ['smk-accordion', 'faq'],
    ],
    'courses-detail' => [
        'styles' => ['product-detail'],
        'scripts' => ['product-detail'],
    ],
    'product-listing' => [
        'styles' => ['product-listing', 'smk-accordion'],
        'scripts' => ['smk-accordion', 'faq', 'home'],
    ],
    'product-detail' => [
        'styles' => ['product-detail', 'smk-accordion'],
        'scripts' => ['smk-accordion', 'faq', 'product-detail'  , 'home'],
    ],
    'contact' => [
        'styles' => ['contact'],
        'scripts' => ['home'],
    ],



    // 'html-tags-reset' => [
    //     'styles' => ['reset'],
    // ],
    // 'html-tags-normal' => [
    //     'styles' => ['reset', 'variables', 'normalize', 'utiliti'],
    // ],
    // 'html-tags' => [
    //     'styles' => ['reset', 'normalize', 'utiliti', 'style'],
    // ],
];