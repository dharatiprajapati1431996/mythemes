<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>


<main class="courses-detail-page">
    <div class="overlay" style=""></div>

    <section class="inner-banner">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Gelato Ingredients</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>

    <!-- content section start -->
    <section class="detail-pages inpg">
        <div class="page-width">
            <div class="flex-container wrap items-start mrgb80">
                <div class="prod-left sticky">

                    <!-- <div class="summary-mobile-title-wrap">
                        <div class="summary-title">
                            <div class="heading-36">PVC Super Tuff Dog Leads</div>
                             <span class="onsale">10%</span>
                            
                                <div class="sku-wrap">
                                    <div class="star-rating" role="img" aria-label="">
                                        <div class="star-rating" role="img" aria-label="Rated 5 out of 5">
                                            <span style="width:100%">Rated<strong class="rating">5</strong> out of 5</span>
                                        </div>(1)
                                    </div>  
                                    <a href="#" class="sku-text">Write a Review</a>
                                </div>
                        </div>

                        <div class="price-wrap">
                            <span class="price"><del aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>76.40</bdi></span></del> <span class="screen-reader-text">Original price was: 76.40</span><ins aria-hidden="true"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">$</span>66.40</bdi></span></ins><span class="screen-reader-text">Current price is: $66.40</span></span>
                        </div>
                    </div> -->


                    <div class="product-prod-detail">
                        <div class="product-inner">
                        <div class="zoom-icon">
                            <img src="assets/images/zoom-pan.svg" alt="zoom-icon" title="" width="46" height="46">
                        </div>


                            
                           <div class="slider-wrapper">

                                <div class="slider slider-product">
                                    <div class="slider-banner-image">
                                        <img src="assets/images/courses-day1.jpg" alt="Traditional Italian Gelato Course" title="" width="750" height="670">
                                    </div>
                                    <div class="slider-banner-image">
                                        <img src="assets/images/courses-day1.jpg" alt="Traditional Italian Gelato Course" title="" width="750" height="670">
                                    </div>
                                </div>

                                <div class="slider slider-thumb slick-arrow">
                                    <div class="thumnail-img">
                                        <img src="assets/images/courses-day1.jpg" alt="Traditional Italian Gelato Course" title="" width="" height="">
                                    </div>
                                    <div class="thumnail-img">
                                        <img src="assets/images/courses-day1.jpg" alt="Traditional Italian Gelato Course" title="" width="" height="">
                                    </div>

                                </div>
                           </div>

                        </div>
                    </div>

                </div>
                <div class="prod-right">  
                    <div class="summary entry-summary">
                        <div class="sum_column">
                            <div class="heading-48">Traditional Italian Gelato Course - 1 Day</div>
                        </div>

                        <div class="flex_wrap price_box">
                            <div class="price price--large price--show-badge">
                                <div class="price__container">
                                    <div class="price__regular">
                                        <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                        <span class="price-item price-item--regular">
                                            $720.00
                                        </span>
                                    </div>
                                    <div class="price__sale">
                                        <span class="visually-hidden visually-hidden--inline">Regular price</span>
                                        <span><s class="price-item price-item--regular"></s></span>
                                        <span class="visually-hidden visually-hidden--inline">Sale price</span>
                                        <span class="price-item price-item--sale price-item--last">$720.00 </span>
                                    </div>
                                    <small class="unit-price caption hidden">
                                        <span class="visually-hidden">Unit price</span>
                                        <span class="price-item price-item--last">
                                            <span></span>
                                            <span aria-hidden="true">/</span>
                                            <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                            <span>
                                            </span>
                                        </span>
                                    </small>
                                </div>
                                <span class="badge price__badge-sale color-accent-2">Sale</span>
                                <span class="stock_info in-stock">In Stock</span>
                            </div>
                        </div>


                        <div class="head-xs bold">Product Info</div>
                        <p>Full interaction of 6 hours of Laboratory in 1 day from 10am to 4pm</p>

                        <div class="head-xs bold">Production techniques:</div>

                        <ul class="ul-line">
                            <li>Mixing/measuring</li>
                            <li>Pasteurization (without the pasteurizer),</li>
                            <li>Homogenization (only with a hand blender),</li>
                            <li>Cooling down, maturation,</li>
                            <li>Freezing/batch freezing</li>
                            <li>Forming/presentation on tray</li>
                            <li>Hardening/storage</li>
                        </ul>




                        <div class="product-form__input product-form__quantity">
                            <label class="quantity__label form__label" for="">Quantity</label>
                            <quantity-input class="quantity">
                                <button class="quantity__button no-js-hidden" onclick="decreaseValue($(this))"
                                    value="Decrease Value" id="decrease" name="minus" type="button">
                                    <img src="assets/images/minus.png" alt="Remove" title="" width="14" height="14">
                                </button>

                                <input class="quantity__input" type="number" name="quantity"
                                    id="Quantity-template--14238873944153__main" min="1" value="1"
                                    form="product-form-template--14238873944153__main">

                                <button class="quantity__button no-js-hidden" id="increase"
                                    onclick="increaseValue($(this))" value="Increase Value" name="plus" type="button">
                                    <img src="assets/images/plus.png" alt="plus" title="" width="14" height="14">
                                </button>
                            </quantity-input>
                        </div>


                        <div class="product-add-cart-wrap">
                            <button type="submit" name="add"
                                class="product-form__submit button button--full-width button--secondary">
                                <img src="assets/images/cart.svg" alt="cart" title="" width="19" height="15">
                                <span>Add to cart</span>

                                <div class="loading__spinner hidden">
                                    <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30">
                                        </circle>
                                    </svg>
                                </div>
                            </button>
                            <button class="buy-button"><img src="assets/images/buy-button.png" alt="buy-button"
                                    width="280" height="81"> </button>
                        </div>

                    </div>
                </div>
            </div>


            <?php block('pickupdeliverysupport'); ?>



            <div class="related-prod-wrap">
                   <div class="heading-48 text-center">Related Products</div>

                    <ul id="product-grid" class="grid product-grid grid--2-col-tablet-down grid--4-col-desktop related-js">
                        <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/ananas-pineapple.png" alt="Ananas (Pineapple)"
                                                        class="motion-reduce" width="297" height="297">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Ananas (Pineapple)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                   <!--  <div class="head-xs">Aromitalia</div> -->
                                                </div>

                                                <div class="card-information">
                                                    <span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $79.00 - $155.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular">



                                                                    </s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $79.00 - $155.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit"
                                                        class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19"
                                                            height="15">
                                                        <span>Add to cart</span>

                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="card__badge bottom left"></div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class=" card card--standard card--media ">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__badge bottom left">
                                                <span class="badge badge--top-left">exclusive</span>
                                            </div>

                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/watermelon.png" alt="watermelon"
                                                        class="motion-reduce" width="" height="">
                                                </div>
                                            </div>

                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5"
                                                    id="title-template--15968257671257__product-grid-6920733229145">
                                                    <a href="#"
                                                        id="CardLink-template--15968257671257__product-grid-6920733229145"
                                                        class="full-unstyled-link">
                                                       <span class="category-heading">Aromitalia</span>

                                                       <span class="prod-heading">Anguria (Watermelon)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>


                                                <div class="card-information">
                                                    <span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $79.00 - 155.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $79.00 - 155.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>
                                                    <button type="submit"
                                                        class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19"
                                                            height="15">
                                                        <span>Add to cart</span>

                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>


                                            <div class="card__badge bottom left"></div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper lightgray-gradient">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__badge bottom left">
                                                <span class="badge badge--top-left onsale">New</span>
                                            </div>
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">

                                                    <img src="assets/images/orange.png" sizes=""
                                                        alt="Arancia (Orange)" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5"
                                                    id="title-template--15968257671257__product-grid-6920734441561">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Arancia (Orange)</span>
                                                    </a>
                                                </h3>


                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $79.00 - $155.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    From $79.00 - $155.00</span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>


                                            <div class="card__badge bottom left"></div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper light-red-gradient">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">

                                                    <img src="assets/images/banana.png" sizes="" alt="Banana"
                                                        class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Banana</span>
                                                    </a>
                                                </h3>


                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $77.00 - $150.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular">



                                                                    </s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $77.00 - $150.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>


                                            <div class="card__badge bottom left"></div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper yellow-gradient">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__badge bottom left">
                                                <span class="badge badge--top-left onsale">New</span>
                                            </div>
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/vegan-base.png" sizes="" alt="Base Vegan F (Vegan Base)"
                                                        class="motion-reduce" width="290" height="296">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>

                                                        <span class="prod-heading">Base Vegan F (Vegan Base)</span>
                                                    </a>
                                                </h3>


                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $44.00 - $500.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $44.00 - $500.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>


                                            <div class="card__badge bottom left"></div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/bubblegum-blue.png" sizes="" alt="Bubblegum Blue"
                                                        class="motion-reduce" width="281" height="297">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Bubblegum Blue</span>
                                                    </a>
                                                </h3>


                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $92.00 - 190.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $92.00 - 190.00</span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>


                                            <div class="card__badge bottom left"></div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/coffee.png" sizes="" alt="CAFFÈ (COFFEE)"
                                                        class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Caffè (Coffee)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $145.00 - $285.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $145.00 - $285.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">

                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/caramel.png" sizes="" alt="Caramel"
                                                        class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Caramel</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                 
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $78.00 - $150.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $78.00 - $150.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper ice-cold-gradient">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/white-chocolate.png" sizes="" alt="Cioccolato Bianco(White Chocolate)" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Cioccolato Bianco(White Chocolate)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                   
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $108.00 - $215.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $108.00 - $215.00</span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/classic-hazelnut.png" sizes="" alt="Classic Hazelnut"
                                                        class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Classic Hazelnut</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $255.00 - $500.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $255.00 - $500.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>


                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/coconut.png" sizes="" alt="Cocco (Coconut)" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Cocco (Coconut)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $77.00 - $150.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $255.00 - $500.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>


                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/fruit-base-50.png" sizes="" alt="Dbf Master 50 Classic Tuttovegetale (Fruit Base 50)" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>

                                                        <span class="prod-heading">Dbf Master 50 Classic Tuttovegetale (Fruit Base 50)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $62.00 - $475.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $62.00 - $475.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/milk-base-50.png" sizes="" alt="Milk Base 50" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Milk Base 50</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $58.00 - $455.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $58.00 - $455.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/milk-base-100.png" sizes="" alt="Dpo Super 100 C Classic Neutra Sgi # (Milk Base (100)" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>

                                                        <span class="prod-heading">Dpo Super 100 C Classic Neutra Sgi # (Milk Base (100)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $60.00 - $465.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $60.00 - $465.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/strawberry.png" sizes="" alt="Fragola (Strawberry)" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>
                                                        <span class="prod-heading">Fragola (Strawberry)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $84.00 - $165.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $84.00 - $165.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="grid__item scroll-trigger animate--slide-in">
                                <div class="card-wrapper product-card-wrapper">
                                    <div class="card card--standard card--media">
                                        <div class="card__inner color-background-2 ratio">
                                            
                                            <div class="card__media">
                                                <div class="media media--transparent media--hover-effect">
                                                    <img src="assets/images/with-seeds.png" sizes="" alt="French Vanilla (With Seeds)" class="motion-reduce" width="" height="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card__content">
                                            <div class="card__information">
                                                <h3 class="card__heading h5">
                                                    <a href="#" class="full-unstyled-link">
                                                        <span class="category-heading">Aromitalia</span>

                                                        <span class="prod-heading">French Vanilla (With Seeds)</span>
                                                    </a>
                                                </h3>

                                                <div class="card-info">
                                                    
                                                </div>

                                                <div class="card-information"><span class="caption-large light"></span>
                                                    <div class="price ">
                                                        <div class="price__container">
                                                            <div class="price__regular"><span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span class="price-item price-item--regular">
                                                                    From $90.00 - $175.00
                                                                </span>
                                                            </div>
                                                            <div class="price__sale">
                                                                <span
                                                                    class="visually-hidden visually-hidden--inline">Regular
                                                                    price</span>
                                                                <span>
                                                                    <s class="price-item price-item--regular"></s>
                                                                </span><span
                                                                    class="visually-hidden visually-hidden--inline">Sale
                                                                    price</span>
                                                                <span class="price-item price-item--sale price-item--last">
                                                                    From
                                                                    $90.00 - $175.00 </span>
                                                            </div>
                                                            <small class="unit-price caption hidden">
                                                                <span class="visually-hidden">Unit price</span>
                                                                <span class="price-item price-item--last">
                                                                    <span></span>
                                                                    <span aria-hidden="true">/</span>
                                                                    <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                                    <span>
                                                                    </span>
                                                                </span>
                                                            </small>
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="product-form__submit button button--full-width button--secondary">
                                                        <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
                                                        <span>Add to cart</span>
                                                        <div class="loading__spinner hidden">
                                                            <svg aria-hidden="true" focusable="false" class="spinner"
                                                                viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                                <circle class="path" fill="none" stroke-width="6" cx="33"
                                                                    cy="33" r="30"></circle>
                                                            </svg>
                                                        </div>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                    </ul>
            </div>

        </div>
    </section> 



    <?php block('newsletter'); ?>

</main>
<?php get_footer();