<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>


<main class="product-listing-page">
    <div class="overlay" style=""></div>

    <section class="inner-banner">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Search Template</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>


    <section class="inpg product-wrapper">
        <div class="page-width">

          <div class="search-template-wrap template-search__header">
            <div class="heading-48 text-center">Search results</div>

            
            <div class="template-search__search">
              <predictive-search data-loading-text="Loading...">
                <main-search>
                    <form action="/search" method="get" role="search" class="search">
                      <div class="field">
                          <input class="search__input field__input" id="Search-In-Template" type="search" name="q" value="bag" placeholder="Search" role="combobox" aria-expanded="false" aria-owns="predictive-search-results" aria-controls="predictive-search-results" aria-haspopup="listbox" aria-autocomplete="list" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false">
                          <label class="field__label" for="Search-In-Template">Search</label>
                          <input name="options[prefix]" type="hidden" value="last">

                          <div class="predictive-search predictive-search--search-template" tabindex="-1" data-predictive-search="">
                              <div class="predictive-search__loading-state">
                                  <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle></svg>
                              </div>
                          </div>

                          <span class="predictive-search-status visually-hidden" role="status" aria-hidden="true"></span><button type="reset" class="reset__button field__button" aria-label="Clear search term">
                          <svg class="icon icon-close" aria-hidden="true" focusable="false">
                            <use xlink:href="#icon-reset">
                          </use></svg>
                        </button>
                        <button type="submit" class="search__button field__button" aria-label="Search">
                          <svg class="icon icon-search" aria-hidden="true" focusable="false">
                            <use xlink:href="#icon-search">
                          </use></svg>
                        </button>
                      </div>
                    </form>
                </main-search>
              </predictive-search>
            </div>
          </div>



          
            <!--  START FILTER -->
			<div class="facets-container scroll-trigger animate--fade-in">
				<facet-filters-form class="facets small-hide">
			      	<form id="FacetFiltersForm" class="facets__form">
          				<div id="FacetsWrapperDesktop" class="facets__wrapper">
    						<details id="Details-filter.v.availability-template--15968257671257__product-grid" class="disclosure-has-popup facets__disclosure js-filter" data-index="1">
                    			<summary class="facets__summary caption-large focus-offset" aria-label="Availability (0 selected)" role="button" aria-expanded="false" aria-controls="Facet-1-template--15968257671257__product-grid">
	                      			<div>
	                        			<span class="facets__summary-label">Availability</span>
	                        				<svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
	  										<path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor"></path>
	  									</svg>
	                      			</div>
                    			</summary>

                    			<div id="Facet-1-template--15968257671257__product-grid" class="parent-display facets__display">
                    				<div class="facets__header">
                          				<div><span class="facets__selected">0 selected</span></div>
				                         	<facet-remove>
				                            	<a href="/collections/bags" class="facets__reset link underlined-link" role="button">Reset</a>
				                          	</facet-remove>
                        			</div>
									<fieldset class="facets-wrap parent-wrap ">
                        				<legend class="visually-hidden">Availability</legend>
                        					<ul class="facets-layout facets-layout-list facets-layout-list--text facets__list list-unstyled" role="list">
												<li class="list-menu__item facets__item">
													<label for="Filter-filter.v.availability-1" class="facets__label facet-checkbox">
                                  						<input type="checkbox" name="filter.v.availability" value="1" id="Filter-filter.v.availability-1"><svg width="1.6rem" height="1.6rem" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
                                      					<rect width="16" height="16" stroke="currentColor" fill="none" stroke-width="1"></rect></svg>

					                                    <svg aria-hidden="true" class="icon icon-checkmark" width="1.1rem" height="0.7rem" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg">
					                                      <path d="M1.5 3.5L2.83333 4.75L4.16667 6L9.5 1" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"></path>
					                                    </svg>
					                                    <span class="facet-checkbox__text" aria-hidden="true">
					                                		<span class="facet-checkbox__text-label">In stock</span> (25)
					                              		</span>
                              							<span class="visually-hidden">In stock (25 products)</span>
                                					</label>
                                				</li>
												<li class="list-menu__item facets__item">
													<label for="Filter-filter.v.availability-2" class="facets__label facet-checkbox">
                                  					<input type="checkbox" name="filter.v.availability" value="0" id="Filter-filter.v.availability-2"><svg width="1.6rem" height="1.6rem" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
                                      				<rect width="16" height="16" stroke="currentColor" fill="none" stroke-width="1"></rect></svg>

				                                    <svg aria-hidden="true" class="icon icon-checkmark" width="1.1rem" height="0.7rem" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 3.5L2.83333 4.75L4.16667 6L9.5 1" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                    				<span class="facet-checkbox__text" aria-hidden="true">
                                						<span class="facet-checkbox__text-label">Out of stock</span> (12)
                                					</span>
                              						<span class="visually-hidden">Out of stock (12 products)</span>
                                					</label>
                                				</li>
                                			</ul>
                      				</fieldset>
                    			</div>
                  			</details>
                
                  			<details id="Details-filter.v.price-template--15968257671257__product-grid" class="disclosure-has-popup facets__disclosure js-filter" data-index="2">
                    			<summary class="facets__summary caption-large focus-offset" role="button" aria-expanded="false" aria-controls="Facet-2-template--15968257671257__product-grid">
				                    <div>
				                        <span>Price</span><svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor"></path></svg>
				                    </div>
                    			</summary>
                    			<div id="Facet-2-template--15968257671257__product-grid" class="facets__display">
                      				<div class="facets__header">
                      					<span class="facets__selected">The highest price is $615.00</span>
                      					<facet-remove>
                      						<a href="/collections/bags" class="facets__reset link underlined-link" role="button">Reset</a>
                          				</facet-remove>
                          			</div>
                      				<price-range class="facets__price">
                        				<span class="field-currency">$</span>
										<div class="field">
										  <input class="field__input" name="filter.v.price.gte" id="Filter-Price-GTE" type="text" inputmode="decimal" placeholder="0" data-pattern="\d| |,|\." data-min="0" data-max="615.00">
										  <label class="field__label" for="Filter-Price-GTE">From</label>
										</div><span class="field-currency">$</span>
										<div class="field">
										  <input class="field__input" name="filter.v.price.lte" id="Filter-Price-LTE" type="text" inputmode="decimal" placeholder="615.00" data-pattern="\d| |,|\." data-min="0" data-max="615.00">
										  <label class="field__label" for="Filter-Price-LTE">To</label>
										</div>
                      				</price-range>
                    			</div>
                  			</details>
              			</div>

              			<div class="facet-filters sorting-category caption">
              				<div class="facet-filters__field">
				                <h2 class="facet-filters__label caption-large text-body">
				                  	<label for="SortBy">Shop by Category</label>
				                </h2>
				                <div class="select">
				                	<select name="sort_by" class="facet-filters__sort select__select caption-large" id="SortBy" aria-describedby="a11y-refresh-page-message">
					                  <option value="best-selling" selected="selected">Gelato Ingredients</option>
					                  <option value="title-ascending">Gelato Equipment</option>
                            <option value="title-ascending">Soft Serve Machines</option>
                            <option value="title-ascending">Gelato Showcases</option>
				                  </select>
				                  	<svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
									<path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
									</path></svg>
				                </div>
              				</div>
            			</div>
          
						      <div class="facet-filters sorting caption">
              				<div class="facet-filters__field">
				                <h2 class="facet-filters__label caption-large text-body">
				                  	<label for="SortBy">Sort by:</label>
				                </h2>
				                <div class="select">
				                	<select name="sort_by" class="facet-filters__sort select__select caption-large" id="SortBy" aria-describedby="a11y-refresh-page-message">
					                    <option value="best-selling" selected="selected">Best selling</option>
					                    <option value="title-ascending">Alphabetically, A-Z</option>
					                    <option value="title-descending">Alphabetically, Z-A</option>
					                    <option value="price-ascending">Price, low to high</option>
					                    <option value="price-descending">Price, high to low</option>
					                    <option value="created-ascending">Date, old to new</option>
					                    <option value="created-descending">Date, new to old</option>
				                  	</select>
				                  	<svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
									 <path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
									</path></svg>
				                </div>
              				</div>
            			</div>
			            <div class="product-count" role="status">
				            <h2 class="product-count__text text-body">
				              <span id="ProductCountDesktop">1-20 of 52 results</span>
				            </h2>

							<div class="loading__spinner hidden">
							  <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
							    <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
							  </svg>
							</div>
						</div>
					</form>
    		</facet-filters-form>


          <menu-drawer class="mobile-facets__wrapper medium-hide large-up-hide" data-breakpoint="mobile">
            <details class="mobile-facets__disclosure disclosure-has-popup">
              <summary class="mobile-facets__open-wrapper focus-offset">
                <span class="mobile-facets__open">
                  <svg class="icon icon-filter" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none"><path fill-rule="evenodd" d="M4.833 6.5a1.667 1.667 0 1 1 3.334 0 1.667 1.667 0 0 1-3.334 0ZM4.05 7H2.5a.5.5 0 0 1 0-1h1.55a2.5 2.5 0 0 1 4.9 0h8.55a.5.5 0 0 1 0 1H8.95a2.5 2.5 0 0 1-4.9 0Zm11.117 6.5a1.667 1.667 0 1 0-3.334 0 1.667 1.667 0 0 0 3.334 0ZM13.5 11a2.5 2.5 0 0 1 2.45 2h1.55a.5.5 0 0 1 0 1h-1.55a2.5 2.5 0 0 1-4.9 0H2.5a.5.5 0 0 1 0-1h8.55a2.5 2.5 0 0 1 2.45-2Z" fill="currentColor"></path>
                  </svg>

                    <span class="mobile-facets__open-label button-label medium-hide large-up-hide">Filter and sort</span>
                    <span class="mobile-facets__open-label button-label small-hide">Filter</span>
                </span>

                <span tabindex="0" class="mobile-facets__close">
                  <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-close" fill="none" viewBox="0 0 18 17"><path d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z" fill="currentColor"></path>
                  </svg>
                </span>
              </summary>

              <facet-filters-form>
                <form id="FacetFiltersFormMobile" class="mobile-facets">
                  <div class="mobile-facets__inner gradient">
                    <div class="mobile-facets__header">
                      <div class="mobile-facets__header-inner">
                        <h2 class="mobile-facets__heading medium-hide large-up-hide">Filter and sort</h2>
                        <h2 class="mobile-facets__heading small-hide">Filter</h2>
                        <p class="mobile-facets__count">1-20 of 52 results</p>
                      </div>
                    </div>
                      <div id="FacetsWrapperMobile" class="mobile-facets__main has-submenu gradient">
                        <details id="Details-Mobile-filter.v.availability-template--15968257671257__product-grid" class="mobile-facets__details js-filter" data-index="mobile-1">
                          <summary class="mobile-facets__summary focus-inset" role="button" aria-expanded="false" aria-controls="FacetMobile-1-template--15968257671257__product-grid">
                            <div>
                              <span>Availability</span>
                              <span class="mobile-facets__arrow"><svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false" class="icon icon-arrow" xmlns="http://www.w3.org/2000/svg">
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor">
                              </path></svg>
                              </span>
                            </div>
                          </summary>

                          <div id="FacetMobile-1-template--15968257671257__product-grid" class="mobile-facets__submenu gradient">
                            <button class="mobile-facets__close-button link link--text focus-inset" aria-expanded="true" type="button">
                              <svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false" class="icon icon-arrow" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor"></path></svg>

                              <span>Availability</span></button>
                              <ul class="facets-layout facets-layout-list facets-layout-list--text mobile-facets__list list-unstyled" role="list">
                                <li class="mobile-facets__item list-menu__item">
                                      <label for="Filter-filter.v.availability-mobile-1" class="facets__label mobile-facets__label">
                                        <input class="mobile-facets__checkbox" type="checkbox" name="filter.v.availability" value="1" id="Filter-filter.v.availability-mobile-1"><span class="mobile-facets__highlight"></span>

                                            <svg width="1.6rem" height="1.6rem" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
                                              <rect width="16" height="16" stroke="currentColor" fill="none" stroke-width="1"></rect>
                                            </svg>

                                            <svg aria-hidden="true" class="icon icon-checkmark" width="1.1rem" height="0.7rem" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                                              <path d="M1.5 3.5L2.83333 4.75L4.16667 6L9.5 1" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>

                                          <span class="facet-checkbox__text" aria-hidden="true"><span class="facet-checkbox__text-label">In stock</span> (25)</span>
                                          <span class="visually-hidden">In stock (25 products)</span>
                                      </label>
                                </li>

                                <li class="mobile-facets__item list-menu__item">
                                      <label for="Filter-filter.v.availability-mobile-2" class="facets__label mobile-facets__label">
                                        <input class="mobile-facets__checkbox" type="checkbox" name="filter.v.availability" value="0" id="Filter-filter.v.availability-mobile-2"><span class="mobile-facets__highlight"></span>

                                          <svg width="1.6rem" height="1.6rem" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
                                            <rect width="16" height="16" stroke="currentColor" fill="none" stroke-width="1"></rect>
                                          </svg>

                                          <svg aria-hidden="true" class="icon icon-checkmark" width="1.1rem" height="0.7rem" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1.5 3.5L2.83333 4.75L4.16667 6L9.5 1" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"></path>
                                          </svg>

                                        <span class="facet-checkbox__text" aria-hidden="true"><span class="facet-checkbox__text-label">Out of stock</span> (12)</span>
                                    <span class="visually-hidden">Out of stock (12 products)</span>
                                  </label>
                                </li>
                              </ul>

                            <div class="mobile-facets__footer gradient">
                              <facet-remove class="mobile-facets__clear-wrapper">
                                <a href="/collections/bags" class="mobile-facets__clear underlined-link" role="button">Clear</a>
                              </facet-remove>
                              <button type="button" class="button button--primary" onclick="this.closest('.mobile-facets__wrapper').querySelector('summary').click()">
                                Apply
                              </button>
                            </div>
                          </div>
                        </details>

                    
                        <details id="Details-Mobile-filter.v.price-template--15968257671257__product-grid" class="mobile-facets__details js-filter" data-index="mobile-2">
                          <summary class="mobile-facets__summary focus-inset" role="button" aria-expanded="false" aria-controls="FacetMobile-2-template--15968257671257__product-grid">
                            <div>
                              <span>Price</span>
                              <span class="mobile-facets__arrow"><svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false" class="icon icon-arrow" xmlns="http://www.w3.org/2000/svg">
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor"></path></svg></span>
                            </div>
                          </summary>

                          <div id="FacetMobile-2-template--15968257671257__product-grid" class="mobile-facets__submenu gradient">
                            <button class="mobile-facets__close-button link link--text focus-inset" aria-expanded="true" type="button">
                              <svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false" class="icon icon-arrow" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor"></path></svg>
                              Price
                            </button><p class="mobile-facets__info">The highest price is $615.00</p>

                            <price-range class="facets__price">
                              <span class="field-currency">$</span>
                                <div class="field">
                                  <input class="field__input" name="filter.v.price.gte" id="Mobile-Filter-Price-GTE" type="text" inputmode="decimal" placeholder="0" data-pattern="\d| |,|\." data-min="0" data-max="615.00">
                                  <label class="field__label" for="Mobile-Filter-Price-GTE">From</label>
                                </div><span class="field-currency">$</span><div class="field">
                                  <input class="field__input" name="filter.v.price.lte" id="Mobile-Filter-Price-LTE" type="text" inputmode="decimal" placeholder="615.00" data-pattern="\d| |,|\." data-min="0" data-max="615.00">
                                  <label class="field__label" for="Mobile-Filter-Price-LTE">To</label>
                                </div>

                            </price-range>
                            <div class="mobile-facets__footer">
                              <facet-remove class="mobile-facets__clear-wrapper">
                                <a href="/collections/bags" class="mobile-facets__clear underlined-link" role="button">Clear</a>
                              </facet-remove>
                              <button type="button" class="button button--primary" onclick="this.closest('.mobile-facets__wrapper').querySelector('summary').click()">
                                Apply
                              </button>
                            </div>
                          </div>
                        </details>
                    
                      
                        <div id="Details-Mobile-SortBy-template--15968257671257__product-grid" class="mobile-facets__details js-filter" data-index="mobile-">
                          <div class="mobile-facets__summary">
                            <div class="mobile-facets__sort">
                              <label for="SortBy-mobile">Sort by:</label>
                              <div class="select">
                                <select name="sort_by" class="select__select" id="SortBy-mobile" aria-describedby="a11y-refresh-page-message">
                                  <option value="manual" selected="selected">Featured</option>
                                    <option value="best-selling">Best selling</option>
                                    <option value="title-ascending">Alphabetically, A-Z</option>
                                    <option value="title-descending">Alphabetically, Z-A</option>
                                    <option value="price-ascending">Price, low to high</option>
                                    <option value="price-descending">Price, high to low</option>
                                    <option value="created-ascending">Date, old to new</option>
                                    <option value="created-descending">Date, new to old</option>
                                  </select>
                                <svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
                                </path></svg>

                              </div>
                            </div>
                          </div>
                      </div>

                      <div class="mobile-facets__footer">
                          <facet-remove class="mobile-facets__clear-wrapper">
                            <a href="/collections/bags" class="mobile-facets__clear underlined-link" role="button">Remove all</a>
                          </facet-remove>
                          <button type="button" class="button button--primary" onclick="this.closest('.mobile-facets__wrapper').querySelector('summary').click()">Apply</button>
                      </div>
                    </div>
                  </div>
                </form>
              </facet-filters-form>
            </details>
          </menu-drawer>

          <div class="active-facets active-facets-mobile medium-hide large-up-hide">
              <facet-remove class="active-facets__button-wrapper">
                  <a href="/collections/bags" class="active-facets__button-remove underlined-link" role="button">
                    <span>Remove all</span>
                  </a>
            </facet-remove>
          </div>
  
            <div class="product-count light medium-hide large-up-hide" role="status">
                <h2 class="product-count__text text-body"><span id="ProductCount">1-20 of 52 results</span></h2>

                <div class="loading__spinner hidden">
                    <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                        <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
                    </svg>
                </div>
            </div>
        </div>
            <!--  END FILTER -->





            <div class="product-grid-container scroll-trigger animate--slide-in" id="ProductGridContainer"
                data-cascade="">
                <div class="collection ">
                    <div class="loading-overlay gradient"></div>
	                    <ul id="product-grid" data-id=""
	                        class="grid product-grid grid--2-col-tablet-down grid--4-col-desktop">
	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/ananas-pineapple.png" alt="Ananas (Pineapple)"
	                                                    class="motion-reduce" width="297" height="297">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Ananas (Pineapple)</span>
	                                            	</a>
	                                            </h3>

	                                            <div class="card-info">
	                                               <!--  <div class="head-xs">Aromitalia</div> -->
	                                            </div>

	                                            <div class="card-information">
	                                                <span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $79.00 - $155.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular">



	                                                                </s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $79.00 - $155.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit"
	                                                    class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19"
	                                                        height="15">
	                                                    <span>Add to cart</span>

	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>
	                                            </div>
	                                        </div>
	                                        <div class="card__badge bottom left"></div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class=" card card--standard card--media ">
	                                    <div class="card__inner color-background-2 ratio">
	                                        <div class="card__badge bottom left">
	                                            <span class="badge badge--top-left">exclusive</span>
	                                        </div>

	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/watermelon.png" alt="watermelon"
	                                                    class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>

	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5"
	                                                id="title-template--15968257671257__product-grid-6920733229145">
	                                                <a href="#"
	                                                    id="CardLink-template--15968257671257__product-grid-6920733229145"
	                                                    class="full-unstyled-link">
	                                                   <span class="category-heading">Aromitalia</span>

	                                                   <span class="prod-heading">Anguria (Watermelon)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>


	                                            <div class="card-information">
	                                                <span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $79.00 - 155.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $79.00 - 155.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>
	                                                <button type="submit"
	                                                    class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19"
	                                                        height="15">
	                                                    <span>Add to cart</span>

	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>
	                                            </div>
	                                        </div>


	                                        <div class="card__badge bottom left"></div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper lightgray-gradient">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        <div class="card__badge bottom left">
	                                            <span class="badge badge--top-left onsale">New</span>
	                                        </div>
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">

	                                                <img src="assets/images/orange.png" sizes=""
	                                                    alt="Arancia (Orange)" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5"
	                                                id="title-template--15968257671257__product-grid-6920734441561">
	                                                <a href="#" class="full-unstyled-link">
	                                                    <span class="category-heading">Aromitalia</span>
	                                                    <span class="prod-heading">Arancia (Orange)</span>
	                                                </a>
	                                            </h3>


	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $79.00 - $155.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                From $79.00 - $155.00</span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>


	                                        <div class="card__badge bottom left"></div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper light-red-gradient">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">

	                                                <img src="assets/images/banana.png" sizes="" alt="Banana"
	                                                    class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Banana</span>
	                                                </a>
	                                            </h3>


	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $77.00 - $150.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular">



	                                                                </s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $77.00 - $150.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>


	                                        <div class="card__badge bottom left"></div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper yellow-gradient">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        <div class="card__badge bottom left">
	                                            <span class="badge badge--top-left onsale">New</span>
	                                        </div>
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/vegan-base.png" sizes="" alt="Base Vegan F (Vegan Base)"
	                                                    class="motion-reduce" width="290" height="296">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>

	                                                	<span class="prod-heading">Base Vegan F (Vegan Base)</span>
	                                                </a>
	                                            </h3>


	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $44.00 - $500.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $44.00 - $500.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>


	                                        <div class="card__badge bottom left"></div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/bubblegum-blue.png" sizes="" alt="Bubblegum Blue"
	                                                    class="motion-reduce" width="281" height="297">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Bubblegum Blue</span>
	                                                </a>
	                                            </h3>


	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $92.00 - 190.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $92.00 - 190.00</span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                	<img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>


	                                        <div class="card__badge bottom left"></div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/coffee.png" sizes="" alt="CAFFÈ (COFFEE)"
	                                                    class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Caffè (Coffee)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $145.00 - $285.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $145.00 - $285.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>
	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">

	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/caramel.png" sizes="" alt="Caramel"
	                                                    class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Caramel</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                             
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $78.00 - $150.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $78.00 - $150.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>
	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper ice-cold-gradient">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/white-chocolate.png" sizes="" alt="Cioccolato Bianco(White Chocolate)" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Cioccolato Bianco(White Chocolate)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                               
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $108.00 - $215.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $108.00 - $215.00</span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/classic-hazelnut.png" sizes="" alt="Classic Hazelnut"
	                                                    class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Classic Hazelnut</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $255.00 - $500.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $255.00 - $500.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>


	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/coconut.png" sizes="" alt="Cocco (Coconut)" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Cocco (Coconut)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $77.00 - $150.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $255.00 - $500.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>


	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/fruit-base-50.png" sizes="" alt="Dbf Master 50 Classic Tuttovegetale (Fruit Base 50)" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>

	                                                	<span class="prod-heading">Dbf Master 50 Classic Tuttovegetale (Fruit Base 50)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $62.00 - $475.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $62.00 - $475.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/milk-base-50.png" sizes="" alt="Milk Base 50" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Milk Base 50</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $58.00 - $455.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $58.00 - $455.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/milk-base-100.png" sizes="" alt="Dpo Super 100 C Classic Neutra Sgi # (Milk Base (100)" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>

	                                                	<span class="prod-heading">Dpo Super 100 C Classic Neutra Sgi # (Milk Base (100)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $60.00 - $465.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $60.00 - $465.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/strawberry.png" sizes="" alt="Fragola (Strawberry)" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>
	                                                	<span class="prod-heading">Fragola (Strawberry)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $84.00 - $165.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $84.00 - $165.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                        <li class="grid__item scroll-trigger animate--slide-in">
	                            <div class="card-wrapper product-card-wrapper">
	                                <div class="card card--standard card--media">
	                                    <div class="card__inner color-background-2 ratio">
	                                        
	                                        <div class="card__media">
	                                            <div class="media media--transparent media--hover-effect">
	                                                <img src="assets/images/with-seeds.png" sizes="" alt="French Vanilla (With Seeds)" class="motion-reduce" width="" height="">
	                                            </div>
	                                        </div>
	                                    </div>
	                                    <div class="card__content">
	                                        <div class="card__information">
	                                            <h3 class="card__heading h5">
	                                                <a href="#" class="full-unstyled-link">
	                                                	<span class="category-heading">Aromitalia</span>

	                                                	<span class="prod-heading">French Vanilla (With Seeds)</span>
	                                                </a>
	                                            </h3>

	                                            <div class="card-info">
	                                                
	                                            </div>

	                                            <div class="card-information"><span class="caption-large light"></span>
	                                                <div class="price ">
	                                                    <div class="price__container">
	                                                        <div class="price__regular"><span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span class="price-item price-item--regular">
	                                                                From $90.00 - $175.00
	                                                            </span>
	                                                        </div>
	                                                        <div class="price__sale">
	                                                            <span
	                                                                class="visually-hidden visually-hidden--inline">Regular
	                                                                price</span>
	                                                            <span>
	                                                                <s class="price-item price-item--regular"></s>
	                                                            </span><span
	                                                                class="visually-hidden visually-hidden--inline">Sale
	                                                                price</span>
	                                                            <span class="price-item price-item--sale price-item--last">
	                                                                From
	                                                                $90.00 - $175.00 </span>
	                                                        </div>
	                                                        <small class="unit-price caption hidden">
	                                                            <span class="visually-hidden">Unit price</span>
	                                                            <span class="price-item price-item--last">
	                                                                <span></span>
	                                                                <span aria-hidden="true">/</span>
	                                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
	                                                                <span>
	                                                                </span>
	                                                            </span>
	                                                        </small>
	                                                    </div>
	                                                </div>

	                                                <button type="submit" class="product-form__submit button button--full-width button--secondary">
	                                                    <img src="assets/images/white-cart.svg" alt="cart" title="" width="19" height="15">
	                                                    <span>Add to cart</span>
	                                                    <div class="loading__spinner hidden">
	                                                        <svg aria-hidden="true" focusable="false" class="spinner"
	                                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
	                                                            <circle class="path" fill="none" stroke-width="6" cx="33"
	                                                                cy="33" r="30"></circle>
	                                                        </svg>
	                                                    </div>
	                                                </button>

	                                            </div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </li>

	                    </ul>



	                    <div class="pagination-wrapper">
						    <nav class="pagination" role="navigation" aria-label="Pagination">
						      	<ul class="pagination__list list-unstyled" role="list">
						      		<li>
							            <a href="#" class="pagination__item pagination__item--next pagination__item-arrow link motion-reduce" aria-label="Previous page">
							              <svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor"></path></svg>
							            </a>
          							</li>
							      	<li>
							      		<a role="link" aria-disabled="true" class="pagination__item pagination__item--current" aria-current="page" aria-label="Page 1">1</a>
							      	</li>
							      	<li>
							      		<a href="#" class="pagination__item link" aria-label="Page 2">2</a>
							      	</li>
							      	<li>
							      		<a href="#" class="pagination__item link" aria-label="Page 3">3</a>
							      	</li>
							      	<li>
							      		<a href="/collections/bags?page=2" class="pagination__item pagination__item--prev pagination__item-arrow link motion-reduce" aria-label="Next page"><svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
							  				<path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor"></path></svg>
							  			</a>
							        </li>
						      	</ul>
						    </nav>
						</div>


                    </nav>
                </div>
            </div>
        </div>


        </div>
    </section>

  

    <?php block('proudlystocking-sec'); ?>  
    <?php block('newsletter'); ?>

</main>
<?php get_footer();