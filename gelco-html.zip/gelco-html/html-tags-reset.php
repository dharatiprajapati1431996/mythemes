<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>
<main class="inpg">

    <div class="container" style="max-width: 1170px;margin:0 auto;">
        <header>
            <nav>
                <ul>
                    <li>HEADER</li>
                    <li><a href="">home</a></li>
                </ul>

            </nav>
        </header>

        <!--  heading tags -->
        <h1> Heading... </h1>
        <h2> Heading... </h2>
        <h3> Heading... </h3>
        <h4> Heading... </h4>
        <h5> Heading... </h5>
        <h6> Heading... </h6>


        <!--  content  -->
        <p>This is dummy text, we use it at Supple during web designing in case we don't have content for new
            NON
            SEO
            pages and it is changed during development of the new site. Hence, don't worry about this dummy
            text. We
            use
            this dummy text to give you an idea how text on this page would look like as a site user.
        </p>
        <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nisi lacus, auctor sit amet purus
            vel, gravida luctus lectus. Aenean rhoncus dapibus enim, sit amet faucibus leo ornare vitae. <br>
            <span> span </span>
            <strong>strong</strong>
            <b>Bold word</b>
            <i>italic</i>
            <em>emphasis</em>
            <mark>mark</mark>
            <small> small </small>
            <sub> sub </sub>
            <sup> sup </sup>
            <u> Statements... </u>
            <abbr title="National Aeronautics and Space Administration">NASA</abbr>
            <strike> strikethrough </strike>
            <span><del> deprecated info </del> <ins> new info </ins> </span>
            <a href="#link">link</a>
        </p>

        <p> This is a <q>short quote</q> </p>
        <a href="">sgsdhfh</a>
        <br>
        <ul>
            <li>unorder List item</li>
            <li>unorder List item with a tag <a href="">sfkshfj</a> </li>
            <li>unorder List itemwidth span <span>sfkshfj</span> </li>
            <li>unorder List item with strong <strong>sfkshfj</strong> </li>
        </ul>
        <ol>

            <li>order List item</li>
            <li>order List item with a tag <a href="">sfkshfj</a> </li>
            <li>order List itemwidth span <span>sfkshfj</span> </li>
            <li>order List item with strong <strong>sfkshfj</strong> </li>
        </ol>

        <hr>

        <!-- list with a ,span, strong -->
        <ul>
            <li>List item
                <ul>
                    <li>nested list item</li>
                </ul>
            </li>
            <li>List item</li>
            <li>List item</li>

        </ul>
        <ol>
            <li>List item
                <ol>
                    <li>nested list item</li>
                </ol>
            </li>
            <li>List item</li>
            <li>List item</li>

        </ol>
        <aside>
            <p> P inside ASIDE tag </p>
        </aside>

        <img src="https://placehold.it/100x100" alt="placeholder-image"><br>
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d278772.8187830562!2d72.41493336470985!3d23.020474097405575!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e848aba5bd449%3A0x4fcedd11614f6516!2sAhmedabad%2C%20Gujarat!5e1!3m2!1sen!2sin!4v1722918927742!5m2!1sen!2sin"
            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe><br>


        <video width="640" height="480"
            src="https://archive.org/download/Popeye_forPresident/Popeye_forPresident_512kb.mp4" controls>
            <track kind="subtitles" src="subtitles_de.vtt" srclang="de">
            <track kind="subtitles" src="subtitles_en.vtt" srclang="en">
            <track kind="subtitles" src="subtitles_ja.vtt" srclang="ja">
            Sorry, your browser doesn't support HTML5 <code>video</code>, but you can
            download this video from the <a href="https://archive.org/details/Popeye_forPresident"
                target="_blank">Internet Archive</a>.
        </video>
        <dl>
            <dt>Coffee</dt>
            <dd>Black hot drink</dd>
            <dt>Milk</dt>
            <dd>White cold drink</dd>
        </dl>
        <!--  -->
        <h2>form tags </h2>

        <form>
            <input type="text" placeholder="enter name">
            <input type="number" placeholder="number">
            <input type="email" placeholder="email">
            <input type="tel" placeholder="phone no.">
            <input type="file" placeholder="upload file">
            <textarea placeholder="address"></textarea>
            <select>
                <option value="0">1</option>
                <option value="1">2</option>
                <option value="0">3</option>
            </select>
            <input type="search" value="search here"><br>

            <input type="radio" id="html" name="fav_language" value="HTML">
            <label for="html">HTML</label><br><br><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
            <label for="vehicle1"> I have a bike</label><br>
            <input type="submit" value="submit">
            <input type="reset">
            <button type="submit">read more </button>
            <fieldset>
                <legend>Personal Information</legend>
                <label for="name">Name</label><br>
                <input name="name" id="name"><br>
                <label for="dob">Date of Birth<label><br>
                        <input name="dob" id="dob" type="date">
            </fieldset>
        </form>



        <table>
            <tr>
                <th>fdsfdsf</th>
                <th>fdsfdsf</th>
                <th>fdsfdsf</th>
            </tr>
            <tr>
                <td>fdsfdsf</td>
                <td>fdsfdsf</td>
                <td>fdsfdsf</td>
            </tr>
        </table>
        <hr>
        <footer>
            <address> relevant contacts <a href=" mailto:mail@example.com">mail</a>.</address>
            <div> created by <a href="https://blazardsky.space">supple</a></div>
        </footer>
    </div>
</main>