<section class="pickupdeliverysupport_sec mrgb80">
    <div class="page-width">
        <div class="picdelsup_container">
            <p><img src="assets/images/pickup-icon.svg" alt="" width="56" height="56">Pick-up</p>
            <p><img src="assets/images/delivery-icon.svg" alt="" width="56" height="56">Delivery</p>
            <p><img src="assets/images/support-icon.svg" alt="" width="56" height="56">Support</p>
        </div>
    </div>
</section>