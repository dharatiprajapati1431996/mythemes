    <div class="why-sec mb-120">
        <div class="container">
            <div class="heading-50 text-center">WhY CHOOSE EAST2WEST FITNESS FOR PERSONAL TRAINING?</div>

            <div class="whychoose-wrap">
                <div class="whychoose-left">
                    <div class="whychoose-ul">
                        <div class="whychoose-li">
                            <img src="assets/images/icon/fitnessplan-icon.svg" alt="fitnessplan-icon" title="" width="92"
                                height="70">
                            <div class="whychs-title">Customised fitness plans in place to meet your personal goals
                            </div>
                        </div>
                        <div class="whychoose-li">
                            <img src="assets/images/icon/fitness-training-icon.svg" alt="fitnessplan-icon" title=""
                                width="92" height="70">
                            <div class="whychs-title">One-on-one sessions assuring focused training and constant
                                feedback</div>
                        </div>
                        <div class="whychoose-li">
                            <img src="assets/images/icon/trainer-icon.svg" alt="fitnessplan-icon" title=""  width="92" height="70">
                            <div class="whychs-title">Tailored exercise programs suiting individual needs</div>
                        </div>
                    </div>
                </div>
                <div class="whychoose-center">
                    <img src="assets/images/trainer-image.png" alt="trainer image" width="533" height="684">
                    <div class="large-text">EAST2WEST FITNESS FOR PERSONAL TRAINING?</div>
                </div>
                <div class="whychoose-right">
                    <div class="whychoose-ul">
                        <div class="whychoose-li">
                            <img src="assets/images/icon/committed-icon.svg" alt="fitnessplan-icon" title="" width="92" height="70">
                            <div class="whychs-title">Committed to your transformation with continuous support and
                                encouragement</div>
                        </div>
                        <div class="whychoose-li">
                            <img src="assets/images/icon/ringwood-location-icon.svg" alt="fitnessplan-icon" title=""
                                width="92" height="70">
                            <div class="whychs-title">Located close to Ringwood train station: Perfect for
                                Lilydale/Belgrave line commuters</div>
                        </div>
                        <div class="whychoose-li">
                            <img src="assets/images/icon/hand-icon.svg" alt="fitnessplan-icon" title="" width="92" height="70">
                            <div class="whychs-title">Our studio provides a supportive,inclusive space for
                                camaraderie, encouragement, & lasting friendships.</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cta-bg content-cta-wrap">
                <div class="content-cta">Jumpstart your personal fitness journey with us. We are ready to celebrate
                    every triumph with you. Call us today at <a href="tel:0423175087">0423 175 087</a> to schedule your
                    consultation for quality personal training in Ringwood.</div>
            </div>
        </div>
    </div>