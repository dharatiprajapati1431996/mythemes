<section class="waveeffect_sec inverted" style="">
    <div class="wavecontainer" dir="rtl" style="">
        <div class="wave_sliderreverse regular slider">
            <div class=""><img src="assets/images/wave-effect.svg" alt="" width="2480" height="9" title=""></div>
            <div class=""><img src="assets/images/wave-effect.svg" alt="" width="2480" height="9" title=""></div>
            <div class=""><img src="assets/images/wave-effect.svg" alt="" width="2480" height="9" title=""></div>
        </div>
    </div>
</section>
<section class="newsletter_sec">
    <div class="page-width">
        <div class="newsletterleft">
            <div class="newslettertxt">Newsletter Signup<span>Get 10% Off Your First Order</span></div>
            <div class="newsletterform">
                <form action="" class="form-fields">
                    <input type="email" class="form-control" name="EMAIL" placeholder="ENTER EMAIL" required="">
                    <input type="submit" class="btn_subscribe btn_white" value="Submit">
                </form>
            </div>
        </div>
        <div class="sociallink_right">
            <p>Stay up to date:</p>
            <ul>
                <li class="fblink"><a href=""><img src="assets/images/fb-footer.svg" alt="" width="" height=""
                            title=""></a></li>
                <li class="instalink"><a href=""><img src="assets/images/insta-footer.svg" alt="" width="" height=""
                            title=""></a></li>
            </ul>
        </div>
    </div>
</section>