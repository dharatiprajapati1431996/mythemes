<section class="proudlystocking_sec">
    <div class="page-width">
        <div class="heading-24"><span>Proudly Stocking</span></div>
        <div class="logoslider">
            <div class="logobx"><img src="assets/images/aromitalia-logo.jpg" alt="aromitalia" width="220" height="75">
            </div>
            <div class="logobx"><img src="assets/images/staf-59-logo.jpg" alt="staf-59" width="220" height="75"></div>
            <div class="logobx"><img src="assets/images/robo-cream-logo.jpg" alt="robo-cream" width="220" height="75">
            </div>
            <div class="logobx"><img src="assets/images/innova-logo.jpg" alt="innova" width="220" height="75"></div>
            <div class="logobx"><img src="assets/images/mondialframec-logo.jpg" alt="mondialframec" width="220"
                    height="75"></div>
            <div class="logobx"><img src="assets/images/staf-59-logo.jpg" alt="staf-59" width="220" height="75"></div>
            <div class="logobx"><img src="assets/images/robo-cream-logo.jpg" alt="robo-cream" width="220" height="75">
            </div>
        </div>
    </div>
</section>