<!-- HOME BANNER -->
<section id="featureslider" class="mrgb80">
    <div class="page-width">
        <div class="featuresliderdiv">
            <div class="featurebx">
                <p><img src="assets/images/signup-get-15-percent-off.svg" class="" width="28" height="25"
                        alt="Sign Up & Get 15% Off">Sign Up & Get 15% Off</p>
            </div>
            <div class="featurebx">
                <p><img src="assets/images/free-shipping.svg" class="" width="28" height="25"
                        alt="Free Shipping Over $90">Free Shipping Over $90</p>
            </div>
            <div class="featurebx">
                <p><img src="assets/images/next-day-dispatch.svg" class="" width="28" height="25"
                        alt="Next Day Dispatch">Next Day Dispatch</p>
            </div>
            <div class="featurebx">
                <p><img src="assets/images/feshness-guaranteed.svg" class="" width="28" height="25"
                        alt="Freshness Guaranteed">Freshness Guaranteeds</p>
            </div>
        </div>
    </div>
</section>