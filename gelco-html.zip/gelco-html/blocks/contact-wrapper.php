 <div class="flex-container wrap mrgb80">
                <div class="ctact-left">
                    <div class="heading-40">General enquiries</div>
                    <p>Just Planet Roastery & Espresso Bar</p>


                    <div class="ft_contactinfo">
                        <dl>
                            <dt><span><img src="assets/images/location-footer.svg" alt="" width="18" height="18"></span></dt>
                            <dd>37 Oshanassy St, Sunbury, VIC 3429</dd>
                        </dl>
                        <dl>
                            <dt><span><img src="assets/images/phone-footer.svg" alt="" width="18" height="18"></span></dt>
                            <dd><a href="tel:0455 249 383">0455 249 383</a></dd>
                        </dl>
                        <dl>
                            <dt><span><img src="assets/images/clock-footer.svg" alt="" width="18" height="18"></span></dt>
                            <dd>
                                <p>Monday - Friday, 7:30am–2pm</p>
                                <p>Saturday, 8am-1pm</p>
                                <p>Sunday, 8.30am–1pm</p>
                            </dd>
                        </dl>
                        <dl>
                            <dt></dt>
                            <dd>
                                <div class="ftsociallinks">
                                    <a href="" class="ft_fblink"><img src="assets/images/fb-footer.svg" alt="" width="38" height="38"></a>
                                    <a href="" class="ft_insta"><img src="assets/images/insta-footer.svg" alt="" width="38" height="38"></a>
                                </div>
                            </dd>
                        </dl>
                    </div>


                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3161.9130367115545!2d144.72806427670022!3d-37.58066542075357!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad6f9b7644c4e41%3A0x14db9821ab54b34a!2s37%20Oshanassy%20St%2C%20Sunbury%20VIC%203429%2C%20Australia!5e0!3m2!1sen!2sin!4v1728470949349!5m2!1sen!2sin" width="100%" height="358" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>

                </div>
                <div class="ctact-right">
                    <div class="form-wrap">
                        <div class="heading-40">Send us a message</div>
                        <form action="" class="form-wrapper">
                            <div class="form-group">
                                <label for="name">Name*</label>
                                <input type="text" class="form-control" placeholder="Enter your name">
                            </div>
                            
                            <div class="row">
                                <div class="form-group width50">
                                    <label for="email">Email*</label>
                                    <input type="email" class="form-control" placeholder="Enter your Email">
                                </div>
                                <div class="form-group width50">
                                    <label for="phone">Phone*</label>
                                    <input type="text" class="form-control" placeholder="Enter your number">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="phone">What type of enquiry would you like to make?*</label>
                                <select name="cars" id="enquiry-type" class="form-control">
                                    <option value="">Select enquiry type</option>
                                    <option value=""></option>
                                    <option value=""></option>
                                    <option value=""></option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea name="" id="" rows="5" cols="5" placeholder="Enter your message"></textarea>
                            </div>
                            <div class="submit-block">
                                <div class="submit-btn">
                                    <input type="submit" value="submit your enquiry">
                                </div>
                            </div>
                        </form>

                        <img src="assets/images/vertical-wave.svg" alt="" title="" width="" height="" class="vertical-wave">

                    </div>
                </div>
            </div>