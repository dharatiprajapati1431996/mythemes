<!-- HOME BANNER -->
<section id="banner">
	<div class="homebannerslider regular slider">
		<div class="slidediv">
			<img src="assets/images/banner-bg.png" alt="" width="1745" height="740" class="desktop_bg">

			<div class="bnrcontent">
				<div class="bannerleft">
					<div class="bannertxt whitetxt">
						<img src="assets/images/pinklines.svg" alt="" width="54" height="54" class="heartbeat">Start
						Your Gelato Business with Australia’s Leading Suppliers
					</div>
					<div class="button-group">
						<a href="" class="button buttonpink" onclick="">Shop Now</a>
						<a href="" class="button buttonblack" onclick="">Get a Free Consultation</a>
					</div>
				</div>
				<div class="bannerright">
					<img src="assets/images/banner-equpments-img.png" alt="" width="656" height="559"
						class="bannerequipment">
				</div>

			</div>
		</div>

		<div class="slidediv">
			<img src="assets/images/banner-bg.png" alt="" width="1745" height="740" class="desktop_bg">

			<div class="bnrcontent">
				<div class="bannerleft">
					<div class="bannertxt whitetxt">
						<img src="assets/images/pinklines.svg" alt="" width="54" height="54" class="heartbeat">Slide two
						text will be here
					</div>
					<div class="button-group">
						<a href="product-listing.php" class="button buttonpink" onclick="">Shop Now</a>
						<a href="" class="button buttonblack" onclick="">Get a Free Consultation</a>
					</div>
				</div>
				<div class="bannerright">
					<img src="assets/images/banner-equpments-img.png" alt="" width="656" height="559"
						class="bannerequipment">
				</div>

			</div>
		</div>

	</div>
</section>