<?php require_once __DIR__ . '/includes/includes.php'; ?>
<?php get_header(); ?>


<main class="contact-page">
    <div class="overlay" style=""></div>

    <section class="inner-banner">
        <div class="page-width">
            <ul class="woo_breadcums">
                <li>
                    <span>
                        <span>
                            <a href="#">Home</a>
                            <span class="breadcrumb_last" aria-current="page">Contact</span>
                        </span>
                    </span>
                </li>
            </ul>
        </div>
    </section>


    <!-- our partners section start -->

    <section class="inpg">
        <div class="page-width">
            <div class="flex-container wrap">
                <div class="ctact-left">
                    <div class="heading-48">Contact</div>

                    <ul class="contact-list">
                        <li>
                            <div class="cont-box">
                                <div class="cont-icon">
                                    <img src="assets/images/email.svg" alt="email" title="" width="15" height="11">
                                </div>
                                <div class="cont-info">
                                    <label>Email</label>
                                    <a href="mailto:sales@gelco.com.au">sales@gelco.com.au</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="cont-box">
                                <div class="cont-icon">
                                    <img src="assets/images/call.svg" alt="call" title="" width="14" height="14">
                                </div>
                                <div class="cont-info">
                                    <label>Phone</label>
                                    <a href="tel:0424 667 322">0424 667 322</a>
                                </div>
                            </div>
                        </li>
                    </ul>


                    <div class="sociallink_right">
                        <p>Stay up to date:</p>
                        <ul>
                            <li class="fblink"><a href=""><img src="assets/images/fb-footer.svg" alt="" width="38" height="38" title=""></a></li>
                            <li class="instalink"><a href=""><img src="assets/images/insta-footer.svg" alt="" width="38" height="38" title=""></a></li>
                        </ul>
                    </div>


                    <div class="machine-img">
                        <img src="assets/images/ice-cream-machine.png" alt="ice cream machine" title="" width="" height="">
                    </div>

                    
                </div>
                <div class="ctact-right">
                    <div class="get-in-touch">
                        <div class="heading-48">Get in touch!</div>
                        <form class="form_box">
                            <div class="row">
                                <div class="form-group width50">
                                    <input class="form-control" type="text" name="name" placeholder="Name*">
                                </div>
                                <div class="form-group width50">
                                    <input class="form-control" type="text" name="phone" placeholder="Last Name*">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group width100">
                                    <input class="form-control" type="text" name="email" placeholder="Company*">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group width50">
                                    <input class="form-control" type="Number" name="name" placeholder="Phone Number*">
                                </div>
                                <div class="form-group width50">
                                    <input class="form-control" type="email" name="phone" placeholder="Email*">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group message_area width100">
                                    <textarea class="form-control" placeholder="Message" name="your-message"></textarea>
                                </div>
                            </div>
                           
                            <div class="reCapta-txt-wrap">
                                <!-- <div class="reCapta-txt">
                                    <p>This site is protected by reCAPTCHA and the Google <a href="#">Privacy Policy</a> and <a href="#">Terms of Service</a> apply.</p>
                                </div> -->
                                <div class="submit_btn">
                                    <input type="submit" name="" value="send" class="btnsubmit">
                                </div>
                            </div>
                           
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- scrolling text section start -->
    <section class="scrollingtxt mrgb80">
        <div class="txtslide"><img src="assets/images/first-text.svg" alt="" width="1358" height="175" title=""></div>
        <div class="txtslide"><img src="assets/images/second-text.svg" alt="" width="960" height="165" title=""></div>
    </section>
    <!-- scrolling text section end -->


    <?php block('proudlystocking-sec'); ?>  
    <?php block('newsletter'); ?>

</main>
<?php get_footer();