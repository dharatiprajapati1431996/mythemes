<footer>
    <div class="footermain">
        <div class="page-width">
            <div class="ft_left ftlogo"><img src="assets/images/logo-footer.svg" alt="" width="161" height="144"
                    title="">
            </div>
            <div class="ft_right_links">
                <div class="widt25 ft_getintouch">
                    <div class="fttitle">Get in Touch</div>
                    <ul>
                        <li><a href="mailto:sales@gelco.com.au"><img src="assets/images/email-icon.svg" alt=""
                                    width="18" height="16" title="">sales@gelco.com.au</a></li>
                        <li><a href="tel:0424 667 322"><img src="assets/images/phone-icon.svg" alt="" width="18"
                                    height="16" title="">0424 667 322</a></li>
                    </ul>
                </div>
                <div class="widt25 quicklinks footerlinks">
                    <div class="fttitle">Quick Links</div>
                    <ul>
                        <li><a href="">Home</a></li>
                        <li><a href="">Gelato Ingredients</a></li>
                        <li><a href="">Equipment</a></li>
                        <li><a href="">Gelato Showcases</a></li>
                        <li><a href="">Clearance</a></li>
                        <li><a href="courses.php">Courses</a></li>
                    </ul>
                </div>
                <div class="widt25 footerlinks">
                    <div class="fttitle">Support</div>
                    <ul>
                        <li><a href="">Search</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="widt25 ft_paymentopt">
                    <div class="fttitle">Payment Options</div>
                    <p><img src="assets/images/payment-option.png" alt="" width="206" height="68" title=""></p>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="page-width">
            <p>Copyright © 2024 Gelco. <span>All Rights Reserved.</span></p>
        </div>
    </div>

    <button class="scrollTop" href="#top" style="opacity: 1;"><i class="fa fa-angle-up"></i></button>
</footer>

<?php wp_footer(); ?>
</body>

</html>